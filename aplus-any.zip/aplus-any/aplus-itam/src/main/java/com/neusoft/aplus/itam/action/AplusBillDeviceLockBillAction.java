package com.neusoft.aplus.itam.action;

import java.util.Map;
import org.restlet.representation.Representation;
import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.service.bo.IAplusBillDeviceService;

/**
 * @ClassName: AplusBillDeviceLockBillAction 
 * @Description: 锁定工单
 * @author lu.z
 * @date 2015年4月23日 下午5:45:36
 */
public class AplusBillDeviceLockBillAction extends BaseAction{
	
	private IAplusBillDeviceService aplusBillDeviceService;
	
	@Override
	public void doInit() {
		aplusBillDeviceService = ApplicationContextFactory.getBean(IAplusBillDeviceService.class);
	}

	@Override
	public void acceptRepresentation(Representation entity) {
	}

	@Override
	public Representation represent() {
		
		return null;
	}

	@Override
	public void removeRepresentations() {
		
	}

	@Override
	public void storeRepresentation(Representation entity) {
		Map<String, String> paramsMap = null;
		try {
			paramsMap = getObjectsFromRepresentation(entity, new TypeReference<Map<String, String>>() {});
			if(paramsMap != null && !paramsMap.isEmpty()){
				String uuids = (String) paramsMap.get("uuids");
				aplusBillDeviceService.lockBillDevice(uuids);
			}
			sendSuccess();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}

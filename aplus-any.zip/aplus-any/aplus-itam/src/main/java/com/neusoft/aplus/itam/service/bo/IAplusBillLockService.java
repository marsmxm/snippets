package com.neusoft.aplus.itam.service.bo;

import java.util.List;

public interface IAplusBillLockService {
	/**
	 * @Description: 设备添加工单锁
	 * @author zhangyun
	 * @date 2015-4-14 下午4:55:23
	 * @param @param devFqn
	 * @param @param billType
	 * @param @param billUuid
	 * @return void
	 * @throws
	 */
	public void saveOrUpdateAplusBillLock(List<String> devFqn, String billUuid);
	/**
	 * @Description: 删除工单锁中设备
	 * @author zhangyun
	 * @date 2015-4-15 下午2:04:43 
	 * @param @param devFqn
	 * @return void
	 * @throws
	 */
	public void deleteAplusBillLockBydevFqns(List<String> devFqn);
	
	
}
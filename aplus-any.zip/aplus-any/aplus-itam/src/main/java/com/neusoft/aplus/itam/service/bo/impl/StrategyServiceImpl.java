package com.neusoft.aplus.itam.service.bo.impl;

import java.text.NumberFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.neusoft.aplus.itam.constant.Constant;
import com.neusoft.aplus.itam.model.dbentity.table.StrategyEntify;
import com.neusoft.aplus.itam.model.dbentity.table.StrategyOrgEntify;
import com.neusoft.aplus.itam.service.bo.IStrategyService;
import com.neusoft.aplus.itam.service.dao.IStrategyDao;
import com.neusoft.aplus.itam.service.dao.IStrategyOrgDao;
import com.neusoft.aplus.model.dbentity.Page;

/**
 * @ClassName: StrategyServiceImpl 
 * @Description: 权限策略实现类
 * @author lu.z
 * @date 2015年5月21日 下午4:52:00
 */
@Component
public class StrategyServiceImpl implements IStrategyService{
	private static Logger logger = LoggerFactory.getLogger(StrategyServiceImpl.class);
			
	@Autowired
	private IStrategyDao strategyDao;
	
	@Autowired
	private IStrategyOrgDao strategyOrgDao;
	
	@Override
	@Transactional
	public void saveStrategy(StrategyEntify strategyEntify, List<StrategyOrgEntify> strategyOrgEntifys) {
		//保存策略信息
		strategyDao.saveStrategy(strategyEntify);
		//保存策略组织信息
		strategyOrgDao.saveStrategyOrgs(strategyOrgEntifys);
	}

	@Override
	@Transactional
	public void updateStrategy(StrategyEntify strategyEntify, List<StrategyOrgEntify> strategyOrgEntifys) {
		//修改策略信息
		strategyDao.updateStrategy(strategyEntify);
		//删除所有策略信息
		strategyOrgDao.removeStrategyOrgsByStrategyId(strategyEntify.getUuid());
		//保存策略权限信息
		strategyOrgDao.saveStrategyOrgs(strategyOrgEntifys);
	}

	@Override
	@Transactional
	public void removeStrategys(List<String> ids) {
		//删除策略信息
		strategyDao.removeStrategys(ids);
		//删除策略组织信息
		strategyOrgDao.removeStrategyOrgs(ids);
	}

	@Override
	@Transactional
	public Map<String, Object> findStrategyByConditions(Map<String, String> paramsMap) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<Criterion> criterions = Lists.newArrayList();
		Iterator<String> iter = paramsMap.keySet().iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			String value = paramsMap.get(key);
			if (StringUtils.equals(key, Constant.PAGE) || StringUtils.equals(key, Constant.PAGE_COUNT)
					|| StringUtils.isBlank(value)) {
				continue;
			}
			if(StringUtils.equals(key, "name")){
				criterions.add(Restrictions.like(key, value));
			} else{
				criterions.add(Restrictions.eq(key, value));
			}
		}

		String pageString = paramsMap.get(Constant.PAGE);
		String pageCountString = paramsMap.get(Constant.PAGE_COUNT);
		NumberFormat numberFormat = NumberFormat.getInstance();

		Integer page = Constant.DEFAULT_PAGE;
		Integer pageCount = Constant.DEFAULT_PAGE_COUNT;
		try {
			page = numberFormat.parse(pageString).intValue();
			pageCount = numberFormat.parse(pageCountString).intValue();
		} catch (Exception e) {
			logger.error("Error page parameter format, page: {}, pageCount: {}", pageString, pageCountString);
		}
		
		Page<StrategyEntify> pageList = strategyDao.findStrategyByConditions(page, pageCount, criterions);
		List<StrategyEntify> strategyEntifys = pageList.getItemList();

		resultMap.put("rows", strategyEntifys);
		resultMap.put("total", pageList.getTotalSize());

		return resultMap;
	}

	@Override
	@Transactional
	public StrategyEntify findStrategyById(String uuid) {
		return strategyDao.findStrategyById(uuid);
	}

	@Override
	@Transactional
	public List<String> findOrgList(String modelId, String orgId) {
		List<String> list = null;
		//查询策略信息
		StrategyEntify strategyEntify = strategyDao.findStrategyByModelId(modelId);
		if(strategyEntify != null){
			//查询数据权限组织信息
			String strategyId = strategyEntify.getUuid();
			StrategyOrgEntify strategyOrgEntify = strategyOrgDao.findStrategyOrgByOrgId(strategyId, orgId);
			if(strategyOrgEntify != null){
				String strategyOrg = strategyOrgEntify.getStrategyOrg(); 
				if(strategyOrg != null && !"".equals(strategyOrg)){
					String strategyOrgs[] = strategyOrg.split(",");
					list = Arrays.asList(strategyOrgs);
				}
			}
		}
		return list;
	}

	@Override
	@Transactional
	public boolean isExistModel(String modelId) {
		StrategyEntify strategyEntify = strategyDao.findStrategyByModelId(modelId);
		if(strategyEntify != null){
			return true;
		}
		return false;
	}
}

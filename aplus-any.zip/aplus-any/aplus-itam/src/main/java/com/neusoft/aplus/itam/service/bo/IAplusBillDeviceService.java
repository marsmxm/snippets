package com.neusoft.aplus.itam.service.bo;

import java.util.List;
import java.util.Map;

import com.neusoft.aplus.itam.model.dbentity.table.AplusBillDeviceEntity;
import com.neusoft.aplus.model.dbentity.Page;

public interface IAplusBillDeviceService {
	/**
	 * @Description: 保存工单设备
	 * @author zhangyun
	 * @date 2015-4-13 上午11:30:49
	 * @param @param Fqns
	 * @param @param bill_uuid
	 * @param @param bill_no
	 * @return void
	 * @throws
	 */
	public void saveAplusBillDevice(List<String> Fqns, String bill_uuid,
			String bill_no);

	/**
	 * @Description: 删除工单设备
	 * @author zhangyun
	 * @date 2015-4-13 上午11:30:49
	 * @param @param Fqns
	 * @param @param bill_uuid
	 * @param @param bill_no
	 * @return void
	 * @throws
	 */
	public void deleteAplusBillDevice(String uuids,String billUuid);

	/**
	 * @Description: 批量修改工单设备
	 * @author zhangyun
	 * @date 2015-4-13 上午11:30:49
	 * @param @param Fqns
	 * @param @param bill_uuid
	 * @param @param bill_no
	 * @return void
	 * @throws
	 */
	public void batchUpdateAplusBillDevice(
			Map<String, Map<String, String>> map, String billUuid);

	/**
	 * @Description: 根据工单UUID 查询工单下设备
	 * @author zhangyun
	 * @date 2015-4-13 下午2:45:23
	 * @param @param bill_uuid
	 * @param @return
	 * @return List<AplusBillDeviceEntity>
	 * @throws
	 */
	public Page<AplusBillDeviceEntity> findAplusDeviceByBillUuid(Integer page,
			Integer pageCount,String billUuid);

	/**
	 * @Description: 锁定工单设备
	 * @author zhangyun
	 * @date 2015-4-14 上午10:43:02
	 * @param @param uuids
	 * @return void
	 * @throws
	 */
	public void lockBillDevice(String uuids);

}

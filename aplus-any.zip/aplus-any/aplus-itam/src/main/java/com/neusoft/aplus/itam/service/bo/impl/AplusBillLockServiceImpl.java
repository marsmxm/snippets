package com.neusoft.aplus.itam.service.bo.impl;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.neusoft.aplus.itam.constant.BillDeviceLock;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillEntity;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillLockEntity;
import com.neusoft.aplus.itam.service.bo.IAplusBillLockService;
import com.neusoft.aplus.itam.service.dao.IAplusBillDao;
import com.neusoft.aplus.itam.service.dao.IAplusBillLockDao;

@Component
public class AplusBillLockServiceImpl implements IAplusBillLockService {
	@Autowired
	private IAplusBillLockDao billLockDao;
	@Autowired
	private IAplusBillDao billDao;

	@Transactional
	@Override
	public void saveOrUpdateAplusBillLock(List<String> devFqn, String billUuid) {
		List<AplusBillLockEntity> entitylist = new LinkedList<AplusBillLockEntity>();
		AplusBillEntity billEntity = new AplusBillEntity();
		billEntity = billDao.findBillByUuid(billUuid);
		for (int i = 0; i < devFqn.size(); i++) {
			AplusBillLockEntity entity = new AplusBillLockEntity();
			entity.setBillType(billEntity.getBillType());
			entity.setBillUuid(billUuid);
			entity.setDevFqn(devFqn.get(i));
			entity.setBillLockType(BillDeviceLock.EXCLUSIVE.name());
			entitylist.add(entity);
		}
		billLockDao.saveOrUpdateAplusBillLock(entitylist);
	}

	@Transactional
	@Override
	public void deleteAplusBillLockBydevFqns(List<String> Fqns) {
		billLockDao.deleteAplusBillLockBydevFqns(Fqns);
	}

}

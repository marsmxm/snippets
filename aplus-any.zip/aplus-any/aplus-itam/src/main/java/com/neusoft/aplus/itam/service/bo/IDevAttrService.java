package com.neusoft.aplus.itam.service.bo;



/**
 * @ClassName: IDevAttrService 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-28 上午10:20:01
 */
public interface IDevAttrService {
	/**
	 * @Description: 加载devtype.xml中的属性
	 * @author jin.ysh
	 * @date 2015-4-28 上午10:20:34 
	 * @param 
	 * @return void
	 * @throws
	 */
	public void loadDevAttr();
}

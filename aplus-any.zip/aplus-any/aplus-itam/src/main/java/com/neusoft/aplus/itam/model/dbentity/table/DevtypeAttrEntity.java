package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;

/**
 * @ClassName: DevtypeAttrEntity 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-27 下午7:35:30
 */
public class DevtypeAttrEntity implements Serializable, Cloneable {

	private static final long serialVersionUID = 1L;
	private String devtypeName;
	private String devtypeId;
	private String attr;
	public String getDevtypeName() {
		return devtypeName;
	}
	public void setDevtypeName(String devtypeName) {
		this.devtypeName = devtypeName;
	}
	public String getDevtypeId() {
		return devtypeId;
	}
	public void setDevtypeId(String devtypeId) {
		this.devtypeId = devtypeId;
	}
	public String getAttr() {
		return attr;
	}
	public void setAttr(String attr) {
		this.attr = attr;
	}
	
}

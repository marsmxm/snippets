package com.neusoft.aplus.itam.handler.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.neusoft.aplus.itam.handler.IAplusBillNo;
import com.neusoft.aplus.itam.service.bo.IAplusBillService;


public class AplusBillNoImpl implements IAplusBillNo {

	@Autowired
	private IAplusBillService aplusBillService;
	
	@Override
	public String generationBillNo(String billType) {
		return aplusBillService.generateNo(billType);
	}
	
}

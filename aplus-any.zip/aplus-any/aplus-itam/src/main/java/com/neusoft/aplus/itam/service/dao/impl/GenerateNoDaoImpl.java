package com.neusoft.aplus.itam.service.dao.impl;

import java.util.List;
import org.springframework.stereotype.Component;
import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.itam.model.dbentity.table.GenerateNoEntity;
import com.neusoft.aplus.itam.service.dao.IGenerateNoDao;

/**
 * @ClassName: BillNoDaoImpl 
 * @Description: 工单号DAO实现类
 * @author lu.z
 * @date 2015年4月21日 上午11:42:03
 */
@Component
public class GenerateNoDaoImpl extends AbstractHibernateDao<GenerateNoEntity> implements IGenerateNoDao {
	@Override
	public void saveOrUpdateBillNo(GenerateNoEntity generateNoEntity) {
		saveOrUpdate(generateNoEntity);
	}

	@Override
	public GenerateNoEntity findGenerateNoEntityByPrefix(String prefix) {
		String hql = "from GenerateNoEntity generateNoEntity where generateNoEntity.prefix = ?";
		List<GenerateNoEntity> list = find(hql, prefix);
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}
}

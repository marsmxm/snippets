package com.neusoft.aplus.itam.service.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Component;
import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.itam.model.dbentity.table.AplusDevtypeEntity;
import com.neusoft.aplus.itam.service.dao.IAplusDevtypeDao;
@Component
public class AplusDevtypeDaoImpl extends AbstractHibernateDao<AplusDevtypeEntity> 
implements IAplusDevtypeDao{
	
	@Override
	public void saveOrUpdateAplusDevtype(AplusDevtypeEntity aplusDevtypeEntity) {
		// TODO Auto-generated method stub
		saveOrUpdate(aplusDevtypeEntity);
	}
	
	@Override
	public void saveAplusDevtype(AplusDevtypeEntity aplusDevtypeEntity) {
		// TODO Auto-generated method stub
		save(aplusDevtypeEntity);
	}

	@Override
	public List<AplusDevtypeEntity> findAplusDevtypeEntitys(int devtypeLevel) {
		// TODO Auto-generated method stub
		String hql = "from AplusDevtypeEntity adt where adt.devtypeLevel<= ? ";
		return find(hql, devtypeLevel);
	}
	
	@Override
	public List<AplusDevtypeEntity> findAplusDevtypeEntityById(String devtypeId) {
		// TODO Auto-generated method stub
		String hql = "from AplusDevtypeEntity adt where adt.devtypeId= ? ";
		return find(hql, devtypeId);
	}
	
	@Override
	public List<AplusDevtypeEntity> findAplusDevtypeEntitys() {
		// TODO Auto-generated method stub
		String hql = "from AplusDevtypeEntity adt ";
		return find(hql);
	}

	@Override
	public void deleteAplusDevtypeEntity(AplusDevtypeEntity aplusDevtypeEntity) {
		// TODO Auto-generated method stub
		remove(aplusDevtypeEntity);
	}

	@Override
	public List<AplusDevtypeEntity> findChildAplusDevtypeEntitys(
			String devtypeId) {
		// TODO Auto-generated method stub 
		String hql = "from AplusDevtypeEntity adt where adt.devtypePath like '%"+devtypeId+"%' ";
		return find(hql);
	}

	@Override
	public int updateDevtypeAttr(String devtypeId, String devtypeAttr) {
		// TODO Auto-generated method stub
		String hql = "update AplusDevtypeEntity adt set adt.devtypeAttr=? where adt.devtypeId=?";
		return createQuery(hql,devtypeAttr,devtypeId).executeUpdate();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AplusDevtypeEntity> findDevtypeByIdBatch(String[] devtypeIds) {
		// TODO Auto-generated method stub
		String hql = "from AplusDevtypeEntity adt where adt.devtypeId in (:devtypeIds) ";
		Query query = createQuery(hql);
		query.setParameterList("devtypeIds", devtypeIds);
		return query.list();
	}

}

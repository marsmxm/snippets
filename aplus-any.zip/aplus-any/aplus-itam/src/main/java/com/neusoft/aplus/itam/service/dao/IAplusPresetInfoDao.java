package com.neusoft.aplus.itam.service.dao;

import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Criterion;

import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetInfoEntity;
import com.neusoft.aplus.model.dbentity.Page;

public interface IAplusPresetInfoDao {
	/**
	 * @Description: 保存预置信息
	 * @author zhangyun
	 * @date 2015-4-16 上午9:27:08
	 * @param @param entity
	 * @return void
	 * @throws
	 */
	public String saveAplusPresrtInfo(AplusPresetInfoEntity entity);

	/**
	 * @Description: 修改预置信息
	 * @author zhangyun
	 * @date 2015-4-16 上午9:27:08
	 * @param @param entity
	 * @return void
	 * @throws
	 */
	public void updateAplusPresrtInfo(AplusPresetInfoEntity entity);

	/**
	 * @Description: 修改判断是否有相同的预置号
	 * @author zhangyun
	 * @date 2015-4-16 上午10:25:12
	 * @param @param presetNo
	 * @param @return
	 * @return List<AplusPresetInfoEntity>
	 * @throws
	 */
	public List<AplusPresetInfoEntity> findAplusPresetInfoByPresetNoAndUuid(
			String presetNo, String uuid);

	/**
	 * @Description: 查询预置是否有相同的预置号
	 * @author zhangyun
	 * @date 2015-4-16 上午11:38:11
	 * @param @param querymap
	 * @param @return
	 * @return List<AplusPresetInfoEntity>
	 * @throws
	 */
	public List<AplusPresetInfoEntity> findAplusPresetInfoByMap(
			Map<String, String> querymap);

	/**
	 * @Description: 删除预置信息
	 * @author zhangyun
	 * @date 2015-4-16 下午4:28:31
	 * @param @param entity
	 * @return void
	 * @throws
	 */
	public void deleteAplusPresrtInfo(AplusPresetInfoEntity entity);

	/**
	 * @Description: UUID查询预置信息
	 * @author zhangyun
	 * @date 2015-4-20 下午3:38:42
	 * @param @param entity
	 * @param @return
	 * @return AplusPresetInfoEntity
	 * @throws
	 */
	public AplusPresetInfoEntity findAplusPresetInfoByUuid(String uuid);

	/**
	 * @Description: 查询预置信息分页
	 * @author zhangyun
	 * @date 2015-4-23 下午3:32:31
	 * @param @param page
	 * @param @param pageCount
	 * @param @param criterions
	 * @param @return
	 * @return Page<AplusPresetInfoEntity>
	 * @throws
	 */
	public Page<AplusPresetInfoEntity> findaplusPresetInfo(Integer page,
			Integer pageCount, List<Criterion> criterions);
}

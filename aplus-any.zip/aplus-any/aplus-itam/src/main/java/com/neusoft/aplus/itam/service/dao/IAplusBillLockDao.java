package com.neusoft.aplus.itam.service.dao;

import java.util.List;

import com.neusoft.aplus.itam.model.dbentity.table.AplusBillLockEntity;

public interface IAplusBillLockDao {
	/**
	 * @Description: 设备添加工单锁
	 * @author zhangyun
	 * @date 2015-4-14 下午4:54:31 
	 * @param @param entityList
	 * @return void
	 * @throws
	 */
	public void saveOrUpdateAplusBillLock(List<AplusBillLockEntity> entityList);
	/**
	 * @Description: 删除设备工单锁
	 * @author zhangyun
	 * @date 2015-4-15 上午11:29:24 
	 * @param @param Fqns
	 * @return void
	 * @throws
	 */
	public void deleteAplusBillLockBydevFqns(List<String> Fqns);
	
	/**
	 * @Description: 根据工单UUID 删除工单锁设备
	 * @author zhangyun
	 * @date 2015-4-14 上午10:14:42
	 * @param @param billUuid
	 * @return void
	 * @throws
	 */
	public void deleteAplusBillLockByBillUuid(String billUuid);

	
}

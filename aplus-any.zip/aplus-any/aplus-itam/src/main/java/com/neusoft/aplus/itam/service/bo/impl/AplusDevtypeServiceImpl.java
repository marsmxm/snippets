package com.neusoft.aplus.itam.service.bo.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.neusoft.aplus.itam.model.dbentity.table.AplusDevtypeEntity;
import com.neusoft.aplus.itam.service.bo.IAplusDevtypeService;
import com.neusoft.aplus.itam.service.dao.IAplusDevtypeDao;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceAttrEntity;
import com.neusoft.aplus.service.core.service.dao.AplusDeviceAttrDao;
@Component
public class AplusDevtypeServiceImpl implements IAplusDevtypeService{
	@Autowired
	private IAplusDevtypeDao aplusDevtypeDao;
	@Autowired
	private AplusDeviceAttrDao aplusDeviceAttrDao;
	@Override
	@Transactional
	public void saveOrUpdateAplusDevtype(AplusDevtypeEntity aplusDevtypeEntity) {
		// TODO Auto-generated method stub
		aplusDevtypeDao.saveOrUpdateAplusDevtype(aplusDevtypeEntity);
	}

	@Override
	@Transactional
	public List<AplusDevtypeEntity> findAplusDevtypeEntitys(String devtypeLevel) {
		// TODO Auto-generated method stub
		if("All".equals(devtypeLevel))
		{
			return aplusDevtypeDao.findAplusDevtypeEntitys();
		}else{
			return aplusDevtypeDao.findAplusDevtypeEntitys(Integer.parseInt(devtypeLevel));
		}
	}

	@Override
	@Transactional
	public void deleteAplusDevtypeEntity(AplusDevtypeEntity aplusDevtypeEntity) {
		// TODO Auto-generated method stub
		aplusDevtypeDao.deleteAplusDevtypeEntity(aplusDevtypeEntity);
	}

	@Override
	@Transactional
	public List<AplusDevtypeEntity> findChildAplusDevtypeEntitys(
			String devtypeId) {
		// TODO Auto-generated method stub
		return aplusDevtypeDao.findChildAplusDevtypeEntitys(devtypeId);
	}

	@Override
	@Transactional
	public int  updateDevtypeAttr(String devtypeId, String attr) {
		// TODO Auto-generated method stub
		return aplusDevtypeDao.updateDevtypeAttr(devtypeId, attr);
	}

	@Override
	@Transactional
	public List<AplusDevtypeEntity> findDevtypeByIdBatch(String[] devtypeIds) {
		// TODO Auto-generated method stub
		return aplusDevtypeDao.findDevtypeByIdBatch(devtypeIds);
	}

	@Override
	@Transactional
	public boolean synchronizeAttr() {
		// TODO Auto-generated method stub
		HashMap<String,AplusDeviceAttrEntity> allDeviceAttrMap = new HashMap<String,AplusDeviceAttrEntity>();
		//获取所有类型
		List<AplusDevtypeEntity> devtypeEntityList = this.findAplusDevtypeEntitys("All");
		for(AplusDevtypeEntity devtypeEntity:devtypeEntityList)
		{
			//根据类型获取所有子类型
			List<AplusDevtypeEntity> devTypes= this.findChildAplusDevtypeEntitys(devtypeEntity.getDevtypeId());
			//将当前类型也放入集合
			devTypes.add(devtypeEntity);
			if(devTypes.size()>0)
			{
				String[] devIds = this.getDevtypeName(devTypes);
				//获取类型下得所有型号
				List<AplusDeviceAttrEntity> deviceAttrEntityList = aplusDeviceAttrDao.findDeviceAttrByDevtypeBatch(devIds);
				for(AplusDeviceAttrEntity deviceAttrEntity:deviceAttrEntityList)
				{
					String key = deviceAttrEntity.getCategory()+"_"+deviceAttrEntity.getDeviceVersion()+"_"+deviceAttrEntity.getDeviceType();
					if(allDeviceAttrMap.containsKey(key))
					{
						AplusDeviceAttrEntity value = allDeviceAttrMap.get(key);
						//将属性合并后放入map
						allDeviceAttrMap.put(key, mergeAplusDeviceAttrEntity(value ,devtypeEntity));
					}else
					{
						allDeviceAttrMap.put(key, mergeAplusDeviceAttrEntity(deviceAttrEntity ,devtypeEntity));
					}
				}
			}
		}
		//map转为list 保存到数据库中
		ArrayList<AplusDeviceAttrEntity> deviceAttr = new ArrayList<AplusDeviceAttrEntity>();
		deviceAttr.addAll(allDeviceAttrMap.values());
		aplusDeviceAttrDao.saveOrUpdateAplusDeviceAttrBatch(deviceAttr);
		return true;
	}
	
	
	
	public String[] getDevtypeName (List<AplusDevtypeEntity> devTypes)
	{
		String[] devIds=null;
		if(devTypes.size()>0)
		{
			 devIds = new String[devTypes.size()];
			 for(int i=0;i<devTypes.size();i++)
			 {
				 devIds[i] = devTypes.get(i).getDevtypeName();
			 }
		}
		return devIds;
	}
	/**
	 * @Description:将other中的属性合并到target中
	 * @author jin.ysh
	 * @date 2015-4-22 下午2:04:57 
	 * @param @param target
	 * @param @param other
	 * @param @return
	 * @return AplusDeviceAttrEntity
	 * @throws
	 */
	public AplusDeviceAttrEntity mergeAplusDeviceAttrEntity(AplusDeviceAttrEntity target,AplusDevtypeEntity other)
	{
		if(null == target.getAttr()||"".equals(target.getAttr()))
		{
			target.setAttr(other.getDevtypeAttr());
			return target;
		}else if (null == other.getDevtypeAttr()||"".equals(other.getDevtypeAttr()))
		{
			return target;
		}else{
			JSONArray targetJSONArray = JSON.parseArray(target.getAttr());
			JSONArray otherJSONArray = JSON.parseArray(other.getDevtypeAttr());
			JSONArray addJSONArray = new JSONArray();
			for(Object otherObject:otherJSONArray)
			{
				boolean isExist = false;
				for(Object targetObject:targetJSONArray)
				{
					String otherDefkey = ((JSONObject)otherObject).getString("defkey");
					String targetDefkey = ((JSONObject)targetObject).getString("defkey");
					if(otherDefkey.equals(targetDefkey))
					{
						isExist = true;
						break;
					}
				}
				if(!isExist)
				{
					addJSONArray.add(otherObject);
				}
				
			}
			targetJSONArray.addAll(addJSONArray);
			target.setAttr(targetJSONArray.toString());
			return target;
		}
	}

	@Override
	@Transactional
	public List<AplusDevtypeEntity> findAplusDevtypeEntityById(String devtypeId) {
		// TODO Auto-generated method stub
		return aplusDevtypeDao.findAplusDevtypeEntityById(devtypeId);
	}

	@Override
	@Transactional
	public void saveAplusDevtype(AplusDevtypeEntity aplusDevtypeEntity) {
		// TODO Auto-generated method stub
		 aplusDevtypeDao.saveAplusDevtype(aplusDevtypeEntity);
	}
	
}

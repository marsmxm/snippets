package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @ClassName: AplusBillEntity
 * @Description: TODO
 * @author zhangyun
 * @date 2015-4-9 上午10:22:58
 */
@Entity
@Table(name = "aplus_bill_lock")
public class AplusBillLockEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	private static String BillLockType = "1";
	private String uuid;// uuid
	private String billType;// 工单类型
	private String devFqn;// 设备表fqn
	private String billUuid;// 工单表UUID
	private String billLockType = BillLockType;// 工单锁类型:1排他锁；2同步锁

	@Column(name = "dev_fqn")
	public String getDevFqn() {
		return devFqn;
	}

	public void setDevFqn(String devFqn) {
		this.devFqn = devFqn;
	}

	@Column(name = "bill_uuid")
	public String getBillUuid() {
		return billUuid;
	}

	public void setBillUuid(String billUuid) {
		this.billUuid = billUuid;
	}

	@Column(name = "bill_lock_type")
	public String getBillLockType() {
		return billLockType;
	}

	public void setBillLockType(String billLockType) {
		this.billLockType = billLockType;
	}

	@Column(name = "bill_type")
	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	@Id
	@GeneratedValue(generator = "paymentableGenerator")
	@GenericGenerator(name = "paymentableGenerator", strategy = "uuid")
	@Column(name = "uuid")
	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	@Override
	public String toString() {
		return "AplusBillEntity [uuid=" + uuid + ", billType=" + billType
				+ ", devFqn=" + devFqn + ", billUuid=" + billUuid
				+ ", billLockType=" + billLockType + "]";
	}
}

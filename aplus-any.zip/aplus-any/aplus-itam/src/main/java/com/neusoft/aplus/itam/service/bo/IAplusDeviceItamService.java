package com.neusoft.aplus.itam.service.bo;

import java.util.Map;

import com.neusoft.aplus.model.dbentity.Page;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;

/**
 * @author zh_ch
 * @date 2015年3月9日 上午10:03:52
 */
public interface IAplusDeviceItamService {
	/**
	 * @Description: TODO
	 * @author zhangyun
	 * @date 2015-4-27 下午3:16:10 
	 * @param @param dimMap
	 * @param @param preciseMap
	 * @param @param billType
	 * @param @return
	 * @return Page<AplusDeviceEntity>
	 * @throws
	 */
	public Page<AplusDeviceEntity> findAplusDeivce(Map<String, String> dimMap,
			Map<String, String> preciseMap,String billType, Integer page, Integer pageCount);
}

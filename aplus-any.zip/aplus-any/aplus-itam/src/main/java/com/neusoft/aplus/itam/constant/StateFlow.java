package com.neusoft.aplus.itam.constant;

public enum StateFlow {
	ASSETS, RESOURCES
}

package com.neusoft.aplus.itam.service.dao;

import java.util.List;

import org.hibernate.criterion.Criterion;

import com.neusoft.aplus.itam.model.dbentity.table.AplusBillEntity;
import com.neusoft.aplus.model.dbentity.Page;

public interface IAplusBillDao {
	/**
	 * @Description: 保存或修改工单
	 * @author zhangyun
	 * @date 2015-4-9 上午11:22:37
	 * @param @param aplusBillList
	 * @return void
	 * @throws
	 */
	public String saveAplusBill(AplusBillEntity entity);

	/**
	 * @Description: 删除工单
	 * @author zhangyun
	 * @date 2015-4-13 上午9:45:43
	 * @param @param entity
	 * @return void
	 * @throws
	 */
	public void deleteAplusBill(AplusBillEntity entity);

	/**
	 * @Description: 修改工单状态
	 * @author zhangyun
	 * @date 2015-4-13 下午3:24:52
	 * @param @param aplusBillList
	 * @return void
	 * @throws
	 */
	public void commitAplusBillStatus(String uuid);

	public String generationBillNo(String bill_type);

	/**
	 * @Description: 根据工单UUID查询工单信息
	 * @author zhangyun
	 * @date 2015-4-14 下午5:06:19
	 * @param @param uuid
	 * @param @return
	 * @return AplusBillEntity
	 * @throws
	 */
	public AplusBillEntity findBillByUuid(String uuid);

	/**
	 * @Description: 完成工单状态
	 * @author zhangyun
	 * @date 2015-4-13 下午3:24:52
	 * @param @param aplusBillList
	 * @return void
	 * @throws
	 */
	public void finishAplusBillStatus(String uuid);

	/**
	 * @Description: 工单类型查询工单
	 * @author zhangyun
	 * @date 2015-4-22 上午11:18:56
	 * @param @param billType
	 * @param @return
	 * @return List<AplusBillEntity>
	 * @throws
	 */

	public Page<AplusBillEntity> findBillByBillType(Integer page,
			Integer pageCount, List<Criterion> criterions);

}

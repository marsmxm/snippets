package com.neusoft.aplus.itam.action;

import java.util.List;

import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.model.dbentity.table.AplusSupplierEntity;
import com.neusoft.aplus.itam.service.bo.IAplusSupplierService;
/**
 * @ClassName: AplusSupplierAction 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-23 下午4:56:20
 */
public class AplusSupplierActionQuery extends BaseAction{
	private IAplusSupplierService aplusSupplierService;
	
	@Override
	public void doInit() {
		aplusSupplierService = ApplicationContextFactory.getBean(IAplusSupplierService.class);
	}

	@Override
	public void acceptRepresentation(Representation entity) {
		// TODO Auto-generated method stub
	}

	@Override
	public Representation represent() {
		System.out.println("------------------");
		// TODO Auto-generated method stub
		List<AplusSupplierEntity> supplierList = null;
		
		boolean isprov = Boolean.valueOf((String) getRequestAttributes().get("isprov"));
		boolean isprod = Boolean.valueOf((String) getRequestAttributes().get("isprod"));
		boolean ischeck = Boolean.valueOf((String) getRequestAttributes().get("ischeck"));
		boolean isdeve = Boolean.valueOf((String) getRequestAttributes().get("isdeve"));
		boolean isserv = Boolean.valueOf((String) getRequestAttributes().get("isserv"));
		boolean istotal = Boolean.valueOf((String) getRequestAttributes().get("istotal"));
		
		supplierList = aplusSupplierService.findAplusSupplierEntitys( isprov, isprod, ischeck, isdeve, isserv, istotal);
		if (supplierList != null && !supplierList.isEmpty()) {
			return createObjectRepresentation(supplierList);
		}
		return null;
	}

	@Override
	public void removeRepresentations() {
	}

	@Override
	public void storeRepresentation(Representation entity) {
	}

}

package com.neusoft.aplus.itam.service.bo.impl;


import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.model.dbentity.table.DevtypeAttrXMLEntity;
import com.neusoft.aplus.itam.service.bo.IDevAttrService;
import com.neusoft.aplus.itam.service.dao.IAplusDevtypeDao;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceAttrEntity;
import com.neusoft.aplus.service.core.service.dao.AplusDeviceAttrDao;
@Component
public class DevAttrServiceImpl implements IDevAttrService{
	private static Logger log = Logger.getLogger(DevAttrServiceImpl.class);
	@Autowired
	private IAplusDevtypeDao aplusDevtypeDao;
	@Autowired
	private AplusDeviceAttrDao aplusDeviceAttrDao;
	
	@Override
	@Transactional
	public void loadDevAttr() {
		// TODO Auto-generated method stub
		log.info("load devtype.xml start");
		//加载设备类型属性
		loadDevtypeAttr();
		//加载型号属性
		loadModelAttr();
		log.info("load devtype.xml end");
	}
	
	
	public void loadDevtypeAttr()
	{
		Map<String, DevtypeAttrXMLEntity>  devtypeAttrMap = ApplicationContextFactory.getBeansOfType(DevtypeAttrXMLEntity.class, false, false);
		if(devtypeAttrMap != null && devtypeAttrMap.size() > 0)
		{
				for (Map.Entry<String, DevtypeAttrXMLEntity> entry : devtypeAttrMap.entrySet())
				{
					DevtypeAttrXMLEntity devtypeAttrEntity = entry.getValue();
					try{
						if (devtypeAttrEntity != null) {
							//更新设备类型的属性
							int count = aplusDevtypeDao.updateDevtypeAttr(devtypeAttrEntity.getDevtypeId(), devtypeAttrEntity.getAttr());
							if(count==0)
							{
								log.info("load devtype error: "+devtypeAttrEntity.getDevtypeId()+"数据库中不存在");
							}else
							{
								log.info("load devtype success: "+devtypeAttrEntity.getDevtypeId());
							}
						}
					}catch(Exception e)
					{
						log.info("load  devtype error: "+devtypeAttrEntity.getDevtypeId()+" "+e.toString());
						e.printStackTrace();
					}
				}
		}
	}
	
	
	public void loadModelAttr()
	{
		Map<String, AplusDeviceAttrEntity>  modelAttrMap = ApplicationContextFactory.getBeansOfType(AplusDeviceAttrEntity.class, false, false);
			if(modelAttrMap != null && modelAttrMap.size() > 0)
			{
				for (Map.Entry<String, AplusDeviceAttrEntity> entry : modelAttrMap.entrySet())
				{
					AplusDeviceAttrEntity modelAttrEntity = entry.getValue();
					try{
						if (modelAttrEntity != null) {
							//更新型号属性
							int count = aplusDeviceAttrDao.updateDeviceAttr(modelAttrEntity.getDeviceType(), modelAttrEntity.getAttr());
							if(count==0)
							{
								log.info("load modelAttr error: "+modelAttrEntity.getDeviceType()+"数据库中不存在");
							}else
							{
								log.info("load modelAttr success: "+modelAttrEntity.getDeviceType());
							}
						}
					}catch(Exception e)
					{
						log.info("load  modelAttr error: "+modelAttrEntity.getDeviceType()+" "+e.toString());
						e.printStackTrace();
					}
				}
			}
	}

}

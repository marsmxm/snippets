package com.neusoft.aplus.itam.action;

import org.restlet.representation.Representation;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.service.bo.IDevAttrService;

/**
 * @ClassName: AttrLoadAction 
 * @Description: 加载devtype.xml 新增型号属性
 * @author jin.ysh
 * @date 2015-5-4 下午5:44:05
 */
public class AttrLoadAction extends BaseAction{
	
	private IDevAttrService devAttrService;
	
	@Override
	public void doInit() {
		devAttrService = ApplicationContextFactory.getBean(IDevAttrService.class);
	}
	@Override
	public void acceptRepresentation(Representation entity) {
		devAttrService.loadDevAttr();
	}

	@Override
	public Representation represent() {
		
		return null;
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		
	}
	
}

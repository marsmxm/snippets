package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * 数据库表aplus_supplier对应的实体类
 * @author jin.ysh
 * @date 2015-4-9 下午15:24:37
 */
@Entity
@Table(name = "aplus_supplier")
public class AplusSupplierEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	//合作商ID
	private String supplierId;
	//企业代码
	private String supNo; 
	//供应商名称
	private String supName;  
	//法人
	private String rep;   
	//企业类别
	private String category; 
	//公司地址
	private String address;  
	//公司邮编
	private String zipcode;  
	//公司电话
	private String telephone; 
	//公司传真
	private String fax;  
	//公司网址
	private String weburl;    
	//联系人
	private String principal; 
	//联系人电话
	private String pritel;  
	//联系人邮箱
	private String priemail;  
	//资本币种
	private String moneytype; 
	//注册资本
	private double capital; 
	//员工人数
	private double staff;   
	//经营范围
	private String range;   
	//备注
	private String remark;    
	//状态
	private double state;  
	//供应商
	private String isprov;   
	//生产商
	private String isprod; 
	//维修商
	private String ischeck;  
	//开发商
	private String isdeve;  
	//服务商
	private String isserv;   
	//集成商
	private String istotal;  
	//其它
	private String isorther;  
	//国内供应商
	private String isdomestic;
	//供应商国内标准码
	private String supcode;   
	@Id
	@GeneratedValue(generator = "paymentableGenerator")
	@GenericGenerator(name = "paymentableGenerator", strategy = "uuid")
	@Column(name = "supplier_id")
	public String getSupplierId() {
		return supplierId;
	}


	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	@Column(name = "sup_no")
	public String getSupNo() {
		return supNo;
	}


	public void setSupNo(String supNo) {
		this.supNo = supNo;
	}

	@Column(name = "sup_name")
	public String getSupName() {
		return supName;
	}


	public void setSupName(String supName) {
		this.supName = supName;
	}

	@Column(name = "rep")
	public String getRep() {
		return rep;
	}


	public void setRep(String rep) {
		this.rep = rep;
	}

	@Column(name = "category")
	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}

	@Column(name = "address")
	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}

	@Column(name = "zipcode")
	public String getZipcode() {
		return zipcode;
	}


	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	@Column(name = "telephone")
	public String getTelephone() {
		return telephone;
	}


	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	@Column(name = "fax")
	public String getFax() {
		return fax;
	}


	public void setFax(String fax) {
		this.fax = fax;
	}

	@Column(name = "weburl")
	public String getWeburl() {
		return weburl;
	}


	public void setWeburl(String weburl) {
		this.weburl = weburl;
	}

	@Column(name = "principal")
	public String getPrincipal() {
		return principal;
	}


	public void setPrincipal(String principal) {
		this.principal = principal;
	}

	@Column(name = "pritel")
	public String getPritel() {
		return pritel;
	}


	public void setPritel(String pritel) {
		this.pritel = pritel;
	}

	@Column(name = "priemail")
	public String getPriemail() {
		return priemail;
	}


	public void setPriemail(String priemail) {
		this.priemail = priemail;
	}

	@Column(name = "moneytype")
	public String getMoneytype() {
		return moneytype;
	}

	
	public void setMoneytype(String moneytype) {
		this.moneytype = moneytype;
	}

	@Column(name = "capital")
	public double getCapital() {
		return capital;
	}


	public void setCapital(double capital) {
		this.capital = capital;
	}

	@Column(name = "staff")
	public double getStaff() {
		return staff;
	}


	public void setStaff(double staff) {
		this.staff = staff;
	}

	@Column(name = "range")
	public String getRange() {
		return range;
	}


	public void setRange(String range) {
		this.range = range;
	}

	@Column(name = "remark")
	public String getRemark() {
		return remark;
	}


	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Column(name = "state")
	public double getState() {
		return state;
	}


	public void setState(double state) {
		this.state = state;
	}

	@Column(name = "isprov")
	public String getIsprov() {
		return isprov;
	}


	public void setIsprov(String isprov) {
		this.isprov = isprov;
	}

	@Column(name = "isprod")
	public String getIsprod() {
		return isprod;
	}


	public void setIsprod(String isprod) {
		this.isprod = isprod;
	}

	@Column(name = "ischeck")
	public String getIscheck() {
		return ischeck;
	}


	public void setIscheck(String ischeck) {
		this.ischeck = ischeck;
	}

	@Column(name = "isdeve")
	public String getIsdeve() {
		return isdeve;
	}


	public void setIsdeve(String isdeve) {
		this.isdeve = isdeve;
	}

	@Column(name = "isserv")
	public String getIsserv() {
		return isserv;
	}


	public void setIsserv(String isserv) {
		this.isserv = isserv;
	}

	@Column(name = "istotal")
	public String getIstotal() {
		return istotal;
	}


	public void setIstotal(String istotal) {
		this.istotal = istotal;
	}

	@Column(name = "isorther")
	public String getIsorther() {
		return isorther;
	}


	public void setIsorther(String isorther) {
		this.isorther = isorther;
	}

	@Column(name = "isdomestic")
	public String getIsdomestic() {
		return isdomestic;
	}


	public void setIsdomestic(String isdomestic) {
		this.isdomestic = isdomestic;
	}

	@Column(name = "supcode")
	public String getSupcode() {
		return supcode;
	}


	public void setSupcode(String supcode) {
		this.supcode = supcode;
	}

}

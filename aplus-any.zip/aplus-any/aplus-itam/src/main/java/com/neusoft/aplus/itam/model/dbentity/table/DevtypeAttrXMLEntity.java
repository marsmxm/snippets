package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;

/**
 * @ClassName: DevtypeAttrEntity 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-16 上午10:48:13
 */
public class DevtypeAttrXMLEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	//类型名
	private String  devtypeName;  
	//类型code
	private String  devtypeId;  
	//属性
	private String  attr;
	
	public String getDevtypeName() {
		return devtypeName;
	}
	public void setDevtypeName(String devtypeName) {
		this.devtypeName = devtypeName;
	}
	public String getDevtypeId() {
		return devtypeId;
	}
	public void setDevtypeId(String devtypeId) {
		this.devtypeId = devtypeId;
	}
	public String getAttr() {
		return attr;
	}
	public void setAttr(String attr) {
		this.attr = attr;
	}    
}

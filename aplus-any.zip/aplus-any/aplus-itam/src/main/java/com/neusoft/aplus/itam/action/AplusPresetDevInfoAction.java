package com.neusoft.aplus.itam.action;

import java.util.Map;

import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;
import com.neusoft.aplus.itam.service.bo.IAplusPresetDevInfoService;
import com.neusoft.aplus.model.dbentity.Page;

/**
 * @ClassName: AplusPresetDevInfo
 * @Description: 预置设备
 * @author lu.z
 * @date 2015年4月24日 上午8:54:25
 */
public class AplusPresetDevInfoAction extends BaseAction {
	private IAplusPresetDevInfoService aplusPresetDevInfoService;
	private Map<String, String> paramsMap;

	@Override
	public void doInit() {
		aplusPresetDevInfoService = ApplicationContextFactory
				.getBean(IAplusPresetDevInfoService.class);
		paramsMap = getRequestParameters();
	}

	@Override
	public void acceptRepresentation(Representation entity) {
		try {
			AplusPresetDevInfoEntity presetDevInfoEntity = getObjectFromRepresentation(
					entity, AplusPresetDevInfoEntity.class);
			aplusPresetDevInfoService
					.saveAplusPresrtDevInfo(presetDevInfoEntity);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();
	}

	@Override
	public Representation represent() {
		Page<AplusPresetDevInfoEntity> aplusPresetDevInfoEntity = null;
		String pageStr = (String) paramsMap.get("page");
		String pageCountStr = (String) paramsMap.get("pageCount");
		String presetUuid = (String) paramsMap.get("presetUuid");
		// 如果传过来为null或者""，默认为第一页
		Integer page = (pageStr == null || "".equals(pageStr)) ? 1 : Integer
				.parseInt(pageStr);
		// 如果传过来为null或者""，默认为每页10条数据
		Integer pageCount = (pageCountStr == null || "".equals(pageCountStr)) ? 10
				: Integer.parseInt(pageCountStr);
		aplusPresetDevInfoEntity = aplusPresetDevInfoService
				.findAplusPresetDevInfo(page, pageCount, presetUuid);

		if (aplusPresetDevInfoEntity != null) {
			return createObjectRepresentation(aplusPresetDevInfoEntity);
		}
		return null;
	}

	@Override
	public void removeRepresentations() {
		String uuid = (String) paramsMap.get("uuid");
		aplusPresetDevInfoService.deleteAplusPresrtDevInfo(uuid);
		sendSuccess();
	}

	@Override
	public void storeRepresentation(Representation entity) {
		try {
			AplusPresetDevInfoEntity presetDevInfoEntity = getObjectFromRepresentation(
					entity, AplusPresetDevInfoEntity.class);

			aplusPresetDevInfoService
					.updateAplusPresrtDevInfo(presetDevInfoEntity);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();
	}

}

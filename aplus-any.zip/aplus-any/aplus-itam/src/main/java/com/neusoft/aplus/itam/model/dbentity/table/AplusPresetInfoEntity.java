package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @ClassName: AplusPresetInfoEntity
 * @Description: TODO
 * @author zhangyun
 * @date 2015-4-9 上午10:22:58
 */
@Entity
@Table(name = "aplus_preset_info")
public class AplusPresetInfoEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	private static String DelFlag = "0";
	private static final double PresetAmount = 0.00;
	private String uuid;// uuid
	private String presetNo;// 预置信息号
	private String presetName;// 预置信息名称
	private String presetSts;// 预置状态
	private String presetType;// 预置类型：采购类、非采购类、软件类
	private Double presetAmount = PresetAmount;// 总额
	private Date dffectiveDate;// 生效日期
	private String signPersion;// 签订人
	private String verifyPersion;// 审批人
	private String simpleExplain;// 简要说明
	private Date signDate;// 签订日期
	private String delFlag = DelFlag;// 删除标记，默认为0 0：正常；1：删除；
	private Date createDate = new Date();// 创建时间
	@Column(name = "create_date")
	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	@Column(name = "preset_no")
	public String getPresetNo() {
		return presetNo;
	}

	public void setPresetNo(String presetNo) {
		this.presetNo = presetNo;
	}

	@Column(name = "preset_name")
	public String getPresetName() {
		return presetName;
	}

	public void setPresetName(String presetName) {
		this.presetName = presetName;
	}

	@Column(name = "preset_sts")
	public String getPresetSts() {
		return presetSts;
	}

	public void setPresetSts(String presetSts) {
		this.presetSts = presetSts;
	}

	@Column(name = "preset_type")
	public String getPresetType() {
		return presetType;
	}

	public void setPresetType(String presetType) {
		this.presetType = presetType;
	}

	@Column(name = "preset_amount")
	public Double getPresetAmount() {
		return presetAmount;
	}

	public void setPresetAmount(Double presetAmount) {
		this.presetAmount = presetAmount;
	}

	@Column(name = "dffective_date")
	public Date getDffectiveDate() {
		return dffectiveDate;
	}

	public void setDffectiveDate(Date dffectiveDate) {
		this.dffectiveDate = dffectiveDate;
	}

	@Column(name = "sign_persion")
	public String getSignPersion() {
		return signPersion;
	}

	public void setSignPersion(String signPersion) {
		this.signPersion = signPersion;
	}

	@Column(name = "verify_persion")
	public String getVerifyPersion() {
		return verifyPersion;
	}

	public void setVerifyPersion(String verifyPersion) {
		this.verifyPersion = verifyPersion;
	}

	@Column(name = "simple_explain")
	public String getSimpleExplain() {
		return simpleExplain;
	}

	public void setSimpleExplain(String simpleExplain) {
		this.simpleExplain = simpleExplain;
	}

	@Column(name = "sign_date")
	public Date getSignDate() {
		return signDate;
	}

	public void setSignDate(Date signDate) {
		this.signDate = signDate;
	}

	@Column(name = "del_flag")
	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	
	

	@Id
	@GeneratedValue(generator = "paymentableGenerator")
	@GenericGenerator(name = "paymentableGenerator", strategy = "uuid")
	@Column(name = "uuid")
	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	@Override
	public String toString() {
		return "AplusPresetInfoEntity [uuid=" + uuid + ", presetNo=" + presetNo
				+ ", presetName=" + presetName + ", presetSts=" + presetSts
				+ ", presetType=" + presetType + ", presetAmount="
				+ presetAmount + ", dffectiveDate=" + dffectiveDate
				+ ", signPersion=" + signPersion + ", verifyPersion="
				+ verifyPersion + ", simpleExplain=" + simpleExplain
				+ ", signDate=" + signDate + ", delFlag=" + delFlag
				+ ", createDate=" + createDate + "]";
	}
}

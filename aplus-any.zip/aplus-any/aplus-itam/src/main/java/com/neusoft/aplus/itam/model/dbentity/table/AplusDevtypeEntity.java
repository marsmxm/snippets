package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.neusoft.aplus.model.usertype.StringJsonUserType;

/**
 * 数据库表aplus_devtype对应的实体类
 * @author jin.ysh
 * @date 2015-4-9 下午15:24:37
 */
@TypeDefs({@TypeDef( name= "StringJsonObject", typeClass = StringJsonUserType.class)})
@Entity
@Table(name = "aplus_devtype")
public class AplusDevtypeEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	//类型编码
	private String  devtypeId;  
	//类型名称
	private String  devtypeName;  
	//显示名称
	private String  devtypeShowName; 
	//类型描述
	private String  devtypeDesc;    
	//上级类型编码
	private String  parentDevtypeId;  
	//路径
	private String  devtypePath; 
	//级别
	private int  devtypeLevel;  
	//创建时间  
	private Date    createdDate;   
	//创建账号
	private String  createdBy;  
	//计量单位
	private String  unit;     
	//库存阀值
	private int  limit; 
	//耗费性质
	private String  dtype;     
	//折旧年限
	private String  oldyear;   
	//折旧方法
	private String  depreway; 
	//3D模型ID字段
	private String  model3d;
	//设备类型属性
	private String  devtypeAttr;
	
	@Id
	@Column(name = "devtype_id")
	@GenericGenerator(name = "idGenerator", strategy = "assigned")
	@GeneratedValue(generator = "idGenerator")
	public String getDevtypeId() {
		return devtypeId;
	}
	public void setDevtypeId(String devtypeId) {
		this.devtypeId = devtypeId;
	}
	@Column(name = "devtype_name")
	public String getDevtypeName() {
		return devtypeName;
	}
	public void setDevtypeName(String devtypeName) {
		this.devtypeName = devtypeName;
	}
	@Column(name = "devtype_show_name")
	public String getDevtypeShowName() {
		return devtypeShowName;
	}
	public void setDevtypeShowName(String devtypeShowName) {
		this.devtypeShowName = devtypeShowName;
	}
	@Column(name = "devtype_desc")
	public String getDevtypeDesc() {
		return devtypeDesc;
	}
	public void setDevtypeDesc(String devtypeDesc) {
		this.devtypeDesc = devtypeDesc;
	}
	@Column(name = "parent_devtype_id")
	public String getParentDevtypeId() {
		return parentDevtypeId;
	}
	public void setParentDevtypeId(String parentDevtypeId) {
		this.parentDevtypeId = parentDevtypeId;
	}
	@Column(name = "devtype_path")
	public String getDevtypePath() {
		return devtypePath;
	}
	public void setDevtypePath(String devtypePath) {
		this.devtypePath = devtypePath;
	}
	@Column(name = "devtype_level")
	public int getDevtypeLevel() {
		return devtypeLevel;
	}
	public void setDevtypeLevel(int devtypeLevel) {
		this.devtypeLevel = devtypeLevel;
	}
	@Column(name = "created_date")
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@Column(name = "created_by")
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	@Column(name = "unit")
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	@Column(name = "limit1")
	public int getLimit() {
		return limit;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}
	@Column(name = "dtype")
	public String getDtype() {
		return dtype;
	}
	public void setDtype(String dtype) {
		this.dtype = dtype;
	}
	@Column(name = "oldyear")
	public String getOldyear() {
		return oldyear;
	}
	public void setOldyear(String oldyear) {
		this.oldyear = oldyear;
	}
	@Column(name = "depreway")
	public String getDepreway() {
		return depreway;
	}
	public void setDepreway(String depreway) {
		this.depreway = depreway;
	}
	@Column(name = "model_3d")
	public String getModel3d() {
		return model3d;
	}
	public void setModel3d(String model3d) {
		this.model3d = model3d;
	}          
	@Column(name = "devtype_attr")
	@Type(type = "StringJsonObject")
	public String getDevtypeAttr() {
		return devtypeAttr;
	}
	public void setDevtypeAttr(String devtypeAttr) {
		this.devtypeAttr = devtypeAttr;
	}
}

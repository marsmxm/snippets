package com.neusoft.aplus.itam.service.dao.impl;

import java.util.List;

import org.springframework.stereotype.Component;

import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.itam.model.dbentity.table.StrategyOrgEntify;
import com.neusoft.aplus.itam.service.dao.IStrategyOrgDao;

/**
 * @ClassName: StrategyOrgDaoImpl 
 * @Description: IStrategyOrgDao实现类
 * @author lu.z
 * @date 2015年5月22日 下午1:58:23
 */
@Component
public class StrategyOrgDaoImpl extends AbstractHibernateDao<StrategyOrgEntify> implements IStrategyOrgDao{

	@Override
	public void saveStrategyOrgs(List<StrategyOrgEntify> strategyOrgEntifys) {
		batchSaveOrUpdate(strategyOrgEntifys);
	}

	@Override
	public void removeStrategyOrgs(List<String> ids) {
		if(ids != null && ids.size() > 0){
			String sql = "delete StrategyOrgEntify where strategyId in ";
			String condition = "(";
			for(int i = 0; i < ids.size(); i++){
				condition += "?,";
			}
			sql += condition.substring(0, condition.length() - 1) + ")";
			createQuery(sql, ids.toArray()).executeUpdate();
		}
	}

	@Override
	public void removeStrategyOrgsByStrategyId(String strategyId) {
		String sql = "delete StrategyOrgEntify where strategyId = ? ";
		createQuery(sql, strategyId).executeUpdate();
	}

	@Override
	public StrategyOrgEntify findStrategyOrgByOrgId(String strategyId, String orgId) {
		String hql = "from StrategyOrgEntify strategyOrgEntify where strategyOrgEntify.strategyId = ? and strategyOrgEntify.orgId = ?";
		List<StrategyOrgEntify> list = find(hql, strategyId, orgId);
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}
}

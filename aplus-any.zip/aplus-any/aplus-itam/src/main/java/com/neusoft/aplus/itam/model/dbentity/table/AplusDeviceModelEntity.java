package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 数据库表aplus_supplier对应的实体类
 * @author jin.ysh
 * @date 2015-4-9 下午15:24:37
 */
@Entity
@Table(name = "aplus_device_model")
public class AplusDeviceModelEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	//uuid
	private String uuid;
	//合作商id
	private String supplierId; 
	//设备类型id
	private String devtypeId;  
	//型号名称
	private String modelName;
	
	@Id
	@Column(name = "uuid")
	@GeneratedValue(strategy = GenerationType.AUTO) 
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	@Column(name = "supplier_id")
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	@Column(name = "devtype_id")
	public String getDevtypeId() {
		return devtypeId;
	}
	public void setDevtypeId(String devtypeId) {
		this.devtypeId = devtypeId;
	}
	@Column(name = "model_name")
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}   

}

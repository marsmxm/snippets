package com.neusoft.aplus.itam.service.dao;

import java.util.List;

import com.neusoft.aplus.itam.model.dbentity.table.TemplateEntity;

/**
 * @ClassName: ITemplateDao
 * @Description: 模板操作数据库接口
 * @author lu.z
 * @date 2015年4月9日 下午1:45:16
 */
public interface ITemplateDao {
	/**
	 * @Description: 保存模板信息
	 * @author lu.z
	 * @date 2015年4月9日 下午1:45:00
	 * @param @param templateEntity
	 * @return void
	 * @throws
	 */
	public void saveTemplate(TemplateEntity templateEntity);
	
	/**
	 * @Description: 保存模板信息
	 * @author lu.z
	 * @date 2015年4月9日 下午1:45:00
	 * @param @param templateEntitys
	 * @return void
	 * @throws
	 */
	public void saveTemplates(List<TemplateEntity> templateEntitys);

	/**
	 * @Description: 根据模板code删除模板信息
	 * @author lu.z
	 * @date 2015年4月9日 下午1:46:01
	 * @param @param templateCode
	 * @return void
	 * @throws
	 */
	public void removeTemplate(String templateCode);
	
	/**
	 * @Description: 根据模板code数组删除模板信息
	 * @author lu.z
	 * @date 2015年4月9日 下午1:46:01
	 * @param templateCodes
	 * @return void
	 * @throws
	 */
	public void removeTemplates(List<String> templateCodes);

	/**
	 * @Description: 根据模板编码查询模板信息
	 * @author lu.z
	 * @date 2015年4月13日 上午10:33:57
	 * @param @param templateCode
	 * @return TemplateEntity
	 * @throws
	 */
	public TemplateEntity findTemplateByCode(String templateCode);
	
	/**
	 * @Description: 查询所有模板code
	 * @author lu.z
	 * @date 2015年4月23日 下午3:06:08 
	 * @param @return
	 * @return List<String>
	 * @throws
	 */
	public List<String> findAllTemplateCodes(); 
	
	/**
	 * @Description: 保存模板
	 * @author lu.z
	 * @date 2015年4月30日 下午1:41:48 
	 * @param @param templateEntity
	 * @return void
	 * @throws
	 */
	public void updateTemplate(TemplateEntity templateEntity);
	
	/**
	 * @Description: 根据模板ID，批量删除模板信息
	 * @author lu.z
	 * @date 2015年4月30日 下午1:43:43 
	 * @param @param ids
	 * @return void
	 * @throws
	 */
	public void removeTemplateByIds(List<Integer> ids);
	
	/**
	 * @Description: 根据ID删除模板信息
	 * @author lu.z
	 * @date 2015年4月30日 下午1:44:45 
	 * @param @param id
	 * @return void
	 * @throws
	 */
	public void removeTemplateById(Integer id);
}

package com.neusoft.aplus.itam.action;

import org.restlet.representation.Representation;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.service.bo.ITemplateService;

/**
 * @ClassName: TemplateAction 
 * @Description: 模板action
 * @author lu.z
 * @date 2015年4月23日 下午4:38:33
 */
public class TemplateAction extends BaseAction{
	
	private ITemplateService templateService;
	
	@Override
	public void doInit() {
		templateService = ApplicationContextFactory.getBean(ITemplateService.class);
	}
	@Override
	public void acceptRepresentation(Representation entity) {
		templateService.reloadTemplate();
	}

	@Override
	public Representation represent() {
		
		return null;
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		
	}
	
}

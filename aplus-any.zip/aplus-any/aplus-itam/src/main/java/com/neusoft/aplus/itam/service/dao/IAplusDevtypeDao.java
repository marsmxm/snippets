package com.neusoft.aplus.itam.service.dao;

import java.util.List;

import com.neusoft.aplus.itam.model.dbentity.table.AplusDevtypeEntity;


/**
 * @ClassName: AplusDevtypeDao 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-9 下午4:28:30
 */
public interface IAplusDevtypeDao {
	/**
	 * @Description: 新增或更新设备类型
	 * @author jin.ysh
	 * @date 2015-4-9 下午4:28:23 
	 * @param @param aplusDevtypeEntity
	 * @return void
	 * @throws
	 */
	public void saveOrUpdateAplusDevtype(AplusDevtypeEntity aplusDevtypeEntity);
	/**
	 * @Description: 查询设备类型
	 * @author jin.ysh
	 * @date 2015-4-9 下午4:30:35 
	 * @param @param 获取当前级别之上的所有设备类型(包含当前级别)，All 表示获取全部
	 * @param @return
	 * @return List<AplusDevtypeEntity>
	 * @throws
	 */
	public List<AplusDevtypeEntity> findAplusDevtypeEntitys(int devtypeLevel);

	/**
	 * @Description: 删除设备类型
	 * @author jin.ysh
	 * @date 2015-4-9 下午4:32:34 
	 * @param @param aplusDevtypeEntity
	 * @return void
	 * @throws
	 */
	public void deleteAplusDevtypeEntity(AplusDevtypeEntity aplusDevtypeEntity);
	
	/**
	 * @Description: 获取当前类型的所有子类型
	 * @author jin.ysh
	 * @date 2015-4-17 上午9:46:17 
	 * @param @param devtypeId
	 * @param @return
	 * @return List<AplusDevtypeEntity>
	 * @throws
	 */
	public List<AplusDevtypeEntity> findChildAplusDevtypeEntitys(String devtypeId);
	
	/**
	 * @return 
	 * @Description: 更新设备类型属性
	 * @author jin.ysh
	 * @date 2015-4-20 上午10:27:32 
	 * @param @param devtypeId
	 * @param @param attr
	 * @return void
	 * @throws
	 */
	public int updateDevtypeAttr(String devtypeId,String attr);
	
	/**
	 * @Description: 批量查询设备类型
	 * @author jin.ysh
	 * @date 2015-4-20 下午5:36:44 
	 * @param @param devtypeIds
	 * @param @return
	 * @return List<AplusDevtypeEntity>
	 * @throws
	 */
    public List<AplusDevtypeEntity> findDevtypeByIdBatch(String[] devtypeIds);
    /**
     * @Description: 获取所有设备类型
     * @author jin.ysh
     * @date 2015-4-21 下午5:58:03 
     * @param @return
     * @return List<AplusDevtypeEntity>
     * @throws
     */
	public List<AplusDevtypeEntity> findAplusDevtypeEntitys();
	
	
	/**
	 * @Description: 通过类型id获取类型
	 * @author jin.ysh
	 * @date 2015-4-24 下午2:50:22 
	 * @param @param devtypeId
	 * @param @return
	 * @return List<AplusDevtypeEntity>
	 * @throws
	 */
	public List<AplusDevtypeEntity> findAplusDevtypeEntityById(String devtypeId);
	/**
	 * @Description: TODO
	 * @author jin.ysh
	 * @date 2015-4-27 上午10:12:24 
	 * @param @param aplusDevtypeEntity
	 * @return void
	 * @throws
	 */
	public void saveAplusDevtype(AplusDevtypeEntity aplusDevtypeEntity);
	

	
	
	
}

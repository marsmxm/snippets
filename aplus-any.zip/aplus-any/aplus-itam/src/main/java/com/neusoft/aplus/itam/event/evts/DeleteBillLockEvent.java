package com.neusoft.aplus.itam.event.evts;

import org.apache.log4j.Logger;

import com.neusoft.aplus.common.event.EventChain;
import com.neusoft.aplus.common.event.Input;
import com.neusoft.aplus.common.event.Output;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.event.ItamEvent;
import com.neusoft.aplus.itam.event.params.StateFlowOutput;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillEntity;
import com.neusoft.aplus.itam.service.dao.IAplusBillLockDao;

/**
 * @ClassName: DeleteBillLockEvent 
 * @Description: 删除工单锁事件
 * @author lu.z
 * @date 2015年4月24日 下午4:56:44
 */
public class DeleteBillLockEvent extends ItamEvent{
	private static Logger logger = Logger.getLogger(DeleteBillLockEvent.class);
	
	private IAplusBillLockDao aplusBillLokcDao;
	
	@Override
	public <T> void fireEvent(Input input, Output output, EventChain<T> chain) {
		logger.info("删除工单锁事件开始");
		aplusBillLokcDao = ApplicationContextFactory.getBean(IAplusBillLockDao.class);
		
		StateFlowOutput stateFlowOutput = (StateFlowOutput) output;
		AplusBillEntity aplusBillEntityOut = stateFlowOutput.getAplusBillEntity();
		String uuid = aplusBillEntityOut.getUuid();
		
		aplusBillLokcDao.deleteAplusBillLockByBillUuid(uuid);
	}

}

package com.neusoft.aplus.itam.service.bo.impl;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import com.google.common.collect.Lists;
import com.neusoft.aplus.common.event.EChainHandler;
import com.neusoft.aplus.common.event.Event;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.constant.BillStatus;
import com.neusoft.aplus.itam.constant.Constant;
import com.neusoft.aplus.itam.constant.StateFlow;
import com.neusoft.aplus.itam.event.ItamEvent;
import com.neusoft.aplus.itam.event.ItamEventChain;
import com.neusoft.aplus.itam.event.params.StateFlowInput;
import com.neusoft.aplus.itam.event.params.StateFlowOutput;
import com.neusoft.aplus.itam.exception.ItamRestException;
import com.neusoft.aplus.itam.model.bizentity.EventEntity;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillDeviceEntity;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillEntity;
import com.neusoft.aplus.itam.model.dbentity.table.FlowEntity;
import com.neusoft.aplus.itam.model.dbentity.table.TemplateEntity;
import com.neusoft.aplus.itam.service.bo.IStateFlowService;
import com.neusoft.aplus.itam.service.dao.IAplusBillDao;
import com.neusoft.aplus.itam.service.dao.IAplusBillDeviceDao;
import com.neusoft.aplus.itam.service.dao.IStateFlowDao;
import com.neusoft.aplus.itam.service.dao.ITemplateDao;
import com.neusoft.aplus.model.dbentity.Page;

/**
 * @ClassName: StateFlowServiceImpl
 * @Description: 状态机对外提供接口的实现类
 * @author lu.z
 * @date 2015年4月9日 上午10:30:40
 */
@Component
public class StateFlowService implements IStateFlowService {

	private static Logger logger = LoggerFactory.getLogger(StateFlowService.class);

	@Autowired
	private IStateFlowDao stateFlowDao;
	@Autowired
	private ITemplateDao templateDao;
	@Autowired
	private EChainHandler<Boolean> eChainHandler;
	@Autowired
	private IAplusBillDao aplusBillDao;
	@Autowired
	private IAplusBillDeviceDao aplusBillDeviceDao;

	@Override
	@Transactional
	public List<FlowEntity> findAllStateFlow() {
		return stateFlowDao.findAllStateFlow();
	}

	@Override
	@Transactional
	public List<FlowEntity> findStateFlowByType(String stateFlowtype) {
		List<FlowEntity> flowEntitys = null;
		if (StateFlow.ASSETS.name().equals(stateFlowtype)) {
			flowEntitys = stateFlowDao.findAllAssetsStateFlow();
		} else if (StateFlow.RESOURCES.name().equals(stateFlowtype)) {
			flowEntitys = stateFlowDao.findAllResourcesStateFlow();
		}
		return flowEntitys;
	}

	@Override
	@Transactional
	public List<FlowEntity> findStateFlowByTemplateCode(String templateCode) {
		return stateFlowDao.findStateFlowByTemplateCode(templateCode);
	}

	@Override
	@Transactional
	public List<FlowEntity> findStateFlowByTemplateCodeAndType(String templateCode, String stateFlowtype) {
		List<FlowEntity> flowEntitys = null;
		if (StateFlow.ASSETS.name().equals(stateFlowtype)) {
			flowEntitys = stateFlowDao.findAssetsStateFlowByTemplateCode(templateCode);
		} else if (StateFlow.RESOURCES.name().equals(stateFlowtype)) {
			flowEntitys = stateFlowDao.findResourcesStateFlowByTemplateCode(templateCode);
		}
		return flowEntitys;
	}

	@Override
	@Transactional
	public FlowEntity findStateFlowByBillType(String billType) {
		return stateFlowDao.findStateFlowByBillType(billType);
	}

	@Override
	@Transactional
	public String findUpdateAttrsByCommitStatus(String billType, String billStatus) {
		FlowEntity flowEntity = stateFlowDao.findStateFlowByBillType(billType);
		if (flowEntity != null) {
			if (BillStatus.SAVE.name().equals(billStatus)) {
				return flowEntity.getBeforeCommitAttrs();
			} else if (BillStatus.APPROVED.name().equals(billStatus)) {
				return flowEntity.getAfterCommitAttrs();
			}
		}
		return null;
	}

	@Override
	@Transactional
	public String findDeviceTypeByBillType(String billType) {
		FlowEntity flowEntity = this.findStateFlowByBillType(billType);
		if (flowEntity != null) {
			TemplateEntity templateEntity = templateDao.findTemplateByCode(flowEntity.getTemplateCode());
			if (templateEntity != null) {
				return templateEntity.getDeviceType();
			}
		}
		return null;
	}

	@Override
	@Transactional
	public boolean doBillFinish(String uuid) {
		AplusBillEntity aplusBillEntity = aplusBillDao.findBillByUuid(uuid);
		String[] params = null;
		if (aplusBillEntity != null) {
			List<AplusBillDeviceEntity> aplusBillDeviceEntitys = aplusBillDeviceDao
					.findAplusDeviceIsByBillUuidAndIsCheck(uuid, "1");
			if (aplusBillDeviceEntitys != null && !aplusBillDeviceEntitys.isEmpty()) {
				String billType = aplusBillEntity.getBillType();
				FlowEntity flowEntity = stateFlowDao.findStateFlowByBillType(billType);
				if (flowEntity != null) {
					String events = flowEntity.getEvents();
					if (events == null || "".equals(events)) {
						String templateCode = flowEntity.getTemplateCode();
						// 状态机事件没有配置，查询模板配置的默认事件
						TemplateEntity templateEntity = templateDao.findTemplateByCode(templateCode);
						if (templateEntity != null) {
							events = templateEntity.getDefalutEvents();
						}
					}
					if (events != null && !"".equals(events)) {
						String evts[] = events.split(",");
						// 事件链
						ItamEventChain itamEventChain = new ItamEventChain();
						for (String evt : evts) {
							Object obj = ApplicationContextFactory.getBean(evt);
							if (obj != null) {
								itamEventChain.addEvent((Event) obj);
							}
						}
						StateFlowInput input = new StateFlowInput(aplusBillEntity, aplusBillDeviceEntitys, flowEntity);
						// 输出参数
						StateFlowOutput output = new StateFlowOutput();
						// 复制工单对象
						AplusBillEntity aplusBillEntityOut = aplusBillEntity.clone();
						output.setAplusBillEntity(aplusBillEntityOut);
						// 复制设备数组
						List<AplusBillDeviceEntity> aplusBillDeviceEntitysOut = new ArrayList<AplusBillDeviceEntity>(
								Arrays.asList(new AplusBillDeviceEntity[aplusBillDeviceEntitys.size()]));
						Collections.copy(aplusBillDeviceEntitysOut, aplusBillDeviceEntitys);

						output.setAplusBillDeviceEntitys(aplusBillDeviceEntitysOut);
						output.setFlowEntity(flowEntity);

						itamEventChain.setInput(input);
						itamEventChain.setOutput(output);
						eChainHandler.setChain(itamEventChain);
						// 执行事件
						eChainHandler.addAndFireEvents(input, output, true);

						return true;
					} else {
						// 没有配置事件链
						params = new String[] { billType };
						ItamRestException.throwException(ItamRestException.NOT_HAVE_EVENTS, null, params, null);
					}
				} else {
					// 工单类型为空
					params = new String[] { billType };
					ItamRestException.throwException(ItamRestException.NOT_HAVE_BILL_RESULT, null, params, null);
				}
			} else {
				// 工单设备信息为空
				params = new String[] { uuid };
				ItamRestException.throwException(ItamRestException.BILL_DEVICES_IS_NULL, null, params, null);
			}
		} else {
			// 工单信息为空
			params = new String[] { uuid };
			ItamRestException.throwException(ItamRestException.BILL_INFO_IS_NULL, null, params, null);
		}
		return false;
	}

	@Override
	@Transactional
	public Page<FlowEntity> findAllStateFlow(Integer page, Integer pageCount) {
		return stateFlowDao.findAllAssetsStateFlow(page, pageCount);
	}

	@Override
	@Transactional
	public Page<FlowEntity> findStateFlowByType(Integer page, Integer pageCount, String stateFlowType) {
		Page<FlowEntity> flowEntitys = null;
		if (StateFlow.ASSETS.name().equals(stateFlowType)) {
			flowEntitys = stateFlowDao.findAllAssetsStateFlow(page, pageCount);
		} else if (StateFlow.RESOURCES.name().equals(stateFlowType)) {
			flowEntitys = stateFlowDao.findAllResourcesStateFlow(page, pageCount);
		}
		return flowEntitys;
	}

	@Override
	@Transactional
	public Page<FlowEntity> findStateFlowByTemplateCode(Integer page, Integer pageCount, String templateCode) {
		return stateFlowDao.findStateFlowByTemplateCode(page, pageCount, templateCode);
	}

	@Override
	@Transactional
	public Page<FlowEntity> findStateFlowByTemplateCodeAndType(Integer page, Integer pageCount, String templateCode,
			String stateFlowType) {
		Page<FlowEntity> flowEntitys = null;
		if (StateFlow.ASSETS.name().equals(stateFlowType)) {
			flowEntitys = stateFlowDao.findAssetsStateFlowByTemplateCode(page, pageCount, templateCode);
		} else if (StateFlow.RESOURCES.name().equals(stateFlowType)) {
			flowEntitys = stateFlowDao.findResourcesStateFlowByTemplateCode(page, pageCount, templateCode);
		}
		return flowEntitys;
	}

	@Override
	@Transactional
	public List<EventEntity> findEventNames() {
		logger.info("获取事件配置文件所有事件名称");
		List<EventEntity> list = null;
		Map<String, ItamEvent> eventMap = ApplicationContextFactory.getBeansOfType(ItamEvent.class, false, false);
		if (eventMap != null && !eventMap.isEmpty()) {
			list = new ArrayList<EventEntity>();
			for (Map.Entry<String, ItamEvent> entry : eventMap.entrySet()) {
				ItamEvent itamEvent = entry.getValue();
				EventEntity eventEntity = new EventEntity();
				eventEntity.setBeanId(entry.getKey());
				eventEntity.setName(itamEvent.getEventName());
				list.add(eventEntity);
			}
		}
		return list;
	}

	@Override
	@Transactional
	public void saveFlowState(FlowEntity flowEntity) {
		stateFlowDao.saveStateFlow(flowEntity);
	}

	@Override
	@Transactional
	public void updateFlowState(FlowEntity flowEntity) {
		stateFlowDao.updateFlowState(flowEntity);
	}

	@Override
	@Transactional
	public void removeFlowStateByIds(List<Integer> ids) {
		stateFlowDao.removeFlowStateByIds(ids);
	}

	@Override
	@Transactional
	public void removeFlowStateById(Integer id) {
		stateFlowDao.removeFlowStateById(id);
	}

	@Override
	@Transactional
	public Map<String, Object> findStateFlowsByConditions(Map<String, String> paramsMap) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<Criterion> criterions = Lists.newArrayList();
		Iterator<String> iter = paramsMap.keySet().iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			String value = paramsMap.get(key);
			if (StringUtils.equals(key, Constant.PAGE) || StringUtils.equals(key, Constant.PAGE_COUNT)
					|| StringUtils.isBlank(value) || StringUtils.equals(key, Constant.METHOD)) {
				continue;
			}

			if (StringUtils.equals(key, "stateFlowtype")) {
				if (StateFlow.ASSETS.name().equals(value)) {
					criterions.add(Restrictions.isNotNull("endStatus"));
				} else if (StateFlow.RESOURCES.name().equals(value)) {
					criterions.add(Restrictions.isNotNull("resEndStatus"));
				}
			} else {
				criterions.add(Restrictions.eq(key, value));
			}
		}

		String pageString = paramsMap.get(Constant.PAGE);
		String pageCountString = paramsMap.get(Constant.PAGE_COUNT);
		NumberFormat numberFormat = NumberFormat.getInstance();

		Integer page = Constant.DEFAULT_PAGE;
		Integer pageCount = Constant.DEFAULT_PAGE_COUNT;
		try {
			page = numberFormat.parse(pageString).intValue();
			pageCount = numberFormat.parse(pageCountString).intValue();
		} catch (Exception e) {
			logger.error("Error page parameter format, page: {}, pageCount: {}", pageString, pageCountString);
		}
		
		Page<FlowEntity> pageList = stateFlowDao.findStateFlowsByConditions(page, pageCount, criterions);
		List<FlowEntity> flowEntitys = pageList.getItemList();

		resultMap.put("list", flowEntitys);
		resultMap.put("totalSize", pageList.getTotalSize());

		return resultMap;
	}
}

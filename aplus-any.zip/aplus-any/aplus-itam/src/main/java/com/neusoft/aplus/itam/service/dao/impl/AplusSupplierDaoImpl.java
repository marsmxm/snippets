package com.neusoft.aplus.itam.service.dao.impl;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.criterion.Example;
import org.springframework.stereotype.Component;

import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.itam.model.dbentity.table.AplusSupplierEntity;
import com.neusoft.aplus.itam.service.dao.IAplusSupplierDao;


@Component
public class AplusSupplierDaoImpl extends AbstractHibernateDao<AplusSupplierEntity> 
implements IAplusSupplierDao{

	@Override
	public void saveOrUpdateAplusSupplier(
			AplusSupplierEntity aplusSupplierEntity) {
		// TODO Auto-generated method stub
		saveOrUpdate(aplusSupplierEntity);
	}

	
	public List<AplusSupplierEntity> findAplusSupplierEntitys(boolean isprov,boolean isprod,boolean ischeck,boolean isdeve,boolean isserv,boolean istotal)
	{	// TODO Auto-generated method stub
		String hql = "from AplusSupplierEntity ase where ase.isprov = ? and ase.isprod = ? and ase.ischeck = ? and ase.isdeve = ? and ase.isserv = ? and ase.istotal = ?  ";
		return find(hql, String.valueOf(isprov), String.valueOf(isprod), String.valueOf(ischeck),String.valueOf(isdeve) ,String.valueOf(isserv) ,String.valueOf(istotal) );
	}

	@Override
	public void deleteAplusSupplierEntity(
			AplusSupplierEntity aplusSupplierEntity) {
		// TODO Auto-generated method stub
		remove(aplusSupplierEntity);
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<AplusSupplierEntity> findAplusSupplierEntitysByDevtype(String devtypeId) {
		// TODO Auto-generated method stub
		String sql = "select DISTINCT on(b.supplier_id, b.sup_name) b.* from aplus_device_model a,aplus_supplier b where a.supplier_id = b.supplier_id  "
				+ "and a.devtype_id=? "
				+ "ORDER  BY b.sup_name";
		SQLQuery query = createSQLQuery(sql, devtypeId);
		query.addEntity(AplusSupplierEntity.class);
		return query.list();
	}


	@Override
	public List<AplusSupplierEntity> findAplusSupplierByObject(
			AplusSupplierEntity aplusSupplierEntity) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<AplusSupplierEntity> results = getSession().createCriteria(AplusSupplierEntity.class)
				  .add( Example.create(aplusSupplierEntity) )
				  .list();
		return results;
	}
}

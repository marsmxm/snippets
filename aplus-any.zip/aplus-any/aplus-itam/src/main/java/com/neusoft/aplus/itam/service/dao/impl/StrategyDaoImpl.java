package com.neusoft.aplus.itam.service.dao.impl;

import java.util.List;

import org.hibernate.criterion.Criterion;
import org.springframework.stereotype.Component;

import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.itam.model.dbentity.table.StrategyEntify;
import com.neusoft.aplus.itam.service.dao.IStrategyDao;
import com.neusoft.aplus.model.dbentity.Page;

/**
 * @ClassName: StrategyDaoImpl 
 * @Description: 数据权限DAO实现类
 * @author lu.z
 * @date 2015年5月21日 下午4:55:31
 */
@Component
public class StrategyDaoImpl extends AbstractHibernateDao<StrategyEntify> implements IStrategyDao{

	@Override
	public void saveStrategy(StrategyEntify strategyEntify) {
		save(strategyEntify);
	}

	@Override
	public void updateStrategy(StrategyEntify strategyEntify) {
		update(strategyEntify);
	}

	@Override
	public void removeStrategys(List<String> ids) {
		if(ids != null && ids.size() > 0){
			String sql = "delete StrategyEntify where uuid in ";
			String condition = "(";
			for(int i = 0; i < ids.size(); i++){
				condition += "?,";
			}
			sql += condition.substring(0, condition.length() - 1) + ")";
			createQuery(sql, ids.toArray()).executeUpdate();
		}
	}

	@Override
	public Page<StrategyEntify> findStrategyByConditions(Integer page, Integer pageCount, List<Criterion> criterions) {
		return getPagedResult(page, pageCount, criterions);
	}

	@Override
	public StrategyEntify findStrategyById(String uuid) {
		String hql = "from StrategyEntify strategyEntify where strategyEntify.uuid = ?";
		List<StrategyEntify> list = find(hql, uuid);
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public StrategyEntify findStrategyByModelId(String modelId) {
		String hql = "from StrategyEntify strategyEntify where strategyEntify.modelId = ?";
		List<StrategyEntify> list = find(hql, modelId);
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}
}

package com.neusoft.aplus.itam.constant;
/**
 * @ClassName: Constant 
 * @Description: 常量类
 * @author lu.z
 * @date 2015年5月5日 上午9:18:46
 */
public interface Constant {
	/**
	 * 默认每页条数
	 */
	int DEFAULT_PAGE_COUNT = 10;
	/**
	 * 默认页数
	 */
	int DEFAULT_PAGE = 1;
	/**
	 * 页数
	 */
	String PAGE = "page";
	/**
	 * 每页条数
	 */
	String PAGE_COUNT = "pageCount";
	/**
	 * method参数
	 */
	String METHOD = "method";
}

package com.neusoft.aplus.itam.service.dao;

import com.neusoft.aplus.itam.model.dbentity.table.GenerateNoEntity;


/**
 * @ClassName: IGenerateNoDao 
 * @Description: 工单号DAO
 * @author lu.z
 * @date 2015年4月21日 上午11:41:27
 */
public interface IGenerateNoDao {
	/**
	 * @Description: 新增或修改编号信息
	 * @author lu.z
	 * @date 2015年4月21日 上午11:44:51 
	 * @param @param generateNoEntity
	 * @return void
	 * @throws
	 */
	public void saveOrUpdateBillNo(GenerateNoEntity generateNoEntity);
	/**
	 * @Description: 根据前缀查询编号信息
	 * @author lu.z
	 * @date 2015年4月21日 上午11:46:19 
	 * @param @param prefix
	 * @param @return
	 * @return GenerateNoEntity
	 * @throws
	 */
	public GenerateNoEntity findGenerateNoEntityByPrefix(String prefix);
}

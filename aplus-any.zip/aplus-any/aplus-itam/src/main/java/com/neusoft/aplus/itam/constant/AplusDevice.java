package com.neusoft.aplus.itam.constant;

/**
 * @ClassName: AplusDevice 
 * @Description: 台账表中设备除Attr属性外的毽值
 * @author zhangyun
 * @date 2015-4-22 下午6:03:36
 */
public enum AplusDevice {
	fqn, name,ip,category,deviceType,deviceVersion,conUuid,createDate,location
}

package com.neusoft.aplus.itam.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.model.dbentity.table.AplusSupplierEntity;
import com.neusoft.aplus.itam.service.bo.IAplusSupplierService;
import com.neusoft.aplus.itam.util.JSONUtil;
/**
 * @ClassName: AplusSupplierAction 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-23 下午4:56:20
 */
public class AplusSupplierAction extends BaseAction{
	private IAplusSupplierService aplusSupplierService;
	private Map<String, String> paramsMap;
	
	private static Logger log = LoggerFactory.getLogger(AplusSupplierAction.class);

	@Override
	public void doInit() {
		aplusSupplierService = ApplicationContextFactory.getBean(IAplusSupplierService.class);
		paramsMap = getRequestParameters();
	}

	@Override
	public void acceptRepresentation(Representation entity) {
		// TODO Auto-generated method stub
	}

	@Override
	public Representation represent() {
		// TODO Auto-generated method stub
		List<AplusSupplierEntity> supplierList = null;
		//json格式的查询条件
		//String queryParam = paramsMap.get("queryParam");
		String queryParam = "{\"supName\":\"dell1235\"}";
		log.info("-----queryParam1------------"+queryParam);
		AplusSupplierEntity aplusSupplierEntity = JSONUtil.getSimpleObject(queryParam,AplusSupplierEntity.class);
		supplierList = aplusSupplierService.findAplusSupplierByObject(aplusSupplierEntity) ;
		if (supplierList != null && !supplierList.isEmpty()) {
			HashMap<String, Object> resultMap = new HashMap<String, Object>();
			resultMap.put("total", supplierList.size());
			resultMap.put("rows", supplierList);
			return createObjectRepresentation(resultMap);
		}
		return null;
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub
		try {
			String supplierId = (String) paramsMap.get("supplierId");
			AplusSupplierEntity aplusSupplierEntity = new AplusSupplierEntity();
			aplusSupplierEntity.setSupplierId(supplierId);
			aplusSupplierService.deleteAplusSupplierEntity(aplusSupplierEntity);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();
	}

	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		AplusSupplierEntity aplusSupplierEntity = null;
		try {
			aplusSupplierEntity = getObjectsFromRepresentation(entity, new TypeReference<AplusSupplierEntity>() {
			});
			if (aplusSupplierEntity != null) {
				aplusSupplierService.saveOrUpdateAplusSupplier(aplusSupplierEntity);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();
	}

}

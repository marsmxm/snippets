package com.neusoft.aplus.itam.model.bizentity;

import java.io.Serializable;

/**
 * @ClassName: EventEntity 
 * @Description: 事件实体类
 * @author lu.z
 * @date 2015年5月4日 上午9:33:47
 */
public class EventEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1053444807135408780L;
	
	/**
	 * 配置文件中配置的bean id
	 */
	private String beanId;
	/**
	 * 配置文件中配置的事件名称
	 */
	private String name;
	
	public String getBeanId() {
		return beanId;
	}
	public void setBeanId(String beanId) {
		this.beanId = beanId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}

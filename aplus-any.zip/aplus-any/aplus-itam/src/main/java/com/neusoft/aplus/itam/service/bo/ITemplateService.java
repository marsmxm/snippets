package com.neusoft.aplus.itam.service.bo;

import java.util.List;
import com.neusoft.aplus.itam.model.dbentity.table.TemplateEntity;

/**
 * @ClassName: ITemplateService 
 * @Description: 模板类接口
 * @author lu.z
 * @date 2015年4月23日 下午1:42:19
 */
public interface ITemplateService {
	/**
	 * @Description: 重新载入模板
	 * @author lu.z
	 * @date 2015年4月23日 下午1:42:53 
	 * @param 
	 * @return void
	 * @throws
	 */
	public void reloadTemplate();
	
	/**
	 * @Description: 保存模板
	 * @author lu.z
	 * @date 2015年4月23日 下午1:45:15 
	 * @param @param templateEntity
	 * @return void
	 * @throws
	 */
	public void saveTemplate(TemplateEntity templateEntity);
	
	/**
	 * @Description: 修改模板
	 * @author lu.z
	 * @date 2015年4月23日 下午1:45:46 
	 * @param @param templateEntity
	 * @return void
	 * @throws
	 */
	public void updateTemplate(TemplateEntity templateEntity);
	
	/**
	 * @Description: 根据id数组删除模板
	 * @author lu.z
	 * @date 2015年4月23日 下午1:46:16 
	 * @param @param ids
	 * @return void
	 * @throws
	 */
	public void removeTemplateByIds(List<Integer> ids);
	
	/**
	 * @Description: 根据id删除模板
	 * @author lu.z
	 * @date 2015年4月23日 下午2:00:21 
	 * @param @param id
	 * @return void
	 * @throws
	 */
	public void removeTemplateById(Integer id);
}

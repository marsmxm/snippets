package com.neusoft.aplus.itam.service.bo.impl;

import java.util.Date;
import java.util.List;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import com.google.common.collect.Lists;
import com.neusoft.aplus.itam.constant.BillStatus;
import com.neusoft.aplus.itam.handler.IAplusBillNo;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillDeviceEntity;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillEntity;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;
import com.neusoft.aplus.itam.model.dbentity.table.FlowEntity;
import com.neusoft.aplus.itam.model.dbentity.table.GenerateNoEntity;
import com.neusoft.aplus.itam.service.bo.IAplusBillService;
import com.neusoft.aplus.itam.service.bo.IAplusPresetDevInfoService;
import com.neusoft.aplus.itam.service.bo.IStateFlowService;
import com.neusoft.aplus.itam.service.dao.IAplusBillDao;
import com.neusoft.aplus.itam.service.dao.IAplusBillDeviceDao;
import com.neusoft.aplus.itam.service.dao.IAplusBillLockDao;
import com.neusoft.aplus.itam.service.dao.IGenerateNoDao;
import com.neusoft.aplus.model.dbentity.Page;

@Component
public class AplusBillServiceImpl implements IAplusBillService {

	private static final int NUMBER_COUNT = 7;

	@Autowired
	private IAplusBillDao aplusBillDao;

	@Autowired
	private IAplusBillNo aplusBillNo;

	@Autowired
	private IAplusBillDeviceDao aplusBillDeviceDao;

	@Autowired
	private IStateFlowService stateFlowService;

	@Autowired
	private IAplusBillLockDao aplusBillLokcDao;

	@Autowired
	private IAplusPresetDevInfoService aplusPresetDevInfoService;

	@Autowired
	private IGenerateNoDao generateNoDao;

	@Transactional
	@Override
	public String saveAplusBill(String billType, String username) {
		AplusBillEntity aplusBill = new AplusBillEntity();
		aplusBill.setBillNo(aplusBillNo.generationBillNo(billType));// 获取工单号
		aplusBill.setBillType(billType);
		String billStatus = BillStatus.SAVE.name();
		FlowEntity flowEntity = stateFlowService
				.findStateFlowByBillType(billType);
		String billName = flowEntity.getName();
		aplusBill.setBillStatus(billStatus);
		aplusBill.setBillName(billName);
		aplusBill.setBillAppUser(username);
		aplusBill.setBillAppTime(new Date());
		return aplusBillDao.saveAplusBill(aplusBill);
	}

	@Transactional
	@Override
	public void deleteAplusBill(String billUuid) {
		// 删除工单
		AplusBillEntity aplusBill = aplusBillDao.findBillByUuid(billUuid);
		FlowEntity flowEntity = stateFlowService
				.findStateFlowByBillType(aplusBill.getBillType());
		aplusBillDao.deleteAplusBill(aplusBill);
		// 删除工单中的设备

		if (flowEntity.getDeviceSource().equals("P"))// 如果是预置设备 回退到货数量
		{
			List<AplusBillDeviceEntity> list = aplusBillDeviceDao
					.findAplusDeviceByBillUuid(billUuid);
			for (AplusBillDeviceEntity e : list) {
				AplusPresetDevInfoEntity presetDevInfoEntity = aplusPresetDevInfoService
						.findAplusPresetDevInfoByUuid(e.getPresetDevUuid());
				presetDevInfoEntity.setArrivalNumber(presetDevInfoEntity
						.getArrivalNumber() - 1);
				aplusPresetDevInfoService
						.backAplusPresrtDevInfoArrivalNumber(presetDevInfoEntity);
			}
		}
		aplusBillDeviceDao.deleteAplusBillDeviceByBillUuid(billUuid);
		aplusBillLokcDao.deleteAplusBillLockByBillUuid(billUuid);
	}

	@Transactional
	@Override
	public void commitAplusBill(String uuid) {
		aplusBillDao.commitAplusBillStatus(uuid);
	}

	@Transactional
	@Override
	public void finishAplusBill(String uuid) {
		stateFlowService.doBillFinish(uuid);
	}

	@Override
	@Transactional
	public String generateNo(String prefix) {
		GenerateNoEntity generateNoEntity = generateNoDao.findGenerateNoEntityByPrefix(prefix);
		if (generateNoEntity != null) {
			generateNoEntity.setNumber(generateNoEntity.getNumber() + 1);
		} else {
			generateNoEntity = new GenerateNoEntity();
			generateNoEntity.setPrefix(prefix);
			generateNoEntity.setNumber(1);
		}
		generateNoDao.saveOrUpdateBillNo(generateNoEntity);
		String number = generateNoEntity.getNumber().toString();
		int numLen = number.length();
		if (numLen < NUMBER_COUNT) {
			for (int i = 0; i < NUMBER_COUNT - numLen; i++) {
				number = "0" + number;
			}
		}
		return generateNoEntity.getPrefix() + number;
	}

	@Override
	@Transactional
	public Page<AplusBillEntity> findBillByBillType(Integer page,
			Integer pageCount, String billType) {
		List<Criterion> criterions = Lists.newArrayList();
		criterions.add(Restrictions.eq("billType", billType));
		return aplusBillDao.findBillByBillType(page, pageCount, criterions);
	}
	@Override
	@Transactional
	public AplusBillEntity findBillByUuid(String Uuid)
	{
		return aplusBillDao.findBillByUuid(Uuid);
	}
}

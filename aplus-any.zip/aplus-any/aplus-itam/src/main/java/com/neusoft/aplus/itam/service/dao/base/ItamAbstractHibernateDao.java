package com.neusoft.aplus.itam.service.dao.base;

import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.neusoft.aplus.common.db.AbstractHibernateDao;

public abstract class ItamAbstractHibernateDao<T> extends AbstractHibernateDao<T> {
	private static final Log log = LogFactory.getLog(ItamAbstractHibernateDao.class);

	/**
	 * @Description: 批量新增数据
	 * @author lu.z
	 * @date 2015年4月13日 下午3:03:08
	 * @param @param entities
	 * @return void
	 * @throws
	 */
	public void batchSave(List<T> entities) {
		if (entities == null || entities.isEmpty()) {
			log.warn("传入参数为空  entities: " + entities);
			return;
		}
		int count = 0;
		for (T entity : entities) {
			save(entity);
			count++;
			if (count % BATCH_SIZE == 0) {
				flushSession();
				clear();
			}
		}
	}

	/**
	 * @Description: 传入参数数组，查询单条数据
	 * @author lu.z
	 * @date 2015年4月13日 下午3:03:18
	 * @param @param paramsMap
	 * @param @return
	 * @return T
	 * @throws
	 */
	public T findEntityByConditions(Map<String, Object> paramsMap) {
		List<T> list = findListByConditions(paramsMap);
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}

	/**
	 * @Description: 传入参数数组，查询多条数据
	 * @author lu.z
	 * @date 2015年4月13日 下午3:05:43
	 * @param @param paramsMap
	 * @param @return
	 * @return List<T>
	 * @throws
	 */
	public List<T> findListByConditions(Map<String, Object> paramsMap) {
		List<T> list = null;
		String hql = "from " + getPersistentClass().getSimpleName() + " entity ";
		Object objs[] = null;
		if (paramsMap != null && !paramsMap.isEmpty()) {
			hql += "where";
			objs = new Object[paramsMap.size()];
			int index = 0;
			for (Map.Entry<String, Object> entry : paramsMap.entrySet()) {
				hql += " entity." + entry.getKey() + " = ? and";
				objs[index] = entry.getValue();
				index++;
			}
		}
		if (objs != null) {
			hql = hql.substring(0, hql.length() - 3);
			list = find(hql, objs);
		}
		return list;
	}
}

package com.neusoft.aplus.itam.service.dao.impl;

import java.util.List;

import org.springframework.stereotype.Component;

import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPositionDefineEntity;
import com.neusoft.aplus.itam.service.dao.IAplusPositionDefineDao;

@Component
public class AplusPositionDefineDaoImpl extends AbstractHibernateDao<AplusPositionDefineEntity> 
implements IAplusPositionDefineDao{
	
	@Override
	public void saveOrUpdateAplusPositionDefine(
			AplusPositionDefineEntity aplusPositionDefineEntity) {
		// TODO Auto-generated method stub
		saveOrUpdate(aplusPositionDefineEntity);
	}

	@Override
	public List<AplusPositionDefineEntity> findAplusPositionDefines(
			int positionLevel) {
		// TODO Auto-generated method stub
		String hql = "from AplusPositionDefineEntity adt where adt.positionLevel<= ? ";
		return find(hql, positionLevel);
	}

	@Override
	public void deleteAplusPositionDefine(
			AplusPositionDefineEntity aplusPositionDefineEntity) {
		// TODO Auto-generated method stub
		remove(aplusPositionDefineEntity);
	}
	@Override
	public List<AplusPositionDefineEntity> findAplusPositionDefines() {
		// TODO Auto-generated method stub
		String hql = "from AplusPositionDefineEntity adt ";
		return find(hql);
	}

	@Override
	public List<AplusPositionDefineEntity> findAplusPositionDefineById(
			String positionId) {
		// TODO Auto-generated method stub
		String hql = "from AplusPositionDefineEntity adt where adt.positionId= ? ";
		return find(hql, positionId);
	}

	@Override
	public void saveAplusPositionDefine(
			AplusPositionDefineEntity aplusPositionDefineEntity) {
		// TODO Auto-generated method stub
		save(aplusPositionDefineEntity);
	}
}

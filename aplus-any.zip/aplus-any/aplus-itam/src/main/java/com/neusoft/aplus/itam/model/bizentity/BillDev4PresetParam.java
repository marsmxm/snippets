package com.neusoft.aplus.itam.model.bizentity;

import java.io.Serializable;
import java.util.List;

import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;

/**
 * @author wangcd
 * @date 2015年4月27日 下午3:38:40
 */
public class BillDev4PresetParam implements Serializable {
	private static final long serialVersionUID = 4262409628136588621L;

	private String billUuid;
	private String billNo;
	private List<AplusPresetDevInfoEntity> presetDevList;
	
	public String getBillUuid() {
		return billUuid;
	}
	public void setBillUuid(String billUuid) {
		this.billUuid = billUuid;
	}
	public String getBillNo() {
		return billNo;
	}
	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}
	public List<AplusPresetDevInfoEntity> getPresetDevList() {
		return presetDevList;
	}
	public void setPresetDevList(List<AplusPresetDevInfoEntity> presetDevList) {
		this.presetDevList = presetDevList;
	}
	
}

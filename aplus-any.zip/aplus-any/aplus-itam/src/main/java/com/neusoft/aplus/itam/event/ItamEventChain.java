package com.neusoft.aplus.itam.event;

import java.util.Iterator;
import java.util.List;

import com.google.common.collect.Lists;
import com.neusoft.aplus.common.event.EventChain;
import com.neusoft.aplus.common.event.Event;
import com.neusoft.aplus.common.event.Input;
import com.neusoft.aplus.common.event.Output;

public class ItamEventChain extends EventChain<Boolean> {
	private List<Event> events = Lists.newArrayList();
	private Input input;
	private Output output;
	
	public ItamEventChain(){
		
	}
	
	public ItamEventChain(Input input, Output output) {
		this.input = input;
		this.output = output;
	}
	
	/**
	 * 事件链异步执行方法
	 */
	@Override
	public Boolean call() throws Exception {
		try {
			fireEvents(this);
		} catch(Exception e) {
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}

	/**
	 * 向事件链中添加单个事件
	 */
	@Override
	public EventChain<Boolean> addEvent(Event e) {
		events.add(e);
		return this;
	}

	/**
	 * 向事件链中添加事件集合
	 */
	@Override
	public EventChain<Boolean> addEvents(Event... es) {
		for (int i = 0; i < es.length; i++) {
			events.add(es[i]);
		}
		return this;
	}

	/**
	 * 执行事件链
	 */
	@Override
	public void fireEvents(EventChain<Boolean> chain) {
		fireEvents(input, output, chain);
	}
	
	/**
	 * 执行事件链，带入事件链输入和输出
	 */
	@Override
	public void fireEvents(Input input, Output output, EventChain<Boolean> chain) {
		for(int i = 0; i < events.size(); i++){
			events.get(i).fireEvent(input, output, chain);
		}
	}
	
	public EventChain<Boolean> addEvents(List<Event> eventList) {
		if(eventList != null && !eventList.isEmpty()){
			Iterator<Event> iterator = eventList.iterator();
			while(iterator.hasNext()){
				events.add(iterator.next());
			}
		}
		return this;
	}

	public List<Event> getEvents() {
		return events;
	}

	public void setEvents(List<Event> events) {
		this.events = events;
	}

	public Input getInput() {
		return input;
	}

	public void setInput(Input input) {
		this.input = input;
	}

	public Output getOutput() {
		return output;
	}

	public void setOutput(Output output) {
		this.output = output;
	}
}


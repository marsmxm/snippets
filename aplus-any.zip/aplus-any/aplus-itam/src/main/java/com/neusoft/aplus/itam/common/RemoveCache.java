package com.neusoft.aplus.itam.common;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @ClassName: RemoveCache 
 * @Description: 自定义删除缓存标签
 * @author lu.z
 * @date 2015年4月14日 上午10:23:39
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface RemoveCache {
	/**
	 *是否使用缓存，默认使用
	 */
	boolean value() default true;
	/**
	 *删除缓存key
	 */
	String[] cacheKeys() default {};
	/**
	 *删除缓存key,及对应以参数拼接的缓存信息
	 */
	String[] cacheKeysArgs() default {};
	/**
	 * 缓存名称，分缓存存储时可以用到该属性
	 */
	String cacheName() default "itamCache";
}

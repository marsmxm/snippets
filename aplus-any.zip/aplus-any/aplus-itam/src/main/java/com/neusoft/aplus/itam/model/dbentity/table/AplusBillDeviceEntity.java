package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.neusoft.aplus.model.usertype.StringJsonUserType;

/**
 * @ClassName: AplusBillDeviceEntity
 * @Description: TODO
 * @author zhangyun
 * @date 2015-4-9 下午4:16:43
 */
@TypeDefs({ @TypeDef(name = "StringJsonObject", typeClass = StringJsonUserType.class) })
@Entity
@Table(name = "aplus_bill_device")
public class AplusBillDeviceEntity implements Serializable, Cloneable {

	private static final long serialVersionUID = 1L;
	private static final String DEFAULT_VERSION = "v1.0";
	private static final String IS_CHECK = "1";
	private String uuid;// uuid
	private String billNo;// 所属工单号
	private String billUuid;// 所属工单uuid
	private String devFqn;// 设备fqn
	private String deviceType;// 资源类型
	private String deviceVersion = DEFAULT_VERSION;// 版本号，一般在资源为软件的场景下涉及
	private String isCheck = IS_CHECK;// 是否选择
	private String attr;// 需要修改的属性，json格式存入数据库
	private String attrNew;// 修改后的属性，json格式存入数据库
	private String presetDevUuid;// 预置设备UUID
	private String category;

	@Column(name = "category")
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Column(name = "preset_dev_uuid")
	public String getPresetDevUuid() {
		return presetDevUuid;
	}

	public void setPresetDevUuid(String presetDevUuid) {
		this.presetDevUuid = presetDevUuid;
	}

	@Column(name = "bill_no")
	public String getBillNo() {
		return billNo;
	}

	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}

	@Column(name = "bill_uuid")
	public String getBillUuid() {
		return billUuid;
	}

	public void setBillUuid(String billUuid) {
		this.billUuid = billUuid;
	}

	@Column(name = "dev_fqn")
	public String getDevFqn() {
		return devFqn;
	}

	public void setDevFqn(String devFqn) {
		this.devFqn = devFqn;
	}

	@Column(name = "device_type")
	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	@Column(name = "device_version")
	public String getDeviceVersion() {
		return deviceVersion;
	}

	public void setDeviceVersion(String deviceVersion) {
		this.deviceVersion = deviceVersion;
	}

	@Column(name = "is_check")
	public String getIsCheck() {
		return isCheck;
	}

	public void setIsCheck(String isCheck) {
		this.isCheck = isCheck;
	}

	@Column(name = "attr")
	@Type(type = "StringJsonObject")
	public String getAttr() {
		return attr;
	}

	public void setAttr(String attr) {
		this.attr = attr;
	}

	@Column(name = "attr_new")
	@Type(type = "StringJsonObject")
	public String getAttrNew() {
		return attrNew;
	}

	public void setAttrNew(String attrNew) {
		this.attrNew = attrNew;
	}

	@Id
	@GeneratedValue(generator = "paymentableGenerator")
	@GenericGenerator(name = "paymentableGenerator", strategy = "uuid")
	@Column(name = "uuid")
	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public AplusBillDeviceEntity clone() {
		try {
			return (AplusBillDeviceEntity) super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String toString() {
		return "AplusBillDeviceEntity [uuid=" + uuid + ", bill_no=" + billNo
				+ ", bill_uuid=" + billUuid + ", dev_fqn=" + devFqn
				+ ", device_type=" + deviceType + ", device_version="
				+ deviceVersion + ", is_check=" + isCheck + ", attr=" + attr
				+ ", attr_new=" + attrNew + "]";
	}
}

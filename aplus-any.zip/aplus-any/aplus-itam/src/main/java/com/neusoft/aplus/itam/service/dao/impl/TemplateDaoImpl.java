package com.neusoft.aplus.itam.service.dao.impl;

import java.util.List;

import org.springframework.stereotype.Component;

import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.itam.model.dbentity.table.TemplateEntity;
import com.neusoft.aplus.itam.service.dao.ITemplateDao;

/**
 * @ClassName: TemplateDaoImpl
 * @Description: 模板操作数据库实现类
 * @author lu.z
 * @date 2015年4月9日 下午1:36:07
 */
@Component
public class TemplateDaoImpl extends AbstractHibernateDao<TemplateEntity> implements ITemplateDao {

	@Override
	public void saveTemplate(TemplateEntity templateEntity) {
		saveOrUpdate(templateEntity);
	}

	@Override
	public void removeTemplate(String templateCode) {
		String hql = "delete TemplateEntity where templateCode = ?";
		createQuery(hql, templateCode).executeUpdate();
	}

	@Override
	public TemplateEntity findTemplateByCode(String templateCode) {
		return findUniqueBy("templateCode", templateCode);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> findAllTemplateCodes() {
		String hql = "select t.templateCode from TemplateEntity t";
		return createQuery(hql).list();
	}

	@Override
	public void removeTemplates(List<String> templateCodes) {
		if(templateCodes != null && !templateCodes.isEmpty()){
			String sql = "delete TemplateEntity where templateCode in ";
			String condition = "(";
			for(int i = 0; i < templateCodes.size(); i++){
				condition += "?,";
			}
			sql += condition.substring(0, condition.length() - 1) + ")";
			createQuery(sql, templateCodes.toArray()).executeUpdate();
		}
	}

	@Override
	public void saveTemplates(List<TemplateEntity> templateEntitys) {
		batchSaveOrUpdate(templateEntitys);
	}

	@Override
	public void updateTemplate(TemplateEntity templateEntity) {
		update(templateEntity);
	}

	@Override
	public void removeTemplateByIds(List<Integer> ids) {
		if(ids != null && !ids.isEmpty()){
			String sql = "delete TemplateEntity where id in ";
			String condition = "(";
			for(int i = 0; i < ids.size(); i++){
				condition += "?,";
			}
			sql += condition.substring(0, condition.length() - 1) + ")";
			createQuery(sql, ids.toArray()).executeUpdate();
		}
	}

	@Override
	public void removeTemplateById(Integer id) {
		String sql = "delete TemplateEntity where id = ? ";
		createQuery(sql, id).executeUpdate();
	}
}

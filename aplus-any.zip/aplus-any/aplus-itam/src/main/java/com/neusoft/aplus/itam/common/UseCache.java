package com.neusoft.aplus.itam.common;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @ClassName: UseCache 
 * @Description: 自定义是否使用缓存标签
 * @author lu.z
 * @date 2015年4月14日 上午10:23:39
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface UseCache {
	/**
	 *是否使用缓存，默认使用
	 */
	boolean value() default true;
	/**
	 *缓存key，配置到类名+方法名，如果有参数的方法会自动加上参数作为key的一部分
	 */
	String cacheKey() default "";
	/**
	 * 缓存名称，分缓存存储时可以用到该属性
	 */
	String cacheName() default "itamCache";
}

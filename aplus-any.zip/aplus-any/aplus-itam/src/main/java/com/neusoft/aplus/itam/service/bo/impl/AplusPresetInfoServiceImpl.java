package com.neusoft.aplus.itam.service.bo.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetInfoEntity;
import com.neusoft.aplus.itam.service.bo.IAplusPresetInfoService;
import com.neusoft.aplus.itam.service.dao.IAplusPresetDevInfoDao;
import com.neusoft.aplus.itam.service.dao.IAplusPresetInfoDao;
import com.neusoft.aplus.model.dbentity.Page;

@Component
public class AplusPresetInfoServiceImpl implements IAplusPresetInfoService {
	@Autowired
	private IAplusPresetInfoDao aplusPresetInfoDao;

	@Autowired
	private IAplusPresetDevInfoDao aplusPresetDevInfoDao;

	@Transactional
	@Override
	public String saveAplusPresrtInfo(AplusPresetInfoEntity entity) { 
		Map<String, String> querymap = new HashMap<String, String>();
		querymap.put("presetNo", entity.getPresetNo());
		List<AplusPresetInfoEntity> list = aplusPresetInfoDao
				.findAplusPresetInfoByMap(querymap);
		if (list.size() == 0) {
			return aplusPresetInfoDao.saveAplusPresrtInfo(entity);
		} else {
			// 合同号不能重复
			return "error";
		}
	}

	@Transactional
	@Override
	public void updateAplusPresrtInfo(AplusPresetInfoEntity entity) {
		List<AplusPresetInfoEntity> list = aplusPresetInfoDao
				.findAplusPresetInfoByPresetNoAndUuid(entity.getPresetNo(), entity.getUuid());
		if (list.size() == 0) {
			aplusPresetInfoDao.updateAplusPresrtInfo(entity);
			// 预置设备表中预置号修改
			List<AplusPresetDevInfoEntity> aplusPresetDevInfoEntityList = aplusPresetDevInfoDao
					.findAplusPresetInfoByPresetUuid(entity.getUuid());
			for (AplusPresetDevInfoEntity e : aplusPresetDevInfoEntityList) {
				e.setPresetNo(entity.getPresetNo());
				aplusPresetDevInfoDao.updateAplusPresrtDevInfo(e);
			}
		} else {
			// 预置号不能重复
		}
	}

	@Transactional
	@Override
	public void deleteAplusPresrtInfo(String uuid) {
		AplusPresetInfoEntity presetInfoEntity = new AplusPresetInfoEntity();
		List<AplusPresetDevInfoEntity> list = aplusPresetDevInfoDao
				.findAplusPresetInfoByPresetUuid(uuid);
		int i = 0;
		for (AplusPresetDevInfoEntity e : list) {
			i += e.getArrivalNumber();
		}
		if (i == 0) {
			presetInfoEntity.setUuid(uuid);
			aplusPresetInfoDao.deleteAplusPresrtInfo(presetInfoEntity);
		} else {
			// 该预置中已有设备到货不可删除
		}

	}

	@Transactional
	@Override
	public List<AplusPresetInfoEntity> findaplusPresetInfoByPresetType(
			String presetType) {
		Map<String, String> querymap = new HashMap<String, String>();
		querymap.put("presetType", presetType);
		return aplusPresetInfoDao.findAplusPresetInfoByMap(querymap);
	}

	@Transactional
	@Override
	public Page<AplusPresetInfoEntity> findaplusPresetInfo(Integer page,
			Integer pageCount, String presetUuid) {
		List<Criterion> criterions = Lists.newArrayList();
		criterions.add(Restrictions.eq("uuid", presetUuid));
		return aplusPresetInfoDao.findaplusPresetInfo(page, pageCount,
				criterions);
	}

}

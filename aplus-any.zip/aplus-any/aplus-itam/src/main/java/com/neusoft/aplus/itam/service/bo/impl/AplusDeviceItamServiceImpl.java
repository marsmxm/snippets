package com.neusoft.aplus.itam.service.bo.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Criterion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.neusoft.aplus.itam.model.dbentity.table.FlowEntity;
import com.neusoft.aplus.itam.service.bo.IAplusDeviceItamService;
import com.neusoft.aplus.itam.service.bo.IStateFlowService;
import com.neusoft.aplus.model.dbentity.Page;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;
import com.neusoft.aplus.service.core.service.dao.AplusDeviceDao;
import com.neusoft.aplus.service.core.util.JsonDBUtil;

@Component
public class AplusDeviceItamServiceImpl implements IAplusDeviceItamService {
	@Autowired
	private AplusDeviceDao aplusDeviceDao;
	@Autowired
	IStateFlowService stateFlowService;
	@Override
	@Transactional
	public Page<AplusDeviceEntity> findAplusDeivce(Map<String, String> dimMap,
			Map<String, String> preciseMap,String billType, Integer page, Integer pageCount) {
		FlowEntity entity = stateFlowService.findStateFlowByBillType(billType);
		preciseMap.put("assetStatus", entity.getStartStatus());
		preciseMap.put("resStatus", entity.getResStartStatus());
		List<Criterion> dimcriterion = JsonDBUtil
				.getCriterionForDimQuery(dimMap);
		List<Criterion> precisecriterion = JsonDBUtil
				.getCriterionForPreciseQuery(preciseMap);
		dimcriterion.addAll(precisecriterion);
		return aplusDeviceDao.findPagedAplusDevices(page, pageCount,
				dimcriterion);
	}
}

package com.neusoft.aplus.itam.event.evts;

import java.util.Iterator;
import java.util.List;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import com.neusoft.aplus.common.event.EventChain;
import com.neusoft.aplus.common.event.Input;
import com.neusoft.aplus.common.event.Output;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.event.ItamEvent;
import com.neusoft.aplus.itam.event.params.StateFlowOutput;
import com.neusoft.aplus.itam.exception.ItamRestException;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillDeviceEntity;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillEntity;
import com.neusoft.aplus.itam.model.dbentity.table.FlowEntity;
import com.neusoft.aplus.itam.service.dao.IAplusBillDao;
import com.neusoft.aplus.itam.service.dao.IAplusBillDeviceDao;

/**
 * @ClassName: FinishedEvent
 * @Description: 工单完成事件
 * @author lu.z
 * @date 2015年4月9日 上午10:44:55
 */
public class StateFlowEvent extends ItamEvent {
	private static Logger log = Logger.getLogger(StateFlowEvent.class);
	/**
	 * 工单信息DAO
	 */
	private IAplusBillDao aplusBillDao;
	/**
	 * 设备DAO
	 */
	private IAplusBillDeviceDao aplusBillDeviceDao;

	@Override
	public <T> void fireEvent(Input input, Output output, EventChain<T> chain) {
		log.info("开始执行工单状态变更事件");
		// 初始化DAO
		aplusBillDao = ApplicationContextFactory.getBean(IAplusBillDao.class);
		aplusBillDeviceDao = ApplicationContextFactory.getBean(IAplusBillDeviceDao.class);

		StateFlowOutput stateFlowOutput = (StateFlowOutput) output;

		AplusBillEntity aplusBillEntityOut = stateFlowOutput.getAplusBillEntity();
		List<AplusBillDeviceEntity> aplusBillDeviceEntitysOut = stateFlowOutput.getAplusBillDeviceEntitys();
		FlowEntity flowEntity = stateFlowOutput.getFlowEntity();

		// 调用工单完成接口,aplusBillEntityOut不用校验null
		aplusBillDao.finishAplusBillStatus(aplusBillEntityOut.getUuid());

		// 判断状态机资产状态
		String endStatus = flowEntity.getEndStatus() == null ? "" : flowEntity.getEndStatus();
		String resEndStatus = flowEntity.getResEndStatus() == null ? "" : flowEntity.getResEndStatus();
		StringBuffer stringBuffer = new StringBuffer("");

		stringBuffer = stringBuffer.append("{\"assetStatus\":\"").append(endStatus).append("\"")
				.append(",\"resStatus\":\"").append(resEndStatus).append("\"").append("}");

		String target = stringBuffer.toString();
		Iterator<AplusBillDeviceEntity> iterator = aplusBillDeviceEntitysOut.iterator();
		while (iterator.hasNext()) {
			AplusBillDeviceEntity aplusBillDeviceEntity = iterator.next();
			// 修改资源状态属性,attr_new中资源属性
			String attrNew = aplusBillDeviceEntity.getAttrNew();
			String attr = null;
			try {
				attr = addAttr(attrNew, target);
			} catch (JSONException e) {
				// 抛出类转换异常
				ItamRestException.throwException(ItamRestException.UPDATE_ATTRIBUTES_TRANSITION_ERROR, e, null, null);
			}
			aplusBillDeviceEntity.setAttrNew(attr);
		}
		// 修改attrNew
		aplusBillDeviceDao.batchUpdateAplusBillDevice(aplusBillDeviceEntitysOut);
	}

	/**
	 * @Description: 往source中添加target中的属性
	 * @author lu.z
	 * @date 2015年4月17日 下午3:17:30
	 * @param @param source
	 * @param @param target
	 * @param @return
	 * @param @throws JSONException
	 * @return String
	 * @throws
	 */
	@SuppressWarnings("unchecked")
	private String addAttr(String source, String target) throws JSONException {
		JSONObject sourceJSONObject = new JSONObject(source);
		JSONObject targetJSONObject = new JSONObject(target);
		if (sourceJSONObject != null && targetJSONObject != null) {
			Iterator<String> iterator = targetJSONObject.keys();
			while (iterator.hasNext()) {
				String key = iterator.next();
				sourceJSONObject.put(key, targetJSONObject.get(key));
			}
		}
		return sourceJSONObject.toString();
	}
}

package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @ClassName: FlowEntity
 * @Description: 状态机实体类(aplus_state_flow)
 * @author lu.z
 * @date 2015年4月9日 上午9:43:34
 */

@Entity
@Table(name = "aplus_state_flow")
public class FlowEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1296519603038653782L;

	/**
	 * 主键
	 */
	private Integer id;
	/**
	 * 工单类型
	 */
	private String billType;
	/**
	 * 名称
	 */
	private String name;
	/**
	 * 资产开始状态
	 */
	private String startStatus;
	/**
	 * 资产结束状态
	 */
	private String endStatus;
	/**
	 * 资源开始状态
	 */
	private String resStartStatus;
	/**
	 * 资源结束状态
	 */
	private String resEndStatus;
	/**
	 * 当前billType，订单提交前可修改属性，以","分隔
	 */
	private String beforeCommitAttrs;
	/**
	 * 当前billType，订单提交后可修改属性，以","分隔
	 */
	private String afterCommitAttrs;
	/**
	 * 当前billType执行流程配置，按步骤顺序以“,”分隔
	 */
	private String events;
	/**
	 * 模板Code
	 */
	private String templateCode;
	/**
	 * 设备来源  P-预置；L-台账
	 */
	private String deviceSource;

	@Id
	@GeneratedValue
	@Column(name = "id")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "bill_type")
	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	@Column(name = "name")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "start_status")
	public String getStartStatus() {
		return startStatus;
	}

	public void setStartStatus(String startStatus) {
		this.startStatus = startStatus;
	}

	@Column(name = "end_status")
	public String getEndStatus() {
		return endStatus;
	}

	public void setEndStatus(String endStatus) {
		this.endStatus = endStatus;
	}

	@Column(name = "res_start_status")
	public String getResStartStatus() {
		return resStartStatus;
	}

	public void setResStartStatus(String resStartStatus) {
		this.resStartStatus = resStartStatus;
	}

	@Column(name = "res_end_status")
	public String getResEndStatus() {
		return resEndStatus;
	}

	public void setResEndStatus(String resEndStatus) {
		this.resEndStatus = resEndStatus;
	}

	@Column(name = "before_commit_attrs")
	public String getBeforeCommitAttrs() {
		return beforeCommitAttrs;
	}

	public void setBeforeCommitAttrs(String beforeCommitAttrs) {
		this.beforeCommitAttrs = beforeCommitAttrs;
	}

	@Column(name = "after_commit_attrs")
	public String getAfterCommitAttrs() {
		return afterCommitAttrs;
	}

	public void setAfterCommitAttrs(String afterCommitAttrs) {
		this.afterCommitAttrs = afterCommitAttrs;
	}

	@Column(name = "events")
	public String getEvents() {
		return events;
	}

	public void setEvents(String events) {
		this.events = events;
	}

	@Column(name = "template_code")
	public String getTemplateCode() {
		return templateCode;
	}

	public void setTemplateCode(String templateCode) {
		this.templateCode = templateCode;
	}
	
	@Column(name = "device_source")
	public String getDeviceSource() {
		return deviceSource;
	}

	public void setDeviceSource(String deviceSource) {
		this.deviceSource = deviceSource;
	}

	@Override
	public String toString() {
		return "FlowEntity [id=" + id + ", billType=" + billType + ", name=" + name + ", startStatus=" + startStatus
				+ " + ,endStatus" + endStatus + ", resStartStatus=" + resStartStatus + ", resEndStatus=" + resEndStatus
				+ ", beforeCommitAttrs=" + beforeCommitAttrs + ", afterCommitAttrs=" + afterCommitAttrs + ", events="
				+ events + ", templateCode=" + templateCode + ", deviceSource=" + deviceSource + "]";
	}
}

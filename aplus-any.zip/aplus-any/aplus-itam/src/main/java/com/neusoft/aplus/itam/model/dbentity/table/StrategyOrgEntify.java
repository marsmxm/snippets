package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @ClassName: StrategyOrgEntify 
 * @Description: 数据策略组织信息
 * @author lu.z
 * @date 2015年5月21日 下午5:45:00
 */
@Entity
@Table(name = "aplus_strategy_orgs")
public class StrategyOrgEntify implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2425212419389930519L;
	
	/**
	 * 主键
	 */
	private String uuid;
	/**
	 * 权限策略ID
	 */
	private String strategyId;
	/**
	 * 组织
	 */
	private String orgId;
	/**
	 * 对应数据权限组织
	 */
	private String strategyOrg;
	
	@Id
	@Column(name = "uuid")
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	@Column(name = "strategy_id")
	public String getStrategyId() {
		return strategyId;
	}
	public void setStrategyId(String strategyId) {
		this.strategyId = strategyId;
	}

	@Column(name = "strategy_org")
	public String getStrategyOrg() {
		return strategyOrg;
	}
	public void setStrategyOrg(String strategyOrg) {
		this.strategyOrg = strategyOrg;
	}
	
	@Column(name = "org_id")
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	
	@Override
	public String toString() {
		return "{uuid = "+uuid+", strategyId = "+strategyId+", strategyOrg = ["+strategyOrg+"], orgId = "+orgId+"}";
	}
}

package com.neusoft.aplus.itam.handler;

import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import com.neusoft.aplus.itam.model.bizentity.FlowTemplate;
import com.neusoft.aplus.itam.service.bo.IStateFlowService;

/**
 * @ClassName: TemplateHandler
 * @Description: 加载模板handler方法
 * @author lu.z
 * @date 2015年4月9日 上午9:40:02
 */
public class TemplateHandler {
	private static Logger log = Logger.getLogger(TemplateHandler.class);
	/**
	 * 模板集合
	 */
	private Map<String, FlowTemplate> flowTemplateMap;
	public Map<String, FlowTemplate> getFlowTemplateMap() {
		return flowTemplateMap;
	}
	public void setFlowTemplateMap(Map<String, FlowTemplate> flowTemplateMap) {
		this.flowTemplateMap = flowTemplateMap;
	}

	/**
	 * 状态机sevice
	 */
	@Autowired
	private IStateFlowService stateFlowService;

	/**
	 * @Description: 加载模板，将配置模板信息、状态机信息存储到数据库中
	 * @author lu.z
	 * @date 2015年4月9日 上午10:59:23
	 * @param
	 * @return void
	 * @throws
	 */
	@SuppressWarnings("unused")
	private void initTemplate() {
		log.info("开始初始化模板");
	}
}

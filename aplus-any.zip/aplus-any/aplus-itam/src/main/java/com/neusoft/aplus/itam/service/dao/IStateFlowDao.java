package com.neusoft.aplus.itam.service.dao;

import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Criterion;

import com.neusoft.aplus.itam.model.dbentity.table.FlowEntity;
import com.neusoft.aplus.model.dbentity.Page;

/**
 * @ClassName: IStateFlowDao
 * @Description: 状态机操作数据库接口
 * @author lu.z
 * @date 2015年4月9日 上午11:04:23
 */
public interface IStateFlowDao {
	/**
	 * @Description: 保存状态机信息
	 * @author lu.z
	 * @date 2015年4月9日 下午1:37:04
	 * @param @param flowEntity
	 * @return void
	 * @throws
	 */
	public void saveStateFlow(FlowEntity flowEntity);

	/**
	 * @Description: 批量保存状态机信息
	 * @author lu.z
	 * @date 2015年4月9日 下午1:37:04
	 * @param @param flowEntitys
	 * @return void
	 * @throws
	 */
	public void saveStateFlows(List<FlowEntity> flowEntitys);

	/**
	 * @Description: 删除状态机信息
	 * @author lu.z
	 * @date 2015年4月9日 下午1:37:41
	 * @param @param templateCode
	 * @return void
	 * @throws
	 */
	public void removeStateFlow(String templateCode);

	/**
	 * @Description: 根据模板code数组删除状态机信息
	 * @author lu.z
	 * @date 2015年4月9日 下午1:37:41
	 * @param templateCodes
	 * @return void
	 * @throws
	 */
	public void removeStateFlows(List<String> templateCode);

	/**
	 * @Description: 获取所有状态机
	 * @author lu.z
	 * @date 2015年4月9日 下午4:10:25
	 * @param @return
	 * @return List<FlowEntity>
	 * @throws
	 */
	public List<FlowEntity> findAllStateFlow();

	/**
	 * @Description: 获取所有状态机（分页）
	 * @author lu.z
	 * @date 2015年4月23日 上午9:38:44
	 * @param @param page
	 * @param @param pageCount
	 * @param @return
	 * @return Page<FlowEntity>
	 * @throws
	 */
	public Page<FlowEntity> findAllStateFlow(Integer page, Integer pageCount);

	/**
	 * @Description: 获取所有资产状态机
	 * @author lu.z
	 * @date 2015年4月9日 下午4:10:25
	 * @param @return
	 * @return List<FlowEntity>
	 * @throws
	 */
	public List<FlowEntity> findAllAssetsStateFlow();

	/**
	 * @Description: 获取所有资产状态机（分页）
	 * @author lu.z
	 * @date 2015年4月23日 上午9:39:10
	 * @param @param page
	 * @param @param pageCount
	 * @param @return
	 * @return Page<FlowEntity>
	 * @throws
	 */
	public Page<FlowEntity> findAllAssetsStateFlow(Integer page, Integer pageCount);

	/**
	 * @Description: 获取所有资源状态机
	 * @author lu.z
	 * @date 2015年4月9日 下午4:10:25
	 * @param @return
	 * @return List<FlowEntity>
	 * @throws
	 */
	public List<FlowEntity> findAllResourcesStateFlow();

	/**
	 * @Description: 获取所有资源状态机（分页）
	 * @author lu.z
	 * @date 2015年4月23日 上午9:39:36
	 * @param @param page
	 * @param @param pageCount
	 * @param @return
	 * @return Page<FlowEntity>
	 * @throws
	 */
	public Page<FlowEntity> findAllResourcesStateFlow(Integer page, Integer pageCount);

	/**
	 * @Description: 根据模板code获取状态机信息
	 * @author lu.z
	 * @date 2015年4月9日 下午4:13:00
	 * @param @param templateCode 模板code
	 * @param @return
	 * @return List<FlowEntity>
	 * @throws
	 */
	public List<FlowEntity> findStateFlowByTemplateCode(String templateCode);

	/**
	 * @Description: 根据模板code获取状态机信息（分页）
	 * @author lu.z
	 * @date 2015年4月23日 上午9:40:02
	 * @param @param page
	 * @param @param pageCount
	 * @param @param templateCode
	 * @param @return
	 * @return Page<FlowEntity>
	 * @throws
	 */
	public Page<FlowEntity> findStateFlowByTemplateCode(Integer page, Integer pageCount, String templateCode);

	/**
	 * @Description: 根据模板code获取资产状态机
	 * @author lu.z
	 * @date 2015年4月9日 下午4:10:25
	 * @param @return
	 * @return List<FlowEntity>
	 * @throws
	 */
	public List<FlowEntity> findAssetsStateFlowByTemplateCode(String templateCode);

	/**
	 * @Description: 根据模板code获取资产状态机（分页）
	 * @author lu.z
	 * @date 2015年4月23日 上午9:40:27
	 * @param @param page
	 * @param @param pageCount
	 * @param @param templateCode
	 * @param @return
	 * @return Page<FlowEntity>
	 * @throws
	 */
	public Page<FlowEntity> findAssetsStateFlowByTemplateCode(Integer page, Integer pageCount, String templateCode);

	/**
	 * @Description: 根据模板code获取资源状态机
	 * @author lu.z
	 * @date 2015年4月9日 下午4:10:25
	 * @param @return
	 * @return List<FlowEntity>
	 * @throws
	 */
	public List<FlowEntity> findResourcesStateFlowByTemplateCode(String templateCode);

	/**
	 * @Description: 根据模板code获取资源状态机（分页）
	 * @author lu.z
	 * @date 2015年4月23日 上午9:40:50
	 * @param @param page
	 * @param @param pageCount
	 * @param @param templateCode
	 * @param @return
	 * @return Page<FlowEntity>
	 * @throws
	 */
	public Page<FlowEntity> findResourcesStateFlowByTemplateCode(Integer page, Integer pageCount, String templateCode);

	/**
	 * @Description: 根据提交状态获取状态机
	 * @author lu.z
	 * @date 2015年4月9日 下午4:26:43
	 * @param @param billType 工单类型
	 * @param @return
	 * @return FlowEntity
	 * @throws
	 */
	public FlowEntity findStateFlowByBillType(String billType);

	/**
	 * @Description: 根据条件查询
	 * @author lu.z
	 * @date 2015年4月13日 下午2:25:30
	 * @param @param paramsMap 参数数组
	 * @param @return
	 * @return FlowEntity
	 * @throws
	 */
	public FlowEntity findStateFlowByConditions(Map<String, Object> paramsMap);

	/**
	 * @Description: 查询所有工单类型
	 * @author lu.z
	 * @date 2015年4月23日 下午3:10:04
	 * @param @return
	 * @return List<String>
	 * @throws
	 */
	public List<String> findAllBillType();

	/**
	 * @Description: 修改状态机信息
	 * @author lu.z
	 * @date 2015年5月4日 上午9:51:45
	 * @param @param flowEntity
	 * @return void
	 * @throws
	 */
	public void updateFlowState(FlowEntity flowEntity);

	/**
	 * @Description: 根据id数组删除状态机信息
	 * @author lu.z
	 * @date 2015年5月4日 上午9:52:43
	 * @param @param ids
	 * @return void
	 * @throws
	 */
	public void removeFlowStateByIds(List<Integer> ids);

	/**
	 * @Description: 根据id删除状态机信息
	 * @author lu.z
	 * @date 2015年5月4日 上午9:53:12
	 * @param @param id
	 * @return void
	 * @throws
	 */
	public void removeFlowStateById(Integer id);
	
	/**
	 * @Description: 根据条件分页查询状态机
	 * @author lu.z
	 * @date 2015年5月5日 上午9:37:31 
	 * @param @param page
	 * @param @param pageCount
	 * @param @param criterions
	 * @param @return
	 * @return Page<FlowEntity>
	 * @throws
	 */
	public Page<FlowEntity> findStateFlowsByConditions(Integer page, Integer pageCount, List<Criterion> criterions);
}

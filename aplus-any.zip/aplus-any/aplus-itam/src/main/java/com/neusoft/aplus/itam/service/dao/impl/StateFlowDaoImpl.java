package com.neusoft.aplus.itam.service.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Criterion;
import org.springframework.stereotype.Component;

import com.neusoft.aplus.itam.model.dbentity.table.FlowEntity;
import com.neusoft.aplus.itam.service.dao.IStateFlowDao;
import com.neusoft.aplus.itam.service.dao.base.ItamAbstractHibernateDao;
import com.neusoft.aplus.model.dbentity.Page;

/**
 * @ClassName: StateFlowDaoImpl
 * @Description: 状态机操作数据库实现类
 * @author lu.z
 * @date 2015年4月9日 上午11:04:01
 */
@Component
public class StateFlowDaoImpl extends ItamAbstractHibernateDao<FlowEntity> implements IStateFlowDao {

	@Override
	public void saveStateFlow(FlowEntity flowEntity) {
		saveOrUpdate(flowEntity);
	}

	@Override
	public void saveStateFlows(List<FlowEntity> flowEntitys) {
		batchSaveOrUpdate(flowEntitys);
	}

	@Override
	public void removeStateFlow(String templateCode) {
		String sql = "delete FlowEntity where templateCode = ?";
		createQuery(sql, templateCode).executeUpdate();
	}

	@Override
	public List<FlowEntity> findAllStateFlow() {
		String hql = "from FlowEntity flowEntity";
		return find(hql);
	}

	@Override
	public List<FlowEntity> findAllAssetsStateFlow() {
		String hql = "from FlowEntity flowEntity where flowEntity.startStatus is not null and flowEntity.endStatus is not null";
		return find(hql);
	}

	@Override
	public List<FlowEntity> findAllResourcesStateFlow() {
		String hql = "from FlowEntity flowEntity where flowEntity.resStartStatus is not null and flowEntity.resEndStatus is not null";
		return find(hql);
	}

	@Override
	public List<FlowEntity> findStateFlowByTemplateCode(String templateCode) {
		String hql = "from FlowEntity flowEntity where flowEntity.templateCode = ?";
		return find(hql, templateCode);
	}

	@Override
	public List<FlowEntity> findAssetsStateFlowByTemplateCode(String templateCode) {
		String hql = "from FlowEntity flowEntity where flowEntity.templateCode = ? and flowEntity.startStatus is not null and flowEntity.endStatus is not null";
		return find(hql, templateCode);
	}

	@Override
	public List<FlowEntity> findResourcesStateFlowByTemplateCode(String templateCode) {
		String hql = "from FlowEntity flowEntity where flowEntity.templateCode = ? and flowEntity.resStartStatus is not null and flowEntity.resEndStatus is not null";
		return find(hql, templateCode);
	}

	@Override
	public FlowEntity findStateFlowByBillType(String billType) {
		String hql = "from FlowEntity flowEntity where flowEntity.billType = ?";
		List<FlowEntity> list = find(hql, billType);
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public FlowEntity findStateFlowByConditions(Map<String, Object> paramsMap) {
		return findEntityByConditions(paramsMap);
	}

	@Override
	public Page<FlowEntity> findAllStateFlow(Integer page, Integer pageCount) {
		String hql = "from FlowEntity flowEntity";
		return getPagedResult(page, pageCount, hql, new Object[]{});
	}

	@Override
	public Page<FlowEntity> findAllAssetsStateFlow(Integer page, Integer pageCount) {
		String hql = "from FlowEntity flowEntity where flowEntity.endStatus is not null";
		return getPagedResult(page, pageCount, hql, new Object[]{});
	}

	@Override
	public Page<FlowEntity> findAllResourcesStateFlow(Integer page, Integer pageCount) {
		String hql = "from FlowEntity flowEntity where flowEntity.resEndStatus is not null";
		return getPagedResult(page, pageCount, hql, new Object[]{});
	}

	@Override
	public Page<FlowEntity> findStateFlowByTemplateCode(Integer page, Integer pageCount, String templateCode) {
		String hql = "from FlowEntity flowEntity where flowEntity.templateCode = ?";
		List<Object> params = new ArrayList<Object>();
		params.add(templateCode);
		return getPagedResult(page, pageCount, hql, params.toArray());
	}

	@Override
	public Page<FlowEntity> findAssetsStateFlowByTemplateCode(Integer page, Integer pageCount, String templateCode) {
		String hql = "from FlowEntity flowEntity where flowEntity.templateCode = ? and flowEntity.endStatus is not null";
		List<Object> params = new ArrayList<Object>();
		params.add(templateCode);
		return getPagedResult(page, pageCount, hql, params.toArray());
	}

	@Override
	public Page<FlowEntity> findResourcesStateFlowByTemplateCode(Integer page, Integer pageCount, String templateCode) {
		String hql = "from FlowEntity flowEntity where flowEntity.templateCode = ? and flowEntity.resEndStatus is not null";
		List<Object> params = new ArrayList<Object>();
		params.add(templateCode);
		return getPagedResult(page, pageCount, hql, params.toArray());
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> findAllBillType() {
		String hql = "select t.billType from FlowEntity t";
		return createQuery(hql).list();
	}

	@Override
	public void removeStateFlows(List<String> templateCodes) {
		if(templateCodes != null && !templateCodes.isEmpty()){
			String sql = "delete FlowEntity where templateCode in ";
			String condition = "(";
			for(int i = 0; i < templateCodes.size(); i++){
				condition += "?,";
			}
			sql += condition.substring(0, condition.length() - 1) + ")";
			createQuery(sql, templateCodes.toArray()).executeUpdate();
		}
	}

	@Override
	public void updateFlowState(FlowEntity flowEntity) {
		update(flowEntity);
	}

	@Override
	public void removeFlowStateByIds(List<Integer> ids) {
		if(ids != null && !ids.isEmpty()){
			String sql = "delete FlowEntity where id in ";
			String condition = "(";
			for(int i = 0; i < ids.size(); i++){
				condition += "?,";
			}
			sql += condition.substring(0, condition.length() - 1) + ")";
			createQuery(sql, ids.toArray()).executeUpdate();
		}
	}

	@Override
	public void removeFlowStateById(Integer id) {
		String sql = "delete TemplateEntity where id = ? ";
		createQuery(sql, id).executeUpdate();
	}

	@Override
	public Page<FlowEntity> findStateFlowsByConditions(Integer page, Integer pageCount, List<Criterion> criterions) {
		return getPagedResult(page, pageCount, criterions);
	}
}

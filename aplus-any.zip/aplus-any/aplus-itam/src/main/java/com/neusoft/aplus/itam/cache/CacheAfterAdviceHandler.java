package com.neusoft.aplus.itam.cache;

import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.neusoft.aplus.common.cache.api.CacheService;
import com.neusoft.aplus.itam.common.RemoveCache;

/**
 * @ClassName: CacheAfterAdviceHandler
 * @Description: 配置标签RemoveCache的方法将会被拦截
 * @author lu.z
 * @date 2015年4月15日 上午11:38:57
 */
public class CacheAfterAdviceHandler {
	Logger logger = LoggerFactory.getLogger(CacheAfterAdviceHandler.class);
	/**
	 * 默认缓存名称
	 */
	private static final String DEFAULT_CACHE_NAME = "myCache";
	@Autowired
	private CacheService cacheService;

	public void doBefore() {
		// TODO:
	}
	
	public void doAfterReturning(JoinPoint joinPoint) {
		Class<?> cls = joinPoint.getTarget().getClass();
		// 获取class中的所有方法
		Method[] methods = cls.getMethods();
		for (Method method : methods) {
			if (method.getName().equals(joinPoint.getSignature().getName())) {
				RemoveCache removeCache = method.getAnnotation(RemoveCache.class);
				if (removeCache != null && removeCache.value()) {
					//直接根据缓存key删除
					String cacheKeys[] = removeCache.cacheKeys();
					for (String cacheKey : cacheKeys) {
						cacheService.remove(DEFAULT_CACHE_NAME, cacheKey);
					}
					//根据缓存前缀，删除缓存信息
					String cachekeysArgs[] = removeCache.cacheKeysArgs();
					//默认为空数组，所以不用判断是否为null
					if(cachekeysArgs.length > 0){
						//获取默认缓存中所有key值
						List<Object> keys = cacheService.getKeys(DEFAULT_CACHE_NAME);
						for(String cacheKey : cachekeysArgs){
							Iterator<Object> iterator = keys.iterator();
							while(iterator.hasNext()){
								Object object = iterator.next();
								if(object instanceof String){
									String key = (String) object;
									if(key.startsWith(cacheKey+".")){
										cacheService.remove(DEFAULT_CACHE_NAME, key);
									}
								}
							}
						}
					}
					
				}
			}
		}
	}

	public void doAfter() {
		// TODO:
	}

	public void doAfterThrowing(JoinPoint joinPoint, Exception ex) {
		logger.error("CacheAfterAdviceHandler拦截方法:{},捕获到异常e:{}", joinPoint, ex.getMessage());
	}

	public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable {
		Object result = joinPoint.proceed();
		return result;
	}
}

package com.neusoft.aplus.itam.action;

import java.util.HashMap;
import java.util.Map;

import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.service.bo.IAplusDeviceItamService;
import com.neusoft.aplus.model.dbentity.Page;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;

/**
 * @author zhangyun
 * @date 2015-4-22 下午2:05:04
 */
public class AplusDeviceItamAction extends BaseAction {
	private IAplusDeviceItamService aplusDeviceItamService;

	@Override
	public void doInit() {
		aplusDeviceItamService = ApplicationContextFactory
				.getBean(IAplusDeviceItamService.class);
	}

	@Override
	public void acceptRepresentation(Representation entity) {
	}

	@Override
	public Representation represent() {
		Page<AplusDeviceEntity> aplusDeviceEntity = null;
		String pageStr = (String) getRequestAttributes().get("page");
		String pageCountStr = (String) getRequestAttributes().get("pageCount");
		// 如果传过来为null或者""，默认为第一页
		Integer page = (pageStr == null || "".equals(pageStr)) ? 1 : Integer
				.parseInt(pageStr);
		// 如果传过来为null或者""，默认为每页10条数据
		Integer pageCount = (pageCountStr == null || "".equals(pageCountStr)) ? 10
				: Integer.parseInt(pageCountStr);
		String billType = (String) getRequestAttributes().get("billType");
		Map<String, String> dimMap = new HashMap<String, String>();
		Map<String, String> preciseMap = new HashMap<String, String>();

		aplusDeviceEntity = aplusDeviceItamService.findAplusDeivce(dimMap,
				preciseMap, billType, page, pageCount);
		if (aplusDeviceEntity != null) {
			return createObjectRepresentation(aplusDeviceEntity);
		}
		return null;
	}

	@Override
	public void removeRepresentations() {
	}

	@Override
	public void storeRepresentation(Representation entity) {
	}
}

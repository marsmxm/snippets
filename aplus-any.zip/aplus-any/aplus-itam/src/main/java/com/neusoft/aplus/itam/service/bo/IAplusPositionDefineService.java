package com.neusoft.aplus.itam.service.bo;

import java.util.List;


import com.neusoft.aplus.itam.model.dbentity.table.AplusPositionDefineEntity;

/**
 * @ClassName: AplusPositionDefineService 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-13 下午2:49:24
 */
public interface IAplusPositionDefineService {
	
	/**
	 * @Description: 新增或更新位置信息
	 * @author jin.ysh
	 * @date 2015-4-9 下午4:28:23 
	 * @param @param AplusPositionDefineEntity
	 * @return void
	 * @throws
	 */
	public void saveOrUpdateAplusPositionDefine(AplusPositionDefineEntity aplusPositionDefineEntity);
	
	/**
	 * @Description: TODO
	 * @author jin.ysh
	 * @date 2015-4-28 下午3:59:26 
	 * @param @param aplusPositionDefineEntity
	 * @return void
	 * @throws
	 */
	public void saveAplusPositionDefine(AplusPositionDefineEntity aplusPositionDefineEntity);
	
	/**
	 * @Description: 查询位置信息
	 * @author jin.ysh
	 * @date 2015-4-9 下午4:30:35 
	 * @param @param 获取当前级别之上的所有位置信息(包含当前级别)，All 表示获取全部
	 * @param @return
	 * @return List<AplusPositionDefineEntity>
	 * @throws
	 */
	public List<AplusPositionDefineEntity> findAplusPositionDefines(String positionLevel);
	/**
	 * @Description: TODO
	 * @author jin.ysh
	 * @date 2015-4-28 下午3:43:39 
	 * @param @param positionLevel
	 * @param @return
	 * @return List<AplusPositionDefineEntity>
	 * @throws
	 */
	public List<AplusPositionDefineEntity> findAplusPositionDefineById(String positionId);
	/**
	 * @Description: 删除位置信息
	 * @author jin.ysh
	 * @date 2015-4-9 下午4:32:34 
	 * @param @param AplusPositionDefineEntity
	 * @return void
	 * @throws
	 */
	public void deleteAplusPositionDefine(AplusPositionDefineEntity aplusPositionDefineEntity);


}

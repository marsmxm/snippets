package com.neusoft.aplus.itam.service.dao;

import java.util.List;

import com.neusoft.aplus.itam.model.dbentity.table.AplusSupplierEntity;


/**
 * @ClassName: AplusSupplierDao 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-10 下午4:34:35
 */
public interface IAplusSupplierDao {
	/**
	 * @Description: 新增或更新合作商
	 * @author jin.ysh
	 * @date 2015-4-9 下午4:28:23 
	 * @param @param aplusDevtypeEntity
	 * @return void
	 * @throws
	 */
	public void saveOrUpdateAplusSupplier(AplusSupplierEntity aplusSupplierEntity);
	/**
	 * @Description: 查询合作商
	 * @author jin.ysh
	 * @date 2015-4-9 下午4:30:35 
	 * @param @param 合作商类型  isprov 供应商,isprod 生产商,
	 * 						 ischeck 维修商,isdeve 开发商,
	 * 						 isserv 服务商,istotal 集成商
	 * @param @return
	 * @return List<AplusSupplierEntity>
	 * @throws
	 */
	public List<AplusSupplierEntity> findAplusSupplierEntitys(boolean isprov,boolean isprod,boolean ischeck,boolean isdeve,boolean isserv,boolean istotal);
	
	/**
	 * @Description: 根据传入对象的条件查询
	 * @author jin.ysh
	 * @date 2015-5-21 下午5:50:01 
	 * @param @param aplusSupplierEntity
	 * @param @return
	 * @return List<AplusSupplierEntity>
	 * @throws
	 */
	public List<AplusSupplierEntity> findAplusSupplierByObject(AplusSupplierEntity aplusSupplierEntity);
	/**
	 * @Description: 删除合作商
	 * @author jin.ysh
	 * @date 2015-4-9 下午4:32:34 
	 * @param @param aplusDevtypeEntity
	 * @return void
	 * @throws
	 */
	public void deleteAplusSupplierEntity(AplusSupplierEntity aplusSupplierEntity);

	/**
	 * @Description: 根据设备类型查询生产厂商
	 * @author jin.ysh
	 * @date 2015-4-13 下午3:20:36 
	 * @param @param devtypeId
	 * @return void
	 * @throws
	 */
	public List<AplusSupplierEntity> findAplusSupplierEntitysByDevtype(String devtypeId);
}

package com.neusoft.aplus.itam.service.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.criterion.Criterion;
import org.springframework.stereotype.Component;

import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;
import com.neusoft.aplus.itam.service.dao.IAplusPresetDevInfoDao;
import com.neusoft.aplus.model.dbentity.Page;

@Component
public class AplusPresetDevInfoDaoImpl extends
		AbstractHibernateDao<AplusPresetDevInfoEntity> implements
		IAplusPresetDevInfoDao {
	@Override
	public String saveAplusPresrtDevInfo(AplusPresetDevInfoEntity entity) {
		return (String)save(entity);
	}

	@Override
	public void updateAplusPresrtDevInfo(AplusPresetDevInfoEntity entity) {
		update(entity);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AplusPresetDevInfoEntity> findAplusPresetInfoByPresetUuid(
			String presetUuid) {
		String hql = "from AplusPresetDevInfoEntity where presetUuid = ? ";
		Query query = createQuery(hql, presetUuid);
		return query.list();
	}

	@Override
	public void deleteAplusPresrtInfo(AplusPresetDevInfoEntity entity) {
		remove(entity);
	}

	@Override
	public AplusPresetDevInfoEntity findAplusPresetDevInfoByUuid(String uuid) {
		return get(uuid);
	}

	@Override
	public Page<AplusPresetDevInfoEntity> findAplusPresetDevInfo(Integer page,
			Integer pageCount, List<Criterion> criterions) {
		return getPagedResult(page, pageCount, criterions);
	}

}

package com.neusoft.aplus.itam.service.bo;

import java.util.List;

import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;

public interface IAplusBillDeviceFromPresetService {
	/**
	 * @Description: 到货选取工单设备
	 * @author zhangyun
	 * @date 2015-4-20 下午5:05:22
	 * @param @param parameters
	 * @param @param bill_uuid
	 * @param @param bill_no
	 * @return void
	 * @throws
	 */
	public void saveAplusBillDeviceByPreset(String bill_uuid, String bill_no, 
			List<AplusPresetDevInfoEntity> presetDevInfoEntityList);
}

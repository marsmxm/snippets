package com.neusoft.aplus.itam.action;

import java.util.Map;

import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetInfoEntity;
import com.neusoft.aplus.itam.service.bo.IAplusPresetInfoService;
import com.neusoft.aplus.model.dbentity.Page;

/**
 * @ClassName: AplusPresetInfoAction
 * @Description: TODO
 * @author zhangyun
 * @date 2015-4-24 上午11:37:56
 */
public class AplusPresetInfoAction extends BaseAction {
	private IAplusPresetInfoService aplusPresetInfoService;
	private Map<String, String> paramsMap;

	@Override
	public void doInit() {
		aplusPresetInfoService = ApplicationContextFactory
				.getBean(IAplusPresetInfoService.class);
		paramsMap = getRequestParameters();
	}

	@Override
	public void acceptRepresentation(Representation entity) {
		try {
			AplusPresetInfoEntity presetInfoEntity = getObjectFromRepresentation(
					entity, AplusPresetInfoEntity.class);
			String presetUuid = aplusPresetInfoService
					.saveAplusPresrtInfo(presetInfoEntity);
			sendJsonResponse("{'presetUuid':" + presetUuid + "}");
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public Representation represent() {
		Page<AplusPresetInfoEntity> aplusPresetInfoEntity = null;
		String pageStr = (String) paramsMap.get("page");
		String pageCountStr = (String) paramsMap.get("pageCount");
		// 如果传过来为null或者""，默认为第一页
		Integer page = (pageStr == null || "".equals(pageStr)) ? 1 : Integer
				.parseInt(pageStr);
		// 如果传过来为null或者""，默认为每页10条数据
		Integer pageCount = (pageCountStr == null || "".equals(pageCountStr)) ? 10
				: Integer.parseInt(pageCountStr);
		String uuid = (String) paramsMap.get("uuid");
		aplusPresetInfoEntity = aplusPresetInfoService.findaplusPresetInfo(
				page, pageCount, uuid);

		if (aplusPresetInfoEntity != null) {
			return createObjectRepresentation(aplusPresetInfoEntity);
		}
		return null;
	}

	@Override
	public void removeRepresentations() {
		String uuid = (String) paramsMap.get("uuid");
		aplusPresetInfoService.deleteAplusPresrtInfo(uuid);
		sendSuccess();
	}

	@Override
	public void storeRepresentation(Representation entity) {
		try {
			AplusPresetInfoEntity presetInfoEntity = getObjectFromRepresentation(
					entity, AplusPresetInfoEntity.class);
			aplusPresetInfoService.updateAplusPresrtInfo(presetInfoEntity);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();
	}

}

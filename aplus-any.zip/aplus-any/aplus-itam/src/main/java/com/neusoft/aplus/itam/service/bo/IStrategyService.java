package com.neusoft.aplus.itam.service.bo;

import java.util.List;
import java.util.Map;

import com.neusoft.aplus.itam.model.dbentity.table.StrategyEntify;
import com.neusoft.aplus.itam.model.dbentity.table.StrategyOrgEntify;

/**
 * @ClassName: IStrategyService 
 * @Description: 数据权限策略
 * @author lu.z
 * @date 2015年5月21日 下午4:51:17
 */
public interface IStrategyService {
	/**
	 * @Description: 新增策略信息
	 * @author lu.z
	 * @date 2015年5月21日 下午5:09:30 
	 * @param strategyEntify
	 * @param strategyOrgEntifys
	 * @return void
	 * @throws
	 */
	public void saveStrategy(StrategyEntify strategyEntify, List<StrategyOrgEntify> strategyOrgEntifys);
	
	/**
	 * @Description: 修改策略信息
	 * @author lu.z
	 * @date 2015年5月21日 下午5:09:54 
	 * @param strategyEntify
	 * @param strategyOrgEntifys
	 * @return void
	 * @throws
	 */
	public void updateStrategy(StrategyEntify strategyEntify, List<StrategyOrgEntify> strategyOrgEntifys);
	
	/**
	 * @Description: 删除策略信息
	 * @author lu.z
	 * @date 2015年5月21日 下午5:10:22 
	 * @param @param ids
	 * @return void
	 * @throws
	 */
	public void removeStrategys(List<String> ids);
	
	/**
	 * @Description: 查询策略信息
	 * @author lu.z
	 * @date 2015年5月21日 下午5:12:17 
	 * @param @param paramsMap
	 * @param @return
	 * @return Map<String,Object>
	 * @throws
	 */
	public Map<String, Object> findStrategyByConditions(Map<String, String> paramsMap);
	
	/**
	 * @Description: 根据id获取策略信息
	 * @author lu.z
	 * @date 2015年5月22日 下午5:33:21 
	 * @param @param uuid
	 * @param @return
	 * @return StrategyEntify
	 * @throws
	 */
	public StrategyEntify findStrategyById(String uuid);
	
	/**
	 * @Description: 根据模块ID和当前操作人的组织机构，查询可以查看的组织机构
	 * @author lu.z
	 * @date 2015年5月26日 下午1:53:28 
	 * @param @param modelId
	 * @param @param orgId
	 * @param @return
	 * @return List<String>
	 * @throws
	 */
	public List<String> findOrgList(String modelId, String orgId);
	
	/**
	 * @Description: 根据模块ID策略是否存在
	 * @author lu.z
	 * @date 2015年5月26日 下午2:24:27 
	 * @param @param modelId
	 * @param @return
	 * @return Integer
	 * @throws
	 */
	public boolean isExistModel(String modelId);
}

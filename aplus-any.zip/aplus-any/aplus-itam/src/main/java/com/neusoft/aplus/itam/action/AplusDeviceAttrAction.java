package com.neusoft.aplus.itam.action;

import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;

import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceAttrEntity;
import com.neusoft.aplus.service.core.service.bo.AplusDeviceAttrBo;
/**
 * @ClassName: AplusDeviceAttrServiceAction 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-24 下午4:21:13
 */
public class AplusDeviceAttrAction extends BaseAction{
	private AplusDeviceAttrBo aplusDeviceAttrBo;
	private Map<String, String> paramsMap;
	@Override
	public void doInit() {
		aplusDeviceAttrBo = ApplicationContextFactory.getBean(AplusDeviceAttrBo.class);
		paramsMap = getRequestParameters();
	}

	@Override
	public void acceptRepresentation(Representation entity) {
		// TODO Auto-generated method stub
	}

	@Override
	public Representation represent() {
		// TODO Auto-generated method stub
		List<AplusDeviceAttrEntity> deviceAttrEntityList = null;
		String deviceType = (String) paramsMap.get("deviceType");
		String deviceVersion = (String) paramsMap.get("deviceVersion");
		String category = (String) paramsMap.get("category");
		if(category!=null)
		{
			deviceAttrEntityList = aplusDeviceAttrBo.findDeviceAttrByDevtype(category);

		}else if(deviceType!=null&&deviceVersion!=null)
		{
			deviceAttrEntityList = aplusDeviceAttrBo.findAplusDeviceAttr(deviceType, deviceVersion);

		}
		
		if (deviceAttrEntityList != null && !deviceAttrEntityList.isEmpty()) {
			return createObjectRepresentation(deviceAttrEntityList);
		}
		return null;
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		AplusDeviceAttrEntity aplusDeviceAttrEntity = null;
		try {
			aplusDeviceAttrEntity = getObjectsFromRepresentation(entity, new TypeReference<AplusDeviceAttrEntity>() {
			});
			if (aplusDeviceAttrEntity != null) {
				aplusDeviceAttrBo.saveOrUpdateAplusDeviceAttr(aplusDeviceAttrEntity);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();
	}

}

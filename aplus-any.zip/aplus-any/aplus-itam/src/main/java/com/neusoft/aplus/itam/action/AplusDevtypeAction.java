package com.neusoft.aplus.itam.action;

import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;

import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.model.dbentity.table.AplusDevtypeEntity;
import com.neusoft.aplus.itam.service.bo.IAplusDevtypeService;
/**
 * @ClassName: AplusDevtypeAction 
 * @Description: 设备类型 rest action
 * @author jin.ysh
 * @date 2015-4-21 下午2:33:54
 */
public class AplusDevtypeAction extends BaseAction{
	private IAplusDevtypeService aplusDevtypeService;
	private Map<String, String> paramsMap;
	@Override
	public void doInit() {
		aplusDevtypeService = ApplicationContextFactory.getBean(IAplusDevtypeService.class);
		paramsMap = getRequestParameters();
	}

	@Override
	public void acceptRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		AplusDevtypeEntity aplusDevtypeEntity = null;
		try {
			aplusDevtypeEntity = getObjectsFromRepresentation(entity, new TypeReference<AplusDevtypeEntity>() {
			});
			if (aplusDevtypeEntity != null) {
				aplusDevtypeService.saveAplusDevtype(aplusDevtypeEntity);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();
	}

	@Override
	public Representation represent() {
		// TODO Auto-generated method stub
		List<AplusDevtypeEntity> devtypeEntityList = null;
		String devtypeLevel = (String)paramsMap.get("devtypeLevel");
		String devtypeId = (String)paramsMap.get("devtypeId");
		if(devtypeLevel!=null)
		{
			devtypeEntityList = aplusDevtypeService.findAplusDevtypeEntitys(devtypeLevel);
		}else if(devtypeId!=null)		
		{
			devtypeEntityList = aplusDevtypeService.findAplusDevtypeEntityById(devtypeId);
		}
		
		if (devtypeEntityList != null && !devtypeEntityList.isEmpty()) {
			return createObjectRepresentation(devtypeEntityList);
		}
		return null;
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub
		try {
			String devtypeId = (String) paramsMap.get("devtypeId");
			AplusDevtypeEntity aplusDevtypeEntity = new AplusDevtypeEntity();
			aplusDevtypeEntity.setDevtypeId(devtypeId);
			aplusDevtypeService.deleteAplusDevtypeEntity(aplusDevtypeEntity);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();
	}

	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		AplusDevtypeEntity aplusDevtypeEntity = null;
		try {
			aplusDevtypeEntity = getObjectsFromRepresentation(entity, new TypeReference<AplusDevtypeEntity>() {
			});
			if (aplusDevtypeEntity != null) {
				aplusDevtypeService.saveOrUpdateAplusDevtype(aplusDevtypeEntity);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();
	}

}

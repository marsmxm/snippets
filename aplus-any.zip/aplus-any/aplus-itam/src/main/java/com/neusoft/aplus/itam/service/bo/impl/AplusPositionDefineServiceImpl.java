package com.neusoft.aplus.itam.service.bo.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.neusoft.aplus.itam.model.dbentity.table.AplusPositionDefineEntity;
import com.neusoft.aplus.itam.service.bo.IAplusPositionDefineService;
import com.neusoft.aplus.itam.service.dao.IAplusPositionDefineDao;

@Component
public class AplusPositionDefineServiceImpl implements IAplusPositionDefineService{
	@Autowired
	private IAplusPositionDefineDao aplusPositionDefineDao;

	@Override
	@Transactional
	public void saveOrUpdateAplusPositionDefine(
			AplusPositionDefineEntity aplusPositionDefineEntity) {
		// TODO Auto-generated method stub
		aplusPositionDefineDao.saveOrUpdateAplusPositionDefine(aplusPositionDefineEntity);
	}

	@Override
	@Transactional
	public List<AplusPositionDefineEntity> findAplusPositionDefines(
			String positionLevel) {
		if("All".equals(positionLevel))
		{
			return aplusPositionDefineDao.findAplusPositionDefines();
		}else{
			return aplusPositionDefineDao.findAplusPositionDefines(Integer.parseInt(positionLevel));
		}
	}

	@Override
	@Transactional
	public void deleteAplusPositionDefine(
			AplusPositionDefineEntity aplusPositionDefineEntity) {
		// TODO Auto-generated method stub
		aplusPositionDefineDao.deleteAplusPositionDefine(aplusPositionDefineEntity);
	}

	@Override
	@Transactional
	public List<AplusPositionDefineEntity> findAplusPositionDefineById(
			String positionId) {
		// TODO Auto-generated method stub
		return aplusPositionDefineDao.findAplusPositionDefineById(positionId);
	}

	@Override
	@Transactional
	public void saveAplusPositionDefine(
			AplusPositionDefineEntity aplusPositionDefineEntity) {
		// TODO Auto-generated method stub
		aplusPositionDefineDao.saveAplusPositionDefine(aplusPositionDefineEntity);
	}

}

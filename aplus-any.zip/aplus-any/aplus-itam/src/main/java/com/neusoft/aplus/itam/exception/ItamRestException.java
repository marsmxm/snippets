package com.neusoft.aplus.itam.exception;

import java.util.Map;
import com.neusoft.aplus.common.exception.AplusException;
import com.neusoft.aplus.common.exception.annotation.MessageCN;
import com.neusoft.aplus.common.exception.annotation.MessageUS;

public class ItamRestException extends AplusException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4215518063071465701L;

	public ItamRestException(String code, Exception original, Object[] params, Map<String, Object> keyPoints) {
		super(code, original, params, keyPoints);
	}

	/**
	 * 异常码范围：1000 ~ 1400
	 */
	@MessageCN("未找到配置文件")
	@MessageUS("unknown spring file")
	public static String UNKNOWN_SPRING_FILE = createExceptionCode(1000);

	@MessageCN("加载模板异常")
	@MessageUS("load template error")
	public static String LOAD_TEMPLATE_ERROR = createExceptionCode(1001);

	@MessageCN("模板:{0},模板编码为空")
	@MessageUS("template:{0},template code is null")
	public static String TEMPLATE_CODE_IS_NULL = createExceptionCode(1002);

	@MessageCN("模板:{0},工单类型未配置")
	@MessageUS("template:{0},have not bill type")
	public static String HAVE_NOT_BILL_TYPE = createExceptionCode(1003);

	@MessageCN("模板:{0},工单类型为空")
	@MessageUS("template:{0},bill type is null")
	public static String BILL_TYPE_IS_NULL = createExceptionCode(1004);

	@MessageCN("模板编码重复")
	@MessageUS("template code repeat")
	public static String TEMPLATE_CODE_REPEAT = createExceptionCode(1005);
	
	@MessageCN("工单uuid:{0},工单信息为null")
	@MessageUS("uuid:{0},bill info is null")
	public static String BILL_INFO_IS_NULL = createExceptionCode(1006);
	
	@MessageCN("工单uuid:{0},工单对应的设备信息为null")
	@MessageUS("uuid:{0},bill devices is null")
	public static String BILL_DEVICES_IS_NULL = createExceptionCode(1007);
	
	@MessageCN("工单类型:{0},没有查询出数据")
	@MessageUS("billtype:{0},havn't result")
	public static String NOT_HAVE_BILL_RESULT = createExceptionCode(1008);
	
	@MessageCN("工单类型:{0},没有配置事件链")
	@MessageUS("billtype:{0},havn't events")
	public static String NOT_HAVE_EVENTS = createExceptionCode(1009);
	
	@MessageCN("修改属性JSON字符串转换异常")
	@MessageUS("update attributes transition error")
	public static String UPDATE_ATTRIBUTES_TRANSITION_ERROR = createExceptionCode(1010);
	
	@MessageCN("工单类型:{0},资产状态和资源状态属性都未配置")
	@MessageUS("billtype:{0},the asset status and resource attributes are not configured")
	public static String ASSET_AND_RESOURCE_NULL = createExceptionCode(1011);
	
	@MessageCN("模板:{0},工单类型:{1},资产状态或者资源状态至少配置一项")
	@MessageUS("template:{0},billtype:{1},assets or resources configure at least one")
	public static String BILLTYPE_CONFIGURE_ERROR = createExceptionCode(1012);
	
	@MessageCN("工单类型重复")
	@MessageUS("bill type repeat")
	public static String BILLTYPE_REPEAT = createExceptionCode(1013);
	
	@MessageCN("查询异常")
	@MessageUS("query error")
	public static String QUERY_ERROR = createExceptionCode(1014);
	
	@MessageCN("修改异常")
	@MessageUS("update error")
	public static String UPDATE_ERROR = createExceptionCode(1015);
	
	@MessageCN("保存异常")
	@MessageUS("save error")
	public static String SAVE_ERROR = createExceptionCode(1016);
	
	@MessageCN("删除异常")
	@MessageUS("delete error")
	public static String DELETE_ERROR = createExceptionCode(1017);
	
	@MessageCN("请求异常")
	@MessageUS("request error")
	public static String REQUEST_ERROR = createExceptionCode(1018);

	/**
	 * 封装异常创建及抛出
	 * 
	 * @param ecode
	 * @param original
	 * @param params
	 * @param keyPoints
	 * @author wuhao
	 * @date 2014-7-23 下午2:45:48
	 */
	public static void throwException(String ecode, Exception original, Object[] params, Map<String, Object> keyPoints) {
		ItamRestException exception = new ItamRestException(ecode, original, params, keyPoints);
		exception.throwEx();
	}

	/**
	 * 工具方法，负责生成异常码
	 * 
	 * @param code
	 * @return String
	 * @author wuhao
	 * @date 2014-7-23 下午2:45:48
	 */
	private static String createExceptionCode(int code) {
		return getFormatedNumber(ID_PLATFORM, code);
	}
}

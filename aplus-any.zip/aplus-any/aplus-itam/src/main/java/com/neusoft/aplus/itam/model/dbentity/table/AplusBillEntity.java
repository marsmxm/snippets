package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @ClassName: AplusBillEntity
 * @Description: TODO
 * @author zhangyun
 * @date 2015-4-9 上午10:22:58
 */

@Entity
@Table(name = "aplus_bill")
public class AplusBillEntity implements Serializable, Cloneable {

	private static final long serialVersionUID = 1L;
	private String uuid;// uuid
	private String billNo;// 工单号
	private String billName;// 工单名称
	private String billType;// 工单类型
	private String billStatus;// 工单状态
	private String billAppUser;// 申请人
	private Date billAppTime;// 申请时间
	private Date billCheckTime;// 提交审批时间
	private Date billFihTime;// 审批通过时间
	private String handleUser;// 工单处理人，存账号
	private Date billCancelTime;// 取消时间
	private Date billPreFihTime;// 预计完成时间
	private String billRemark;// 备注
	private String delFlag;// 删除标记

	@Column(name = "bill_no")
	public String getBillNo() {
		return billNo;
	}

	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}

	@Column(name = "bill_name")
	public String getBillName() {
		return billName;
	}

	public void setBillName(String billName) {
		this.billName = billName;
	}

	@Column(name = "bill_type")
	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	@Column(name = "bill_status")
	public String getBillStatus() {
		return billStatus;
	}

	public void setBillStatus(String billStatus) {
		this.billStatus = billStatus;
	}

	@Column(name = "bill_app_user")
	public String getBillAppUser() {
		return billAppUser;
	}

	public void setBillAppUser(String billAppUser) {
		this.billAppUser = billAppUser;
	}

	@Column(name = "bill_app_time")
	public Date getBillAppTime() {
		return billAppTime;
	}

	public void setBillAppTime(Date billAppTime) {
		this.billAppTime = billAppTime;
	}

	@Column(name = "bill_check_time")
	public Date getBillCheckTime() {
		return billCheckTime;
	}

	public void setBillCheckTime(Date billCheckTime) {
		this.billCheckTime = billCheckTime;
	}

	@Column(name = "bill_fih_time")
	public Date getBillFihTime() {
		return billFihTime;
	}

	public void setBillFihTime(Date billFihTime) {
		this.billFihTime = billFihTime;
	}

	@Column(name = "handle_user")
	public String getHandleUser() {
		return handleUser;
	}

	public void setHandleUser(String handleUser) {
		this.handleUser = handleUser;
	}

	@Column(name = "bill_cancel_time")
	public Date getBillCancelTime() {
		return billCancelTime;
	}

	public void setBillCancelTime(Date billCancelTime) {
		this.billCancelTime = billCancelTime;
	}

	@Column(name = "bill_pre_fih_time")
	public Date getBillPreFihTime() {
		return billPreFihTime;
	}

	public void setBillPreFihTime(Date billPreFihTime) {
		this.billPreFihTime = billPreFihTime;
	}

	@Column(name = "bill_remark")
	public String getBillRemark() {
		return billRemark;
	}

	public void setBillRemark(String billRemark) {
		this.billRemark = billRemark;
	}

	@Column(name = "del_flag")
	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	@Id
	@GeneratedValue(generator = "paymentableGenerator")
	@GenericGenerator(name = "paymentableGenerator", strategy = "uuid")
	@Column(name = "uuid")
	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	
	public AplusBillEntity clone(){
		try {
			return (AplusBillEntity) super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String toString() {
		return "AplusBillEntity [uuid=" + uuid + ", bill_no=" + billNo
				+ ", bill_name=" + billName + ", bill_type=" + billType
				+ ", bill_status=" + billStatus + ", bill_app_user="
				+ billAppUser + ", bill_app_time=" + billAppTime
				+ ", bill_check_time=" + billCheckTime + ", bill_fih_time="
				+ billFihTime + ", handle_user=" + handleUser
				+ ", bill_cancel_time=" + billCancelTime
				+ ", bill_pre_fih_time=" + billPreFihTime + ", bill_remark="
				+ billRemark + ", del_flag=" + delFlag + "]";
	}
}

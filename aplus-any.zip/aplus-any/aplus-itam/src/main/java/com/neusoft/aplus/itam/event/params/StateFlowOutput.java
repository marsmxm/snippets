package com.neusoft.aplus.itam.event.params;

import java.io.Serializable;
import java.util.List;
import com.neusoft.aplus.common.event.Output;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillDeviceEntity;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillEntity;
import com.neusoft.aplus.itam.model.dbentity.table.FlowEntity;

public class StateFlowOutput implements Output, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7310158159988954852L;
	
	/**
	 * 工单
	 */
	private AplusBillEntity aplusBillEntity;
	/**
	 * 工单对应的设备
	 */
	private List<AplusBillDeviceEntity> AplusBillDeviceEntitys;
	/**
	 * 状态机
	 */
	private FlowEntity flowEntity;

	public StateFlowOutput() {

	}

	public StateFlowOutput(AplusBillEntity aplusBillEntity, List<AplusBillDeviceEntity> AplusBillDeviceEntitys) {
		this.aplusBillEntity = aplusBillEntity;
		this.AplusBillDeviceEntitys = AplusBillDeviceEntitys;
	}

	public StateFlowOutput(AplusBillEntity aplusBillEntity, List<AplusBillDeviceEntity> AplusBillDeviceEntitys,
			FlowEntity flowEntity) {
		this.aplusBillEntity = aplusBillEntity;
		this.AplusBillDeviceEntitys = AplusBillDeviceEntitys;
		this.flowEntity = flowEntity;
	}

	public AplusBillEntity getAplusBillEntity() {
		return aplusBillEntity;
	}

	public void setAplusBillEntity(AplusBillEntity aplusBillEntity) {
		this.aplusBillEntity = aplusBillEntity;
	}

	public List<AplusBillDeviceEntity> getAplusBillDeviceEntitys() {
		return AplusBillDeviceEntitys;
	}

	public void setAplusBillDeviceEntitys(List<AplusBillDeviceEntity> aplusBillDeviceEntitys) {
		AplusBillDeviceEntitys = aplusBillDeviceEntitys;
	}

	public FlowEntity getFlowEntity() {
		return flowEntity;
	}

	public void setFlowEntity(FlowEntity flowEntity) {
		this.flowEntity = flowEntity;
	}
}

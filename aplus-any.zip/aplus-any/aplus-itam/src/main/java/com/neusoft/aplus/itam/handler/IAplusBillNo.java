package com.neusoft.aplus.itam.handler;
/**
 * @author xizhy
 * @date 2015-4-13 下午5:49:45
 */
public interface IAplusBillNo {
	public String generationBillNo(String billType);
}

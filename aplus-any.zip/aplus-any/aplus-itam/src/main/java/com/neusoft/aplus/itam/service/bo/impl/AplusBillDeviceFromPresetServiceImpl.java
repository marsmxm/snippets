package com.neusoft.aplus.itam.service.bo.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillDeviceEntity;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;
import com.neusoft.aplus.itam.service.bo.IAplusBillDeviceFromPresetService;
import com.neusoft.aplus.itam.service.bo.IAplusPresetDevInfoService;
import com.neusoft.aplus.itam.service.dao.IAplusBillDeviceDao;

@Component
public class AplusBillDeviceFromPresetServiceImpl implements IAplusBillDeviceFromPresetService {
	@Autowired
	private IAplusBillDeviceDao aplusBillDeviceDao;
	@Autowired
	private IAplusPresetDevInfoService aplusPresetDevInfoService;

	

	@Transactional
	public void saveAplusBillDeviceByPreset(String bill_uuid, String bill_no, 
			List<AplusPresetDevInfoEntity> presetDevInfoEntityList) {
		for (AplusPresetDevInfoEntity presetDevInfoEntity : presetDevInfoEntityList) {
			List<AplusBillDeviceEntity> billDeviceEntityList = new LinkedList<AplusBillDeviceEntity>();
			AplusPresetDevInfoEntity entity = aplusPresetDevInfoService
					.findAplusPresetDevInfoByUuid(presetDevInfoEntity.getUuid());
			if (presetDevInfoEntity.getArrivalNumber() + entity.getArrivalNumber() > entity
					.getNumber()) {
				// 到货数量不能大于总数量

			} else {
				for (int j = 0; j < presetDevInfoEntity.getArrivalNumber(); j++) {
					AplusBillDeviceEntity billDeviceEntity = new AplusBillDeviceEntity();
					billDeviceEntity.setBillNo(bill_no);
					billDeviceEntity.setBillUuid(bill_uuid);
					billDeviceEntity.setDeviceType(entity.getDeviceType());
					billDeviceEntity
							.setDeviceVersion(entity.getDeviceVersion());
					JSONObject attr = new JSONObject();
					JSONArray jsonAttr = JSONArray.parseArray(entity.getAttr());
					Iterator<Object> it = jsonAttr.iterator();
					while(it.hasNext()){
						JSONObject json = (JSONObject)it.next();
						attr.put(json.get("name").toString(),"");
					}
					billDeviceEntity.setAttr(attr.toJSONString());
					billDeviceEntity.setAttrNew("{}");
					billDeviceEntity.setPresetDevUuid(presetDevInfoEntity.getUuid());
					billDeviceEntity.setCategory(entity.getCategory());
					billDeviceEntityList.add(billDeviceEntity);
				}
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("uuid", presetDevInfoEntity.getUuid());
				map.put("arrivalNumber", presetDevInfoEntity.getArrivalNumber());
				aplusPresetDevInfoService
						.updateAplusPresrtDevInfoArrivalNumber(map);
				aplusBillDeviceDao.saveAplusBillDevice(billDeviceEntityList);
			}
		}

	}
}

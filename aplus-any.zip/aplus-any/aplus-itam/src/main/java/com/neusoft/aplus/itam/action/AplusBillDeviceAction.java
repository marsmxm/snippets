package com.neusoft.aplus.itam.action;

import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillDeviceEntity;
import com.neusoft.aplus.itam.service.bo.IAplusBillDeviceService;
import com.neusoft.aplus.model.dbentity.Page;

/**
 * @author zhangyun
 * @date 2015-4-22 下午2:05:04
 */
public class AplusBillDeviceAction extends BaseAction {
	private IAplusBillDeviceService aplusBillDeviceService;
	private static Logger log = LoggerFactory.getLogger(AplusBillAction.class);
	private Map<String, String> paramsMapTatol;

	@Override
	public void doInit() {
		aplusBillDeviceService = ApplicationContextFactory
				.getBean(IAplusBillDeviceService.class);
		paramsMapTatol = getRequestParameters();
	}

	@Override
	public void acceptRepresentation(Representation entity) {
		Map<String, String> paramsMap = null;
		try {
			paramsMap = getObjectsFromRepresentation(entity,
					new TypeReference<Map<String, String>>() {
					});
			List<String> fqnlist = null;
			if (paramsMap != null && !paramsMap.isEmpty()) {
				String billUuid = (String) paramsMap.get("billUuid");
				String billNo = (String) paramsMap.get("billNo");
				String fqns = (String) paramsMap.get("fqns");
				if (fqns != null && !"".equals(fqns)) {
					fqnlist = JSONUtil.getObjectList(fqns, String.class);
				}
				aplusBillDeviceService.saveAplusBillDevice(fqnlist, billUuid,
						billNo);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();

	}

	@Override
	public Representation represent() {
		Page<AplusBillDeviceEntity> aplusBillDeviceEntity = null;
		String pageStr = (String) paramsMapTatol.get("page");
		String pageCountStr = (String) paramsMapTatol.get("pageCount");
		// 如果传过来为null或者""，默认为第一页
		Integer page = (pageStr == null || "".equals(pageStr)) ? 1 : Integer
				.parseInt(pageStr);
		// 如果传过来为null或者""，默认为每页10条数据
		Integer pageCount = (pageCountStr == null || "".equals(pageCountStr)) ? 10
				: Integer.parseInt(pageCountStr);
		String billUuid = (String) paramsMapTatol.get("billUuid");
		aplusBillDeviceEntity = aplusBillDeviceService
				.findAplusDeviceByBillUuid(page, pageCount, billUuid);
		if (aplusBillDeviceEntity != null) {
			return createObjectRepresentation(aplusBillDeviceEntity);
		}
		return null;
	}

	@Override
	public void removeRepresentations() {
		try {
			String billUuid = (String) paramsMapTatol.get("billUuid");// 工单UUID
																	// 查看工单是否为到货
			String uuids = (String) paramsMapTatol.get("uuids");// 设备UUID
			aplusBillDeviceService.deleteAplusBillDevice(uuids, billUuid);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}
		sendSuccess();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void storeRepresentation(Representation entity) {
		Map<String, Object> paramsMap = null;
		try {
			paramsMap = getObjectsFromRepresentation(entity,
					new TypeReference<Map<String, Object>>() {
					});

			Map<String, Map<String, String>> map = (Map<String, Map<String, String>>) paramsMap
					.get("map");
			String billUuid = (String) paramsMap.get("billUuid");
			aplusBillDeviceService.batchUpdateAplusBillDevice(map, billUuid);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();
	}
}

package com.neusoft.aplus.itam.service.dao.impl;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.criterion.Criterion;
import org.springframework.stereotype.Component;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillDeviceEntity;
import com.neusoft.aplus.itam.service.dao.IAplusBillDeviceDao;
import com.neusoft.aplus.itam.service.dao.base.ItamAbstractHibernateDao;
import com.neusoft.aplus.model.dbentity.Page;

@Component
public class AplusBillDeviceDaoImpl extends
		ItamAbstractHibernateDao<AplusBillDeviceEntity> implements
		IAplusBillDeviceDao {
	@Override
	public void saveAplusBillDevice(List<AplusBillDeviceEntity> entity) {
		batchSave(entity);
	}

	@Override
	public void deleteAplusBillDevice(List<AplusBillDeviceEntity> entityList) {
		batchRemove(entityList);
	}

	@Override
	public void batchUpdateAplusBillDevice(
			List<AplusBillDeviceEntity> entityList) {
		batchSaveOrUpdate(entityList);
	}

	@Override
	public AplusBillDeviceEntity findAplusDeivceByUuid(String uuid) {
		return get(uuid);
	}

	@Override
	public List<AplusBillDeviceEntity> findAplusDeviceByBillUuid(String billUuid) {
		String hql = " from AplusBillDeviceEntity " + "where bill_uuid = ? ";
		return find(hql, billUuid);
	}

	@Override
	public void deleteAplusBillDeviceByBillUuid(String billUuid) {
		String hql = "delete from AplusBillDeviceEntity t where t.billUuid=?";
		Query query = createQuery(hql, billUuid);
		query.executeUpdate();
	}

	@Override
	public void lockBillDevice(List<String> uuids) {
		String sql = "update AplusBillDeviceEntity set isCheck = '0'  "
				+ "WHERE uuid in (:uuid) ";
		Query query = createQuery(sql);
		query.setParameterList("uuid", uuids);
		query.executeUpdate();

	}
	
	public Page<AplusBillDeviceEntity> findAllAplusDevice(Integer page,
			Integer pageCount, List<Criterion> criterions){
		return getPagedResult(page,pageCount,criterions);
	}

	@Override
	public List<AplusBillDeviceEntity> findAplusDeviceIsByBillUuidAndIsCheck(String billUuid, String isCheck) {
		String hql = " from AplusBillDeviceEntity aplusBillDeviceEntity where aplusBillDeviceEntity.billUuid = ? and aplusBillDeviceEntity.isCheck = ?";
		return find(hql, billUuid, isCheck);
	}
}

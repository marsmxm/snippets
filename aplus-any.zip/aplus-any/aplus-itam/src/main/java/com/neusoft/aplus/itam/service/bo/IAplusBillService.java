package com.neusoft.aplus.itam.service.bo;

import com.neusoft.aplus.itam.model.dbentity.table.AplusBillEntity;
import com.neusoft.aplus.model.dbentity.Page;

public interface IAplusBillService {
	/**
	 * @Description: 创建工单
	 * @author zhangyun
	 * @date 2015-4-14 上午9:30:57
	 * @param @param billType
	 * @param @param username
	 * @return void
	 * @throws
	 */
	public String saveAplusBill(String billType, String username);
	
	
	/**
	 * @Description: 删除工单
	 * @author zhangyun
	 * @date 2015-4-13 上午9:47:34
	 * @param @param aplusBillList
	 * @return void
	 * @throws
	 */
	public void deleteAplusBill(String billUuid);

	/**
	 * @Description: 提交工单
	 * @author zhangyun
	 * @date 2015-4-13 下午4:12:59
	 * @param @param uuid
	 * @param @param type
	 * @return void
	 * @throws
	 */
	public void commitAplusBill(String uuid);

	/**
	 * @Description: 完成工单
	 * @author zhangyun
	 * @date 2015-4-13 下午4:12:59
	 * @param @param uuid
	 * @return void
	 * @throws
	 */
	public void finishAplusBill(String uuid);

	/**
	 * @Description: 分页查询工单
	 * @author zhangyun
	 * @date 2015-4-24 上午10:18:00 
	 * @param @param page
	 * @param @param pageCount
	 * @param @param billType
	 * @param @return
	 * @return Page<AplusBillEntity>
	 * @throws
	 */
	public Page<AplusBillEntity> findBillByBillType(Integer page,
			Integer pageCount, String billType);

	/**
	 * @Description: 获取编号
	 * @author lu.z
	 * @date 2015年4月21日 上午11:05:26
	 * @param @param prefix 前缀
	 * @return String
	 * @throws
	 */
	public String generateNo(String prefix);
	/**
	 * @Description: 根据UUid查询工单
	 * @author zhangyun
	 * @date 2015-4-24 下午3:05:22 
	 * @param @param Uuid
	 * @param @return
	 * @return AplusBillEntity
	 * @throws
	 */
	public AplusBillEntity findBillByUuid(String Uuid);
}
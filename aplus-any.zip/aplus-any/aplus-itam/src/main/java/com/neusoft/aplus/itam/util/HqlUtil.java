package com.neusoft.aplus.itam.util;

import java.util.HashMap;
import java.util.Set;

public class HqlUtil {
	public static String createHql(String tableName, HashMap<String, ?> params)
	{
		//from AplusPositionDefineEntity adt where adt.positionLevel<= ? 
		String hql = "from "+tableName+" tab where ";
		Set<String> paramKey = params.keySet();
		for(String key:paramKey)
		{
			Object value = params.get(key);
			if(value instanceof String)
			{
				hql+=" tab."+key+"='"+value+"' and ";
			}else if (value instanceof String[])
			{
				String str="(";
				for(String s:(String[])value)
				{
					str+="'"+s+"',";
				}
				str = str.substring(0, str.length()-1)+")";
				
				hql+=" tab."+key+" in "+str+" and ";
			}
		}
		return hql.substring(0, hql.length()-4);
	}
}

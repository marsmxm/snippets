package com.neusoft.aplus.itam.action;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;
import org.restlet.representation.Representation;
import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.constant.Constant;
import com.neusoft.aplus.itam.exception.ItamRestException;
import com.neusoft.aplus.itam.model.dbentity.table.StrategyEntify;
import com.neusoft.aplus.itam.model.dbentity.table.StrategyOrgEntify;
import com.neusoft.aplus.itam.service.bo.IStrategyService;

/**
 * @ClassName: StrategyAction 
 * @Description: 权限策略action
 * @author lu.z
 * @date 2015年5月20日 下午4:49:44
 */
public class StrategyAction extends BaseAction{
	
	private Map<String, String> paramsMap;
	private IStrategyService strategyService;
	
	@Override
	public void doInit() {
		paramsMap = getRequestParameters();
		strategyService = ApplicationContextFactory.getBean(IStrategyService.class);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void acceptRepresentation(Representation entity) {
		Map<String, String> paramsMap = null;
		try {
			paramsMap = getObjectsFromRepresentation(entity, new TypeReference<Map<String, String>>() {});
			if(paramsMap != null){
				paramsMap.put("type", "add");
				Map<String, Object> map = transfor2Map(paramsMap);
				StrategyEntify strategyEntify = (StrategyEntify) map.get("strategyEntify");
				List<StrategyOrgEntify> strategyOrgEntifys = (List<StrategyOrgEntify>) map.get("strategyOrgEntifys");
				//保存数据权限信息
				strategyService.saveStrategy(strategyEntify, strategyOrgEntifys);
			}
		} catch (Exception e) {
			ItamRestException.throwException(ItamRestException.SAVE_ERROR, e, null, null);
		}
	}
	
	
	
	@Override
	public Representation represent() {
		String m = paramsMap.get("m"); 
		if("getDatas".equals(m)){
			String strategyName = paramsMap.get("strategyName"); 
			String modelId = paramsMap.get("modelId");  
			String page = paramsMap.get("page"); 
			String pageCount = paramsMap.get("pageCount"); 
			Map<String, String> paramsMap = new HashMap<String, String>();
			paramsMap.put(Constant.PAGE, page);
			paramsMap.put(Constant.PAGE_COUNT, pageCount);
			paramsMap.put("modelId", modelId);
			paramsMap.put("name", strategyName);
			Map<String, Object> resultMap = strategyService.findStrategyByConditions(paramsMap);
			return createObjectRepresentation(resultMap);
		} else if("getDataById".equals(m)){
			String uuid = paramsMap.get("uuid"); 
			StrategyEntify strategyEntify = strategyService.findStrategyById(uuid);
			return createObjectRepresentation(strategyEntify);
		} else if("isExistModel".equals(m)){
			String modelId = paramsMap.get("modelId"); 
			boolean isExist = strategyService.isExistModel(modelId);
			Map<String, Boolean> resultMap = new HashMap<String, Boolean>();
			resultMap.put("isExist", isExist);
			return createObjectRepresentation(resultMap);
		}
		return null;
	}

	@Override
	public void removeRepresentations() {
		String idsStr = paramsMap.get("ids");
		if(idsStr != null && !"".equals(idsStr)){
			String ids[] = idsStr.split(",");
			List<String> list = Arrays.asList(ids);
			strategyService.removeStrategys(list);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void storeRepresentation(Representation entity) {
		Map<String, String> paramsMap = null;
		try {
			paramsMap = getObjectsFromRepresentation(entity, new TypeReference<Map<String, String>>() {});
			if(paramsMap != null){
				Map<String, Object> map = transfor2Map(paramsMap);
				StrategyEntify strategyEntify = (StrategyEntify) map.get("strategyEntify");
				List<StrategyOrgEntify> strategyOrgEntifys = (List<StrategyOrgEntify>) map.get("strategyOrgEntifys");
				//保存数据权限信息
				strategyService.updateStrategy(strategyEntify, strategyOrgEntifys);
			}
		} catch (Exception e) {
			ItamRestException.throwException(ItamRestException.UPDATE_ERROR, e, null, null);
		}
	}
	
	/**
	 * @Description: 将获取到的参数转换成service需要的对象
	 * @author lu.z
	 * @date 2015年5月22日 下午3:56:35 
	 * @param @param paramsMap
	 * @param @return
	 * @param @throws Exception
	 * @return Map<String,Object>
	 * @throws
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Object> transfor2Map(Map<String, String> paramsMap) throws Exception{
		Map<String, Object> map = new HashMap<String, Object>();
		
		String name = paramsMap.get("name");
		String modelName = paramsMap.get("modelName");
		String modelId = paramsMap.get("modelId");
		String datas = paramsMap.get("datas");
		String user = paramsMap.get("user");
		String type = paramsMap.get("type");
		
		StrategyEntify strategyEntify = new StrategyEntify();
		String strategyId = UUID.randomUUID().toString();
		strategyEntify.setUuid(strategyId);
		strategyEntify.setName(name);
		strategyEntify.setModelName(modelName);
		strategyEntify.setModelId(modelId);
		strategyEntify.setOrgsTree(datas);
		if("add".equals(type)){
			strategyEntify.setCreateUser(user);
			strategyEntify.setCreateTime(new Date(System.currentTimeMillis()));
		} else{
			strategyEntify.setUpdateUser(user);
			strategyEntify.setUpdateTime(new Date(System.currentTimeMillis()));
			String uuid = paramsMap.get("uuid");
			strategyEntify.setUuid(uuid);
		}
		map.put("strategyEntify", strategyEntify);
		JSONObject jsonObject = new JSONObject(datas);
		if(jsonObject != null){
			Iterator<String> iterator = jsonObject.keys();
			List<StrategyOrgEntify> strategyOrgEntifys = new ArrayList<StrategyOrgEntify>();
			while(iterator.hasNext()){
				String key = iterator.next();
				StrategyOrgEntify strategyOrgEntify = new StrategyOrgEntify();
				strategyOrgEntify.setUuid(UUID.randomUUID().toString());
				strategyOrgEntify.setStrategyId(strategyId);
				strategyOrgEntify.setOrgId(key);
				JSONArray orgs = jsonObject.getJSONArray(key);
				String strategyOrg = parseOrgTree(orgs);
				if(!"".equals(strategyOrg)){
					strategyOrg = strategyOrg.substring(0, strategyOrg.length() - 1);
				}
				strategyOrgEntify.setStrategyOrg(strategyOrg);
				strategyOrgEntifys.add(strategyOrgEntify);
			}
			map.put("strategyOrgEntifys", strategyOrgEntifys);
		}
		return map;
	}
	/**
	 * @Description: 解析策略组织数
	 * @author lu.z
	 * @date 2015年5月22日 下午3:56:10 
	 * @param @param orgs
	 * @param @return
	 * @param @throws Exception
	 * @return String
	 * @throws
	 */
	private String parseOrgTree(JSONArray orgs) throws Exception{
		String strategyOrgs = "";
		if(orgs != null){
			for(int i = 0; i < orgs.length(); i++){
				JSONObject jsonObject = orgs.getJSONObject(i);
				if(jsonObject != null){
					strategyOrgs += jsonObject.getString("id") + ",";
					if(jsonObject.has("children")){
						JSONArray children = jsonObject.getJSONArray("children");
						strategyOrgs += parseOrgTree(children);
					}
				}
			}
		}
		return strategyOrgs;
	}
}

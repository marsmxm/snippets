package com.neusoft.aplus.itam.service.dao;

import java.util.List;

import com.neusoft.aplus.itam.model.dbentity.table.StrategyOrgEntify;

/**
 * @ClassName: IStrategyOrgDao 
 * @Description: 数据权限组织DAO
 * @author lu.z
 * @date 2015年5月22日 下午1:59:33
 */
public interface IStrategyOrgDao {
	/**
	 * @Description: 保存数据权限组织信息
	 * @author lu.z
	 * @date 2015年5月22日 下午2:00:21 
	 * @param 
	 * @return void
	 * @throws
	 */
	public void saveStrategyOrgs(List<StrategyOrgEntify> strategyOrgEntifys);
	/**
	 * @Description: 删除数据权限组织信息
	 * @author lu.z
	 * @date 2015年5月22日 下午2:01:31 
	 * @param strategyIds
	 * @return void
	 * @throws
	 */
	public void removeStrategyOrgs(List<String> ids);
	/**
	 * @Description: 删除所有数据权限组织信息
	 * @author lu.z
	 * @date 2015年5月25日 上午11:43:01 
	 * @param strategyId
	 * @return void
	 * @throws
	 */
	public void removeStrategyOrgsByStrategyId(String strategyId);
	/**
	 * @Description: 根据策略ID和组织ID，查询数据权限信息
	 * @author lu.z
	 * @date 2015年5月26日 下午2:03:42 
	 * @param strategyId
	 * @param orgId
	 * @return void
	 * @throws
	 */
	public StrategyOrgEntify findStrategyOrgByOrgId(String strategyId, String orgId);
}

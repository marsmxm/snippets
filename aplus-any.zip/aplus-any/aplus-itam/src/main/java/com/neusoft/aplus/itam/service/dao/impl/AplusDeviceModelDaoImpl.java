package com.neusoft.aplus.itam.service.dao.impl;

import java.util.List;

import org.springframework.stereotype.Component;
import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.itam.model.dbentity.table.AplusDeviceModelEntity;
import com.neusoft.aplus.itam.service.dao.IAplusDeviceModelDao;


@Component
public class AplusDeviceModelDaoImpl extends AbstractHibernateDao<AplusDeviceModelEntity> 
implements IAplusDeviceModelDao{

	@Override
	public List<AplusDeviceModelEntity> findAplusDeviceModelByDevtypeAndSupp(
			String devtypeId, String supplierId) {
		// TODO Auto-generated method stub
		String hql = "from AplusDeviceModelEntity adm where adm.devtypeId = ?  and adm.supplierId=?";
		return find(hql, devtypeId,supplierId);
	}

	@Override
	public List<AplusDeviceModelEntity> findAplusDeviceModelByDevtype(
			String devtypeId) {
		// TODO Auto-generated method stub
		String hql = "from AplusDeviceModelEntity adm where adm.devtypeId = ?";
		return find(hql, devtypeId);
	}

	@Override
	public void saveOrUpdateAplusDeviceModel(
			AplusDeviceModelEntity aplusDeviceModelEntity) {
		// TODO Auto-generated method stub
		save(aplusDeviceModelEntity);
		
	}
}

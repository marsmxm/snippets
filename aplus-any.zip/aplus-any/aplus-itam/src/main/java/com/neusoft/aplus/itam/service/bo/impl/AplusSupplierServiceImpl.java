package com.neusoft.aplus.itam.service.bo.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.neusoft.aplus.itam.model.dbentity.table.AplusSupplierEntity;
import com.neusoft.aplus.itam.service.bo.IAplusSupplierService;
import com.neusoft.aplus.itam.service.dao.IAplusSupplierDao;

@Component
public class AplusSupplierServiceImpl implements IAplusSupplierService{
	@Autowired
	private IAplusSupplierDao aplusSupplierDao;

	@Override
	@Transactional
	public void saveOrUpdateAplusSupplier(
			AplusSupplierEntity aplusSupplierEntity) {
		// TODO Auto-generated method stub
		aplusSupplierDao.saveOrUpdateAplusSupplier(aplusSupplierEntity);
	}

	@Override
	@Transactional
	public List<AplusSupplierEntity> findAplusSupplierEntitys(boolean isprov,
			boolean isprod, boolean ischeck, boolean isdeve, boolean isserv,
			boolean istotal) {
		// TODO Auto-generated method stub
		return aplusSupplierDao.findAplusSupplierEntitys(isprov, isprod, ischeck, isdeve, isserv, istotal);
	}

	@Override
	@Transactional
	public void deleteAplusSupplierEntity(
			AplusSupplierEntity aplusSupplierEntity) {
		// TODO Auto-generated method stub
		aplusSupplierDao.deleteAplusSupplierEntity(aplusSupplierEntity);
		
	}

	@Override
	@Transactional
	public List<AplusSupplierEntity> findAplusSupplierEntitysByDevtype(
			String devtypeId) {
		// TODO Auto-generated method stub
		return aplusSupplierDao.findAplusSupplierEntitysByDevtype(devtypeId);
	}

	@Override
	@Transactional
	public List<AplusSupplierEntity> findAplusSupplierByObject(
			AplusSupplierEntity aplusSupplierEntity) {
		// TODO Auto-generated method stub
		return aplusSupplierDao.findAplusSupplierByObject(aplusSupplierEntity);
	} 	

}

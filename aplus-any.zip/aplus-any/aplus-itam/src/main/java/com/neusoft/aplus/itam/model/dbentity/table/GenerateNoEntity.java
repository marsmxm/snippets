package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @ClassName: GenerateNoEntity 
 * @Description: 生成的编号实体类
 * @author lu.z
 * @date 2015年4月21日 上午11:34:59
 */
@Entity
@Table(name = "aplus_generation_no")
public class GenerateNoEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6552386427775919578L;
	
	/**
	 * 主键
	 */
	private Integer id;
	/**
	 * 工单号前缀
	 */
	private String prefix;
	/**
	 * 工单号数量
	 */
	private Integer number;
	
	@Id
	@GeneratedValue
	@Column(name = "id")
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	@Column(name = "prefix")
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	
	@Column(name = "number")
	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}
}

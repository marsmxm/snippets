package com.neusoft.aplus.itam.service.bo;

import java.util.List;
import java.util.Map;

import com.neusoft.aplus.itam.model.bizentity.EventEntity;
import com.neusoft.aplus.itam.model.dbentity.table.FlowEntity;
import com.neusoft.aplus.model.dbentity.Page;

/**
 * @ClassName: IStateFlowService
 * @Description: 状态机对外提供的接口
 * @author lu.z
 * @date 2015年4月9日 上午10:30:19
 */
public interface IStateFlowService {
	/**
	 * @Description: 获取所有状态机
	 * @author lu.z
	 * @date 2015年4月9日 下午4:10:25
	 * @param @return
	 * @return List<FlowEntity>
	 * @throws
	 */
	public List<FlowEntity> findAllStateFlow();

	/**
	 * @Description: 获取所有状态机（分页）
	 * @author lu.z
	 * @date 2015年4月23日 上午9:34:57
	 * @param @param page
	 * @param @param pageCount
	 * @param @return
	 * @return Page<FlowEntity>
	 * @throws
	 */
	public Page<FlowEntity> findAllStateFlow(Integer page, Integer pageCount);

	/**
	 * @Description: 根据类型获取状态机
	 * @author lu.z
	 * @date 2015年4月9日 下午4:14:41
	 * @param @param type 类型 (StateFlow.ASSETS-资产；StateFlow.RESOURCES-资源)
	 * @param @return
	 * @return List<FlowEntity>
	 * @throws
	 */
	public List<FlowEntity> findStateFlowByType(String stateFlowType);

	/**
	 * @Description: 根据类型获取状态机（分页）
	 * @author lu.z
	 * @date 2015年4月23日 上午9:35:53
	 * @param @param page
	 * @param @param pageCount
	 * @param @param stateFlow
	 * @param @return
	 * @return List<FlowEntity>
	 * @throws
	 */
	public Page<FlowEntity> findStateFlowByType(Integer page, Integer pageCount, String stateFlowType);

	/**
	 * @Description: 根据模板code获取状态机信息
	 * @author lu.z
	 * @date 2015年4月9日 下午4:13:00
	 * @param @param templateCode 模板code
	 * @param @return
	 * @return List<FlowEntity>
	 * @throws
	 */
	public List<FlowEntity> findStateFlowByTemplateCode(String templateCode);

	/**
	 * @Description: 根据模板code获取状态机信息（分页）
	 * @author lu.z
	 * @date 2015年4月23日 上午9:36:31
	 * @param @param page
	 * @param @param pageCount
	 * @param @param templateCode
	 * @param @return
	 * @return List<FlowEntity>
	 * @throws
	 */
	public Page<FlowEntity> findStateFlowByTemplateCode(Integer page, Integer pageCount, String templateCode);

	/**
	 * @Description: 根据模板code和类型获取状态机信息
	 * @author lu.z
	 * @date 2015年4月9日 下午4:14:02
	 * @param @param templateCode 模板code
	 * @param @param type 类型 (StateFlow.ASSETS-资产；StateFlow.RESOURCES-资源)
	 * @param @return
	 * @return List<FlowEntity>
	 * @throws
	 */
	public List<FlowEntity> findStateFlowByTemplateCodeAndType(String templateCode, String stateFlowType);

	/**
	 * @Description: 根据模板code和类型获取状态机信息（分页）
	 * @author lu.z
	 * @date 2015年4月23日 上午9:36:58
	 * @param @param page
	 * @param @param pageCount
	 * @param @param templateCode
	 * @param @param stateFlow
	 * @param @return
	 * @return List<FlowEntity>
	 * @throws
	 */
	public Page<FlowEntity> findStateFlowByTemplateCodeAndType(Integer page, Integer pageCount, String templateCode,
			String stateFlowType);

	/**
	 * @Description: 根据工单类型获取状态机
	 * @author lu.z
	 * @date 2015年4月9日 下午4:23:11
	 * @param @param billType 工单类型
	 * @param @return
	 * @return FlowEntity
	 * @throws
	 */
	public FlowEntity findStateFlowByBillType(String billType);

	/**
	 * @Description: 根据提交状态获取状态机
	 * @author lu.z
	 * @date 2015年4月9日 下午4:26:43
	 * @param @param billType 工单类型
	 * @param @param commitStatus 提交状态
	 *        (BillStatus.SAVE-提交前；BillStatus.APPROVED-提交后)
	 * @param @return
	 * @return Map<String,String>
	 * @throws
	 */
	public String findUpdateAttrsByCommitStatus(String billType, String billStatus);

	/**
	 * @Description: 查看工单类型可以修改的设备是软件还是硬件
	 * @author lu.z
	 * @date 2015年4月20日 上午10:06:30
	 * @param @param billType
	 * @param @return
	 * @return String
	 * @throws
	 */
	public String findDeviceTypeByBillType(String billType);

	/**
	 * @Description: 工作操作结束
	 * @author lu.z
	 * @date 2015年4月9日 下午5:06:16
	 * @param @param uuid 工单主键
	 * @param @return
	 * @return boolean
	 * @throws
	 */
	public boolean doBillFinish(String uuid);
	
	/**
	 * @Description: 获取配置的事件名称
	 * @author lu.z
	 * @date 2015年4月23日 下午1:34:34 
	 * @param @return
	 * @return List<EventEntity>
	 * @throws
	 */
	public List<EventEntity> findEventNames();
	
	/**
	 * @Description: 保存状态机信息
	 * @author lu.z
	 * @date 2015年4月23日 下午1:47:47 
	 * @param flowEntity
	 * @return void
	 * @throws
	 */
	public void saveFlowState(FlowEntity flowEntity);
	
	/**
	 * @Description: 修改状态机
	 * @author lu.z
	 * @date 2015年4月23日 下午1:53:41 
	 * @param @param flowEntity
	 * @return void
	 * @throws
	 */
	public void updateFlowState(FlowEntity flowEntity);
	
	/**
	 * @Description: 根据id数组删除状态机信息
	 * @author lu.z
	 * @date 2015年4月23日 下午1:52:50 
	 * @param @param ids
	 * @return void
	 * @throws
	 */
	public void removeFlowStateByIds(List<Integer> ids);
	
	/**
	 * @Description: 根据id删除状态机信息
	 * @author lu.z
	 * @date 2015年4月23日 下午2:06:05 
	 * @param @param id
	 * @return void
	 * @throws
	 */
	public void removeFlowStateById(Integer id);
	
	/**
	 * @Description: 根据条件查询状态机
	 * @author lu.z
	 * @date 2015年5月5日 上午9:22:00 
	 * @param @param paramsMap
	 * @return Map<String, Object>
	 * @throws
	 */
	public Map<String, Object> findStateFlowsByConditions(Map<String, String> paramsMap);
}

package com.neusoft.aplus.itam.service.dao;

import java.util.List;

import com.neusoft.aplus.itam.model.dbentity.table.AplusDeviceModelEntity;


/**
 * @ClassName: AplusDeviceModelDao 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-13 下午4:08:59
 */
public interface IAplusDeviceModelDao {
	/**
	 * @Description: 根据设备类型和合作商id查询型号
	 * @author jin.ysh
	 * @date 2015-4-13 下午4:10:55 
	 * @param @param devtypeId
	 * @param @param supplierId
	 * @param @return
	 * @return List<AplusDeviceModelEntity>
	 * @throws
	 */
	public List<AplusDeviceModelEntity> findAplusDeviceModelByDevtypeAndSupp(String devtypeId,String supplierId);
	/**
	 * @Description: 根据设备类型查询型号
	 * @author jin.ysh
	 * @date 2015-4-17 下午4:29:15 
	 * @param @param devtypeId
	 * @param @return
	 * @return List<AplusDeviceModelEntity>
	 * @throws
	 */
	public List<AplusDeviceModelEntity> findAplusDeviceModelByDevtype(String devtypeId);
	/**
	 * @Description: 保存设备型号
	 * @author jin.ysh
	 * @date 2015-4-17 下午5:17:11 
	 * @param @param aplusDeviceModelEntity
	 * @return void
	 * @throws
	 */
	public void saveOrUpdateAplusDeviceModel(AplusDeviceModelEntity aplusDeviceModelEntity);
}

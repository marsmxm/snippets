package com.neusoft.aplus.itam.service.dao.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.criterion.Criterion;
import org.springframework.stereotype.Component;

import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.itam.constant.BillStatus;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillEntity;
import com.neusoft.aplus.itam.service.dao.IAplusBillDao;
import com.neusoft.aplus.model.dbentity.Page;

@Component
public class AplusBillDaoImpl extends AbstractHibernateDao<AplusBillEntity>
		implements IAplusBillDao {
	@Override
	public String saveAplusBill(AplusBillEntity entity) {
		return (String)save(entity);
	}

	@Override
	public void deleteAplusBill(AplusBillEntity entity) {
		remove(entity);
	}

	@Override
	public void commitAplusBillStatus(String uuid) {
		String hql = "update AplusBillEntity t set t.billCheckTime = ?,t.billStatus=? where t.uuid=?";
		Query query = createQuery(hql, new Date(), BillStatus.APPROVING.name(),
				uuid);
		query.executeUpdate();
	}

	@Override
	public String generationBillNo(String bill_type) {

		return null;
	}

	public AplusBillEntity findBillByUuid(String uuid) {
		return get(uuid);
	}

	@Override
	public void finishAplusBillStatus(String uuid) {
		String hql = "update AplusBillEntity t set t.billFihTime = ?,t.billStatus=? where t.uuid=?";
		Query query = createQuery(hql, new Date(), BillStatus.CLOSED.name(),
				uuid);
		query.executeUpdate();
	}

	@Override
	public Page<AplusBillEntity> findBillByBillType(Integer page,
			Integer pageCount, List<Criterion> criterions) {

		return getPagedResult(page, pageCount, criterions);
	}
}

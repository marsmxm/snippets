package com.neusoft.aplus.itam.constant;

/**
 * @ClassName: BillDeviceLock
 * @Description: 工单锁类型:排他锁,同步锁
 * @author zhangyun
 * @date 2015-4-22 上午10:40:01
 */
public enum BillDeviceLock {
	EXCLUSIVE, SYNCHRO
}

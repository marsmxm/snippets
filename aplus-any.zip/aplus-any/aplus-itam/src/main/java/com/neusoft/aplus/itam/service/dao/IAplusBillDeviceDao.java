package com.neusoft.aplus.itam.service.dao;

import java.util.List;

import org.hibernate.criterion.Criterion;

import com.neusoft.aplus.itam.model.dbentity.table.AplusBillDeviceEntity;
import com.neusoft.aplus.model.dbentity.Page;

public interface IAplusBillDeviceDao {
	/**
	 * @Description: 保存工单设备
	 * @author zhangyun
	 * @date 2015-4-13 下午2:41:28
	 * @param @param entity
	 * @return void
	 * @throws
	 */
	public void saveAplusBillDevice(List<AplusBillDeviceEntity> entity);

	/**
	 * @Description: 删除工单设备
	 * @author zhangyun
	 * @date 2015-4-13 下午2:41:44
	 * @param @param entityList
	 * @return void
	 * @throws
	 */
	public void deleteAplusBillDevice(List<AplusBillDeviceEntity> entityList);

	/**
	 * @Description: 批量修改工单设备属性
	 * @author zhangyun
	 * @date 2015-4-13 下午2:42:05
	 * @param @param entityList
	 * @return void
	 * @throws
	 */
	public void batchUpdateAplusBillDevice(
			List<AplusBillDeviceEntity> entityList);

	/**
	 * @Description: 根据工单设备UUID 查询工单设备
	 * @author zhangyun
	 * @date 2015-4-13 下午2:42:48
	 * @param @param uuid
	 * @param @return
	 * @return AplusBillDeviceEntity
	 * @throws
	 */
	public AplusBillDeviceEntity findAplusDeivceByUuid(String uuid);

	/**
	 * @Description: 根据工单UUID查询工单下设备
	 * @author zhangyun
	 * @date 2015-4-13 下午2:43:17
	 * @param @param bill_uuid
	 * @param @return
	 * @return List<AplusBillDeviceEntity>
	 * @throws
	 */
	public List<AplusBillDeviceEntity> findAplusDeviceByBillUuid(String billUuid);

	/**
	 * @Description: 根据工单UUID 删除工单下设备
	 * @author zhangyun
	 * @date 2015-4-14 上午10:14:42
	 * @param @param billUuid
	 * @return void
	 * @throws
	 */
	public void deleteAplusBillDeviceByBillUuid(String billUuid);

	/**
	 * @Description: 锁定工单设备
	 * @author zhangyun
	 * @date 2015-4-14 上午10:53:10
	 * @param @param uuids
	 * @return void
	 * @throws
	 */
	public void lockBillDevice(List<String> uuids);
	/**
	 * @Description: 分页查询工单设备
	 * @author zhangyun
	 * @date 2015-4-23 下午3:06:14 
	 * @param @param page
	 * @param @param pageCount
	 * @param @param criterions
	 * @param @return
	 * @return Page<AplusBillEntity>
	 * @throws
	 */
	public Page<AplusBillDeviceEntity> findAllAplusDevice(Integer page,
			Integer pageCount, List<Criterion> criterions);
	
	/**
	 * @Description: 根据工单uuid和锁定状态查询工单设备信息
	 * @author lu.z
	 * @date 2015年4月24日 上午11:15:37 
	 * @param @param billUuid
	 * @param @param isCheck
	 * @param @return
	 * @return List<AplusBillDeviceEntity>
	 * @throws
	 */
	public List<AplusBillDeviceEntity> findAplusDeviceIsByBillUuidAndIsCheck(String billUuid, String isCheck);
}

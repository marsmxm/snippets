package com.neusoft.aplus.itam.action;

import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;

import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPositionDefineEntity;
import com.neusoft.aplus.itam.service.bo.IAplusPositionDefineService;
/**
 * @ClassName: AplusPositionDefineAction 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-23 下午4:05:24
 */
public class AplusPositionDefineAction extends BaseAction{
	private IAplusPositionDefineService aplusPositionDefineService;
	private Map<String, String> paramsMap;
	@Override
	public void doInit() {
		aplusPositionDefineService = ApplicationContextFactory.getBean(IAplusPositionDefineService.class);
		paramsMap = getRequestParameters();
	}

	@Override
	public void acceptRepresentation(Representation entity) {
		AplusPositionDefineEntity aplusPositionDefineEntity = null;
		try {
			aplusPositionDefineEntity = getObjectsFromRepresentation(entity, new TypeReference<AplusPositionDefineEntity>() {
			});
			if (aplusPositionDefineEntity != null) {
				aplusPositionDefineService.saveAplusPositionDefine(aplusPositionDefineEntity);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();
	}

	@Override
	public Representation represent() {
		// TODO Auto-generated method stub
		List<AplusPositionDefineEntity> positionDefineList = null;
		String positionLevel = (String) paramsMap.get("positionLevel");
		String positionId = (String) paramsMap.get("positionId");
		if(positionId!=null)
		{
			positionDefineList = aplusPositionDefineService.findAplusPositionDefineById(positionId);
		}else if(positionLevel!=null)
		{
			positionDefineList = aplusPositionDefineService.findAplusPositionDefines(positionLevel);
		}
		if (positionDefineList != null && !positionDefineList.isEmpty()) {
			return createObjectRepresentation(positionDefineList);
		}
		return null;
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub
		try {
			String positionId = (String) paramsMap.get("positionId");
			AplusPositionDefineEntity aplusPositionDefineEntity = new AplusPositionDefineEntity();
			aplusPositionDefineEntity.setPositionId(positionId);
			aplusPositionDefineService.deleteAplusPositionDefine(aplusPositionDefineEntity);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();
		
	}

	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		AplusPositionDefineEntity aplusPositionDefineEntity = null;
		try {
			aplusPositionDefineEntity = getObjectsFromRepresentation(entity, new TypeReference<AplusPositionDefineEntity>() {
			});
			if (aplusPositionDefineEntity != null) {
				aplusPositionDefineService.saveOrUpdateAplusPositionDefine(aplusPositionDefineEntity);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();
	}

}

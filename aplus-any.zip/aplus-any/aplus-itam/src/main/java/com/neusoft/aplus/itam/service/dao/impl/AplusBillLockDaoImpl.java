package com.neusoft.aplus.itam.service.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Component;

import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillLockEntity;
import com.neusoft.aplus.itam.service.dao.IAplusBillLockDao;

@Component
public class AplusBillLockDaoImpl extends
		AbstractHibernateDao<AplusBillLockEntity> implements
		IAplusBillLockDao {
	@Override
	public void saveOrUpdateAplusBillLock(List<AplusBillLockEntity> entityList) {
		batchSaveOrUpdate(entityList);
	}
	
	public void deleteAplusBillLockBydevFqns(List<String> Fqns)
	{
		String hql = "delete from AplusBillLockEntity t where t.devFqn in (:Fqns) ";
		Query query = createQuery(hql);
		query.setParameterList("Fqns", Fqns);
		query.executeUpdate();
	}
	
	@Override
	public void deleteAplusBillLockByBillUuid(String billUuid)
	{
		String hql = "delete from AplusBillLockEntity t where t.billUuid=?";
		Query query = createQuery(hql, billUuid);
		query.executeUpdate();
	}
}

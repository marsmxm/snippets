package com.neusoft.aplus.itam.service.bo.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.exception.ItamRestException;
import com.neusoft.aplus.itam.model.bizentity.FlowTemplate;
import com.neusoft.aplus.itam.model.dbentity.table.FlowEntity;
import com.neusoft.aplus.itam.model.dbentity.table.TemplateEntity;
import com.neusoft.aplus.itam.service.bo.ITemplateService;
import com.neusoft.aplus.itam.service.dao.IStateFlowDao;
import com.neusoft.aplus.itam.service.dao.ITemplateDao;

/**
 * @ClassName: TemplateServiceImpl
 * @Description: 模板管理service
 * @author lu.z
 * @date 2015年4月23日 下午1:42:01
 */
@Component
public class TemplateServiceImpl implements ITemplateService {

	private static Logger logger = LoggerFactory.getLogger(TemplateServiceImpl.class);

	@Autowired
	private ITemplateDao templateDao;
	@Autowired
	private IStateFlowDao stateFlowDao;

	@Override
	@Transactional
	public void reloadTemplate() {
		logger.info("重新载入模板开始");
		Map<String, FlowTemplate> flowTemplateMap = ApplicationContextFactory.getBeansOfType(FlowTemplate.class, false,
				false);
		// 校验模板配置是否正确，如果校验失败直接抛出异常，校验成功则会继续执行
		Map<String, List<String>> resultMap = this.checkTemplate(flowTemplateMap);

		List<String> xmlTemplateCodes = resultMap.get("xmlTemplateCodes");
		// 没有需要载入的模板信息
		if (xmlTemplateCodes != null && !xmlTemplateCodes.isEmpty()) {
			List<String> xmlBillTypes = resultMap.get("xmlBillTypes");
			// 删除需要重新刷新数据库的，如果xml模板配置的code和页面新增模板的code相同，xml模板信息会覆盖页面操作的模板信息
			templateDao.removeTemplates(xmlTemplateCodes);
			stateFlowDao.removeStateFlows(xmlTemplateCodes);

			// 与数据库数据比对
			// 查询所有模板信息
			List<String> templateCodes = templateDao.findAllTemplateCodes();
			List<String> billTypes = stateFlowDao.findAllBillType();

			templateCodes.addAll(xmlTemplateCodes);
			billTypes.addAll(xmlBillTypes);

			// 判断是否与数据库中templateCode重复
			if (!checkRepeat(templateCodes)) {
				ItamRestException.throwException(ItamRestException.TEMPLATE_CODE_REPEAT, null, null, null);
			}
			if (!checkRepeat(billTypes)) {
				ItamRestException.throwException(ItamRestException.BILLTYPE_REPEAT, null, null, null);
			}

			// 校验成功，将模板信息保存到数据库
			List<TemplateEntity> templateEntitys = new ArrayList<TemplateEntity>();
			List<FlowEntity> flowEntitys = new ArrayList<FlowEntity>();
			for (Map.Entry<String, FlowTemplate> entry : flowTemplateMap.entrySet()) {
				FlowTemplate flowTemplate = entry.getValue();
				if (flowTemplate.isReflush()) {
					String templateCode = flowTemplate.getTemplateCode();
					TemplateEntity templateEntity = new TemplateEntity();
					templateEntity.setTemplateCode(flowTemplate.getTemplateCode());
					templateEntity.setTemplateName(flowTemplate.getTemplateName());
					templateEntity.setTemplateDescription(flowTemplate.getTemplateDescription());
					templateEntity.setDefalutEvents(flowTemplate.getDefalutEvents());
					templateEntity.setDeviceType(flowTemplate.getDeviceType());
					templateEntitys.add(templateEntity);
					
					List<FlowEntity> flowList = flowTemplate.getFlowList();
					if (flowList != null && !flowList.isEmpty()) {
						Iterator<FlowEntity> iterator = flowList.iterator();
						while (iterator.hasNext()) {
							FlowEntity flowEntity = iterator.next();
							flowEntity.setTemplateCode(templateCode);
						}
					}
					
					flowEntitys.addAll(flowList);
				}
			}
			//保存模板信息
			templateDao.saveTemplates(templateEntitys);
			//保存状态机信息
			stateFlowDao.saveStateFlows(flowEntitys);
		}
	}

	@Override
	@Transactional
	public void saveTemplate(TemplateEntity templateEntity) {
		templateDao.saveTemplate(templateEntity);
	}

	@Override
	@Transactional
	public void updateTemplate(TemplateEntity templateEntity) {
		templateDao.updateTemplate(templateEntity);
	}

	@Override
	@Transactional
	public void removeTemplateByIds(List<Integer> ids) {
		templateDao.removeTemplateByIds(ids);
	}

	@Override
	@Transactional
	public void removeTemplateById(Integer id) {
		templateDao.removeTemplateById(id);
	}

	/**
	 * @Description: 校验模板正确正确性
	 * @author lu.z
	 * @date 2015年4月23日 下午2:18:35
	 * @param flowTemplateMap
	 * @return
	 * @throws
	 */
	private Map<String, List<String>> checkTemplate(Map<String, FlowTemplate> flowTemplateMap) {
		List<String> templateCodeList = new ArrayList<String>();
		List<String> billTypeList = new ArrayList<String>();
		Map<String, List<String>> map = null;
		for (Map.Entry<String, FlowTemplate> entry : flowTemplateMap.entrySet()) {
			FlowTemplate flowTemplate = entry.getValue();
			// 不需要重新载入的模板，不做校验
			if (flowTemplate.isReflush()) {
				String templateBeanId = entry.getKey();
				// 校验模板code不能为空
				if (flowTemplate.getTemplateCode() == null || "".equals(flowTemplate.getTemplateCode())) {
					String[] params = { templateBeanId };
					ItamRestException.throwException(ItamRestException.TEMPLATE_CODE_IS_NULL, null, params, null);
				}
				// 校验状态机不能为空
				List<FlowEntity> flowList = flowTemplate.getFlowList();
				if (flowList != null && !flowList.isEmpty()) {
					// 校验状态机
					Iterator<FlowEntity> iterator = flowList.iterator();
					while (iterator.hasNext()) {
						FlowEntity flowEntity = iterator.next();
						// 判断状态机工单类型是否配置
						if (flowEntity.getBillType() == null || "".equals(flowEntity.getBillType())) {
							String[] params = { templateBeanId };
							ItamRestException.throwException(ItamRestException.BILL_TYPE_IS_NULL, null, params, null);
						}
						// 判断状态机资源状态获取资产状态对应关系
						if (((flowEntity.getStartStatus() == null || "".equals(flowEntity.getEndStatus())) || (flowEntity
								.getEndStatus() == null || "".equals(flowEntity.getEndStatus())))
								&& ((flowEntity.getResStartStatus() == null || "".equals(flowEntity.getResStartStatus())) || (flowEntity
										.getResEndStatus() == null || "".equals(flowEntity.getResEndStatus())))) {
							String[] params = { templateBeanId, flowEntity.getBillType() };
							ItamRestException.throwException(ItamRestException.BILLTYPE_CONFIGURE_ERROR, null, params,
									null);
						}
						// 将工单类型加入到数组中，最后判断工单类型是否重复
						billTypeList.add(flowEntity.getBillType());
					}
				} else {
					String[] params = { templateBeanId };
					ItamRestException.throwException(ItamRestException.HAVE_NOT_BILL_TYPE, null, params, null);
				}
				// 将模板code放入list中，最后判断模板code是否重复
				templateCodeList.add(flowTemplate.getTemplateCode());
			}
		}
		if (!checkRepeat(templateCodeList)) {
			ItamRestException.throwException(ItamRestException.TEMPLATE_CODE_REPEAT, null, null, null);
		}
		if (!checkRepeat(billTypeList)) {
			ItamRestException.throwException(ItamRestException.BILLTYPE_REPEAT, null, null, null);
		}
		map = new HashMap<String, List<String>>();
		map.put("xmlTemplateCodes", templateCodeList);
		map.put("xmlBillTypes", billTypeList);
		return map;
	}

	/**
	 * @Description: 校验list中数据是否重复
	 * @author lu.z
	 * @date 2015年4月9日 下午3:12:54
	 * @param @param list
	 * @param @return
	 * @return boolean
	 * @throws
	 */
	private <T> boolean checkRepeat(List<T> list) {
		if (list != null && list.size() > 1) {
			for (int i = 0; i < list.size() - 1; i++) {
				T t = list.get(i);
				for (int j = i + 1; j < list.size(); j++) {
					T t1 = list.get(j);
					if (t instanceof String) {
						if (((String) t).equals((String) t1)) {
							return false;
						}
					}
				}
			}
		}
		return true;
	}
}

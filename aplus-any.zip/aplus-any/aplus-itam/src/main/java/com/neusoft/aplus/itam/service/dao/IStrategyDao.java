package com.neusoft.aplus.itam.service.dao;

import java.util.List;

import org.hibernate.criterion.Criterion;

import com.neusoft.aplus.itam.model.dbentity.table.StrategyEntify;
import com.neusoft.aplus.model.dbentity.Page;

/**
 * @ClassName: IStrategyDao 
 * @Description: 权限策略DAO
 * @author lu.z
 * @date 2015年5月21日 下午4:55:14
 */
public interface IStrategyDao {
	/**
	 * @Description: 新增数据权限策略
	 * @author lu.z
	 * @date 2015年5月21日 下午4:57:48 
	 * @param @param strategyEntify
	 * @return void
	 * @throws
	 */
	public void saveStrategy(StrategyEntify strategyEntify);
	/**
	 * @Description: 修改数据权限策略
	 * @author lu.z
	 * @date 2015年5月21日 下午4:58:21 
	 * @param @param strategyEntify
	 * @return void
	 * @throws
	 */
	public void updateStrategy(StrategyEntify strategyEntify);
	/**
	 * @Description: 删除数据权限策略
	 * @author lu.z
	 * @date 2015年5月21日 下午4:59:48 
	 * @param @param ids
	 * @return void
	 * @throws
	 */
	public void removeStrategys(List<String> ids);
	/**
	 * @Description: 查询策略信息
	 * @author lu.z
	 * @date 2015年5月21日 下午5:01:06 
	 * @param @param page
	 * @param @param pageCount
	 * @param @param criterions
	 * @param @return
	 * @return Page<StrategyEntify>
	 * @throws
	 */
	public Page<StrategyEntify> findStrategyByConditions(Integer page, Integer pageCount, List<Criterion> criterions);
	/**
	 * @Description: 根据id获取策略信息
	 * @author lu.z
	 * @date 2015年5月22日 下午5:31:18 
	 * @param @param uuid
	 * @param @return
	 * @return StrategyEntify
	 * @throws
	 */
	public StrategyEntify findStrategyById(String uuid);
	/**
	 * @Description: 根据模块ID
	 * @author lu.z
	 * @date 2015年5月26日 下午1:58:11 
	 * @param @param modelId
	 * @param @return
	 * @return StrategyEntify
	 * @throws
	 */
	public StrategyEntify findStrategyByModelId(String modelId);
}

package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.neusoft.aplus.model.usertype.StringJsonUserType;

/**
 * @ClassName: AplusPresetDevInfoEntity
 * @Description: TODO
 * @author zhangyun
 * @date 2015-4-9 下午4:16:43
 */
@TypeDefs({ @TypeDef(name = "StringJsonObject", typeClass = StringJsonUserType.class) })
@Entity
@Table(name = "aplus_preset_dev_info")
public class AplusPresetDevInfoEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String DEFAULT_VERSION = "v1.0";
	private String uuid;// uuid
	private String presetNo;// 预置信息号
	private String presetUuid;// 预置信息uuid
	private int number = 0;// 总数量
	private int arrivalNumber = 0;// 到货数量
	private String deviceVersion = DEFAULT_VERSION;// 版本号，一般在资源为软件的场景下涉及
	private String deviceType;// 资源类型
	private String attr;// 需要修改的属性，json格式存入数据库

	private String category;

	@Column(name = "category")
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Column(name = "preset_no")
	public String getPresetNo() {
		return presetNo;
	}

	public void setPresetNo(String presetNo) {
		this.presetNo = presetNo;
	}

	@Column(name = "preset_uuid")
	public String getPresetUuid() {
		return presetUuid;
	}

	public void setPresetUuid(String presetUuid) {
		this.presetUuid = presetUuid;
	}

	@Column(name = "number")
	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	@Column(name = "arrival_number")
	public int getArrivalNumber() {
		return arrivalNumber;
	}

	public void setArrivalNumber(int arrivalNumber) {
		this.arrivalNumber = arrivalNumber;
	}

	@Column(name = "device_version")
	public String getDeviceVersion() {
		return deviceVersion;
	}

	public void setDeviceVersion(String deviceVersion) {
		this.deviceVersion = deviceVersion;
	}

	@Column(name = "device_type")
	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	@Column(name = "attr")
	@Type(type = "StringJsonObject")
	public String getAttr() {
		return attr;
	}

	public void setAttr(String attr) {
		this.attr = attr;
	}

	@Id
	@GeneratedValue(generator = "paymentableGenerator")
	@GenericGenerator(name = "paymentableGenerator", strategy = "uuid")
	@Column(name = "uuid")
	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	@Override
	public String toString() {
		return "AplusBillDeviceEntity [uuid=" + uuid + ", presetNo=" + presetNo
				+ ", presetUuid=" + presetUuid + ", number=" + number
				+ ", arrivalNumber=" + arrivalNumber + ", device_version="
				+ deviceVersion + ", deviceType=" + deviceType + ", attr="
				+ attr + "]";
	}
}

package com.neusoft.aplus.itam.service.bo.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.neusoft.aplus.itam.constant.BillStatus;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillDeviceEntity;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillEntity;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;
import com.neusoft.aplus.itam.model.dbentity.table.FlowEntity;
import com.neusoft.aplus.itam.service.bo.IAplusBillDeviceService;
import com.neusoft.aplus.itam.service.bo.IAplusBillLockService;
import com.neusoft.aplus.itam.service.bo.IAplusPresetDevInfoService;
import com.neusoft.aplus.itam.service.bo.IStateFlowService;
import com.neusoft.aplus.itam.service.dao.IAplusBillDao;
import com.neusoft.aplus.itam.service.dao.IAplusBillDeviceDao;
import com.neusoft.aplus.model.dbentity.Page;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;
import com.neusoft.aplus.service.core.service.dao.AplusDeviceDao;

@Component
public class AplusBillDeviceServiceImpl implements IAplusBillDeviceService {
	@Autowired
	private IAplusBillDeviceDao aplusBillDeviceDao;
	@Autowired
	private AplusDeviceDao aplusDeviceDao;
	@Autowired
	private IAplusBillDao aplusBillDao;

	@Autowired
	private IAplusBillLockService aplusBillLokcService;
	@Autowired
	private IStateFlowService stateFlowService;
	@Autowired
	private IAplusPresetDevInfoService aplusPresetDevInfoService;

	@Transactional
	public void saveAplusBillDevice(List<String> Fqns, String bill_uuid,
			String bill_no) {
		List<AplusDeviceEntity> entity = aplusDeviceDao.findAplusDevices(Fqns);
		List<AplusBillDeviceEntity> billDeviceEntityList = new LinkedList<AplusBillDeviceEntity>();
		for (AplusDeviceEntity e : entity) {
			AplusBillDeviceEntity billDeviceEntity = new AplusBillDeviceEntity();
			billDeviceEntity.setBillNo(bill_no);
			billDeviceEntity.setBillUuid(bill_uuid);
			billDeviceEntity.setDevFqn(e.getFqn());
			billDeviceEntity.setDeviceType(e.getDeviceType());
			billDeviceEntity.setDeviceVersion(e.getDeviceVersion());
			billDeviceEntity.setAttr(e.getAttr());
			billDeviceEntity.setCategory(e.getCategory());
			billDeviceEntity.setAttrNew("{}");
			billDeviceEntityList.add(billDeviceEntity);
		}
		aplusBillDeviceDao.saveAplusBillDevice(billDeviceEntityList);
		aplusBillLokcService.saveOrUpdateAplusBillLock(Fqns, bill_uuid);
	}

	@Transactional
	public void deleteAplusBillDevice(String uuids, String billUuid) {
		AplusBillEntity billEntity = aplusBillDao.findBillByUuid(billUuid);
		FlowEntity flowEntity = stateFlowService
				.findStateFlowByBillType(billEntity.getBillType());
		String[] uuid = uuids.split(",");
		List<AplusBillDeviceEntity> billDeviceEntityList = new LinkedList<AplusBillDeviceEntity>();
		List<String> devFqns = new ArrayList<String>();
		for (int i = 0; i < uuid.length; i++) {
			AplusBillDeviceEntity billDeviceEntity = aplusBillDeviceDao
					.findAplusDeivceByUuid(uuid[i]);
			devFqns.add(billDeviceEntity.getDevFqn());
			billDeviceEntityList.add(billDeviceEntity);
			if (flowEntity.getDeviceSource().equals("T")) {
				// 如果是台账设备
			} else {
				// 如果是预置设备回退到货数量
				AplusPresetDevInfoEntity presetDevInfoEntity = aplusPresetDevInfoService
						.findAplusPresetDevInfoByUuid(billDeviceEntity
								.getPresetDevUuid());
				presetDevInfoEntity.setArrivalNumber(presetDevInfoEntity
						.getArrivalNumber() - 1);
				aplusPresetDevInfoService
						.backAplusPresrtDevInfoArrivalNumber(presetDevInfoEntity);
			}

		}
		aplusBillDeviceDao.deleteAplusBillDevice(billDeviceEntityList);
		aplusBillLokcService.deleteAplusBillLockBydevFqns(devFqns);

	}

	@Transactional
	public void batchUpdateAplusBillDevice(
			Map<String, Map<String, String>> map, String billUuid) {
		AplusBillEntity billEntity = new AplusBillEntity();
		billEntity = aplusBillDao.findBillByUuid(billUuid);
		String key = "";
		if (billEntity.getBillStatus().equals(BillStatus.SAVE.name())) {
			key = stateFlowService.findUpdateAttrsByCommitStatus(
					billEntity.getBillType(), BillStatus.SAVE.toString());
		} else {
			key = stateFlowService.findUpdateAttrsByCommitStatus(
					billEntity.getBillType(), BillStatus.APPROVED.toString());
		}
		String[] keys = key.split(",");
		List<AplusBillDeviceEntity> billDeviceEntityList = new LinkedList<AplusBillDeviceEntity>();
		Iterator<Map.Entry<String, Map<String, String>>> entries = map
				.entrySet().iterator();
		while (entries.hasNext()) {
			AplusBillDeviceEntity billDeviceEntity = new AplusBillDeviceEntity();
			Map.Entry<String, Map<String, String>> entry = entries.next();
			Map<String, String> valueMap = entry.getValue();// 前台传来修改属性的值集合
			billDeviceEntity = aplusBillDeviceDao.findAplusDeivceByUuid(entry
					.getKey());
			String attrNew = billDeviceEntity.getAttrNew();
			// 数据库中设备原属性
			@SuppressWarnings("unchecked")
			Map<String, String> attr_new = JSON.parseObject(attrNew, Map.class);
			for (int i = 0; i < keys.length; i++) {
				if (valueMap.containsKey(keys[i])) {
					attr_new.put(keys[i], valueMap.get(keys[i]));// 修改对应配置属性的值
				}
			}
			billDeviceEntity.setAttrNew(JSON.toJSONString(attr_new));
			billDeviceEntity.setUuid(entry.getKey());
			billDeviceEntityList.add(billDeviceEntity);
		}
		aplusBillDeviceDao.batchUpdateAplusBillDevice(billDeviceEntityList);
	}

	@Transactional
	public Page<AplusBillDeviceEntity> findAplusDeviceByBillUuid(Integer page,
			Integer pageCount, String billUuid) {
		List<Criterion> criterions = Lists.newArrayList();
		criterions.add(Restrictions.eq("billUuid", billUuid));
		return aplusBillDeviceDao.findAllAplusDevice(page, pageCount,
				criterions);
	}

	@Transactional
	public void lockBillDevice(String uuids) {
		String[] uuid = uuids.split(",");
		List<String> uuidList = new ArrayList<String>();
		for (int i = 0; i < uuid.length; i++) {
			uuidList.add(uuid[i]);
		}
		aplusBillDeviceDao.lockBillDevice(uuidList);

	}
}

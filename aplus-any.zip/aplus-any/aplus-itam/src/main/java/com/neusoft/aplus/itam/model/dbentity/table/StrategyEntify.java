package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @ClassName: StrategyEntify 
 * @Description: 数据权限策略实体类
 * @author lu.z
 * @date 2015年5月20日 下午4:52:53
 */
@Entity
@Table(name = "aplus_strategy")
public class StrategyEntify implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4017600279711691310L;
	/**
	 * 主键
	 */
	private String uuid;
	/**
	 * 策略名称
	 */
	private String name;
	/**
	 * 模块名称
	 */
	private String modelName;
	/**
	 * 模块ID
	 */
	private String modelId;
	/**
	 * 组织权限树
	 */
	private String orgsTree;
	/**
	 * 创建人
	 */
	private String createUser;
	/**
	 * 创建时间
	 */
	private Date createTime;
	/**
	 * 修改人
	 */
	private String updateUser;
	/**
	 * 修改时间
	 */
	private Date updateTime;
	
	@Id
	@Column(name = "uuid")
	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	@Column(name = "name")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Column(name = "model_name")
	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	
	@Column(name = "model_id")
	public String getModelId() {
		return modelId;
	}

	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	
	@Column(name = "create_user")
	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	
	@Column(name = "create_time")
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
	@Column(name = "update_user")
	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	
	@Column(name = "update_time")
	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
	@Column(name = "orgs_tree")
	public String getOrgsTree() {
		return orgsTree;
	}

	public void setOrgsTree(String orgsTree) {
		this.orgsTree = orgsTree;
	}

	@Override
	public String toString() {
		return "{uuid = "+uuid+", name = "+name+", modelName = "+modelName+", modelId = "+modelId+", "+
				"createUser = "+createUser+", createTime = "+createTime+", updateUser = "+updateUser+", "+
				"updateTime = "+updateTime+", orgsTree = "+orgsTree+"}";
	}
}

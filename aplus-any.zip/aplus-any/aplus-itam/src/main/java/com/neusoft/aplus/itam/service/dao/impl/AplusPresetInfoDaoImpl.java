package com.neusoft.aplus.itam.service.dao.impl;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Component;

import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetInfoEntity;
import com.neusoft.aplus.itam.service.dao.IAplusPresetInfoDao;
import com.neusoft.aplus.model.dbentity.Page;

@Component
public class AplusPresetInfoDaoImpl extends
		AbstractHibernateDao<AplusPresetInfoEntity> implements
		IAplusPresetInfoDao {
	@Override
	public String saveAplusPresrtInfo(AplusPresetInfoEntity entity) {
		return (String)save(entity);
	}

	@Override
	public void updateAplusPresrtInfo(AplusPresetInfoEntity entity) {
		update(entity);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AplusPresetInfoEntity> findAplusPresetInfoByMap(
			Map<String, String> querymap) {
		Iterator<?> it = querymap.entrySet().iterator();
		Criteria criteria = createCriteria();
		while (it.hasNext()) {
			@SuppressWarnings("rawtypes")
			Map.Entry entry = (Map.Entry) it.next();
			String key = entry.getKey().toString();
			String value = entry.getValue().toString();
			criteria.add(Restrictions.eq(key, value));
		}
		return criteria.list();
	}

	@Override
	public List<AplusPresetInfoEntity> findAplusPresetInfoByPresetNoAndUuid(
			String presetNo, String uuid) {
		String hql = "from AplusPresetInfoEntity where presetNo = ? and uuid !=?  ";
		return find(hql, presetNo, uuid);
	}

	@Override
	public void deleteAplusPresrtInfo(AplusPresetInfoEntity entity) {
		remove(entity);
	}

	@Override
	public AplusPresetInfoEntity findAplusPresetInfoByUuid(String uuid) {
		return get(uuid);
	}

	@Override
	public Page<AplusPresetInfoEntity> findaplusPresetInfo(Integer page,
			Integer pageCount, List<Criterion> criterions) {
		return getPagedResult(page, pageCount, criterions);
	}

}

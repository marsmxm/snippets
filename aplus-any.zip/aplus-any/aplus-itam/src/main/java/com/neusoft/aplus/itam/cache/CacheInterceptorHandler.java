package com.neusoft.aplus.itam.cache;

import java.lang.reflect.Method;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import com.neusoft.aplus.common.cache.api.CacheService;
import com.neusoft.aplus.itam.common.UseCache;


/**
 * @ClassName: CacheInterceptorHandler
 * @Description: 配置查询标签UseCache的方法将会被拦截
 * @author lu.z
 * @date 2015年4月15日 上午9:28:50
 */
public class CacheInterceptorHandler {
	Logger logger = LoggerFactory.getLogger(CacheInterceptorHandler.class);
	/**
	 * 默认缓存名称
	 */
	private static final String DEFAULT_CACHE_NAME = "myCache";
	@Autowired
	private CacheService cacheService;

	public void doBefore() {
		// TODO:
	}

	public void doAfterReturning() {
		// TODO:
	}

	public void doAfter() {
		// TODO:
	}

	public void doAfterThrowing(JoinPoint joinPoint, Exception ex) {
		logger.error("CacheInterceptorHandler拦截方法:{},捕获到异常e:{}", joinPoint, ex.getMessage());
	}

	public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable {
		Object result = null;
		try{
			Class<?> cls = joinPoint.getTarget().getClass();
			// 获取class中的所有方法
			Method[] methods = cls.getMethods();
			for (Method method : methods) {
				if (method.getName().equals(joinPoint.getSignature().getName())) {
					UseCache useCache = method.getAnnotation(UseCache.class);
					// 使用缓存
					if (useCache != null && useCache.value()) {
						// 读取缓存，如果换成存在，返回缓存对象
						String cacheKey = useCache.cacheKey();
						//判断方法是否含有参数，如果有参数，将参数值追加到key后面
						Object args[] = joinPoint.getArgs();
						if(args != null && args.length > 0){
							for(Object arg : args){
								cacheKey += "." + arg;
							}
						}
						if (cacheService.isInCache(DEFAULT_CACHE_NAME, cacheKey)) {
							result = cacheService.get(DEFAULT_CACHE_NAME, cacheKey);
						} else {
							result = joinPoint.proceed();
							// 将返回值存到cache中
							cacheService.put(DEFAULT_CACHE_NAME, cacheKey, result);
						}
					} else {
						result = joinPoint.proceed();
					}
				}
			}
		} catch(Exception e){
			result = joinPoint.proceed();
		}
		return result;
	}
}

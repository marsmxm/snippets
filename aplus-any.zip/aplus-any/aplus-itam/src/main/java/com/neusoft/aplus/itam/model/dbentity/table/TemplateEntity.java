package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @ClassName: TemplateEntity
 * @Description: 模板实体类(aplus_template)
 * @author lu.z
 * @date 2015年4月9日 上午10:13:19
 */
@Entity
@Table(name = "aplus_template")
public class TemplateEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1239468771535945271L;

	/**
	 * 主键
	 */
	private Integer id;
	/**
	 * 模板CODE
	 */
	private String templateCode;
	/**
	 * 模板名称
	 */
	private String templateName;
	/**
	 * 模板描述
	 */
	private String templateDescription;
	/**
	 * 模板默认执行事件
	 */
	private String defalutEvents;
	/**
	 * 设备类型 software-软件；hardware-硬件
	 */
	private String deviceType;

	@Id
	@GeneratedValue
	@Column(name = "id")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "template_code")
	public String getTemplateCode() {
		return templateCode;
	}

	public void setTemplateCode(String templateCode) {
		this.templateCode = templateCode;
	}

	@Column(name = "template_name")
	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	@Column(name = "template_description")
	public String getTemplateDescription() {
		return templateDescription;
	}

	public void setTemplateDescription(String templateDescription) {
		this.templateDescription = templateDescription;
	}

	@Column(name = "defalut_events")
	public String getDefalutEvents() {
		return defalutEvents;
	}

	public void setDefalutEvents(String defalutEvents) {
		this.defalutEvents = defalutEvents;
	}
	
	@Column(name = "device_type")
	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	@Override
	public String toString() {
		return "TemplateEntity [id=" + id + ", templateCode=" + templateCode + ", templateName=" + templateName
				+ ", templateDescription=" + templateDescription + ", defalut_events=" + defalutEvents + "]";
	}
}

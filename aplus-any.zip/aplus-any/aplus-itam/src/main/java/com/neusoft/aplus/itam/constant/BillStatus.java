package com.neusoft.aplus.itam.constant;

/**
 * @ClassName: BillStatus 
 * @Description: 工单类型常量枚举。取消、保存、审批中、审批通过、关闭
 * @author wangcd
 * @date 2015年4月15日 上午9:04:47
 */
public enum BillStatus {
	CANCEL,SAVE,APPROVING,APPROVED,CLOSED
}

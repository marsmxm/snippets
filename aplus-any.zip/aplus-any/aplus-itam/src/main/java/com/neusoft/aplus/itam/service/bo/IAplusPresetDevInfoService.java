package com.neusoft.aplus.itam.service.bo;

import java.util.List;
import java.util.Map;

import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetInfoEntity;
import com.neusoft.aplus.model.dbentity.Page;

public interface IAplusPresetDevInfoService {
	/**
	 * @Description: 保存预置设备信息
	 * @author zhangyun
	 * @date 2015-4-16 上午9:19:32
	 * @param @param map
	 * @return void
	 * @throws
	 */
	public String saveAplusPresrtDevInfo(AplusPresetDevInfoEntity presetDevInfoEntity);

	/**
	 * @Description: 修改预置信息
	 * @author zhangyun
	 * @date 2015-4-16 上午10:54:38
	 * @param @param map
	 * @return void
	 * @throws
	 */
	public void updateAplusPresrtDevInfo(AplusPresetDevInfoEntity entity);

	/**
	 * @Description: 刪除预置设备信息
	 * @author zhangyun
	 * @date 2015-4-16 上午10:54:38
	 * @param @param map
	 * @return void
	 * @throws
	 */
	public void deleteAplusPresrtDevInfo(String uuid);

	/**
	 * @Description: 根据预置类型查询预置信息
	 * @author zhangyun
	 * @date 2015-4-16 上午11:28:58
	 * @param @param presetType
	 * @param @return
	 * @return List<AplusPresetInfoEntity>
	 * @throws
	 */
	public List<AplusPresetInfoEntity> findaplusPresetInfoByPresetType(
			String presetType);

	/**
	 * @Description: 根据UUid查询预置信息
	 * @author zhangyun
	 * @date 2015-4-16 上午11:28:58
	 * @param @param Uuid
	 * @param @return
	 * @return List<AplusPresetInfoEntity>
	 * @throws
	 */
	public AplusPresetDevInfoEntity findAplusPresetDevInfoByUuid(String Uuid);

	/**
	 * @Description: 修改到货数量
	 * @author zhangyun
	 * @date 2015-4-20 下午5:31:47
	 * @param @param map
	 * @return void
	 * @throws
	 */
	public void updateAplusPresrtDevInfoArrivalNumber(Map<String, Object> map);

	/**
	 * @Description: 回退到货数量
	 * @author zhangyun
	 * @date 2015-4-21 下午2:12:50
	 * @param @param entity
	 * @return void
	 * @throws
	 */
	public void backAplusPresrtDevInfoArrivalNumber(
			AplusPresetDevInfoEntity entity);

	/**
	 * @Description: 分页查询预置设备
	 * @author zhangyun
	 * @date 2015-4-24 上午10:12:56 
	 * @param @param page
	 * @param @param pageCount
	 * @param @param presetUuid 预置UUID
	 * @param @return
	 * @return Page<AplusPresetDevInfoEntity>
	 * @throws
	 */
	public Page<AplusPresetDevInfoEntity> findAplusPresetDevInfo(Integer page,
			Integer pageCount, String presetUuid);
}
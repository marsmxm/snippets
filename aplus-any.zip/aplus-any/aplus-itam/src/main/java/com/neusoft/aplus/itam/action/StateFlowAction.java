package com.neusoft.aplus.itam.action;

import java.util.Map;
import org.restlet.representation.Representation;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.exception.ItamRestException;
import com.neusoft.aplus.itam.service.bo.IStateFlowService;

/**
 * @ClassName: StateFlowAction
 * @Description: 状态机action
 * @author lu.z
 * @date 2015年4月30日 下午2:05:57
 */
public class StateFlowAction extends BaseAction {

	private IStateFlowService stateFlowService;
	private Map<String, String> paramsMap;

	@Override
	public void doInit() {
		stateFlowService = ApplicationContextFactory.getBean(IStateFlowService.class);
		paramsMap = getRequestParameters();
	}

	@Override
	public void acceptRepresentation(Representation entity) {

	}

	@Override
	public Representation represent() {
		Map<String, Object> resultMap = null;
		try{
			resultMap = stateFlowService.findStateFlowsByConditions(paramsMap);
		} catch(Exception e){
			ItamRestException.throwException(ItamRestException.QUERY_ERROR, e, null, null);
		}
		return createObjectRepresentation(resultMap);
	}

	@Override
	public void removeRepresentations() {

	}

	@Override
	public void storeRepresentation(Representation entity) {

	}
}

package com.neusoft.aplus.itam.action;

import java.util.List;

import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.model.bizentity.BillDev4PresetParam;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;
import com.neusoft.aplus.itam.service.bo.IAplusBillDeviceFromPresetService;

/**
 * @author zhangyun
 * @date 2015-4-22 下午2:05:04
 */
public class AplusBillDeviceFromPresetAction extends BaseAction {
	private IAplusBillDeviceFromPresetService aplusBillDeviceFromPresetService;
	@Override
	public void doInit() {
		aplusBillDeviceFromPresetService = ApplicationContextFactory
				.getBean(IAplusBillDeviceFromPresetService.class);
	}

	@Override
	public void acceptRepresentation(Representation entity) {
		try {
			BillDev4PresetParam param = getObjectFromRepresentation(entity,BillDev4PresetParam.class);
			String billUuid = param.getBillUuid();
			String billNo = param.getBillNo();
			List<AplusPresetDevInfoEntity> list = param.getPresetDevList();
			aplusBillDeviceFromPresetService.saveAplusBillDeviceByPreset(billUuid,billNo,list);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public Representation represent() {
		return null;
	}

	@Override
	public void removeRepresentations() {
		
	}

	@Override
	public void storeRepresentation(Representation entity) {
		
	}
}

package com.neusoft.aplus.itam.event;

import com.neusoft.aplus.common.event.Event;

/**
 * @ClassName: ItamEvent 
 * @Description: itam工程evet基类
 * @author lu.z
 * @date 2015年4月16日 上午10:11:32
 */
public abstract class ItamEvent implements Event{
	//事件名称
	protected String eventName;

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
}

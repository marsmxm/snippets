package com.neusoft.aplus.itam.service.dao;

import java.util.List;

import org.hibernate.criterion.Criterion;

import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;
import com.neusoft.aplus.model.dbentity.Page;

public interface IAplusPresetDevInfoDao {
	/**
	 * @Description: 保存设备预置信息
	 * @author zhangyun
	 * @date 2015-4-16 上午9:27:08
	 * @param @param entity
	 * @return void
	 * @throws
	 */
	public String saveAplusPresrtDevInfo(AplusPresetDevInfoEntity entity);

	/**
	 * @Description: 修改预置信息
	 * @author zhangyun
	 * @date 2015-4-16 上午9:27:08
	 * @param @param entity
	 * @return void
	 * @throws
	 */
	public void updateAplusPresrtDevInfo(AplusPresetDevInfoEntity entity);

	/**
	 * @Description: 根据预置UUID 查询预置设备的到货数量
	 * @author zhangyun
	 * @date 2015-4-16 下午4:20:49
	 * @param @param presetUuid
	 * @param @return
	 * @return List<AplusPresetDevInfoEntity>
	 * @throws
	 */
	public List<AplusPresetDevInfoEntity> findAplusPresetInfoByPresetUuid(
			String presetUuid);

	/**
	 * @Description: 删除设备预置
	 * @author zhangyun
	 * @date 2015-4-16 下午5:00:49
	 * @param @param entity
	 * @return void
	 * @throws
	 */
	public void deleteAplusPresrtInfo(AplusPresetDevInfoEntity entity);

	/**
	 * @Description: 根据UUID 查询设备预置信息
	 * @author zhangyun
	 * @date 2015-4-16 下午5:03:18
	 * @param @param uuid
	 * @param @return
	 * @return AplusPresetDevInfoEntity
	 * @throws
	 */
	public AplusPresetDevInfoEntity findAplusPresetDevInfoByUuid(String uuid);
	/**
	 * @Description: 查询预置设备
	 * @author zhangyun
	 * @date 2015-4-23 下午4:14:34 
	 * @param @param page
	 * @param @param pageCount
	 * @param @param criterions
	 * @param @return
	 * @return Page<AplusPresetDevInfoEntity>
	 * @throws
	 */
	public Page<AplusPresetDevInfoEntity> findAplusPresetDevInfo(Integer page,
			Integer pageCount, List<Criterion> criterions);

}

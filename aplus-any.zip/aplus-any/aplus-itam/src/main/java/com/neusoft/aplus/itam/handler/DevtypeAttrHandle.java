package com.neusoft.aplus.itam.handler;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.model.dbentity.table.DevtypeAttrXMLEntity;
import com.neusoft.aplus.itam.service.bo.IAplusDevtypeService;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceAttrEntity;
import com.neusoft.aplus.service.core.service.bo.AplusDeviceAttrBo;



/**
 * @ClassName: DevtypeAttrHandle 
 * @Description: 加载属性的Handle
 * @author jin.ysh
 * @date 2015-4-20 下午3:32:07
 */
public class DevtypeAttrHandle {
	private static Logger log = Logger.getLogger(DevtypeAttrHandle.class);
	@Autowired
    private IAplusDevtypeService aplusDevtypeBo;
	@Autowired
	private AplusDeviceAttrBo aplusDeviceAttrBo;
	/**
	 * @Description: TODO
	 * @author jin.ysh
	 * @date 2015-4-20 下午3:31:50 
	 * @param 
	 * @return void
	 * @throws
	 */
	@SuppressWarnings("unused")
	private void initDevtype() {
		log.info("load devtype.xml start");
		//加载设备类型属性
		loadDevtypeAttr();
		//加载型号属性
		loadModelAttr();
		log.info("load devtype.xml end");
	}
	
	
	public void loadDevtypeAttr()
	{
		Map<String, DevtypeAttrXMLEntity>  devtypeAttrMap = ApplicationContextFactory.getBeansOfType(DevtypeAttrXMLEntity.class, false, false);
		if(devtypeAttrMap != null && devtypeAttrMap.size() > 0)
		{
				for (Map.Entry<String, DevtypeAttrXMLEntity> entry : devtypeAttrMap.entrySet())
				{
					DevtypeAttrXMLEntity devtypeAttrEntity = entry.getValue();
					try{
						if (devtypeAttrEntity != null) {
							//更新设备类型的属性
							int count = aplusDevtypeBo.updateDevtypeAttr(devtypeAttrEntity.getDevtypeId(), devtypeAttrEntity.getAttr());
							if(count==0)
							{
								log.info("load devtype error: "+devtypeAttrEntity.getDevtypeId()+"数据库中不存在");
							}else
							{
								log.info("load devtype success: "+devtypeAttrEntity.getDevtypeId());
							}
						}
					}catch(Exception e)
					{
						log.info("load  devtype error: "+devtypeAttrEntity.getDevtypeId()+" "+e.toString());
						e.printStackTrace();
					}
				}
		}
	}
	
	
	public void loadModelAttr()
	{
		Map<String, AplusDeviceAttrEntity>  modelAttrMap = ApplicationContextFactory.getBeansOfType(AplusDeviceAttrEntity.class, false, false);
			if(modelAttrMap != null && modelAttrMap.size() > 0)
			{
				for (Map.Entry<String, AplusDeviceAttrEntity> entry : modelAttrMap.entrySet())
				{
					AplusDeviceAttrEntity modelAttrEntity = entry.getValue();
					try{
						if (modelAttrEntity != null) {
							//更新型号属性
							int count = aplusDeviceAttrBo.updateDeviceAttr(modelAttrEntity.getDeviceType(), modelAttrEntity.getAttr());
							if(count==0)
							{
								log.info("load modelAttr error: "+modelAttrEntity.getDeviceType()+"数据库中不存在");
							}else
							{
								log.info("load modelAttr success: "+modelAttrEntity.getDeviceType());
							}
						}
					}catch(Exception e)
					{
						log.info("load  modelAttr error: "+modelAttrEntity.getDeviceType()+" "+e.toString());
						e.printStackTrace();
					}
				}
			}
	}
}

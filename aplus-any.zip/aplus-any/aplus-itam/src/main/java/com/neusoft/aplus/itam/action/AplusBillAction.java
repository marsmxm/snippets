package com.neusoft.aplus.itam.action;

import java.util.Map;

import org.restlet.representation.Representation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.constant.BillStatus;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillEntity;
import com.neusoft.aplus.itam.service.bo.IAplusBillService;
import com.neusoft.aplus.model.dbentity.Page;

/**
 * @ClassName: AplusBillAction
 * @Description: 工单Action
 * @author zhangyun
 * @date 2015-4-22 上午10:46:46
 */
public class AplusBillAction extends BaseAction {

	private IAplusBillService aplusBillService;
	private static Logger log = LoggerFactory.getLogger(AplusBillAction.class);
	private Map<String, String> paramsMap;

	@Override
	public void doInit() {
		aplusBillService = ApplicationContextFactory
				.getBean(IAplusBillService.class);
		paramsMap = getRequestParameters();
	}

	@Override
	public void acceptRepresentation(Representation entity) {
		try {
			AplusBillEntity billEntity = getObjectFromRepresentation(entity,
					AplusBillEntity.class);
			String uuid = aplusBillService.saveAplusBill(
					billEntity.getBillType(), billEntity.getBillAppUser());

			sendJsonResponse("{'uuid' : " + uuid + "}");
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	@Override
	public Representation represent() {
		Page<AplusBillEntity> aplusBillEntityPage = null;
		AplusBillEntity aplusBillEntity = null;
		String method = (String) paramsMap.get("method");
		if (method != null && !"".equals(method)) {
			if ("findBillByBillType".equals(method)) {
				String pageStr = (String) paramsMap.get("page");
				String pageCountStr = (String) paramsMap.get("pageCount");
				// 如果传过来为null或者""，默认为第一页
				Integer page = (pageStr == null || "".equals(pageStr)) ? 1
						: Integer.parseInt(pageStr);
				// 如果传过来为null或者""，默认为每页10条数据
				Integer pageCount = (pageCountStr == null || ""
						.equals(pageCountStr)) ? 10 : Integer
						.parseInt(pageCountStr);
				String billType = (String) paramsMap.get("billType");
				aplusBillEntityPage = aplusBillService.findBillByBillType(page,
						pageCount, billType);
				if (aplusBillEntityPage != null) {
					return createObjectRepresentation(aplusBillEntityPage);
				}
			} else {
				String uuid = (String) paramsMap.get("uuid");

				aplusBillEntity = aplusBillService.findBillByUuid(uuid);
				if (aplusBillEntity != null) {
					return createObjectRepresentation(aplusBillEntity);
				}
			}
		}
		return null;
	}

	@Override
	public void removeRepresentations() {
		try {
			String uuid = (String) paramsMap.get("uuid");
			aplusBillService.deleteAplusBill(uuid);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}
		sendSuccess();
	}

	@Override
	public void storeRepresentation(Representation entity) {

		try {
			AplusBillEntity billEntity = getObjectFromRepresentation(entity,
					AplusBillEntity.class);
			String uuid = billEntity.getUuid();
			String billStatus = billEntity.getBillStatus();
			if (billStatus.equals(BillStatus.SAVE.name())) {
				aplusBillService.commitAplusBill(uuid);
			} else {
				aplusBillService.finishAplusBill(uuid);
			}

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		sendSuccess();

	}

}

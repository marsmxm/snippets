package com.neusoft.aplus.itam.model.bizentity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.neusoft.aplus.itam.model.dbentity.table.FlowEntity;

/**
 * @ClassName: FlowTemplate
 * @Description: 模板实体类
 * @author lu.z
 * @date 2015年4月9日 上午10:30:01
 */
public class FlowTemplate implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1206785371032042473L;
	/**
	 * 模板CODE
	 */
	private String templateCode;
	/**
	 * 模板名称
	 */
	private String templateName;
	/**
	 * 设备类型 software-软件；hardware-硬件
	 */
	private String deviceType;
	/**
	 * 是否重新载入数据库
	 */
	private boolean reflush;
	/**
	 * 默认事件
	 */
	private String defalutEvents;
	/**
	 * 模板描述，预留字段
	 */
	private String templateDescription;
	/**
	 * 状态机集合（list配置简单，不易出错）
	 */
	private List<FlowEntity> flowList;
	/**
	 * 状态机Map（将状态机list转换成Map，方便从缓存中获取FlowEntity对象）
	 */
	private Map<String, FlowEntity> flowMap;

	public String getTemplateCode() {
		return templateCode;
	}

	public void setTemplateCode(String templateCode) {
		this.templateCode = templateCode;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public boolean isReflush() {
		return reflush;
	}

	public void setReflush(boolean reflush) {
		this.reflush = reflush;
	}

	public List<FlowEntity> getFlowList() {
		return flowList;
	}

	public void setFlowList(List<FlowEntity> flowList) {
		this.flowList = flowList;
	}

	public String getDefalutEvents() {
		return defalutEvents;
	}

	public void setDefalutEvents(String defalutEvents) {
		this.defalutEvents = defalutEvents;
	}

	public String getTemplateDescription() {
		return templateDescription;
	}

	public void setTemplateDescription(String templateDescription) {
		this.templateDescription = templateDescription;
	}

	public Map<String, FlowEntity> getFlowMap() {
		return flowMap;
	}

	public void setFlowMap(Map<String, FlowEntity> flowMap) {
		this.flowMap = flowMap;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
}

package com.neusoft.aplus.itam.service.bo.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetInfoEntity;
import com.neusoft.aplus.itam.service.bo.IAplusPresetDevInfoService;
import com.neusoft.aplus.itam.service.dao.IAplusPresetDevInfoDao;
import com.neusoft.aplus.itam.service.dao.IAplusPresetInfoDao;
import com.neusoft.aplus.model.dbentity.Page;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceAttrEntity;
import com.neusoft.aplus.service.core.service.dao.AplusDeviceAttrDao;

@Component
public class AplusPresetDevInfoServiceImpl implements
		IAplusPresetDevInfoService {
	@Autowired
	private IAplusPresetDevInfoDao aplusPresetDevInfoDao;
	@Autowired
	private IAplusPresetInfoDao aplusPresetInfoDao;

	@Autowired
	private AplusDeviceAttrDao aplusDeviceAttrDao;

	@Transactional
	@Override
	public String saveAplusPresrtDevInfo(AplusPresetDevInfoEntity entity) {
		Map<String, String> querymap = new HashMap<String, String>();
		querymap.put("presetNo", entity.getPresetNo());
		List<AplusPresetInfoEntity> list = aplusPresetInfoDao
				.findAplusPresetInfoByMap(querymap);
		for (AplusPresetInfoEntity e : list) {
			entity.setPresetUuid(e.getUuid());
		}
		List<AplusDeviceAttrEntity> deviceAttrEntityList = aplusDeviceAttrDao
				.findAplusDeviceAttrBy(entity.getDeviceType(),
						entity.getDeviceVersion(), entity.getCategory());
		for (AplusDeviceAttrEntity d : deviceAttrEntityList) {
			entity.setAttr(d.getAttr());
		}
		return aplusPresetDevInfoDao.saveAplusPresrtDevInfo(entity);
	}

	@Transactional
	@Override
	public void updateAplusPresrtDevInfo(AplusPresetDevInfoEntity entity) {
		AplusPresetDevInfoEntity entity1 = new AplusPresetDevInfoEntity();
		entity1 = aplusPresetDevInfoDao.findAplusPresetDevInfoByUuid(entity
				.getUuid());
		if (entity.getNumber() < entity1.getArrivalNumber()) {
			// 总数量不能小于到货数量
		} else {
			entity1.setNumber(entity.getNumber());
			entity1.setDeviceType(entity.getDeviceType());
			entity1.setDeviceVersion(entity.getDeviceVersion());
			entity1.setCategory(entity.getCategory());
			List<AplusDeviceAttrEntity> deviceAttrEntityList = aplusDeviceAttrDao
					.findAplusDeviceAttrBy(entity.getDeviceType(),
							entity.getDeviceVersion(), entity.getCategory());
			for (AplusDeviceAttrEntity d : deviceAttrEntityList) {
				entity1.setAttr(d.getAttr());
			}
			aplusPresetDevInfoDao.updateAplusPresrtDevInfo(entity1);
		}
	}

	@Transactional
	@Override
	public void deleteAplusPresrtDevInfo(String uuid) {
		AplusPresetDevInfoEntity entity = aplusPresetDevInfoDao
				.findAplusPresetDevInfoByUuid(uuid);
		if (entity.getArrivalNumber() == 0) {
			aplusPresetDevInfoDao.deleteAplusPresrtInfo(entity);
		} else {

		}

	}

	@Transactional
	@Override
	public List<AplusPresetInfoEntity> findaplusPresetInfoByPresetType(
			String presetType) {
		Map<String, String> querymap = new HashMap<String, String>();
		querymap.put("presetType", presetType);
		return aplusPresetInfoDao.findAplusPresetInfoByMap(querymap);
	}

	@Transactional
	@Override
	public AplusPresetDevInfoEntity findAplusPresetDevInfoByUuid(String Uuid) {
		return aplusPresetDevInfoDao.findAplusPresetDevInfoByUuid(Uuid);
	}

	@Transactional
	@Override
	public void updateAplusPresrtDevInfoArrivalNumber(Map<String, Object> map) {
		AplusPresetDevInfoEntity entity = new AplusPresetDevInfoEntity();
		entity = aplusPresetDevInfoDao.findAplusPresetDevInfoByUuid(map.get(
				"uuid").toString());
		if (Integer.parseInt(map.get("arrivalNumber").toString())
				+ entity.getArrivalNumber() > entity.getNumber()) {
			// 总数量不能小于到货数量
		} else {
			entity.setArrivalNumber(Integer.parseInt(map.get("arrivalNumber")
					.toString()) + entity.getArrivalNumber());
			aplusPresetDevInfoDao.updateAplusPresrtDevInfo(entity);
		}

	}

	@Transactional
	@Override
	public void backAplusPresrtDevInfoArrivalNumber(
			AplusPresetDevInfoEntity entity) {
		aplusPresetDevInfoDao.updateAplusPresrtDevInfo(entity);
	}

	@Transactional
	@Override
	public Page<AplusPresetDevInfoEntity> findAplusPresetDevInfo(Integer page,
			Integer pageCount, String presetUuid) {

		List<Criterion> criterions = Lists.newArrayList();

		criterions.add(Restrictions.eq("presetUuid", presetUuid));

		return aplusPresetDevInfoDao.findAplusPresetDevInfo(page, pageCount,
				criterions);

	}

}

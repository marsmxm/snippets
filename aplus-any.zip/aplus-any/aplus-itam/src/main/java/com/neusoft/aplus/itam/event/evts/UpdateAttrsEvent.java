package com.neusoft.aplus.itam.event.evts;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import com.neusoft.aplus.common.event.EventChain;
import com.neusoft.aplus.common.event.Input;
import com.neusoft.aplus.common.event.Output;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.itam.event.ItamEvent;
import com.neusoft.aplus.itam.event.params.StateFlowOutput;
import com.neusoft.aplus.itam.exception.ItamRestException;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillDeviceEntity;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;
import com.neusoft.aplus.service.core.service.dao.AplusDeviceDao;

/**
 * @ClassName: UpdateAttrsEvent
 * @Description: 更新台账表属性事件
 * @author lu.z
 * @date 2015年4月9日 上午10:45:58
 */
public class UpdateAttrsEvent extends ItamEvent {
	private static Logger log = Logger.getLogger(UpdateAttrsEvent.class);
	private AplusDeviceDao aplusDeviceDao;

	@Override
	public <T> void fireEvent(Input input, Output output, EventChain<T> chain) {
		log.info("开始调用更新台账事件");
		// 初始化DAO
		aplusDeviceDao = ApplicationContextFactory.getBean(AplusDeviceDao.class);

		StateFlowOutput stateFlowOutput = (StateFlowOutput) output;

		List<AplusBillDeviceEntity> aplusBillDeviceEntitysOut = stateFlowOutput.getAplusBillDeviceEntitys();

		List<AplusDeviceEntity> aplusDeviceEntitys = null;
		if (aplusBillDeviceEntitysOut != null && !aplusBillDeviceEntitysOut.isEmpty()) {
			aplusDeviceEntitys = new ArrayList<AplusDeviceEntity>();
			Iterator<AplusBillDeviceEntity> iterator = aplusBillDeviceEntitysOut.iterator();
			while (iterator.hasNext()) {
				AplusBillDeviceEntity aplusBillDeviceEntity = iterator.next();
				String attr = null;
				try {
					attr = comparison(aplusBillDeviceEntity.getAttr(), aplusBillDeviceEntity.getAttrNew());
					String devFqn = aplusBillDeviceEntity.getDevFqn();

					AplusDeviceEntity aplusDeviceEntity = aplusDeviceDao.findAplusDevice(devFqn);
					// 台账对象设置更改之后的属性
					aplusDeviceEntity.setAttr(attr);
					aplusDeviceEntitys.add(aplusDeviceEntity);
				} catch (Exception e) {
					// 抛出类转换异常
					ItamRestException.throwException(ItamRestException.UPDATE_ATTRIBUTES_TRANSITION_ERROR, e, null,
							null);
				}
			}
		}

		// 更新台账表
		if (aplusDeviceEntitys != null && !aplusDeviceEntitys.isEmpty()) {
			aplusDeviceDao.saveOrUpdateAplusDevices(aplusDeviceEntitys);
		}
	}

	/**
	 * @Description: 将source中含有target中的信息更新
	 * @author lu.z
	 * @date 2015年4月17日 下午3:16:40
	 * @param @param source
	 * @param @param target
	 * @param @return
	 * @param @throws Exception
	 * @return String
	 * @throws
	 */
	@SuppressWarnings("unchecked")
	private String comparison(String source, String target) throws Exception {
		JSONObject sourceJSONObject = new JSONObject(source);
		JSONObject targetJSONObject = new JSONObject(target);
		if (sourceJSONObject != null && targetJSONObject != null) {
			Iterator<String> iterator = sourceJSONObject.keys();
			while (iterator.hasNext()) {
				String key = iterator.next();
				if (targetJSONObject.has(key)) {
					sourceJSONObject.put(key, targetJSONObject.get(key));
				}
			}
		}
		return sourceJSONObject.toString();
	}
}

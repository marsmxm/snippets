package com.neusoft.aplus.itam.model.dbentity.table;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @ClassName: AplusPositionDefineEntity 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-14 下午2:49:33
 */
@Entity
@Table(name = "aplus_positon_define")
public class AplusPositionDefineEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	//位置ID
	private String positionId;
	//位置名称
	private String positionName; 
	//位置级别
	private int positionLevel;  
	//树形结构中的父节点
	private String parentPositionId;   
	//位置显示名
	private String positionShowName; 
	//树形结构中的路径
	private String positionPath;
	@Id
	@Column(name = "position_id")
	@GenericGenerator(name = "idGenerator", strategy = "assigned")
	@GeneratedValue(generator = "idGenerator")
	public String getPositionId() {
		return positionId;
	}
	public void setPositionId(String positionId) {
		this.positionId = positionId;
	}
	
	@Column(name = "position_name")
	public String getPositionName() {
		return positionName;
	}
	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}
	
	@Column(name = "position_level")
	public int getPositionLevel() {
		return positionLevel;
	}
	public void setPositionLevel(int positionLevel) {
		this.positionLevel = positionLevel;
	}
	
	@Column(name = "parent_position_id")
	public String getParentPositionId() {
		return parentPositionId;
	}
	public void setParentPositionId(String parentPositionId) {
		this.parentPositionId = parentPositionId;
	}
	
	@Column(name = "position_show_name")
	public String getPositionShowName() {
		return positionShowName;
	}
	public void setPositionShowName(String positionShowName) {
		this.positionShowName = positionShowName;
	}
	
	@Column(name = "position_path")
	public String getPositionPath() {
		return positionPath;
	}
	public void setPositionPath(String positionPath) {
		this.positionPath = positionPath;
	}  
	
}

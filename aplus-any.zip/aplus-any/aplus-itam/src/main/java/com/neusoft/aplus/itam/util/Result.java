package com.neusoft.aplus.itam.util;

import java.io.Serializable;

/**
 * @ClassName: Result
 * @Description: 校验返回结果
 * @author lu.z
 * @date 2015年4月9日 下午2:11:36
 */
public class Result implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5868205547594980383L;

	public Result() {

	}

	/**
	 * 返回结果，默认false
	 */
	private boolean success = false;
	/**
	 * 错误信息
	 */
	private String errorMsg;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
}

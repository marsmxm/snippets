package com.neusoft.aplus.itam.test.action;


import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import com.neusoft.aplus.common.base.RestClient;

/**
 * @ClassName: AttrLoadAction 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-5-4 下午5:51:15
 */
public class AttrLoadActionTest {
	private static RestClient client;

	@BeforeClass
	public static void createClient() {
		client = new RestClient(Protocol.HTTPS);
	}
	/**
	 * @Description: TODO
	 * @author jin.ysh
	 * @date 2015-5-4 下午5:55:09 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void loadAttr() {
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/loadAplusDeviceAttr");
		Response response = client.post(uri, null);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
	
}

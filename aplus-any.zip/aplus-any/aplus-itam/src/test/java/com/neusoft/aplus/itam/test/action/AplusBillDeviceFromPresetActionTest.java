package com.neusoft.aplus.itam.test.action;

import java.util.LinkedList;
import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.itam.model.bizentity.BillDev4PresetParam;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;

/**
 * @ClassName: AplusBillDeviceActionTest 
 * @Description: AplusBillDeviceActionTest测试类
 * @author lu.z
 * @date 2015年4月23日 下午5:07:31
 */
public class AplusBillDeviceFromPresetActionTest {
	private static RestClient client;

	@BeforeClass
	public static void createClient() {
		client = new RestClient(Protocol.HTTPS);
	}
	
	/**
	 * @Description: 保存工单设备
	 * @author lu.z
	 * @date 2015年4月23日 下午5:08:10 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void saveAplusBillDevice(){
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/aplusBillDeviceFromPreset");
		// TODO:补充参数
		
		BillDev4PresetParam param = new BillDev4PresetParam();
		param.setBillNo("F00000018");
		param.setBillUuid("8a8185ee4d21d8d4014d21dba46c0001");
		List<AplusPresetDevInfoEntity> list = new LinkedList<AplusPresetDevInfoEntity>();
		AplusPresetDevInfoEntity e = new AplusPresetDevInfoEntity();
		e.setArrivalNumber(5);
		e.setUuid("8a8185ee4d22059e014d2210459d0001");
		list.add(e);
		param.setPresetDevList(list);
		
		Representation data = new JsonRepresentation(JSONUtil.getJsonString(param));
		Response response = client.post(uri, data);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
	
}

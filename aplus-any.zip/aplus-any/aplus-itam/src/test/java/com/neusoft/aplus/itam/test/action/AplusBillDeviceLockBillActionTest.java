package com.neusoft.aplus.itam.test.action;

import java.util.HashMap;
import java.util.Map;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.Representation;
import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.common.util.JSONUtil;

/**
 * @ClassName: AplusBillDeviceLockBillActionTest 
 * @Description: AplusBillDeviceLockBillActionTest测试类
 * @author lu.z
 * @date 2015年4月23日 下午5:47:36
 */
public class AplusBillDeviceLockBillActionTest {
	private static RestClient client;

	@BeforeClass
	public static void createClient() {
		client = new RestClient(Protocol.HTTPS);
	}
	
	/**
	 * @Description: 锁定工单
	 * @author lu.z
	 * @date 2015年4月23日 下午5:52:42 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void lockBillDevice(){
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/aplusBillDevice/lockBillDevice");
		// TODO:补充参数
		String uuids = "8a8185ee4d22059e014d221393ab0002,8a8185ee4d22059e014d221393ab0003";
		Map<String, String> paramsMap = new HashMap<String, String>();
		paramsMap.put("uuids", uuids);
		String jsonString = JSONUtil.getJsonString(paramsMap);
		Representation data = new JsonRepresentation(jsonString);
		Response response = client.put(uri, data);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
}

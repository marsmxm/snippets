package com.neusoft.aplus.itam.test.action;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.itam.model.dbentity.table.AplusBillEntity;

/**
 * @ClassName: BillNoActionTest
 * @Description: BillNoAction测试类
 * @author lu.z
 * @date 2015年4月21日 下午12:56:23
 */
public class AplusBillActionTest {
	private static RestClient client;

	@BeforeClass
	public static void createClient() {
		client = new RestClient(Protocol.HTTPS);
	}

	/**
	 * @Description: 创建工单
	 * @author lu.z
	 * @date 2015年4月21日 下午12:55:53
	 * @param
	 * @return void
	 * @throws
	 */
	@Test
	public void creatBill() {
		Reference uri = new Reference(
				"http://127.0.0.1:8182/api/aplus/itam/bill");
		AplusBillEntity entity = new AplusBillEntity();
		entity.setBillType("F0");
		entity.setBillAppUser("CLOUD");
		String jsonString = JSONUtil.getJsonString(entity);
		Representation data = new JsonRepresentation(jsonString);
		Response response = client.post(uri, data);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}

	/**
	 * @Description: 查询工单
	 * @author zhangyun
	 * @date 2015-4-27 上午11:11:12
	 * @param
	 * @return void
	 * @throws
	 */
	@Test
	public void findBill() {
		// TODO: 补充参数
		Reference uri = new Reference(
				"http://127.0.0.1:8182/api/aplus/itam/bill?billType=F0&method=findBillByBillType");
		Response response = client.get(uri);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
		try {
			JsonRepresentation result = new JsonRepresentation(
					response.getEntity());
			JSONObject jsonObject = result.getJsonObject();
			if (jsonObject != null) {
				System.out.println("工單信息 = " + jsonObject.toString());
			}
			Assert.assertNotNull("工單信息为空", jsonObject);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @Description: 删除
	 * @author zhangyun
	 * @date 2015-4-27 上午11:12:11
	 * @param
	 * @return void
	 * @throws
	 */
	@Test
	public void deleteBill() {
		// TODO: 补充参数
		Reference uri = new Reference(
				"http://127.0.0.1:8182/api/aplus/itam/bill?uuid=8a8185ee4d21c9e2014d21cb1d810001");
		Response response = client.delete(uri);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}

	/**
	 * @Description: 修改工单
	 * @author zhangyun
	 * @date 2015-4-27 上午11:13:21
	 * @param
	 * @return void
	 * @throws
	 */
	@Test
	public void updateBill() {
		Reference uri = new Reference(
				"http://127.0.0.1:8182/api/aplus/itam/bill?uuid=8a8185ee4d21d8d4014d21dba46c0001&billStatus=SAVE");
		// TODO: 补充参数
		AplusBillEntity entity = new AplusBillEntity();
		entity.setBillStatus("SAVE");
		entity.setUuid("8a8185ee4d21d8d4014d21dba46c0001");
		String jsonString = JSONUtil.getJsonString(entity);
		Representation data = new JsonRepresentation(jsonString);
		Response response = client.put(uri, data);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
}

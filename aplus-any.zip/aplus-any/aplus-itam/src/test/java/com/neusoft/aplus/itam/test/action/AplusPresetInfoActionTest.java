package com.neusoft.aplus.itam.test.action;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetInfoEntity;

/**
 * @ClassName: AplusPresetDevInfoActionTest 
 * @Description: AplusPresetDevInfoActionTest测试类
 * @author lu.z
 * @date 2015年4月24日 上午9:09:38
 */
public class AplusPresetInfoActionTest {
	private static RestClient client;

	@BeforeClass
	public static void createClient() {
		client = new RestClient(Protocol.HTTPS);
	}
	
	/**
	 * @Description: 保存预置设备信息
	 * @author lu.z
	 * @date 2015年4月24日 上午9:11:14 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void saveAplusPresrtDevInfo(){
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/presetInfo");
		// TODO: 补充参数
		AplusPresetInfoEntity presetInfoEntity = new AplusPresetInfoEntity();
		presetInfoEntity.setPresetNo("3");
		presetInfoEntity.setPresetName("测试3");
		presetInfoEntity.setPresetAmount(4.00);
		presetInfoEntity.setPresetType("1");
		presetInfoEntity.setVerifyPersion("super11");
		presetInfoEntity.setSignPersion("cloud2");
		String jsonString = JSONUtil.getJsonString(presetInfoEntity);
		Representation data = new JsonRepresentation(jsonString);
		Response response = client.post(uri, data);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
	
	/**
	 * @Description: 修改预置信息
	 * @author lu.z
	 * @date 2015年4月24日 上午9:11:30 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void updateAplusPresrtDevInfo(){
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/presetInfo");
		// TODO: 补充参数
		AplusPresetInfoEntity presetInfoEntity = new AplusPresetInfoEntity();
		presetInfoEntity.setUuid("8a8185ee4d21d8d4014d21f6bb770002");
		presetInfoEntity.setPresetNo("5");
		presetInfoEntity.setPresetName("必须好用");
	
		String jsonString = JSONUtil.getJsonString(presetInfoEntity);
		Representation data = new JsonRepresentation(jsonString);
		Response response = client.put(uri, data);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
	
	/**
	 * @Description: 刪除预置设备信息
	 * @author lu.z
	 * @date 2015年4月24日 上午9:11:42 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void deleteAplusPresrtDevInfo(){
		// TODO: 补充参数
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/presetInfo?uuid=8a8185ee4d21d8d4014d21f6bb770002");
		Response response = client.delete(uri);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
	
	/**
	 * @Description: 根据UUid查询预置信息
	 * @author lu.z
	 * @date 2015年4月24日 上午9:11:53 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void findAplusPresetDevInfoByUuid(){
		// TODO: 补充参数
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/presetInfo?uuid=8a8185ee4d21d8d4014d21f6bb770002");
		Response response = client.get(uri);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
		try {
			JsonRepresentation result = new JsonRepresentation(response.getEntity());
			JSONObject jsonObject = result.getJsonObject();
			if(jsonObject != null){
				System.out.println("预置信息 = " + jsonObject.toString());
			}
			Assert.assertNotNull("预置信息为空", jsonObject);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
}

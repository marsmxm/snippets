package com.neusoft.aplus.itam.test.action;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;

import com.neusoft.aplus.common.base.RestClient;

/**
 * @ClassName: AplusBillDeviceActionTest 
 * @Description: AplusBillDeviceActionTest测试类
 * @author lu.z
 * @date 2015年4月23日 下午5:07:31
 */
public class AplusDeviceItamActionTest {
	private static RestClient client;

	@BeforeClass
	public static void createClient() {
		client = new RestClient(Protocol.HTTPS);
	}
	
	/**
	 * @Description: 保存工单设备
	 * @author lu.z
	 * @date 2015年4月23日 下午5:08:10 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void findAplusDeviceItam(){
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/findAplusDeviceItam?billType=F0");
		Response response = client.get(uri);
		try {
			JsonRepresentation result = new JsonRepresentation(response.getEntity());
			JSONObject jsonObject = result.getJsonObject();
			if(jsonObject != null){
				String str = jsonObject.toString();
				System.out.println("==========================");
				System.out.println("str = " + str);
			}

			Assert.assertNotNull("工单类型：F0，返回结果为空", jsonObject);
			Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	
	
}

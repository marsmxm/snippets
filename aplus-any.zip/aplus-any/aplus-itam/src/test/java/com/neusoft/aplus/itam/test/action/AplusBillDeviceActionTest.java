package com.neusoft.aplus.itam.test.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.common.util.JSONUtil;

/**
 * @ClassName: AplusBillDeviceActionTest 
 * @Description: AplusBillDeviceActionTest测试类
 * @author lu.z
 * @date 2015年4月23日 下午5:07:31
 */
public class AplusBillDeviceActionTest {
	private static RestClient client;

	@BeforeClass
	public static void createClient() {
		client = new RestClient(Protocol.HTTPS);
	}
	
	/**
	 * @Description: 保存工单设备
	 * @author lu.z
	 * @date 2015年4月23日 下午5:08:10 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void saveAplusBillDevice(){
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/aplusBillDevice");
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		// TODO:补充参数
		List<String> fqns = new ArrayList<String>();
		fqns.add("1001.0");
		fqns.add("1002.0");

		paramsMap.put("Fqns", fqns);
		paramsMap.put("billUuid", "8a81852f4cfa93a4014cfa9412b20001");
		paramsMap.put("billNo", "F00000014");
		String jsonString = JSONUtil.getJsonString(paramsMap);
		Representation data = new JsonRepresentation(jsonString);
		Response response = client.post(uri, data);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
	
	/**
	 * @Description: 批量修改工单设备
	 * @author lu.z
	 * @date 2015年4月23日 下午5:34:01 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void batchUpdateAplusBillDevice(){
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/aplusBillDevice");
		Map<String, Object> paramsMap = new HashMap<String, Object>();
		// TODO:补充参数
		Map<String, Map<String, String>> map = new HashMap<String, Map<String, String>>();
		String billUuid = "12321312";
		Map<String, String> m = new HashMap<String, String>();
		m.put("name", "sss");
		map.put("v1", m);
		paramsMap.put("map", map);
		paramsMap.put("billUuid", billUuid);
		String jsonString = JSONUtil.getJsonString(paramsMap);
		Representation data = new JsonRepresentation(jsonString);
		Response response = client.put(uri, data);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
	
	@Test
	public void deleteAplusBillDevice(){
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/aplusBillDevice?uuids=aaa&billUuid=bbb");
		Response response = client.delete(uri);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
	
	/**
	 * @Description: 根据工单UUID 查询工单下设备
	 * @author lu.z
	 * @date 2015年4月27日 下午2:01:10 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void findAplusDeviceByBillUuid(){
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/aplusBillDevice?billUuid=8a8185ee4cf8e123014cf8e28e410003&page=1&pageCount=10");
		Response response = client.get(uri);
		try {
			JsonRepresentation result = new JsonRepresentation(response.getEntity());
			JSONObject jsonObject = result.getJsonObject();
			Assert.assertNotNull("查询工单下设备，返回结果为空", jsonObject);
			JSONArray jsonArray = jsonObject.getJSONArray("itemList");
			Assert.assertNotNull("查询工单下设备，返回结果为空", jsonArray);
			if (jsonArray != null && jsonArray.length() > 0) {
				for (int i = 0; i < jsonArray.length(); i++) {
					String str = jsonArray.get(i).toString();
					System.out.println("==========================");
					System.out.println("str = " + str);
				}
			}
			Assert.assertEquals("查询工单下设备,返回状态码不等于200", 200, response.getStatus().getCode());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
}

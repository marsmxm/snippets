package com.neusoft.aplus.itam.test.action;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.itam.model.dbentity.table.AplusPresetDevInfoEntity;

/**
 * @ClassName: AplusPresetDevInfoActionTest 
 * @Description: AplusPresetDevInfoActionTest测试类
 * @author lu.z
 * @date 2015年4月24日 上午9:09:38
 */
public class AplusPresetDevInfoActionTest {
	private static RestClient client;

	@BeforeClass
	public static void createClient() {
		client = new RestClient(Protocol.HTTPS);
	}
	
	/**
	 * @Description: 保存预置设备信息
	 * @author lu.z
	 * @date 2015年4月24日 上午9:11:14 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void saveAplusPresrtDevInfo(){
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/presetDevInfo");
		// TODO: 补充参数
		AplusPresetDevInfoEntity presetDevInfoEntity = new AplusPresetDevInfoEntity();
		presetDevInfoEntity.setPresetNo("3");
		presetDevInfoEntity.setPresetUuid("8a8185ee4d21fddb014d220263860001");
		presetDevInfoEntity.setNumber(20);
		presetDevInfoEntity.setDeviceType("OPCTester");
		presetDevInfoEntity.setDeviceVersion("v1.0");
		presetDevInfoEntity.setCategory("OPC");
		String jsonString = JSONUtil.getJsonString(presetDevInfoEntity);
		Representation data = new JsonRepresentation(jsonString);
		Response response = client.post(uri, data);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
	
	/**
	 * @Description: 修改预置信息
	 * @author lu.z
	 * @date 2015年4月24日 上午9:11:30 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void updateAplusPresrtDevInfo(){
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/presetDevInfo");
		// TODO: 补充参数
		AplusPresetDevInfoEntity presetDevInfoEntity = new AplusPresetDevInfoEntity();
		presetDevInfoEntity.setUuid("8a8185ee4d21fddb014d2202da950002");
		presetDevInfoEntity.setNumber(10);
		presetDevInfoEntity.setDeviceType("Modbussimulate");
		presetDevInfoEntity.setDeviceVersion("1");
		presetDevInfoEntity.setCategory("SIMULATE");
		
		String jsonString = JSONUtil.getJsonString(presetDevInfoEntity);
		Representation data = new JsonRepresentation(jsonString);
		Response response = client.put(uri, data);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
	
	/**
	 * @Description: 刪除预置设备信息
	 * @author lu.z
	 * @date 2015年4月24日 上午9:11:42 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void deleteAplusPresrtDevInfo(){
		// TODO: 补充参数
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/presetDevInfo?uuid=8a8185ee4d21fddb014d2202da950002");
		Response response = client.delete(uri);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
	
	/**
	 * @Description: 根据UUid查询预置信息
	 * @author lu.z
	 * @date 2015年4月24日 上午9:11:53 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void findAplusPresetDevInfoByUuid(){
		// TODO: 补充参数
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/presetDevInfo?presetUuid=8a8185ee4d21fddb014d220263860001");
		Response response = client.get(uri);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
		try {
			JsonRepresentation result = new JsonRepresentation(response.getEntity());
			JSONObject jsonObject = result.getJsonObject();
			if(jsonObject != null){
				System.out.println("预置信息 = " + jsonObject.toString());
			}
			Assert.assertNotNull("预置信息为空", jsonObject);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	

}

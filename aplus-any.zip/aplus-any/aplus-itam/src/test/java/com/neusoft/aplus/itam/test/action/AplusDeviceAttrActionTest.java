package com.neusoft.aplus.itam.test.action;

import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONException;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceAttrEntity;

/**
 * @ClassName: AplusSupplierActionTest 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-23 下午5:19:48
 */
public class AplusDeviceAttrActionTest {
	private static RestClient client;

	@BeforeClass
	public static void createClient() {
		client = new RestClient(Protocol.HTTPS);
	}
	/**
	 * @Description: TODO
	 * @author jin.ysh
	 * @date 2015-4-23 下午5:20:22 
	 * @param 
	 * @return void
	 * @throws
	 */
	@Test
	public void findDeviceAttrEntityByDeviceType() {
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/aplusDeviceAttr?deviceType=Modbussimulate&deviceVersion=1");
		Response response = client.get(uri);
		try {
			JsonRepresentation result = new JsonRepresentation(response.getEntity());
			JSONArray jsonObject = result.getJsonArray();
			//JSONObject jsonObject = result.getJsonObject();
			if(jsonObject != null){
				String str = jsonObject.toString();
				System.out.println("==========================");
				System.out.println("str = " + str);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @Description: TODO
	 * @author jin.ysh
	 * @date 2015-4-27 上午11:37:56 
	 * @param 
	 * @return void
	 * @throws
	 */
	//@Test
	public void findDeviceAttrEntityByCategory() {
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/aplusDeviceAttr?category=SIMULATE");
		Response response = client.get(uri);
		try {
			JsonRepresentation result = new JsonRepresentation(response.getEntity());
			JSONArray jsonObject = result.getJsonArray();
			//JSONObject jsonObject = result.getJsonObject();
			if(jsonObject != null){
				String str = jsonObject.toString();
				System.out.println("==========================");
				System.out.println("str = " + str);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	
	//@Test
	public void saveOrUpdateDeviceAttrEntity() {
 		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/aplusDeviceAttr");
		// TODO: 补充参数
 		AplusDeviceAttrEntity aplusDeviceAttrEntity = new AplusDeviceAttrEntity();
		aplusDeviceAttrEntity.setSupplierId("a2115");
		aplusDeviceAttrEntity.setCategory("b2115");
		aplusDeviceAttrEntity.setDeviceType("c2115");
		aplusDeviceAttrEntity.setDeviceVersion("d2115");
		aplusDeviceAttrEntity.setAttr("[{\"defkey22\":\"ip\",\"name\":\"assetStatus\",\"notNull\":true},{\"defkey\":\"ip\",\"name\":\"resStatus\",\"notNull\":true}]");
		String jsonString = JSONUtil.getJsonString(aplusDeviceAttrEntity);
		Representation data = new JsonRepresentation(jsonString);
		Response response = client.put(uri, data);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());	
	}
}

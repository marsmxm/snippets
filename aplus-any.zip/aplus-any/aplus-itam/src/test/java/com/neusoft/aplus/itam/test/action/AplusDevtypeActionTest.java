package com.neusoft.aplus.itam.test.action;

import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONException;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.itam.model.dbentity.table.AplusDevtypeEntity;

/**
 * @ClassName: AplusDevtypeActionTest 
 * @Description: TODO
 * @author jin.ysh
 * @date 2015-4-23 上午11:31:46
 */
public class AplusDevtypeActionTest {
	private static RestClient client;

	@BeforeClass
	public static void createClient() {
		client = new RestClient(Protocol.HTTPS);
	}
	/**
	 * @Description: 查询设备类型
	 * @author jin.ysh
	 * @date 2015-4-23 上午11:31:59 
	 * @param 
	 * @return void
	 * @throws
	 */
	//@Test
	public void findAplusDevtypeEntitys() {
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/devtype?devtypeId=4491");
		Response response = client.get(uri);
		try {
			JsonRepresentation result = new JsonRepresentation(response.getEntity());
			JSONArray jsonObject = result.getJsonArray();
			if(jsonObject != null){
				String str = jsonObject.toString();
				System.out.println("==========================");
				System.out.println("str = " + str);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	
	
	//@Test
	public void saveAplusDevtype() {
 		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/devtype");
		// TODO: 补充参数
 		AplusDevtypeEntity aplusDevtypeEntity = new AplusDevtypeEntity();
 		aplusDevtypeEntity.setDevtypeId("555");
 		aplusDevtypeEntity.setDevtypeName("软件1234666");
 		aplusDevtypeEntity.setDevtypeLevel(3);
 		aplusDevtypeEntity.setDevtypePath("/");
 		aplusDevtypeEntity.setDevtypeAttr("[{\"defkey\":\"ip\",\"name\":\"assetStatus\",\"notNull\":true},{\"defkey\":\"ip\",\"name\":\"resStatus\",\"notNull\":true}]");

		String jsonString = JSONUtil.getJsonString(aplusDevtypeEntity);
		Representation data = new JsonRepresentation(jsonString);
		Response response = client.post(uri, data);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());	
	}
	
	//@Test
	public void updateAplusDevtype() {
 		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/devtype");
		// TODO: 补充参数
 		AplusDevtypeEntity aplusDevtypeEntity = new AplusDevtypeEntity();
 		aplusDevtypeEntity.setDevtypeId("555");
 		aplusDevtypeEntity.setDevtypeName("软件abc");
 		aplusDevtypeEntity.setDevtypeLevel(3);
 		aplusDevtypeEntity.setDevtypePath("/");
 		aplusDevtypeEntity.setDevtypeAttr("[{\"defkey\":\"ip\",\"name\":\"assetStatus\",\"notNull\":true},{\"defkey\":\"ip\",\"name\":\"resStatus\",\"notNull\":true}]");

		String jsonString = JSONUtil.getJsonString(aplusDevtypeEntity);
		Representation data = new JsonRepresentation(jsonString);
		Response response = client.put(uri, data);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());	
	}
	@Test
	public void removeAplusDevtype(){
		Reference uri = new Reference("http://127.0.0.1:8182/api/aplus/itam/devtype?devtypeId=4491");
		Response response = client.delete(uri);
		Assert.assertEquals("返回状态码不等于200", 200, response.getStatus().getCode());
	}
}

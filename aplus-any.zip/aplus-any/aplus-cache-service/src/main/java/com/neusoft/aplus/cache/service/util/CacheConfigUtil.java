package com.neusoft.aplus.cache.service.util;

import java.io.File;

import net.sf.ehcache.CacheManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.neusoft.aplus.common.util.FileUtil;

public class CacheConfigUtil {
	
	private static Logger log = LoggerFactory.getLogger(CacheConfigUtil.class);
	private static String SPRING_PATH = File.separator.concat("spring");
	private static String EHCACHE_PATH = File.separator.concat("ehcache");
	
	/**
	 *  获取配置文件的绝对路径
	 *  读取启动时穿入的config_file参数，来确定应该读取的配置文件
	 *  参数为配置文件末位的编号
	 * 	src/main/resources/ehcache/ehcache1.xml
	 *  src/main/resources/spring/applicationContext1.xml
	 * )
	 * @param path
	 * @author MaHan
	 * @date 2015年4月17日
	 */
	private static String getAbsolutePath(String path){
		String springPath = FileUtil.getRepositoryPath(path);
		File dir = new File(springPath);
		File[] files = dir.listFiles();
		String fileNum = System.getProperty("config_file");
		for(File f:files){
			String absolutePath = f.getAbsolutePath();
			absolutePath = absolutePath.trim();
			String tail = absolutePath.substring(absolutePath.length()-5, absolutePath.length()-4);
			if(tail.equals(fileNum.trim())){
				return absolutePath;
			}
		}
		return null;
	}
	/**
	 * Spring配置文件读取，并初始化
	 * 
	 * @author MaHan
	 * @date 2015年4月17日
	 */
	@SuppressWarnings("resource")
	public static void loadSpring(){
		String absolutePath = getAbsolutePath(SPRING_PATH);
		String springFile = "file:"+absolutePath;
		log.debug("最终加载的spring配置文件：" + springFile);
		new FileSystemXmlApplicationContext(springFile);
	}
	/**
	 * 根据ehcache配置文件创建CacheManager
	 * @return
	 * @author MaHan
	 * @date 2015年4月17日
	 */
	public static CacheManager getCacheManager(){
		String absolutePath = getAbsolutePath(EHCACHE_PATH);
		CacheManager cacheManager = CacheManager.create(absolutePath);
		log.debug("由配置文件创建CacheManager：" + absolutePath);
		return cacheManager;
	}
}

package com.neusoft.aplus.cache.service.main;

import com.neusoft.aplus.cache.service.util.CacheConfigUtil;

public class CacheServiceLaunch {
	
	public static void main(String[] args) {
		CacheConfigUtil.loadSpring();
	}
	
}

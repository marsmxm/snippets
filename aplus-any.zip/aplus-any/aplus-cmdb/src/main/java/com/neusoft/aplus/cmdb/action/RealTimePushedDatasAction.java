package com.neusoft.aplus.cmdb.action;

import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;

import com.neusoft.aplus.cmdb.exception.CmdbException;
import com.neusoft.aplus.cmdb.util.ActionUtil;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.model.bizentity.AplusMsgAction;

/**
 * 实时数据推动开始接口
 * 
 * @author zh_ch
 * @date 2015年3月17日 下午5:37:10
 */
public class RealTimePushedDatasAction extends BaseAction {

	/**
	 * 实时数据定时推送注册接口
	 */
	@Override
	public void acceptRepresentation(Representation entity) {
		List<Map<String, String>> paraList = null;
		try {
			paraList = ActionUtil.getListFromRequest(entity);
			ActionUtil.handleRealTimeAction(paraList,
					AplusMsgAction.PUSH_REGISTE);
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}
		sendSuccess();
	}

	@Override
	public Representation represent() {
		return null;
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub

	}

	/**
	 * 实时数据定时推送去注册接口（即推送任务注销接口）
	 */
	@Override
	public void storeRepresentation(Representation entity) {
		List<Map<String, String>> paraList = null;
		try {
			paraList = ActionUtil.getListFromRequest(entity);
			ActionUtil.handleRealTimeAction(paraList,
					AplusMsgAction.PUSH_UNREGISTE);
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}
		sendSuccess();
	}
}

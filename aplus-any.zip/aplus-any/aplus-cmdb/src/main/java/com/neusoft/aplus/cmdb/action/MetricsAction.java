package com.neusoft.aplus.cmdb.action;

import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;

import com.neusoft.aplus.cmdb.exception.CmdbException;
import com.neusoft.aplus.cmdb.util.ActionUtil;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;
import com.neusoft.aplus.model.bizentity.AplusMsgAction;
import com.neusoft.aplus.model.bizentity.DeviceTypeId;
import com.neusoft.aplus.model.dbentity.table.AplusMetricEntity;

/**
 * 关于指标信息的对外rest接口
 * @author zh_ch
 * @date 2015年4月20日 下午2:28:24
 */
public class MetricsAction extends BaseAction {
	private Map<String, String> queryParaMap = null;

	@Override
	public void doInit() {
		queryParaMap = ActionUtil.cleanMap(getRequestParameters());
	}

	@Override
	public void acceptRepresentation(Representation entity) {
		// TODO Auto-generated method stub

	}

	/**
	 * 根据条件查询指标，传入参数格式请参考wiki
	 */
	@Override
	public Representation represent() {
		Map<String, Object> resultMap = null;
		try {
			resultMap = ActionUtil.getMetricWithCriterion(queryParaMap);
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}

		return createObjectRepresentation(resultMap);
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub

	}

	/**
	 * 更新标准指标（即python定义的指标）
	 * 更新后构造指标更改的ZMQ消息事件，由server根据变更重新调度任务
	 */
	@Override
	public void storeRepresentation(Representation entity) {
		List<AplusMetricEntity> entityList = null;
		List<DeviceTypeId> typeList = null;
		try {
			entityList = getObjectsFromRepresentation(entity,
					AplusMetricEntity.class);
			typeList = ActionUtil.updateStdMetric(entityList);
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}

		//构造ZMQ消息时间并发送
		ZMQMessage zmqMessage = new ZMQMessage(ZMQConst.TOPIC_TO_DBUSSERVER,
				JSONUtil.getJsonString(typeList), AplusMsgAction.UPDATE_METRIC);
		ActionUtil.publishMessageToServer(zmqMessage);
		sendSuccess();
	}
}

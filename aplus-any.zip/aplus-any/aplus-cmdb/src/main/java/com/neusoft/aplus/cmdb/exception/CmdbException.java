package com.neusoft.aplus.cmdb.exception;

import java.util.Map;

import com.neusoft.aplus.common.exception.AplusException;
import com.neusoft.aplus.common.exception.annotation.MessageCN;
import com.neusoft.aplus.common.exception.annotation.MessageUS;

/**
 * @author zh_ch
 * @date 2015年4月14日 下午2:51:02
 */
public class CmdbException extends AplusException {
	private static final long serialVersionUID = 1L;

	// 异常码范围900_1000
	@MessageCN("")
	@MessageUS("")
	public static final String BOTTOMEX = createExceptionCode(901);

	public CmdbException(String code, Exception original, Object[] params,
			Map<String, Object> keyPoints) {
		super(code, original, params, keyPoints);
	}

	public static void throwException(String exCode) {
		throwException(exCode, null, null, null);
	}

	public static void throwException(String exCode, Exception original,
			Object[] params, Map<String, Object> keyPoints) {
		new CmdbException(exCode, original, params, keyPoints).throwEx();
	}
	
	public static void throwException(String exCode, Exception original) {
		new CmdbException(exCode, original, null, null).throwEx();
	}

	private static String createExceptionCode(int code) {
		return getFormatedNumber(ID_PLATFORM, code);
	}
}

package com.neusoft.aplus.cmdb.action;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neusoft.aplus.cmdb.exception.CmdbException;
import com.neusoft.aplus.cmdb.model.ActionConst;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.util.SpringUtil;
import com.neusoft.aplus.model.bizentity.DeviceTypeId;
import com.neusoft.aplus.service.core.service.bo.AplusDeviceAttrBo;

/**
 * aplus_device_attr表对应的CRDU操作
 * @author zh_ch
 * @date 2015年4月14日 上午9:05:39
 */
public class CategorysAction extends BaseAction {
	private AplusDeviceAttrBo aplusDeviceAttrBo;

	@Override
	public void doInit() {
		aplusDeviceAttrBo = SpringUtil.getBean(AplusDeviceAttrBo.class);
	}

	@Override
	public void acceptRepresentation(Representation entity) {
		// TODO Auto-generated method stub

	}

	/**
	 * 查询category及devicetype和deviceVersion组成的树形结构
	 */
	@Override
	public Representation represent() {
		Map<String, List<DeviceTypeId>> categoryMap = null;
		List<Map<String, Object>> resultList = null;
		try {
			categoryMap = aplusDeviceAttrBo.findAllCategoryAndDeviceType();
			resultList = transferFromMap(categoryMap);
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}

		return createObjectRepresentation(resultList);
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub

	}

	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub

	}

	/**
	 * 为liferay专门做的转化
	 */
	private List<Map<String, Object>> transferFromMap(
			Map<String, List<DeviceTypeId>> categoryMap) {
		List<Map<String, Object>> resultList = Lists.newArrayList();
		Iterator<String> iterator = categoryMap.keySet().iterator();
		while (iterator.hasNext()) {
			Map<String, Object> map = Maps.newHashMap();
			String category = iterator.next();
			List<DeviceTypeId> list = categoryMap.get(category);
			map.put(ActionConst.CATEGORY_HQL, category);
			map.put(ActionConst.DEVICE_TYPEID_LIST, list);
			resultList.add(map);
		}
		return resultList;
	}
}

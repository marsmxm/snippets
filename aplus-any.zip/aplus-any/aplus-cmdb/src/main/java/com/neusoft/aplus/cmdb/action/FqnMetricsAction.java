package com.neusoft.aplus.cmdb.action;

import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;

import com.google.common.collect.Lists;
import com.neusoft.aplus.cmdb.exception.CmdbException;
import com.neusoft.aplus.cmdb.model.ActionConst;
import com.neusoft.aplus.cmdb.model.Message;
import com.neusoft.aplus.cmdb.util.ActionUtil;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;
import com.neusoft.aplus.model.bizentity.AplusMsgAction;
import com.neusoft.aplus.model.dbentity.table.AplusFqnMetricEntity;
import com.neusoft.aplus.model.dbentity.table.FqnMetricUnionPk;

/**
 * 导入针对子系统（opc协议居多）的指标信息
 * 子系统的指标信息与标准资源的指标信息有差别，需区别对待
 * 此接口为对象接口，传入的参数都是json格式
 * @author zh_ch
 * @date 2015年4月7日 上午10:57:31
 */
public class FqnMetricsAction extends BaseAction {

	@SuppressWarnings("unchecked")
	@Override
	public void acceptRepresentation(Representation entity) {
		List<AplusFqnMetricEntity> entityList = null;
		try {
			entityList = getObjectsFromRepresentation(entity,
					AplusFqnMetricEntity.class);
			Map<String, Object> map = ActionUtil.saveFqnMetric(entityList);
			List<FqnMetricUnionPk> fqnIntersectionfList = (List<FqnMetricUnionPk>) map
					.get(ActionConst.FQNINTERSECTION_LIST);
			List<AplusFqnMetricEntity> needSaveAplusFqnMetricEntity = (List<AplusFqnMetricEntity>) map
					.get(ActionConst.SAVEAFM_BEAN);
			if (needSaveAplusFqnMetricEntity.size() > 0) {

				List<FqnMetricUnionPk> fqnValueList = (List<FqnMetricUnionPk>) map
						.get(ActionConst.FQNVALUE_LIST);
				//子系统指标导入成功后，向server发送子系统指标导入ZMQ时间，server根据事件调度任务
				ZMQMessage message = new ZMQMessage(
						ZMQConst.TOPIC_TO_DBUSSERVER,
						JSONUtil.getJsonString(Lists
								.newArrayList(fqnValueList)),
						AplusMsgAction.ADD_FQN_METRIC);
				ActionUtil.publishMessageToServer(message);
			}
			if (fqnIntersectionfList.size() > 0) {
				Message messageInfo = ActionUtil
						.generateMessage(fqnIntersectionfList);
				sendResponse(messageInfo);
			} else {
				sendSuccess();
			}
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}

	}

	@Override
	public Representation represent() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub

	}

	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub
	}
}

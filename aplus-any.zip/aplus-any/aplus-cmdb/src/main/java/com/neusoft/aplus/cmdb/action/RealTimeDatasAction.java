package com.neusoft.aplus.cmdb.action;

import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;

import com.neusoft.aplus.cmdb.exception.CmdbException;
import com.neusoft.aplus.cmdb.util.ActionUtil;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.model.bizentity.AplusMsgAction;

/**
 * 查询实时数据，单次调用
 * 
 * @author zh_ch
 * @date 2015年3月17日 下午5:26:58
 */
public class RealTimeDatasAction extends BaseAction {

	@Override
	public void acceptRepresentation(Representation entity) {
		List<Map<String, String>> paraList = null;
		try {
			paraList = ActionUtil.getListFromRequest(entity);
			ActionUtil.handleRealTimeAction(paraList, AplusMsgAction.PUSH_ONCE);
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}
		sendSuccess();
	}

	@Override
	public Representation represent() {
		return null;
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub
	}

	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub

	}
}

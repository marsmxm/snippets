package com.neusoft.aplus.cmdb.model;

/**
 * @author zh_ch
 * @date 2015年4月8日 下午4:25:16
 */
public class ActionConst {
	// 查询资源的条件常量,对应数据库entity的属性名，可参考model中的DB ENTITY
	public static final String PAGE = "page"; // 第x页
	public static final String PAGE_COUNT = "pageCount"; // 每页显示的数目
	public static final String CATEGORY_HQL = "category"; // HQL语句中的category
	public static final String DEVICE_NAME_HQL = "name"; // HQL语句中的name(资源名称)
	public static final String DEVICE_TYPE_HQL = "deviceType"; // HQL语句中的deviceType
	public static final String DEVICE_VERSION_HQL = "deviceVersion";
	public static final String LOCATION_HQL = "location";
	public static final String ATTR_HQL = "attr";
	public static final String CREATE_DATE_HQL = "createDate";
	public static final String DEVICE_FQN_HQL = "fqn";
	public static final String CONN_ACTIVE_HQL = "active";
	public static final String DEVICE_TYPEID_LIST = "deviceTypeIdList";
	public static final String ALARMCNT = "alarmcnt";
	public static final Long DEFAULT_INTERVAL = 3600000L;
	public static final Integer DEFAULT_PAGE = 1;
	public static final Integer DEFAULT_PAGECOUNT = Integer.MAX_VALUE;

	// 返回值
	public static final String USER_DIR = System.getProperty("user.dir");
	public static final String DEVICE_CNT = "deviceCnt";
	public static final String DEVICE_LIST = "deviceList";
	public static final String CONN_LIST = "connList";
	public static final String METRIC_LIST = "metricList";

	// api地址常量
	public static final String API_HTTP = "http://"; // http协议
	public static final String API_DEVICE_ALARMCNT = "/api/aplus/alert/count"; // alert模块提供接口URL

	// 消息常量
	public static final String MESSAGE_TYPE = "提示信息";
	public static final String FQNINTERSECTION_LIST = "fqnIntersectionfList";
	public static final String SAVEADE_BEAN = "AplusDeviceSave";
	public static final String SAVEAFM_BEAN = "AplusFqnMetricSave";
	public static final String FQNVALUE_LIST = "fqnValueList";

}

package com.neusoft.aplus.cmdb.importer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.base.Objects;
import com.neusoft.aplus.cmdb.model.ActionConst;
import com.neusoft.aplus.cmdb.util.ActionUtil;
import com.neusoft.aplus.common.util.SpringUtil;
import com.neusoft.aplus.model.ModelConst;
import com.neusoft.aplus.model.dbentity.table.AplusFqnMetricEntity;
import com.neusoft.aplus.model.dbentity.table.FqnMetricUnionPk;
import com.neusoft.aplus.service.core.service.bo.AplusFqnMetricBo;

/**
 * 子系统指标信息的文件导入处理逻辑类
 * @author zh_ch
 * @date 2015年5月12日 下午1:16:16
 */
@Component
public final class AplusFqnMetricImporter {

	@Autowired
	private AplusFqnMetricBo aplusFqnMetricBo;

	public Map<String, Object> importExcel(String filename) throws Exception {
		boolean is2003 = false;

		if (VersionExcel.isExcel2003(filename)) {
			is2003 = true;
		} else {
			is2003 = false;
		}

		return parseExcelForDevice(filename, is2003);
	}

	private Map<String, Object> parseExcelForDevice(String filename,
			boolean is2003) {

		// 第一步：创建WokBook（工作薄）
		File f = new File(filename);
		Workbook workbook = null;
		AplusFqnMetricEntity fme = null;
		List<AplusFqnMetricEntity> fmes = null;
		
		List<String> fqnList = new ArrayList<String>();
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			InputStream stream = new FileInputStream(f);
			if (is2003) {
				workbook = new HSSFWorkbook(stream);
			} else {
				workbook = new XSSFWorkbook(stream);
			}
			// 第二部：获得Sheet（工作表）
			Sheet sheet = workbook.getSheetAt(7);
			if (sheet.getPhysicalNumberOfRows() <= 1) {
				return null;
			}

			fmes = new ArrayList<AplusFqnMetricEntity>();

			Set<String> set = new HashSet<String>();
			// 第三部：根据row和column来获取cell中的value
			List<FqnMetricUnionPk> list = new ArrayList<FqnMetricUnionPk>();
			for (Row row : sheet) {
				if (row.getRowNum() > 0) {
					fme = new AplusFqnMetricEntity();
					fqnList.add(getStringCellValue(row.getCell(0)));
					fme.setFqn(getStringCellValue(row.getCell(0)));
					fme.setMetricName(getStringCellValue(row.getCell(1)));
					fme.setMetricCode(getStringCellValue(row.getCell(2)));
					fme.setMetricUnit(getStringCellValue(row.getCell(3)));
					fme.setMetricInterval(Math.round((Float
							.parseFloat(getStringCellValue(row.getCell(4))))));
					fme.setMetricTimeUnit(getStringCellValue(row.getCell(5)));
					fme.setMetricActive(getStringCellValue(row.getCell(6))
							.equalsIgnoreCase("true") ? true : false);
					fme.setMetricType(Math.round((Float
							.parseFloat(getStringCellValue(row.getCell(7))))));
					fme.setMetricDefkey(getStringCellValue(row.getCell(8)));
					if(!Objects.equal(null,row.getCell(9))&&!Objects.equal("",row.getCell(9))){
						fme.setMetricInfo(getStringJSONValue(row.getCell(9)));
					}
					fme.setDeviceType(getStringCellValue(row.getCell(10)));
					fme.setDeviceVersion(getStringCellValue(row.getCell(11)));
					set.add(getStringCellValue(row.getCell(0)));
					
					FqnMetricUnionPk fmu = new FqnMetricUnionPk();
					fmu.setFqn(getStringCellValue(row.getCell(0)));
					fmu.setMetricName(getStringCellValue(row.getCell(1)));
					fmes.add(fme);
					list.add(fmu);
				}

			}

			// 判断fqn数据库是否重复,如果重复 ，则不插入，重复则记录
			AplusFqnMetricBo aplusFqnMetricBo = SpringUtil.getBean(AplusFqnMetricBo.class);
			List<Object[]> fqnFromDBList = aplusFqnMetricBo.findALLFqnAndMetricName();
			
			// 取差集
			List<FqnMetricUnionPk> fqnValueList = ActionUtil.diffMetric(list, fqnFromDBList);
			// 取交集
			List<FqnMetricUnionPk> fqnIntersectionfList = ActionUtil.intersectMetric(list,
					fqnFromDBList);
			List<AplusFqnMetricEntity> needSaveAplusFqnMetricEntity = new ArrayList<AplusFqnMetricEntity>();
	
			for (int i = 0; i < fmes.size(); i++) {
				AplusFqnMetricEntity bean = fmes.get(i);
				FqnMetricUnionPk pk = new FqnMetricUnionPk();
				pk.setFqn(bean.getFqn());
				pk.setMetricName(bean.getMetricName());
				if (fqnValueList.contains(pk)) {
					needSaveAplusFqnMetricEntity.add(bean);
					
				}
			}

			// 如果过滤出来的数据为0 则不保存
			if (needSaveAplusFqnMetricEntity.size() > 0) {
				// 实体入库,需要进行修改
				aplusFqnMetricBo
						.saveOrUpdateAplusFqnMetrics(needSaveAplusFqnMetricEntity);
			}

			map.put(ActionConst.FQNINTERSECTION_LIST, fqnIntersectionfList);
			map.put(ActionConst.SAVEAFM_BEAN,  
					needSaveAplusFqnMetricEntity);
			map.put(ActionConst.FQNVALUE_LIST, fqnValueList);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (workbook != null) {
				try {
					workbook.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return map;

	}

	/**
	 * 根据类型获取cell的值
	 */
	public String getStringCellValue(Cell cell) {
		String cellValue = null;

		if (cell == null) {
			return "";
			
		} else {
			switch (cell.getCellType()) {
			case HSSFCell.CELL_TYPE_NUMERIC: // 数字
				cellValue = cell.getNumericCellValue() + "";
				break;

			case HSSFCell.CELL_TYPE_STRING: // 字符串
				cellValue = cell.getStringCellValue();
				break;

			case HSSFCell.CELL_TYPE_BOOLEAN: // Boolean
				cellValue = cell.getBooleanCellValue() + "";
				break;

			case HSSFCell.CELL_TYPE_FORMULA: // 公式
				cellValue = cell.getCellFormula() + "";
				break;

			case HSSFCell.CELL_TYPE_BLANK: // 空值
				cellValue =" ";
				break;

			case HSSFCell.CELL_TYPE_ERROR: // 故障
				cellValue = "非法字符";
				break;

			default:
				cellValue = "";
				break;
			}
		}

		return cellValue;
	}
	
	
	
	public String getStringJSONValue(Cell cell) {
		String cellValue = null;

		if (cell == null) {
			return ModelConst.DEFAULT_JSONOBJECT_TEXT;
			
		} else {
			switch (cell.getCellType()) {
			case HSSFCell.CELL_TYPE_NUMERIC: // 数字
				cellValue = cell.getNumericCellValue() + "";
				break;

			case HSSFCell.CELL_TYPE_STRING: // 字符串
				cellValue = cell.getStringCellValue();
				break;

			case HSSFCell.CELL_TYPE_BOOLEAN: // Boolean
				cellValue = cell.getBooleanCellValue() + "";
				break;

			case HSSFCell.CELL_TYPE_FORMULA: // 公式
				cellValue = cell.getCellFormula() + "";
				break;

		
			default:
				cellValue = ModelConst.DEFAULT_JSONOBJECT_TEXT;
				break;
			}
		}

		return cellValue;
	}

	/**
	 * 判定excel的版本
	 */
	static class VersionExcel {
		public static boolean isExcel2003(String filePath) {
			return filePath.matches("^.+\\.(?i)(xls)$");
		}

		public static boolean isExcel2007(String filePath) {
			return filePath.matches("^.+\\.(?i)(xlsx)$");
		}
	}

}

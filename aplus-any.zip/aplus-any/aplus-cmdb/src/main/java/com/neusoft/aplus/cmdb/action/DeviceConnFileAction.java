package com.neusoft.aplus.cmdb.action;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.restlet.representation.InputRepresentation;
import org.restlet.representation.Representation;

import com.google.common.collect.Lists;
import com.neusoft.aplus.cmdb.exception.CmdbException;
import com.neusoft.aplus.cmdb.importer.AplusDeviceConnImporter;
import com.neusoft.aplus.cmdb.model.ActionConst;
import com.neusoft.aplus.cmdb.model.Message;
import com.neusoft.aplus.cmdb.util.ActionUtil;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;
import com.neusoft.aplus.model.bizentity.AplusMsgAction;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;

/**
 * 资源/连接文件导入
 * 与ConnectionsAction的作用相同，一个对象接口，一个文件接口
 * @author zh_ch
 * @date 2015年3月27日 上午11:20:07
 */
public class DeviceConnFileAction extends BaseAction {

	@SuppressWarnings("unchecked")
	@Override
	public void acceptRepresentation(Representation entity) {
		InputRepresentation inputRep = null;
		File file = null;
		try {
			inputRep = (InputRepresentation) entity;
			file = ActionUtil.fileImportHandler(inputRep);
			// export excel
			AplusDeviceConnImporter importer = ApplicationContextFactory
					.getBean(AplusDeviceConnImporter.class);
			Map<String, Object> map = importer.importExcel(file.getPath());
			List<String> fqnIntersectionfList = (List<String>) map
					.get(ActionConst.FQNINTERSECTION_LIST);
			List<AplusDeviceEntity> needSaveAplusDeviceEntity = (List<AplusDeviceEntity>) map
					.get(ActionConst.SAVEADE_BEAN);
			
			//过滤fqn 
			List<String> fqn = Lists.newArrayList();
			for(int i=0;i<needSaveAplusDeviceEntity.size();i++){
				AplusDeviceEntity ade = needSaveAplusDeviceEntity.get(i);
				if(ade!=null){
					fqn.add(ade.getFqn());
				}
				
			}
			if (needSaveAplusDeviceEntity.size() > 0) {
				// send message
				ZMQMessage message = new ZMQMessage(
						ZMQConst.TOPIC_TO_DBUSSERVER,
						JSONUtil.getJsonString(fqn),
						AplusMsgAction.ADD_DEVICECON);

				ActionUtil.publishMessageToServer(message);
			}
			if (fqnIntersectionfList.size() > 0) {

				Message messageInfo = ActionUtil
						.generateMessage(fqnIntersectionfList);
				sendResponse(messageInfo);
			} else {
				sendSuccess();
			}
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}
	}

	@Override
	public Representation represent() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub

	}

	@Override
	public void storeRepresentation(Representation entity) {

	}
}

package com.neusoft.aplus.cmdb.action;

import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neusoft.aplus.cmdb.exception.CmdbException;
import com.neusoft.aplus.cmdb.util.ActionUtil;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;
import com.neusoft.aplus.model.bizentity.AplusMsgAction;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;

/**
 * 资源的CRDU操作
 * @author zh_ch
 * @date 2015年4月8日 下午2:57:45
 */
public class DevicesAction extends BaseAction {
	private Map<String, String> queryParaMap = null;

	@Override
	public void doInit() {
		queryParaMap = ActionUtil.cleanMap(getRequestParameters());
	}

	/**
	 * 更新资源，可更新部分只包括资源名称、物理位置、扩展信息
	 */
	@Override
	public void acceptRepresentation(Representation entity) {
		AplusDeviceEntity device = null;
		try {
			device = getObjectFromRepresentation(entity,
					AplusDeviceEntity.class);
			ActionUtil.updateDevice(device);
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}

		sendSuccess();
	}

	/**
	 * 根据条件查询device信息，查询条件格式可见wiki的rest接口
	 */
	@Override
	public Representation represent() {
		Map<String, Object> resultMap = null;
		try {
			resultMap = ActionUtil.getDeviceWithCriteria(queryParaMap);
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}

		return createObjectRepresentation(resultMap);
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub

	}

	/**
	 * 删除资源列表，删除资源列表后向server发送删除资源的ZMQ事件，服务端暂停资源的采集任务
	 */
	@Override
	public void storeRepresentation(Representation entity) {
		List<String> paraList = null;
		try {
			paraList = getObjectsFromRepresentation(entity, String.class);
			ActionUtil.deleteDevice(paraList);
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}

		Map<String, List<String>> queryMap = Maps.newHashMap();
		for (String fqn : paraList) {
			List<String> metric = Lists.newArrayListWithCapacity(0);
			queryMap.put(fqn, metric);
		}

		ZMQMessage zmqMessage = new ZMQMessage(ZMQConst.TOPIC_TO_DBUSSERVER,
				JSONUtil.getJsonString(queryMap),
				AplusMsgAction.DEELTE_DEVICECON);
		ActionUtil.publishMessageToServer(zmqMessage);
		sendSuccess();
	}
}

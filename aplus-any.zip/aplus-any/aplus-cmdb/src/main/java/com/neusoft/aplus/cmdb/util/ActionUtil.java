package com.neusoft.aplus.cmdb.util;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Date;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.Representation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.TypeReference;
import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.neusoft.aplus.cmdb.model.ActionConst;
import com.neusoft.aplus.cmdb.model.AplusDeviceWithAlarmCnt;
import com.neusoft.aplus.cmdb.model.Message;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.common.config.NettyServerConf;
import com.neusoft.aplus.common.util.AplusCollectionUtils;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.common.util.SpringUtil;
import com.neusoft.aplus.common.util.StreamUtil;
import com.neusoft.aplus.common.util.ZMQUtil;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;
import com.neusoft.aplus.common.zmq.topic.Publisher;
import com.neusoft.aplus.common.zmq.topic.factory.PubSubFactory;
import com.neusoft.aplus.model.ModelConst;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.bizentity.AplusHistoryMetricData;
import com.neusoft.aplus.model.bizentity.AplusMetricData;
import com.neusoft.aplus.model.bizentity.AplusMsgAction;
import com.neusoft.aplus.model.bizentity.DeviceTypeId;
import com.neusoft.aplus.model.dbentity.Page;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;
import com.neusoft.aplus.model.dbentity.table.AplusFqnMetricEntity;
import com.neusoft.aplus.model.dbentity.table.AplusMetricEntity;
import com.neusoft.aplus.model.dbentity.table.FqnMetricUnionPk;
import com.neusoft.aplus.service.core.service.AplusServiceParam;
import com.neusoft.aplus.service.core.service.bo.AplusDeviceBo;
import com.neusoft.aplus.service.core.service.bo.AplusFqnMetricBo;
import com.neusoft.aplus.service.core.service.bo.AplusMetricBo;
import com.neusoft.aplus.service.core.service.bo.AplusMonitorDataBo;

/**
 * 历史数据查询、资源映射信息获取等
 * 
 * @author zh_ch
 * @date 2015年3月19日 上午10:03:20
 */
public class ActionUtil {
	private static final Logger logger = LoggerFactory
			.getLogger(ActionUtil.class);

	// 从aplus_fqn_metric获取fqn的指标名称列表
	public static List<String> getMetircNames(
			AplusFqnMetricBo aplusFqnMetricBo, String fqn) {
		List<String> metricNameList = Lists.newArrayList();
		List<AplusFqnMetricEntity> entityList = aplusFqnMetricBo.findByFqn(fqn);

		for (AplusFqnMetricEntity entity : entityList) {
			metricNameList.add(entity.getMetricName());
		}

		return metricNameList;
	}

	/**
	 * 处理实时推送请求的方法，包括推送一次（pushonce/pushregiste/pushunregiste)
	 * @param deviceMap
	 * @param action
	 * @return
	 * @author zh_ch
	 * @date 2015年3月19日 上午10:44:12
	 */
	public static void handleRealTimeAction(List<Map<String, String>> paraList,
			AplusMsgAction action) {
		ZMQMessage message = null;
		Map<String, List<String>> queryMap = Maps.newHashMap();
		//获得fqn_metric表的业务逻辑处理类的对象
		AplusFqnMetricBo aplusFqnMetricBo = SpringUtil
				.getBean(AplusFqnMetricBo.class);
		//构建fqn与metric列表的Map
		for (Map<String, String> map : paraList) {
			String fqn = map.get(AplusServiceParam.getFqn());
			if (StringUtils.isBlank(fqn)) {
				continue;
			}

			String metricNameString = map
					.get(AplusServiceParam.getMetricList());
			List<String> metricNames = null;

			if (StringUtils.isBlank(metricNameString)
					&& aplusFqnMetricBo.isFqnExist(fqn)) {
				metricNames = ActionUtil.getMetircNames(aplusFqnMetricBo, fqn);
			} else {
				metricNames = JSONUtil.getObjectList(metricNameString,
						String.class);
			}

			queryMap.put(fqn, metricNames);
		}

		//构建ZMQ消息
		if (action.isPushOnceAction()) {
			message = new ZMQMessage(ZMQConst.TOPIC_TO_DBUSSERVER,
					JSONUtil.getJsonString(queryMap), AplusMsgAction.PUSH_ONCE);
		} else if (action.isPushRegisteAction()) {
			message = new ZMQMessage(ZMQConst.TOPIC_TO_DBUSSERVER,
					JSONUtil.getJsonString(queryMap),
					AplusMsgAction.PUSH_REGISTE);
		} else {
			message = new ZMQMessage(ZMQConst.TOPIC_TO_DBUSSERVER,
					JSONUtil.getJsonString(queryMap),
					AplusMsgAction.PUSH_UNREGISTE);
		}

		publishMessageToServer(message);
	}

	/**
	 * 获取参数
	 * 
	 * @param entity
	 * @return
	 * @throws Exception
	 * @author zh_ch
	 * @date 2015年4月15日 上午10:03:18
	 */
	public static List<Map<String, String>> getListFromRequest(
			Representation entity) throws Exception {
		List<Map<String, String>> resultList = null;
		TypeReference<List<Map<String, String>>> type = new TypeReference<List<Map<String, String>>>() {
		};
		resultList = BaseAction.getObjectsFromRepresentation(entity, type);
		return resultList;
	}

	/**
	 * 获取参数为string/string的map
	 * 
	 * @param entity
	 * @return
	 * @throws Exception
	 * @author zh_ch
	 * @date 2015年4月15日 上午9:32:03
	 */
	public static Map<String, String> getMapFromRequest(Representation entity)
			throws Exception {
		Map<String, String> resultMap = null;
		TypeReference<Map<String, String>> type = new TypeReference<Map<String, String>>() {
		};
		resultMap = BaseAction.getObjectsFromRepresentation(entity, type);
		return resultMap;
	}

	/**
	 * 查询历史数据私有接口
	 */
	public static Map<String, Object> getHistoricalData(
			List<Map<String, String>> paraList) {
		Map<String, Object> resultMap = Maps.newHashMap();
		List<AplusDeviceMonitorData> monitorList = null;
		Map<String, List<AplusHistoryMetricData>> monitorData = null;
		AplusMonitorDataBo aplusMonitorDataBo = SpringUtil
				.getBean(AplusMonitorDataBo.class);
		if (AplusCollectionUtils.isBlank(paraList)) {
			return resultMap;
		}

		List<Map<AplusServiceParam, Object>> params = getParaMapMonitorData(paraList);

		if (isQueryLastPoint(params)) {
			monitorList = aplusMonitorDataBo.findLastMonitorData(params);
			for (AplusDeviceMonitorData entity : monitorList) {
				if(resultMap.containsKey(entity.getFqn())){
					AplusDeviceMonitorData obj = (AplusDeviceMonitorData)resultMap.get(entity.getFqn());
					Map<String, AplusMetricData> map = obj.getMetricDatas();
					map.putAll(entity.getMetricDatas());
					obj.setMetricDatas(map);
					resultMap.put(entity.getFqn(), obj);
				}
				else{
				resultMap.put(entity.getFqn(), entity);
				}
			}
			resultMap.put(AplusServiceParam.getClassName(),
					AplusDeviceMonitorData.class);
		} else {
			monitorData = aplusMonitorDataBo.findHistoryMonitorData(params);
			resultMap = transferMap(monitorData);
			resultMap.put(AplusServiceParam.getClassName(),
					AplusHistoryMetricData.class);
		}

		return resultMap;
	}

	/**
	 * 判断是否为查询最后一个点
	 * @param paraList
	 * @return
	 * @author zh_ch
	 * @date 2015年8月18日 上午10:06:57
	 */
	private static Boolean isQueryLastPoint(
			List<Map<AplusServiceParam, Object>> paraList) {
		Map<AplusServiceParam, Object> paraMap = paraList.get(0);
		Object startTime = paraMap.get(AplusServiceParam.START_TIME);
		Object pointNum = paraMap.get(AplusServiceParam.POINTS_NUM);
		if (Objects.equal(null, startTime) || Objects.equal(null, pointNum)) {
			return Boolean.TRUE;
		}

		return Boolean.FALSE;
	}

	/**
	 * 将Map<String, List<AplusHistoryMetricData>>转化为Map<String, Object>
	 * @param map
	 * @return
	 * @author zh_ch
	 * @date 2015年8月18日 上午10:07:39
	 */
	private static Map<String, Object> transferMap(
			Map<String, List<AplusHistoryMetricData>> map) {
		Map<String, Object> resultMap = Maps.newHashMap();
		Iterator<String> iter = map.keySet().iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			Object value = map.get(key);
			resultMap.put(key, value);
		}

		return resultMap;
	}

	/**
	 * 处理文件导入
	 * 
	 * @param readableRep
	 * @author zh_ch
	 * @date 2015年3月27日 下午3:24:36
	 */
	public static File fileImportHandler(Representation representation) {
		FileOutputStream out = null;
		File fileName = getTempFileName();
		try {
			out = new FileOutputStream(fileName);
			representation.write(out);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		} finally {
			StreamUtil.closeOutputStream(out);
		}
		return fileName;
	}

	/**
	 * 获取资源文件导入的临时文件名
	 * 
	 * @return
	 * @author zh_ch
	 * @date 2015年3月27日 下午4:28:06
	 */
	private static File getTempFileName() {
		String fileName = SpringUtil.getBean(NettyServerConf.class)
				.getTmpImportPath();
		if (StringUtils.isBlank(fileName)) {
			fileName = ActionConst.USER_DIR + File.separator
					+ "tempimport.xlsm";
		}

		return new File(fileName);
	}

	/**
	 * 保存资源/连接数据
	 * 
	 * @param paraMap
	 * @author zh_ch
	 * @date 2015年4月3日 下午3:20:40
	 */
	public static Map<String, Object> saveDeviceAndConn(
			List<AplusDeviceEntity> entityList) {
		AplusDeviceBo aplusDeviceBo = SpringUtil.getBean(AplusDeviceBo.class);
		List<String> fqnList = new ArrayList<String>();
		// 获取json里面的Fqn
		for (int i = 0; i < entityList.size(); i++) {
			AplusDeviceEntity ade = entityList.get(i);
			fqnList.add(ade.getFqn());
		}
		// 判断fqn数据库是否重复,如果重复 ，则不插入，重复则记录
		List<String> fqnFromDBList = aplusDeviceBo.findAllFqn();
		// 取差集
		List<String> fqnValueList = ActionUtil.diff(fqnList, fqnFromDBList);
		// 取交集
		List<String> fqnIntersectionfList = ActionUtil.intersect(fqnList,
				fqnFromDBList);
		List<AplusDeviceEntity> needSaveAplusDeviceEntity = new ArrayList<AplusDeviceEntity>();
		for (int i = 0; i < entityList.size(); i++) {
			AplusDeviceEntity bean = entityList.get(i);
			if (fqnValueList.contains(bean.getFqn())) {
				needSaveAplusDeviceEntity.add(bean);
			}
		}
		// 如果过滤出来的数据为0 则不保存
		if (needSaveAplusDeviceEntity.size() > 0) {
			// 实体入库,需要进行修改
			aplusDeviceBo.saveOrUpdateAplusDevices(needSaveAplusDeviceEntity);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(ActionConst.FQNINTERSECTION_LIST, fqnIntersectionfList);
		map.put(ActionConst.SAVEADE_BEAN, needSaveAplusDeviceEntity);
		return map;
	}

	/**
	 * 更新标准指标信息
	 * @param entityList
	 * @return
	 * @author zh_ch
	 * @date 2015年8月18日 上午10:08:33
	 */
	public static List<DeviceTypeId> updateStdMetric(
			List<AplusMetricEntity> entityList) {
		Set<DeviceTypeId> deviceTypeSet = Sets.newHashSet();
		AplusMetricBo aplusMetricBo = SpringUtil.getBean(AplusMetricBo.class);
		aplusMetricBo.saveOrUpdateAplusMetrics(entityList);

		for (AplusMetricEntity metricEntity : entityList) {
			DeviceTypeId deviceTypeId = new DeviceTypeId();
			deviceTypeId.setDeviceType(metricEntity.getDeviceType());
			deviceTypeId.setDeviceVersion(metricEntity.getDeviceVersion());
			deviceTypeSet.add(deviceTypeId);
		}

		return Lists.newArrayList(deviceTypeSet);
	}

	/**
	 * 保存指标信息，针对aplus_fqn_metric表
	 * 
	 * @param entityList
	 * @author zh_ch
	 * @date 2015年4月7日 上午10:49:21
	 */
	public static Map<String, Object> saveFqnMetric(
			List<AplusFqnMetricEntity> entityList) {
		List<FqnMetricUnionPk> list = new ArrayList<FqnMetricUnionPk>();
		for (AplusFqnMetricEntity entity : entityList) {
			FqnMetricUnionPk fmu = new FqnMetricUnionPk();
			fmu.setFqn(entity.getFqn());
			fmu.setMetricName(entity.getMetricName());
			list.add(fmu);
		}

		AplusFqnMetricBo aplusFqnMetricBo = SpringUtil
				.getBean(AplusFqnMetricBo.class);

		// 判断fqn数据库是否重复,如果重复 ，则不插入，重复则记录
		List<Object[]> fqnFromDBList = aplusFqnMetricBo
				.findALLFqnAndMetricName();
		// 取差集
		List<FqnMetricUnionPk> fqnValueList = ActionUtil.diffMetric(list,
				fqnFromDBList);
		// 取交集
		List<FqnMetricUnionPk> fqnIntersectionfList = ActionUtil
				.intersectMetric(list, fqnFromDBList);
		List<AplusFqnMetricEntity> needSaveAplusFqnMetricEntity = Lists
				.newArrayList();
		for (int i = 0; i < entityList.size(); i++) {
			AplusFqnMetricEntity bean = entityList.get(i);
			FqnMetricUnionPk pk = new FqnMetricUnionPk();
			pk.setFqn(bean.getFqn());
			pk.setMetricName(bean.getMetricName());
			if (fqnValueList.contains(pk)) {
				needSaveAplusFqnMetricEntity.add(bean);
			}
		}
		// 如果过滤出来的数据为0 则不保存
		if (needSaveAplusFqnMetricEntity.size() > 0) {
			// 实体入库,需要进行修改
			aplusFqnMetricBo
					.saveOrUpdateAplusFqnMetrics(needSaveAplusFqnMetricEntity);
		}
		Map<String, Object> map = Maps.newHashMap();

		map.put(ActionConst.FQNINTERSECTION_LIST, fqnIntersectionfList);
		map.put(ActionConst.SAVEAFM_BEAN, needSaveAplusFqnMetricEntity);
		map.put(ActionConst.FQNVALUE_LIST, fqnValueList);

		return map;
	}

	/**
	 * 分页查询资源
	 * 
	 * @param page
	 * @param pageCount
	 * @return
	 * @author zh_ch
	 * @date 2015年4月8日 下午3:48:30
	 */
	private static Page<AplusDeviceEntity> getDeviceWithoutCriteria(
			Integer page, Integer pageCount) {
		AplusDeviceBo aplusDeviceBo = SpringUtil.getBean(AplusDeviceBo.class);
		return aplusDeviceBo.findPagedAplusDevice(page, pageCount);
	}

	/**
	 * 更新资源
	 * 
	 * @param entity
	 * @author zh_ch
	 * @date 2015年4月8日 下午3:56:22
	 */
	public static void updateDevice(AplusDeviceEntity entity) {
		AplusDeviceBo aplusDeviceBo = SpringUtil.getBean(AplusDeviceBo.class);
		aplusDeviceBo.saveOrUpdateAplusDevice(entity);
	}

	/**
	 * 删除资源
	 * 
	 * @param entityList
	 * @author zh_ch
	 * @date 2015年4月8日 下午4:24:32
	 */
	public static void deleteDevice(List<String> fqnList) {
		AplusDeviceBo aplusDeviceBo = SpringUtil.getBean(AplusDeviceBo.class);
		aplusDeviceBo.removeAplusDeviceByFqn(fqnList);
	}

	/**
	 * 根据查询条件查询资源信息
	 * 
	 * @param paraMap
	 * @return
	 * @author zh_ch
	 * @date 2015年4月9日 下午1:32:38
	 */
	public static Map<String, Object> getDeviceWithCriteria(
			Map<String, String> paraMap) {
		Map<String, Integer> pageParaMap = getPagedQueryParaMap(paraMap);
		Integer page = pageParaMap.get(ActionConst.PAGE);
		Integer pageCount = pageParaMap.get(ActionConst.PAGE_COUNT);
		// 最终的查询结果map
		Map<String, Object> resultMap = Maps.newHashMap();
		// 带告警个数的资源列表
		List<AplusDeviceWithAlarmCnt> alarmCntList = Lists.newArrayList();
		Page<AplusDeviceEntity> pageList = null;
		List<AplusDeviceEntity> resultList = null;

		if (isGetDeviceWithoutCriteria(paraMap)) {
			pageList = getDeviceWithoutCriteria(page, pageCount);
			resultList = pageList.getItemList();
			for (AplusDeviceEntity entity : resultList) {
				AplusDeviceWithAlarmCnt alarmCnt = new AplusDeviceWithAlarmCnt();
				alarmCnt.transferFromEntity(entity);
				alarmCntList.add(alarmCnt);
			}
			resultMap.put(ActionConst.DEVICE_CNT, pageList.getTotalSize());
			resultMap.put(ActionConst.DEVICE_LIST, alarmCntList);
			return resultMap;
		}

		AplusDeviceBo aplusDeviceBo = SpringUtil.getBean(AplusDeviceBo.class);
		List<Criterion> criterions = getCriterionForDeviceQuery(paraMap);
		pageList = aplusDeviceBo.findPagedAplusDevice(page, pageCount,
				criterions);
		resultList = pageList.getItemList();

		if (isGetDeviceWithAlarmCnt(paraMap)) {
			alarmCntList = getDeviceWithAlarmCnt(resultList);
			resultMap.put(ActionConst.DEVICE_CNT, pageList.getTotalSize());
			resultMap.put(ActionConst.DEVICE_LIST, alarmCntList);
			return resultMap;
		}

		for (AplusDeviceEntity entity : resultList) {
			AplusDeviceWithAlarmCnt deviceWithAlarmCnt = new AplusDeviceWithAlarmCnt();
			deviceWithAlarmCnt.transferFromEntity(entity);
			alarmCntList.add(deviceWithAlarmCnt);
		}

		resultMap.put(ActionConst.DEVICE_CNT, pageList.getTotalSize());
		resultMap.put(ActionConst.DEVICE_LIST, alarmCntList);

		return resultMap;
	}

	/**
	 * 判断是否获取所有资源信息
	 * 
	 * @param paraMap
	 * @return
	 * @author zh_ch
	 * @date 2015年4月10日 上午9:10:00
	 */
	private static Boolean isGetDeviceWithoutCriteria(
			Map<String, String> paraMap) {
		String deviceType = paraMap.get(ActionConst.DEVICE_TYPE_HQL);
		String deviceVersion = paraMap.get(ActionConst.DEVICE_VERSION_HQL);
		String deviceName = paraMap.get(ActionConst.DEVICE_NAME_HQL);
		String location = paraMap.get(ActionConst.LOCATION_HQL);
		String attr = paraMap.get(ActionConst.ATTR_HQL);
		String createDate = paraMap.get(ActionConst.CREATE_DATE_HQL);
		String alarmCnt = paraMap.get(ActionConst.ALARMCNT);

		Boolean isGetAllDevice = StringUtils.isBlank(deviceType)
				&& StringUtils.isBlank(deviceVersion)
				&& StringUtils.isBlank(deviceName)
				&& StringUtils.isBlank(location) && StringUtils.isBlank(attr)
				&& StringUtils.isBlank(createDate)
				&& StringUtils.isBlank(alarmCnt);

		return isGetAllDevice;
	}

	/**
	 * 获取分页查询时候的页数和每页记录条数 如果传递的分页参数有问题则默认查询全部数据
	 * 
	 * @param paraMap
	 * @return
	 * @author zh_ch
	 * @date 2015年4月9日 下午1:33:21
	 */
	private static Map<String, Integer> getPagedQueryParaMap(
			Map<String, String> paraMap) {
		Map<String, Integer> resultMap = Maps.newHashMap();
		NumberFormat numberFormat = NumberFormat.getInstance();
		String pageString = paraMap.get(ActionConst.PAGE);
		String pageCountString = paraMap.get(ActionConst.PAGE_COUNT);
		Integer page = ActionConst.DEFAULT_PAGE;
		Integer pageCount = ActionConst.DEFAULT_PAGECOUNT;

		try {
			page = numberFormat.parse(pageString).intValue();
			pageCount = numberFormat.parse(pageCountString).intValue();
		} catch (Exception e) {
			logger.error(
					"Error page parameter format, page: {}, pageCount: {}",
					pageString, pageCountString);
		}

		resultMap.put(ActionConst.PAGE, page);
		resultMap.put(ActionConst.PAGE_COUNT, pageCount);
		return resultMap;
	}

	/**
	 * 获取资源查询的sql和参数
	 * 
	 * @param paraMap
	 * @return
	 * @author zh_ch
	 * @date 2015年4月10日 上午9:10:33
	 */
	public static List<Criterion> getCriterionForDeviceQuery(
			Map<String, String> paraMap) {
		List<Criterion> criterions = Lists.newArrayList();
		Iterator<String> iter = paraMap.keySet().iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			String value = paraMap.get(key);
			if (StringUtils.equals(key, ActionConst.PAGE)
					|| StringUtils.equals(key, ActionConst.PAGE_COUNT)
					|| StringUtils.equals(key, ActionConst.ALARMCNT)
					|| StringUtils.isBlank(value)) {
				continue;
			}

			if (StringUtils.equals(key, ActionConst.ATTR_HQL)) {
				criterions.add(Restrictions.sqlRestriction(ActionConst.ATTR_HQL
						+ "::text like '%" + value + "%'"));
			} else if (StringUtils.equals(key, ActionConst.CREATE_DATE_HQL)) {
				criterions.add(Restrictions.eq(key, Date.valueOf(value)));
			} else {
				criterions.add(Restrictions.eq(key, value));
			}
		}

		return criterions;
	}

	/**
	 * 根据fqn在policy侧获取告警数目
	 * 
	 * @param entityList
	 * @return
	 * @author zh_ch
	 * @date 2015年4月13日 下午1:25:48
	 */
	private static List<AplusDeviceWithAlarmCnt> getDeviceWithAlarmCnt(
			List<AplusDeviceEntity> entityList) {
		NettyServerConf conf = SpringUtil.getBean(NettyServerConf.class);
		String alarmCntApi = ActionConst.API_HTTP + conf.getAlarmAddress()
				+ ActionConst.API_DEVICE_ALARMCNT;
		List<AplusDeviceWithAlarmCnt> resultList = Lists.newArrayList();
		List<String> paraList = Lists.newArrayList();
		for (AplusDeviceEntity entity : entityList) {
			paraList.add(entity.getFqn());
		}

		RestClient restClient = new RestClient(Protocol.HTTP);
		JsonRepresentation representation = new JsonRepresentation(
				JSONUtil.getJsonString(paraList));
		Response response = restClient.post(new Reference(alarmCntApi),
				representation);
		Map<String, Integer> resultMap = JSONUtil.getComplexObject(
				response.getEntityAsText(),
				new TypeReference<Map<String, Integer>>() {
				});
		for (AplusDeviceEntity entity : entityList) {
			AplusDeviceWithAlarmCnt alarmDevice = new AplusDeviceWithAlarmCnt();
			alarmDevice.transferFromEntity(entity);
			if (!Objects.equal(null, resultMap)) {
				alarmDevice.setAlarmCount(resultMap.get(entity.getFqn()));
			}
			resultList.add(alarmDevice);
		}

		return resultList;
	}

	/**
	 * 判断获取资源信息时是否携带告警数目
	 * 
	 * @param paraMap
	 * @return
	 * @author zh_ch
	 * @date 2015年4月13日 下午1:26:23
	 */
	private static Boolean isGetDeviceWithAlarmCnt(Map<String, String> paraMap) {
		String alarmCnt = paraMap.get(ActionConst.ALARMCNT);
		if (StringUtils.isBlank(alarmCnt)
				|| Objects.equal(Boolean.FALSE, Boolean.parseBoolean(alarmCnt))) {
			return Boolean.FALSE;
		}

		return Boolean.TRUE;
	}

	/**
	 * 将URL传递过来的空字符处理掉
	 * @param queryParaMap
	 * @return
	 * @author zh_ch
	 * @date 2015年8月18日 上午10:13:51
	 */
	public static Map<String, String> cleanMap(Map<String, String> queryParaMap) {
		Map<String, String> resultMap = Maps.newHashMap();
		Iterator<String> iter = queryParaMap.keySet().iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			String value = queryParaMap.get(key);
			if (!Objects.equal(value, null)) {
				value = value.trim();
				resultMap.put(key, value);
			}
		}

		return resultMap;
	}

	/**
	 * 将传递给rest接口的参数转化为查询历史数据需要的参数
	 * @param paraList
	 * @return
	 * @author zh_ch
	 * @date 2015年8月18日 上午10:23:43
	 */
	private static List<Map<AplusServiceParam, Object>> getParaMapMonitorData(
			List<Map<String, String>> paraList) {
		List<Map<AplusServiceParam, Object>> resultList = Lists.newArrayList();
		NumberFormat numberFormat = NumberFormat.getInstance();
		for (Map<String, String> map : paraList) {
			Map<AplusServiceParam, Object> resultMap = Maps.newHashMap();
			// 设置fqn
			String fqn = map.get(AplusServiceParam.getFqn());
			if (StringUtils.isBlank(fqn)) {
				continue;
			}

			resultMap.put(AplusServiceParam.FQN, fqn);

			// 设置指标列表
			String metricString = map.get(AplusServiceParam.getMetricList());
			if (!StringUtils.isBlank(metricString)) {
				List<String> metrics = JSONUtil.getObjectList(metricString,
						String.class);
				resultMap.put(AplusServiceParam.METRIC_LIST, metrics);
			}

			// 设置时间属性
			String startTimeString = map.get(AplusServiceParam.getStartTime());
			String endTimeString = map.get(AplusServiceParam.getEndTime());
			String intervalString = map.get(AplusServiceParam.getInterval());
			Long interval = ActionConst.DEFAULT_INTERVAL;
			Long startTime = null;
			Long endTime = null;
			try {
				startTime = numberFormat.parse(startTimeString).longValue();
				endTime = numberFormat.parse(endTimeString).longValue();
				resultMap.put(AplusServiceParam.START_TIME, startTime);
				resultMap.put(AplusServiceParam.END_TIME, endTime);
			} catch (Exception e) {
				try {
					interval = numberFormat.parse(intervalString).longValue();
					endTime = System.currentTimeMillis();
					startTime = endTime - interval;
					resultMap.put(AplusServiceParam.START_TIME, startTime);
					resultMap.put(AplusServiceParam.END_TIME, endTime);
				} catch (Exception ex) {
					logger.error(
							"Error interval parameter format: startTime + endTime: {}, interval: {}",
							startTimeString + endTimeString, intervalString);
				}
			}

			// 设置点数
			String pointNumString = map.get(AplusServiceParam.getPointNum());
			Integer pointNum = null;
			try {
				pointNum = numberFormat.parse(pointNumString).intValue();
				resultMap.put(AplusServiceParam.POINTS_NUM, pointNum);
			} catch (Exception e) {
				logger.error("Error pointNum format, pointNum: {}",
						pointNumString);
			}

			resultList.add(resultMap);
		}

		return resultList;
	}

	/**
	 * rest发布订阅消息方法
	 * 
	 * @param message
	 * @author zh_ch
	 * @date 2015年4月20日 上午9:48:20
	 */
	public static void publishMessageToServer(ZMQMessage message) {
		Publisher pub = PubSubFactory.newPublisher(ZMQConst.PROC_DBUSREST);
		ZMQUtil.publish(pub, message);
		logger.debug("DataBus Rest发布一条消息：{}", message);
	}

	/**
	 * 根据查询条件获取metric信息
	 * 
	 * @param queryParaMap
	 * @return
	 * @author zh_ch
	 * @date 2015年4月20日 下午2:47:58
	 */
	public static Map<String, Object> getMetricWithCriterion(
			Map<String, String> queryParaMap) {
		Map<String, Object> resultMap = Maps.newHashMap();
		List<AplusMetricEntity> metricList = null;
		String fqn = queryParaMap.get(ActionConst.DEVICE_FQN_HQL);
		String deviceType = queryParaMap.get(ActionConst.DEVICE_TYPE_HQL);
		String deviceVersion = queryParaMap.get(ActionConst.DEVICE_VERSION_HQL);

		AplusFqnMetricBo aplusFqnMetricBo = SpringUtil
				.getBean(AplusFqnMetricBo.class);
		AplusMetricBo aplusMetricBo = SpringUtil.getBean(AplusMetricBo.class);

		if (StringUtils.isNotBlank(fqn)) {
			metricList = aplusFqnMetricBo.findAplusMetricByFqn(fqn);
			if (metricList == null || metricList.isEmpty()) {
				metricList = aplusMetricBo.findAplusMetricByFqn(fqn);
			}
		} else if (StringUtils.isBlank(deviceType)) {
			logger.error("Error parameters format, fqn: {}, deviceType: {}",
					fqn, deviceType);
			throw new RuntimeException(
					"Error parameters format, fqn: empty, deviceType: empty");
		} else {
			deviceVersion = StringUtils.isBlank(deviceVersion) ? ModelConst.DEFAULT_VERSION
					: deviceVersion;
			metricList = aplusMetricBo.findAplusMetrics(deviceType,
					deviceVersion);
		}

		resultMap.put(ActionConst.METRIC_LIST, metricList);
		return resultMap;
	}

	/**
	 * 更新资源列表
	 * @param deviceList
	 * @return
	 * @author zh_ch
	 * @date 2015年8月18日 上午10:09:41
	 */
	public static List<AplusDeviceEntity> updateAplusDevice(
			List<AplusDeviceEntity> deviceList) {
		List<AplusDeviceEntity> pubList = Lists.newArrayList();
		AplusDeviceBo aplusDeviceBo = SpringUtil.getBean(AplusDeviceBo.class);
		for (AplusDeviceEntity entity : deviceList) {
			String fqn = entity.getFqn();
			AplusDeviceEntity aplusDevice = aplusDeviceBo
					.findAplusDeviceByFqn(fqn);
			if (Objects.equal(null, aplusDevice)) {
				aplusDeviceBo.saveOrUpdateAplusDevice(entity);
				continue;
			}

			if (!StringUtils.equals(entity.getDeviceType(),
					aplusDevice.getDeviceType())
					|| !StringUtils.equals(entity.getDeviceVersion(),
							aplusDevice.getDeviceVersion())
					|| !aplusDevice.getIsSubSystem().equals(
							entity.getIsSubSystem())) {
				pubList.add(entity);
			}

			aplusDeviceBo.saveOrUpdateAplusDevice(entity);
		}
		return pubList;
	}

	/**
	 * 从资源中解析connection信息
	 * @param queryParaMap
	 * @return
	 * @author zh_ch
	 * @date 2015年8月18日 上午10:10:01
	 */
	public static List<AplusConnection> findAplusConnection(
			Map<String, String> queryParaMap) {
		List<AplusConnection> aplusConnList = Lists.newArrayList();
		String fqn = queryParaMap.get(ActionConst.DEVICE_FQN_HQL);
		// 如果为null、""、非true字符则解析为fasle
		Boolean active = Boolean.valueOf(queryParaMap
				.get(ActionConst.CONN_ACTIVE_HQL));
		if (StringUtils.isBlank(fqn)) {
			return aplusConnList;
		}

		AplusDeviceBo aplusDeviceBo = SpringUtil.getBean(AplusDeviceBo.class);

		AplusDeviceEntity deviceEntity = aplusDeviceBo
				.findAplusDeviceByFqn(fqn);

		if (Objects.equal(null, deviceEntity)) {
			return aplusConnList;
		}

		if (Objects.equal(Boolean.FALSE, active)) {
			return deviceEntity.findAplusConnection();
		} else {
			AplusConnection aplusConn = deviceEntity
					.findActiveAplusConnection();
			aplusConnList.add(aplusConn);
		}

		return aplusConnList;
	}

	/**
	 * 更新connection信息
	 * @param connMap
	 * @return
	 * @author zh_ch
	 * @date 2015年8月18日 上午10:10:23
	 */
	public static List<String> updateAplusConnection(Map<String, String> connMap) {
		List<String> fqnList = Lists.newArrayList();
		AplusDeviceBo aplusDeviceBo = SpringUtil.getBean(AplusDeviceBo.class);
		Iterator<String> iterator = connMap.keySet().iterator();
		while (iterator.hasNext()) {
			String fqn = iterator.next();
			String value = connMap.get(fqn);
			aplusDeviceBo.updateAplusConnection(fqn, value);
			fqnList.add(fqn);
		}

		return fqnList;
	}

	/**
	 * 取差集集合
	 * 
	 * @param ls
	 * @param ls2
	 * @return
	 */
	public static List<String> diff(List<String> ls, List<String> ls2) {
		List<String> result = new ArrayList<String>();
		result.addAll(ls);
		result.removeAll(ls2);
		return result;
	}

	/**
	 * 取差集集合
	 * 
	 * @param ls
	 * @param ls2
	 * @return
	 */
	public static List<FqnMetricUnionPk> diffMetric(List<FqnMetricUnionPk> ls,
			List<Object[]> ls2) {
		List<FqnMetricUnionPk> dbList = new ArrayList<FqnMetricUnionPk>();

		List<FqnMetricUnionPk> result = new ArrayList<FqnMetricUnionPk>();
		for (Object[] obj : ls2) {
			FqnMetricUnionPk pk = new FqnMetricUnionPk();
			pk.setFqn(String.valueOf(obj[0]));
			pk.setMetricName(String.valueOf(obj[1]));

			dbList.add(pk);
		}

		for (int i = 0; i < ls.size(); i++) {
			FqnMetricUnionPk pk = ls.get(i);
			if (dbList.contains(pk)) {
				continue;
			}
			result.add(pk);
		}

		return result;
	}

	/**
	 * 取交接集合
	 * 
	 * @param ls
	 * @param ls2
	 * @return
	 */
	public static List<String> intersect(List<String> ls, List<String> ls2) {
		List<String> result = new ArrayList<String>();
		result.addAll(ls);
		result.retainAll(ls2);
		return result;
	}

	public static List<FqnMetricUnionPk> intersectMetric(
			List<FqnMetricUnionPk> ls, List<Object[]> ls2) {
		List<FqnMetricUnionPk> result = new ArrayList<FqnMetricUnionPk>();
		for (Object[] obj : ls2) {
			FqnMetricUnionPk pk = new FqnMetricUnionPk();
			pk.setFqn(String.valueOf(obj[0]));
			pk.setMetricName(String.valueOf(obj[1]));
			if (ls.contains(pk)) {
				result.add(pk);
			}

		}

		return result;
	}

	/**
	 * 消息返回
	 * 
	 * @param list
	 * @return
	 */
	public static Message generateMessage(List<?> list) {
		StringBuilder message = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			Object obj = list.get(i);
			if (i == 0) {
				message.append(obj.toString());
			} else {
				message.append("," + obj.toString());
			}
		}
		message.append(" 已经在数据库存在");
		Message messageInfo = new Message();
		messageInfo.setMessageType(ActionConst.MESSAGE_TYPE);
		messageInfo.setMessageDetail(message.toString());
		return messageInfo;
	}
}

package com.neusoft.aplus.cmdb.action;

import java.util.List;

import org.restlet.representation.Representation;

import com.neusoft.aplus.cmdb.exception.CmdbException;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.util.SpringUtil;
import com.neusoft.aplus.service.core.service.bo.AplusDeviceBo;

/**
 * 查询所有位置信息
 * @author zh_ch
 * @date 2015年4月8日 上午11:30:44
 */
public class LocationsAction extends BaseAction {

	private AplusDeviceBo aplusDeviceBo;

	@Override
	public void doInit() {
		aplusDeviceBo = SpringUtil.getBean(AplusDeviceBo.class);
	}

	@Override
	public void acceptRepresentation(Representation entity) {

	}

	/**
	 * 查询所有位置信息
	 */
	@Override
	public Representation represent() {
		List<String> resultList = null;
		try {
			resultList = aplusDeviceBo.findAllDistinctLocation();
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}

		return createObjectRepresentation(resultList);
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub

	}

	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub

	}
}

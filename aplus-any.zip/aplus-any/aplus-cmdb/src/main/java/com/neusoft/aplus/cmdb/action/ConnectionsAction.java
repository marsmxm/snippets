package com.neusoft.aplus.cmdb.action;

import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;

import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.cmdb.exception.CmdbException;
import com.neusoft.aplus.cmdb.util.ActionUtil;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusMsgAction;

/**
 * connection对应的CRDU操作
 * @author zh_ch
 * @date 2015年5月21日 下午1:52:37
 */
public class ConnectionsAction extends BaseAction {

	//传入的参数，包括fqn和active两个属性，分别表示资源标识和连接是否可用
	private Map<String, String> queryParaMap = null;

	@Override
	public void doInit() {
		queryParaMap = ActionUtil.cleanMap(getRequestParameters());
	}

	@Override
	public void acceptRepresentation(Representation entity) {

	}

	/**
	 * 查询connection
	 */
	@Override
	public Representation represent() {
		List<AplusConnection> aplusConnList = null;
		try {
			aplusConnList = ActionUtil.findAplusConnection(queryParaMap);
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}
		return createObjectRepresentation(aplusConnList);
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub

	}

	/**
	 * 更新connection，更新connection发送ZMQ事件，通知服务端根据改变的connection调度任务
	 */
	@Override
	public void storeRepresentation(Representation entity) {
		Map<String, String> connMap = null;
		try {
			connMap = getObjectsFromRepresentation(entity,
					new TypeReference<Map<String, String>>() {
					});
			List<String> fqnList = ActionUtil.updateAplusConnection(connMap);
			ZMQMessage zmqMessage = new ZMQMessage(
					ZMQConst.TOPIC_TO_DBUSSERVER,
					JSONUtil.getJsonString(fqnList), AplusMsgAction.UPDATE_CONN);
			ActionUtil.publishMessageToServer(zmqMessage);
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}

		sendSuccess();
	}
}

package com.neusoft.aplus.cmdb.action;

import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;

import com.neusoft.aplus.cmdb.exception.CmdbException;
import com.neusoft.aplus.cmdb.util.ActionUtil;
import com.neusoft.aplus.common.base.BaseAction;

/**
 * 查询历史数据
 * 接口传递的参数格式请参考wiki
 * @author zh_ch
 * @date 2015年3月17日 下午5:22:27
 */
public class HistoricalDatasAction extends BaseAction {

	@Override
	public void acceptRepresentation(Representation entity) {
		List<Map<String, String>> paraList = null;
		Map<String, Object> resultMap = null;
		try {
			paraList = ActionUtil.getListFromRequest(entity);
			resultMap = ActionUtil.getHistoricalData(paraList);
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}
		sendResponse(resultMap);
	}

	@Override
	public Representation represent() {
		return null;
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub

	}

	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub

	}
}

package com.neusoft.aplus.cmdb.action;

import java.util.List;
import java.util.Map;

import org.restlet.representation.Representation;

import com.google.common.collect.Lists;
import com.neusoft.aplus.cmdb.exception.CmdbException;
import com.neusoft.aplus.cmdb.model.ActionConst;
import com.neusoft.aplus.cmdb.model.Message;
import com.neusoft.aplus.cmdb.util.ActionUtil;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;
import com.neusoft.aplus.model.bizentity.AplusMsgAction;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;

/**
 * 提交资源/连接信息到DB
 * 此接口接收的是资源列表的json格式
 * @author zh_ch
 * @date 2015年4月3日 下午12:56:59
 */
public class DeviceConnectionsAction extends BaseAction {

	/**
	 * 添加device，connection信息包含在device信息中
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void acceptRepresentation(Representation entity) {
		List<AplusDeviceEntity> entityList = null;
		try {
			entityList = getObjectsFromRepresentation(entity,
					AplusDeviceEntity.class);
			Map<String, Object> map = ActionUtil.saveDeviceAndConn(entityList);
			List<String> fqnIntersectionfList = (List<String>) map
					.get(ActionConst.FQNINTERSECTION_LIST);
			List<AplusDeviceEntity> needSaveAplusDeviceEntity = (List<AplusDeviceEntity>) map
					.get(ActionConst.SAVEADE_BEAN);
			// 过滤fqn
			List<String> fqnList = Lists.newArrayList();
			for (int i = 0; i < needSaveAplusDeviceEntity.size(); i++) {
				AplusDeviceEntity ade = needSaveAplusDeviceEntity.get(i);
				if (ade != null) {
					fqnList.add(ade.getFqn());
				}

			}

			if (needSaveAplusDeviceEntity.size() > 0) {
				// 导入资源后通知server端开始调度任务，发送的事件类型为ADD_DEVICECON
				ZMQMessage message = new ZMQMessage(
						ZMQConst.TOPIC_TO_DBUSSERVER,
						JSONUtil.getJsonString(fqnList),
						AplusMsgAction.ADD_DEVICECON);
				ActionUtil.publishMessageToServer(message);
			}
			if (fqnIntersectionfList.size() > 0) {
				Message messageInfo = ActionUtil
						.generateMessage(fqnIntersectionfList);
				sendResponse(messageInfo);
			} else {
				sendSuccess();
			}
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}
	}

	@Override
	public Representation represent() {
		return null;
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub
	}

	/**
	 * 更新device信息
	 */
	@Override
	public void storeRepresentation(Representation entity) {
		List<AplusDeviceEntity> deviceList = null;
		List<AplusDeviceEntity> pubList = null;
		try {
			deviceList = getObjectsFromRepresentation(entity,
					AplusDeviceEntity.class);
			pubList = ActionUtil.updateAplusDevice(deviceList);
			ZMQMessage message = new ZMQMessage(ZMQConst.TOPIC_TO_DBUSSERVER,
					JSONUtil.getJsonString(pubList),
					AplusMsgAction.UPDATE_DEVICE);
			ActionUtil.publishMessageToServer(message);
		} catch (Exception ex) {
			CmdbException.throwException(CmdbException.BOTTOMEX, ex);
		}

		sendSuccess();
	}
}

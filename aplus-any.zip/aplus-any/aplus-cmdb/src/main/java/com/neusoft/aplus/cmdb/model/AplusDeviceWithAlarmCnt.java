package com.neusoft.aplus.cmdb.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.Map;

import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.model.ModelConst;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;

/**
 * 带有告警数目的资源实体
 * @author zh_ch
 * @date 2015年4月22日 下午3:48:22
 */
public class AplusDeviceWithAlarmCnt implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String fqn;// 用来表示某个资源的唯一标识，不能由数据库自动生成，不能为空

	private String name;// 资源的名称，不能为空

	private String ip;// 资源的IP地址，可以为空

	private String category;// 资源的分类，可以为空

	private String deviceType;// 资源类型，不能为空

	// 版本号，一般在资源为软件的场景下涉及，不能为空，默认值为 v1.0
	private String deviceVersion = ModelConst.DEFAULT_VERSION;

	private Map<String, String> attr;// 属性，json格式存入数据库

	private Date createDate;

	private String location;

	private Integer alarmCount;

	public String getFqn() {
		return fqn;
	}

	public void setFqn(String fqn) {
		this.fqn = fqn;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getDeviceVersion() {
		return deviceVersion;
	}

	public void setDeviceVersion(String deviceVersion) {
		this.deviceVersion = deviceVersion;
	}

	public Map<String, String> getAttr() {
		return attr;
	}

	public void setAttr(Map<String, String> attr) {
		this.attr = attr;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Integer getAlarmCount() {
		return alarmCount;
	}

	public void setAlarmCount(Integer alarmCount) {
		this.alarmCount = alarmCount;
	}

	public void transferFromEntity(AplusDeviceEntity entity) {
		this.fqn = entity.getFqn();
		this.name = entity.getName();
		this.ip = entity.getIp();
		this.category = entity.getCategory();
		this.deviceType = entity.getDeviceType();
		this.deviceVersion = entity.getDeviceVersion();
		this.createDate = entity.getCreateDate();
		this.location = entity.getLocation();
		this.attr = JSONUtil.getComplexObject(entity.getAttr(),
				new TypeReference<Map<String, String>>() {
				});
	}

}

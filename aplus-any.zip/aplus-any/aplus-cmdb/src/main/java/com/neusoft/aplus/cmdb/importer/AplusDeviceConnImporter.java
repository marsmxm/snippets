package com.neusoft.aplus.cmdb.importer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.neusoft.aplus.cmdb.model.ActionConst;
import com.neusoft.aplus.cmdb.util.ActionUtil;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;
import com.neusoft.aplus.service.core.service.bo.AplusDeviceBo;

/**
 * 资源导入
 * 
 * 导入设备，连接信息，设备类型等数据
 * 
 * @author Yao Bo
 * @date 2015年3月4日 下午1:53:40
 */
@Component
public final class AplusDeviceConnImporter {
	private static Logger logger = Logger
			.getLogger(AplusDeviceConnImporter.class);
	private List<AplusDeviceEntity> device = null;

	@Autowired
	private AplusDeviceBo aplusDeviceBo;

	public Map<String, Object> importExcel(String filename) throws Exception {
		boolean is2003 = false;
		if (VersionExcel.isExcel2007(filename)) {
			logger.info("Parsing 2003Excel file: " + filename);
			is2003 = true;
		} else {
			logger.info("Parsing 2007+Excel file: " + filename);
			is2003 = false;
		}

		return parseExcelForDevice(filename, is2003);
	}

	/**
	 * 
	 * @param filename
	 * @param is2003
	 * @return
	 */
	private Map<String, Object> parseExcelForDevice(String filename,
			boolean is2003) {
		File f = new File(filename);
		List<String> fqnList = new ArrayList<String>();
		Workbook workbook = null;

		AplusDeviceEntity ade = null;
		try {
			InputStream stream = new FileInputStream(f);
			if (is2003) {
				workbook = new HSSFWorkbook(stream);
			} else {
				workbook = new XSSFWorkbook(stream);
			}
			Sheet sheet = workbook.getSheetAt(2);
			if (sheet.getPhysicalNumberOfRows() <= 1) {
				logger.error("Empty sheet: " + workbook + "->" + sheet);

			}

			device = new ArrayList<AplusDeviceEntity>();
			for (Row row : sheet) {
				if (row.getRowNum() > 0) {
					ade = new AplusDeviceEntity();
					fqnList.add(getStringCellValue(row.getCell(0)));
					ade.setFqn(getStringCellValue(row.getCell(0)));// Fqn
					ade.setName(getStringCellValue(row.getCell(1)));
					ade.setIp(getStringCellValue(row.getCell(2)));
					ade.setCategory(getStringCellValue(row.getCell(3)));
					ade.setDeviceType(getStringCellValue(row.getCell(4)));
					ade.setDeviceVersion(getStringCellValue(row.getCell(5)));
					ade.setLocation(getStringCellValue(row.getCell(6)));
					ade.setAttr(getStringCellValue(row.getCell(7)));
					ade.setCreateDate(new Date(System.currentTimeMillis()));
					ade.setIsSubSystem(getStringCellValue(row.getCell(10))
							.equalsIgnoreCase("true") ? true : false);
					ade.setConnInfo(getStringCellValue(row.getCell(9)));
					device.add(ade);
				}
			}
		} catch (Exception e) {

		} finally {
			if (workbook != null) {
				try {
					workbook.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		// 判断fqn数据库是否重复,如果重复 ，则不插入，重复则记录
		List<String> fqnFromDBList = aplusDeviceBo.findAllFqn();
		// 取差集
		List<String> fqnValueList = ActionUtil.diff(fqnList, fqnFromDBList);
		// 取交集
		List<String> fqnIntersectionfList = ActionUtil.intersect(fqnList,
				fqnFromDBList);

		List<AplusDeviceEntity> needSaveAplusDeviceEntity = new ArrayList<AplusDeviceEntity>();

		for (int i = 0; i < device.size(); i++) {
			AplusDeviceEntity bean = device.get(i);
			if (fqnValueList.contains(bean.getFqn())) {
				needSaveAplusDeviceEntity.add(bean);
			}

		}

		// 如果过滤出来的数据为0 则不保存
		if (needSaveAplusDeviceEntity.size() > 0) {
			// 实体入库,需要进行修改
			aplusDeviceBo.saveOrUpdateAplusDevices(needSaveAplusDeviceEntity);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(ActionConst.FQNINTERSECTION_LIST, fqnIntersectionfList);
		map.put(ActionConst.SAVEADE_BEAN,
				needSaveAplusDeviceEntity);

		return map;
	}

	/**
	 * 根据类型获取cell的值
	 */
	public String getStringCellValue(Cell cell) {
		String cellValue = null;

		if (cell == null) {
			return "";
		} else {
			switch (cell.getCellType()) {
			case HSSFCell.CELL_TYPE_NUMERIC: // 数字
				cellValue = cell.getNumericCellValue() + "";
				break;

			case HSSFCell.CELL_TYPE_STRING: // 字符串
				cellValue = cell.getStringCellValue();
				break;

			case HSSFCell.CELL_TYPE_BOOLEAN: // Boolean
				cellValue = cell.getBooleanCellValue() + "";
				break;

			case HSSFCell.CELL_TYPE_FORMULA: // 公式
				cellValue = cell.getCellFormula() + "";
				break;

			case HSSFCell.CELL_TYPE_BLANK: // 空值
				cellValue = " ";
				break;

			case HSSFCell.CELL_TYPE_ERROR: // 故障
				cellValue = "非法字符";
				break;

			default:
				cellValue = "";
				break;
			}
		}

		return cellValue;
	}

	/**
	 * 判定excel的版本
	 */
	static class VersionExcel {
		public static boolean isExcel2003(String filePath) {
			return filePath.matches("^.+\\.(?i)(xlsm)$");
		}

		public static boolean isExcel2007(String filePath) {
			return filePath.matches("^.+\\.(?i)(xlsxm)$");
		}
	}
}

package com.neusoft.aplus.cmdb.test;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.junit.Test;
import org.restlet.Response;
import org.restlet.data.MediaType;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.representation.FileRepresentation;

import com.alibaba.fastjson.TypeReference;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neusoft.aplus.cmdb.model.ActionConst;
import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.service.core.service.AplusServiceParam;

/**
 * @author zh_ch
 * @date 2015骞�3鏈�27鏃� 涓婂崍11:42:08
 */
public class PutActionTest {
	private static RestClient client = new RestClient(Protocol.HTTP);

	@Test
	public void putFileTest() {
		FileRepresentation entity = new FileRepresentation("d:\\资产信息导入模板-测试服务器-1.xlsm",
				MediaType.APPLICATION_MSOFFICE_XLSX);
		Reference uri = new Reference(
				"http://localhost:8182/api/aplus/databus/deviceconnfile");
		Response res = client.post(uri, entity);
		System.out.println("code is : " + res.getStatus().getCode());
	}
	
	

	
	
	@Test
	public void criteriaTest() {
		Map<String, String> paraMap = Maps.newHashMap();
		paraMap.put(ActionConst.PAGE, "1");
		paraMap.put(ActionConst.PAGE_COUNT, "10");
		paraMap.put(ActionConst.CATEGORY_HQL, "http");
		paraMap.put(ActionConst.DEVICE_TYPE_HQL, "pcc");
		paraMap.put(ActionConst.LOCATION_HQL, "浜屽彿妤煎洓灞傛満鎴�8");
		paraMap.put(ActionConst.DEVICE_NAME_HQL, "name_3");
		paraMap.put(ActionConst.ATTR_HQL, "ip");
		paraMap.put(ActionConst.CREATE_DATE_HQL, "2015-04-10");
		paraMap.put(ActionConst.ALARMCNT, Boolean.FALSE.toString());
		//List<Criterion> list = ActionUtil.getCriterionForDeviceQuery(paraMap);
		//System.out.println(list);
		System.out.println(JSONUtil.getJsonString(paraMap));
	}
	
	@Test
	public void paraTest() {

		List<Map<String, Object>> list = Lists.newArrayList();
		Map<String, Object> map = Maps.newHashMap();
		List<String> metrics = Lists.newArrayList();
		metrics.add("metric1");
		metrics.add("metric2");
		map.put(AplusServiceParam.getFqn(), "fqn1");
		map.put(AplusServiceParam.getMetricList(), metrics);
		map.put(AplusServiceParam.getLocale(), Locale.US.toString());
		map.put(AplusServiceParam.getInterval(), "360000000");
		list.add(map);
		
		Map<String, Object> map1 = Maps.newHashMap();
		List<String> metrics1 = Lists.newArrayList();
		metrics1.add("metric1");
		metrics1.add("metric2");
		map1.put(AplusServiceParam.getFqn(), "fqn2");
		map1.put(AplusServiceParam.getMetricList(), metrics1);
		map1.put(AplusServiceParam.getLocale(), Locale.US.toString());
		map1.put(AplusServiceParam.getInterval(), "360000000");
		list.add(map1);
		String text = JSONUtil.getJsonString(list);
		
		System.out.println("text == " + text);
		
		List<Map<String, String>> result = JSONUtil.getComplexObject(text, new TypeReference<List<Map<String, String>>>(){});
		String str = result.get(0).get("FQN");
		System.out.println(str);
	}
}

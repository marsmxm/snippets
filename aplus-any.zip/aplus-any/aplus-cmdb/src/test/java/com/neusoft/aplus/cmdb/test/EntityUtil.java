package com.neusoft.aplus.cmdb.test;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.bizentity.AplusMetricData;
import com.neusoft.aplus.model.bizentity.AplusMetricValueType;
import com.neusoft.aplus.model.dbentity.table.AplusFqnMetricEntity;

/**
 * @author zh_ch
 * @date 2015年4月17日 下午4:16:01
 */
public class EntityUtil {
	public static List<AplusDeviceMonitorData> getMonitorData() {
		List<AplusDeviceMonitorData> monitorList = Lists.newArrayList();
		Long time = System.currentTimeMillis();
		//第一个
		AplusDeviceMonitorData monitor1 = new AplusDeviceMonitorData();
		Map<String, AplusMetricData> map1 = Maps.newHashMap();
		AplusMetricData metricData1 = new AplusMetricData();
		metricData1.setName("metric_1");
		metricData1.setValue("1100");
		metricData1.setRecordTime(time);
		
		AplusMetricData metricData2 = new AplusMetricData();
		metricData2.setName("metric_2");
		metricData2.setValue("1200");
		metricData2.setRecordTime(time);
		
		map1.put("metric_1", metricData1);
		map1.put("metric_2", metricData2);
		
		monitor1.setFqn("fqn1");
		monitor1.setMetricDatas(map1);
		
		//第二个
		AplusDeviceMonitorData monitor2 = new AplusDeviceMonitorData();
		Map<String, AplusMetricData> map2 = Maps.newHashMap();
		AplusMetricData metricData3 = new AplusMetricData();
		metricData3.setName("metric_3");
		metricData3.setValue("1300");
		metricData3.setRecordTime(time);
		
		AplusMetricData metricData4 = new AplusMetricData();
		metricData4.setName("metric_4");
		metricData4.setValue("1400");
		metricData4.setRecordTime(time);
		
		map2.put("metric_3", metricData3);
		map2.put("metric_4", metricData4);
		
		monitor2.setFqn("fqn2");
		monitor2.setMetricDatas(map2);
		
		//加入到list
		monitorList.add(monitor1);
		monitorList.add(monitor2);
		return monitorList;
	}
	
	@Test
	public void testMonitor() {
		String text = JSONUtil.getJsonString(getMonitorData());
		System.out.println(text);
	}
	
	@Test
	public void testFqnMetric() {
		List<AplusFqnMetricEntity> metricList = Lists.newArrayList();
		AplusFqnMetricEntity entity1 = new AplusFqnMetricEntity();
		entity1.setFqn("fqn_opc_test");
		entity1.setDeviceType("OPCTester");
		entity1.setMetricName("Random.String");
		entity1.setMetricCode("Random.String");
		entity1.setMetricUnit("");
		entity1.setMetricInterval(30);
		entity1.setMetricTimeUnit(TimeUnit.SECONDS.toString());
		entity1.setMetricActive(Boolean.TRUE);
		entity1.setMetricDefkey("random.string_i18n_key");
		entity1.setMetricType(AplusMetricValueType.TYPE_STRING);
		
		AplusFqnMetricEntity entity2 = new AplusFqnMetricEntity();
		entity2.setFqn("fqn_opc_test");
		entity2.setDeviceType("OPCTester");
		entity2.setMetricName("Random.Int4");
		entity2.setMetricCode("Random.Int4");
		entity2.setMetricUnit("");
		entity2.setMetricInterval(30);
		entity2.setMetricTimeUnit(TimeUnit.SECONDS.toString());
		entity2.setMetricActive(Boolean.TRUE);
		entity2.setMetricDefkey("random.int4_i18n_key");
		entity2.setMetricType(AplusMetricValueType.TYPE_LONG);
		
		metricList.add(entity1);
		metricList.add(entity2);
		
		String text = JSONUtil.getJsonString(metricList);
		System.out.println(text);
	}
}

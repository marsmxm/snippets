package com.neusoft.aplus.cmdb.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.restlet.Response;
import org.restlet.data.MediaType;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.FileRepresentation;
import org.restlet.representation.Representation;

import com.alibaba.fastjson.TypeReference;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neusoft.aplus.cmdb.model.ActionConst;
import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;
import com.neusoft.aplus.model.dbentity.table.AplusFqnMetricEntity;

/**
 * @author zh_ch
 * @date 2015年3月20日 下午5:10:37
 */
public class PostActionTest {
	private static RestClient client = new RestClient(Protocol.HTTP);

	@Test
	public void testPostThenGetData() {
		
		Reference uri = new Reference(
				"http://localhost:8182/api/aplus/databus/gethistoricaldata");
		Map<String, List<String>> deviceMap = Maps.newHashMap();
		List<String> list = Lists.newArrayList();
		list.add("metricName");
		deviceMap.put("fqn", list);
		String jsonString = JSONUtil.getJsonString(deviceMap);
		Representation data = new JsonRepresentation(jsonString);
		Response res = client.post(uri, data);
		System.out.println(res.getStatus().getCode());
		//Assert.assertEquals(200, res.getStatus().getCode());
	}

	@Test
	public void testGetFqnAndName() throws IOException {
		Reference uri = new Reference(
				"http://10.1.5.161:8182/api/aplus/databus/fqnandname");
		Map<String, String> map = Maps.newHashMap();
		String jsonString = JSONUtil.getJsonString(map);
		Representation data = new JsonRepresentation(jsonString);
		Response res = client.post(uri, data);
		String result = res.getEntityAsText();
		System.out.println(result);
		List<Map<String, String>> resultList = JSONUtil.getComplexObject(
				result, new TypeReference<List<Map<String, String>>>() {
				});
		for (int i = 0; i < resultList.size(); i++) {
			Map<String, String> deviceMap = resultList.get(i);
			System.out.println("fqn == " + deviceMap.get("deviceFqn"));
			System.out.println("name == " + deviceMap.get("deviceName"));
		}
	}

	@Test
	public void deviceConnTest() {
		Reference uri = new Reference(
				"http://localhost:8182/api/aplus/databus/deviceconn");
		String jsonString = JSONUtil.getJsonString(getCriteria());
		JsonRepresentation data = new JsonRepresentation(jsonString);
		Response res = client.put(uri, data);
		System.out.println(res.getEntityAsText());
	}
	
	@Test
	public void testDeviceTypeAndVersion() {
		
		String deviceData = mockData();
		Reference uri = new Reference(
				"http://localhost:8182/api/aplus/databus/deviceconnections");
		JsonRepresentation data = new JsonRepresentation(deviceData);
		Response res = client.post(uri, data);
		System.out.println(res.getStatus().getCode());
		System.out.println(res.getEntityAsText());
	
	}
	
	@Test
	public void testFqnmetrics() {
		
		String deviceData = mockFqnmetricsData();
		String json = JSONUtil.getJsonString(deviceData);
		System.out.println(json);
		Reference uri = new Reference(
				"http://localhost:8182/api/aplus/databus/fqnmetrics");
		JsonRepresentation data = new JsonRepresentation(deviceData);
		Response res = client.post(uri, data);
		System.out.println(res.getStatus().getCode());
		System.out.println(res.getEntityAsText());
	
	}
	
	private String  mockData(){
		
		List<AplusDeviceEntity> list = Lists.newArrayList();
		
		AplusDeviceEntity ade = new AplusDeviceEntity();
		ade.setFqn("Test1");
		ade.setName("红外防盗入侵13");
		ade.setCategory("device");
	    ade.setConnInfo("[{\"host\":\"10.1.5.161\",\"domain\":\"WORKGROUP\",\"user\":\"zh_ch\",\"pwd\":\"China3010@\",\"progid\":\"Matrikon.OPC.Simulation.1\",\"clsid\":\"F8582CF2-88FB-11D0-B850-00C0F0104305\",\"active\":\"true\"}]");
		ade.setIp("10.1.5.161");
		ade.setDeviceType("RUQINBAOJING");
		ade.setDeviceVersion("v1.0");
		ade.setAttr("{\"email\":\"blx5@neusoft.com\",\"phone_num\":\"18855669988\",\"leader\":\"baolx5\"}");
		ade.setLocation("二号楼四层机房8");
		ade.setIsSubSystem(Boolean.TRUE);
		list.add(ade);
		String json = JSONUtil.getJsonString(list);
		System.out.println(json);
		return json;
	}

	
	
	private String mockFqnmetricsData(){
		
		List<AplusFqnMetricEntity> entityList = Lists.newArrayList();
		
		AplusFqnMetricEntity afme = new AplusFqnMetricEntity();
		afme.setFqn("Test1");
		afme.setMetricName("yy");
		afme.setMetricCode("Bucket Brigade.Boolean");
		afme.setMetricInterval(30);
		afme.setMetricTimeUnit("SECONDS");
		afme.setMetricActive(Boolean.TRUE);
		afme.setMetricType(0);
		afme.setMetricDefkey("random.boolean_i18n_key");
		afme.setDeviceType("THERMOMETER");
		afme.setMetricUnit("sdfsd");
		
		
		
		entityList.add(afme);
	
	
		String json = JSONUtil.getJsonString(entityList);
		return json;

	}
	
	@Test
	public void mapString() {
		Map<String, List<String>> map = Maps.newHashMap();
		List<String> list = Lists.newArrayList();
		list.add("aa");
		list.add("bb");
		map.put("deviceList", list);
		System.out.println(JSONUtil.getJsonString(map));
	}
	
	private static Map<String, String> getCriteria() {
		Map<String, String> paraMap = Maps.newHashMap();
		paraMap.put(ActionConst.PAGE, "1");
		paraMap.put(ActionConst.PAGE_COUNT, "10");
		paraMap.put(ActionConst.CATEGORY_HQL, "http");
		paraMap.put(ActionConst.DEVICE_TYPE_HQL, "pcc");
		paraMap.put(ActionConst.LOCATION_HQL, "二号楼四层机房8");
		paraMap.put(ActionConst.DEVICE_NAME_HQL, "name_3");
		paraMap.put(ActionConst.ATTR_HQL, "ip");
		paraMap.put(ActionConst.CREATE_DATE_HQL, "2015-04-10");
		paraMap.put(ActionConst.ALARMCNT, Boolean.FALSE.toString());
		return paraMap;
	}
	@Test
	public void testDeviceconnfileExportExcel() {
		FileRepresentation entity = new FileRepresentation("D:\\workspace\\tempimport.xlsm",
				MediaType.APPLICATION_MSOFFICE_XLSM);
		Reference uri = new Reference(
				"http://localhost:8182/api/aplus/databus/deviceconnfile");
		Response res = client.post(uri, entity);
		System.out.println("code is : " + res.getStatus().getCode());
		System.out.println("Message is: " + res.getEntityAsText());
	}
	
	@Test
	public void testFqnmetricfileExportExcel() {
		FileRepresentation entity = new FileRepresentation("D:\\workspace\\tempimport.xlsm",
				MediaType.APPLICATION_MSOFFICE_XLSM);
		Reference uri = new Reference(
				"http://localhost:8182/api/aplus/databus/fqnmetricfile");
		Response res = client.post(uri, entity);
		System.out.println("code is : " + res.getStatus().getCode());
		System.out.println("Message is: " + res.getEntityAsText());
	}
	
	@Test
	public void testInputStream() throws FileNotFoundException {
		InputStream input = new FileInputStream("d:\\input.xlsx");
		Reference uri = new Reference(
				"http://localhost:8182/api/aplus/databus/deviceconnfile");
		Response res = client.post(uri, input);
		System.out.println("code is : " + res.getStatus().getCode());
		System.out.println("Message is: " + res.getEntityAsText());
	}
	
	@Test
	public void testFile() {
		File file = new File("d:\\input.xlsx");
		Reference uri = new Reference(
				"http://localhost:8182/api/aplus/databus/deviceconnfile");
		Response res = client.post(uri, file);
		System.out.println("code is : " + res.getStatus().getCode());
	}
	
	public static final String STR = "{\"deviceList\":[{\"attr\":\"{\\\"eamil\\\":\\\"blx1@neusoft.com\\\",\\\"phone_num\\\":\\\"18855669988\\\",\\\"leader\\\":\\\"baolx1\\\"}\",\"category\":\"category1\",\"conUuid\":\"91a76b4c-9ffb-4e6f-87d3-287cddf48964\",\"createDate\":1428996478724,\"deviceType\":\"hp\",\"deviceVersion\":\"1.0\",\"fqn\":\"1001.0\",\"ip\":\"10.1.5.110\",\"location\":\"二号楼四层机房2\",\"name\":\"hp\"},{\"attr\":\"{\\\"eamil\\\":\\\"blx2@neusoft.com\\\",\\\"phone_num\\\":\\\"18855669988\\\",\\\"leader\\\":\\\"baolx2\\\"}\",\"category\":\"category2\",\"conUuid\":\"5ebe6e78-3b3e-4bab-bec2-f2fc5a90e4e0\",\"createDate\":1428996478727,\"deviceType\":\"lenovo\",\"deviceVersion\":\"2.0\",\"fqn\":\"1002.0\",\"ip\":\"10.1.5.113\",\"location\":\"二号楼四层机房6\",\"name\":\"lenovo\"},{\"attr\":\"{\\\"eamil\\\":\\\"blx3@neusoft.com\\\",\\\"phone_num\\\":\\\"18855669988\\\",\\\"leader\\\":\\\"baolx3\\\"}\",\"category\":\"category3\",\"conUuid\":\"d9f359b6-345a-490c-bd28-fa7078702093\",\"createDate\":1428996478728,\"deviceType\":\"dell\",\"deviceVersion\":\"1.0\",\"fqn\":\"1003.0\",\"ip\":\"10.1.5.116\",\"location\":\"二号楼四层机房8\",\"name\":\"dell\"},{\"attr\":\"{\\\"eamil\\\":\\\"blx4@neusoft.com\\\",\\\"phone_num\\\":\\\"18855669988\\\",\\\"leader\\\":\\\"baolx4\\\"}\",\"category\":\"category4\",\"conUuid\":\"d9f359b6-345a-490c-bd28-fa7078702093\",\"createDate\":1428996478730,\"deviceType\":\"thinkpad\",\"deviceVersion\":\"3.0\",\"fqn\":\"1004.0\",\"ip\":\"10.1.5.169\",\"location\":\"二号楼四层机房8\",\"name\":\"thinkpad\"},{\"attr\":\"{\\\"eamil\\\":\\\"blx5@neusoft.com\\\",\\\"phone_num\\\":\\\"18855669988\\\",\\\"leader\\\":\\\"baolx5\\\"}\",\"category\":\"category5\",\"conUuid\":\"9cbe3b1a-11cd-4b9a-9e01-7ef743d40797\",\"createDate\":1428996478732,\"deviceType\":\"thinkpad\",\"deviceVersion\":\"4.0\",\"fqn\":\"1005.0\",\"ip\":\"10.1.5.110\",\"location\":\"二号楼四层机房8\",\"name\":\"thinkpad\"},{\"attr\":\"{\\\"eamil\\\":\\\"blx6@neusoft.com\\\",\\\"phone_num\\\":\\\"18855669988\\\",\\\"leader\\\":\\\"baolx6\\\"}\",\"category\":\"category6\",\"conUuid\":\"43c99b8b-f2d5-4ba5-a2be-8eb9996726d3\",\"createDate\":1428996478733,\"deviceType\":\"thinkpad\",\"deviceVersion\":\"4.5\",\"fqn\":\"1006.0\",\"ip\":\"10.1.5.110\",\"location\":\"二号楼四层机房8\",\"name\":\"dell\"},{\"attr\":\"{\\\"eamil\\\":\\\"blx7@neusoft.com\\\",\\\"phone_num\\\":\\\"18855669988\\\",\\\"leader\\\":\\\"baolx7\\\"}\",\"category\":\"category7\",\"conUuid\":\"206196cc-b703-4852-b3fa-2daa34a27d81\",\"createDate\":1428996478736,\"deviceType\":\"thinkpad\",\"deviceVersion\":\"4.8\",\"fqn\":\"1007.0\",\"ip\":\"10.1.5.110\",\"location\":\"二号楼四层机房8\",\"name\":\"thinkpad\"},{\"attr\":\"{\\\"email\\\":\\\"blx4@neusoft_com\\\",\\\"phone_num\\\":\\\"13866575511\\\",\\\"leader\\\":\\\"baolongxiang\\\"}\",\"category\":\"category8\",\"conUuid\":\"4150cf7b-62f3-40b9-b735-c81c5f4189c1\",\"createDate\":1428996478737,\"deviceType\":\"thinkpad\",\"deviceVersion\":\"4.9\",\"fqn\":\"1008.0\",\"ip\":\"10.1.5.116\",\"location\":\"二号楼四层机房6\",\"name\":\"thinkpad\"}],\"connList\":[{\"active\":true,\"conInfo\":\"{\\\"ipaddress\\\":\\\"10.1.5.168\\\",\\\"port\\\":\\\"8080\\\",\\\"community\\\":\\\"communtiy1\\\",\\\"retry\\\":\\\"2\\\",\\\"timeout\\\":\\\"10s\\\",\\\"version\\\":\\\"1.1\\\"}\",\"conUuid\":\"91a76b4c-9ffb-4e6f-87d3-287cddf48964\"},{\"active\":false,\"conInfo\":\"{\\\"ipaddress\\\":\\\"10.1.5.169\\\",\\\"port\\\":\\\"8081\\\",\\\"community\\\":\\\"communtiy2\\\",\\\"retry\\\":\\\"3\\\",\\\"timeout\\\":\\\"11s\\\",\\\"version\\\":\\\"1.2\\\"}\",\"conUuid\":\"5ebe6e78-3b3e-4bab-bec2-f2fc5a90e4e0\"},{\"active\":true,\"conInfo\":\"{\\\"ipaddress\\\":\\\"10.1.5.161\\\",\\\"port\\\":\\\"8082\\\",\\\"community\\\":\\\"communtiy\\\",\\\"retry\\\":\\\"4\\\",\\\"timeout\\\":\\\"12s\\\",\\\"version\\\":\\\"1.4\\\"}\",\"conUuid\":\"d9f359b6-345a-490c-bd28-fa7078702093\"},{\"active\":true,\"conInfo\":\"{\\\"ipaddress\\\":\\\"10.1.5.162\\\",\\\"port\\\":\\\"8084\\\",\\\"community\\\":\\\"communtiy5\\\",\\\"retry\\\":\\\"6\\\",\\\"timeout\\\":\\\"14s\\\",\\\"version\\\":\\\"1.5\\\"}\",\"conUuid\":\"9cbe3b1a-11cd-4b9a-9e01-7ef743d40797\"},{\"active\":true,\"conInfo\":\"{\\\"ipaddress\\\":\\\"10.1.5.161\\\",\\\"port\\\":\\\"8085\\\",\\\"community\\\":\\\"communtiy6\\\",\\\"retry\\\":\\\"7\\\",\\\"timeout\\\":\\\"15s\\\",\\\"version\\\":\\\"1.6\\\"}\",\"conUuid\":\"43c99b8b-f2d5-4ba5-a2be-8eb9996726d3\"},{\"active\":false,\"conInfo\":\"{\\\"port\\\":\\\"9190\\\",\\\"community\\\":\\\"comm\\\",\\\"retry\\\":\\\"50\\\",\\\"ipaddress\\\":\\\"10.1.5.168\\\",\\\"timeout\\\":\\\"300s\\\",\\\"version\\\":\\\"1.2\\\"}\",\"conUuid\":\"206196cc-b703-4852-b3fa-2daa34a27d81\"},{\"active\":true,\"conInfo\":\"{\\\"port\\\":\\\"9190\\\",\\\"community\\\":\\\"comm\\\",\\\"retry\\\":\\\"50\\\",\\\"ipaddress\\\":\\\"10.1.5.168\\\",\\\"timeout\\\":\\\"301s\\\",\\\"version\\\":\\\"1.4\\\"}\",\"conUuid\":\"4150cf7b-62f3-40b9-b735-c81c5f4189c1\"}]}";
}
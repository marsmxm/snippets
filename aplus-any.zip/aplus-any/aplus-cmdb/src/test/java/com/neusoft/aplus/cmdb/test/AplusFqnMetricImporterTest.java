package com.neusoft.aplus.cmdb.test;

import java.io.File;

import org.apache.commons.io.FilenameUtils;
import org.junit.BeforeClass;
import org.junit.Test;

import com.neusoft.aplus.cmdb.importer.AplusFqnMetricImporter;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;

public class AplusFqnMetricImporterTest {
	
private static String basedir = FilenameUtils.getFullPath(new File("").getAbsolutePath());
	
	@BeforeClass
	public static void setupClass() {
		
		ApplicationContextFactory.initialize(
				new String[] { basedir + "aplus-common\\src\\main\\resources\\spring\\applicationContext-properties.xml",
						 basedir + "aplus-common\\src\\main\\resources\\spring\\applicationContext-common.xml",
						 basedir + "aplus-common\\src\\main\\resources\\spring\\applicationContext-dataSource.xml"});
		
	}
	
	@Test
	public void testParseExcel(){
		AplusFqnMetricImporter importer = 
				(AplusFqnMetricImporter) ApplicationContextFactory.getBean("aplusFqnMetricImporter");
		String filename = basedir.concat("aplus-cmdb/src/test/resources/data/fqn_metric模板.xlsx");
		try {
			importer.importExcel(filename);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

package com.neusoft.aplus.cmdb.test;

import java.sql.Date;

import org.junit.Test;

import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;

/**
 * @author zh_ch
 * @date 2015年4月20日 上午10:02:30
 */
public class DeviceEntityTest {
	@Test
	public void deviceEntityTest() {
		AplusDeviceEntity entity = new AplusDeviceEntity();
		entity.setCreateDate(new Date(System.currentTimeMillis()));
		String text = JSONUtil.getJsonString(entity);
		System.out.println(text);
		AplusDeviceEntity newEntity = JSONUtil.getSimpleObject(text, AplusDeviceEntity.class);
		System.out.println(newEntity.getCreateDate());
	}
}

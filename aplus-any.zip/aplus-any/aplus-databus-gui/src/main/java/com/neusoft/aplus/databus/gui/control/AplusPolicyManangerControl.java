package com.neusoft.aplus.databus.gui.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.databus.gui.constant.AplusGuiConstant;
import com.neusoft.aplus.databus.gui.rest.RestAction;
import com.neusoft.aplus.databus.gui.rest.RestContant;
import com.neusoft.aplus.databus.gui.view.tabView.AplusPolicyManageView;
import com.neusoft.aplus.model.dbentity.table.AplusMetricEntity;
import com.neusoft.aplus.policy.biz.service.model.POLCAlertMessage;
import com.neusoft.aplus.policy.biz.service.model.POLCPolicyConditionEntity;
import com.neusoft.aplus.policy.biz.service.model.POLCPolicyEntity;
import com.neusoft.aplus.policy.biz.service.model.POLCPolicyFrequency;
import com.neusoft.aplus.policy.biz.service.model.POLCPolicyFrequency.POLCFrequencyFormat;
import com.neusoft.aplus.policy.biz.service.model.POLCPolicyOperationEntity;
import com.neusoft.aplus.policy.biz.service.model.POLCPolicyResEntity;
import com.neusoft.aplus.service.core.transcoding.biz.service.bo.model.DataDictionaryParameters;

/**
 * @author wuhao
 * @date 2015-4-17 下午5:37:08
 */
public class AplusPolicyManangerControl extends AplusBaseControl {

	private AplusPolicyManageView policyManageView;// 策略维护视图
	private static AplusPolicyManangerControl instance = new AplusPolicyManangerControl();
	private POLCPolicyEntity entity = null; // 修改模式时正在修改的实体类
	private String type = null;// 新增模式时，设备类型
	private String version = null;// 新增模式时，设备版本
	private List<DataDictionaryParameters> alarmLevel = null;
	private static Logger log = LoggerFactory.getLogger(AplusPolicyManangerControl.class);

	private AplusPolicyManangerControl() {
		super();
		policyManageView = new AplusPolicyManageView();
//		initData();
		initListener();
	}

	public void initFrame(POLCPolicyEntity entity) {
		this.entity = entity;
		policyManageView.getPolicyName().setText(entity.getPName());
		policyManageView.getPolicyDes().setText(entity.getDescription());
		policyManageView.getResNameLabel().setText(
				AplusPolicyControl.getInstance().getResName());// 资源名称

		POLCPolicyConditionEntity conditionEntity = entity
				.getPolicyConditionList().get(0);
		policyManageView.getThresholdCiComboBox().setSelectedItem(
				conditionEntity.getComparator());
		policyManageView.getThreshold().setText(conditionEntity.getThreshold());

		if (entity.getActive() == 1) {
			policyManageView.getImmediatelyRadio().setSelected(true);
		} else {
			policyManageView.getNoeffectRadio().setSelected(true);
		}

		POLCPolicyOperationEntity operationEntity = entity
				.getPolicyOperationList().get(0);

		policyManageView.getAplusAlarmNotifyView().getAlarmRadioButton()
				.setSelected(true);
		policyManageView.getAplusAlarmNotifyView().getLevelComboBox()
				.setSelectedIndex(entity.getPriority()-1);
	
		
		policyManageView.getAplusAlarmNotifyView().getContextTextArea()
				.setText(JSONUtil.getSimpleObject(operationEntity.getOperationInfo().toString(), POLCAlertMessage.class).getMessage());

		// 触发条件
		POLCFrequencyFormat trigger = entity.getFrequency().getTrigger();
		if (trigger.getFrequencyType() == 0) {
			policyManageView.getAplusAlarmNotifyView().getTriEveryRadioButton()
					.setSelected(true);
		} else {
			policyManageView.getAplusAlarmNotifyView().getTriCountRadioButton()
					.setSelected(true);
			policyManageView.getAplusAlarmNotifyView().getTriSpinner()
					.getModel().setValue(trigger.getTimes());
		}

		// 清除条件
		POLCFrequencyFormat fixed = entity.getFrequency().getFixed();
		if (fixed.getFrequencyType() == 0) {
			policyManageView.getAplusAlarmNotifyView()
					.getClearEveryRadioButton().setSelected(true);
		} else {
			policyManageView.getAplusAlarmNotifyView()
					.getClearCountRadioButton().setSelected(true);

			policyManageView.getAplusAlarmNotifyView().getClearSpinner()
					.getModel().setValue(fixed.getTimes());
		}

		initAllMetric(entity.getResType(), entity.getResVersion(), entity.getPolicyConditionList().get(0)
				.getFqn(), conditionEntity.getFlag());

	}

	/**
	 * 新增模式进入时
	 * 
	 * @param type
	 * @param version
	 * @author wuhao
	 * @date 2015-4-25 上午10:55:50
	 */
	public void initFrame(String type, String version) {
		initAllMetric(type, version, null, null);
		policyManageView.getResNameLabel().setText(
				AplusPolicyControl.getInstance().getResName());// 资源名称
		this.type = type;
		this.version = version;
	}

	private String checkSave() {
		if (policyManageView.getPolicyName().getText() == null
				|| policyManageView.getPolicyName().getText().toString()
						.length() == 0) {
			return "策略名称不能为空";
		} else if(policyManageView.getHadTable().getModel().getRowCount()!=1){
			return "请设置一个指标策略";
			
		}else {
			return AplusGuiConstant.EMPTY_STRING;
		}

	}

	private POLCPolicyEntity getSaveEntity(int operMode) {

		POLCPolicyEntity saveEntity = null;
		JComboBox comboBox = policyManageView.getAplusAlarmNotifyView()
				.getLevelComboBox();

		String metric = (String) ((DefaultTableModel) policyManageView
				.getHadTable().getModel()).getValueAt(0, 0);
		
		POLCAlertMessage message = new POLCAlertMessage();
		message.setMessage(policyManageView
				.getAplusAlarmNotifyView().getContextTextArea().getText());
		
		// 如果是修改
		if (AplusGuiConstant.DIALOG_OPERMODE_EDIT == operMode) {

			saveEntity = this.entity;
			
			// 仅考虑一个策略一个指标一个告警
			POLCPolicyOperationEntity operationEntity = saveEntity
					.getPolicyOperationList().get(0);
			operationEntity.setOperationInfo(message);
			operationEntity.setOType(1);

			POLCPolicyConditionEntity conditionEntity = saveEntity
					.getPolicyConditionList().get(0);
			conditionEntity.setComparator(policyManageView
					.getThresholdCiComboBox().getSelectedItem().toString());
			conditionEntity.setThreshold(policyManageView.getThreshold()
					.getText().toString());
			conditionEntity.setCType(1);
			conditionEntity.setFlag(metric);

			// 修改不用操作reslist；

			// 新增
		} else {
			saveEntity = new POLCPolicyEntity();
			saveEntity.setResType(type);
			saveEntity.setResVersion(version);
			saveEntity.setCreateTime(new Timestamp(System.currentTimeMillis()));

			List<POLCPolicyOperationEntity> operationList = new ArrayList<POLCPolicyOperationEntity>();
			POLCPolicyOperationEntity operationEntity = new POLCPolicyOperationEntity();
			operationEntity.setOperationInfo(message);
			operationEntity.setOType(1);
			
//			POLCAlertMessage alertMessage = new POLCAlertMessage();
//			alertMessage.setMessage("1234");
//			operationEntity.setOperationInfo(alertMessage);
			operationList.add(operationEntity);
			saveEntity.setPolicyOperationList(operationList);

			List<POLCPolicyConditionEntity> conditionList = new ArrayList<POLCPolicyConditionEntity>();
			POLCPolicyConditionEntity conditionEntity = new POLCPolicyConditionEntity();
			conditionEntity.setComparator(policyManageView
					.getThresholdCiComboBox().getSelectedItem().toString());
			conditionEntity.setThreshold(policyManageView.getThreshold()
					.getText().toString());
			conditionEntity.setFlag(metric);
			conditionEntity.setCType(1);
			conditionList.add(conditionEntity);
			saveEntity.setPolicyConditionList(conditionList);

			// 如果是设备的新增
			if (AplusPolicyControl.getInstance().getResName() != null
					&& AplusPolicyControl.getInstance().getResName().length() > 0) {
				saveEntity.setPType(0);

				String fqn = AplusPolicyControl.getInstance().getResName()
						.split("/")[1];

				List<POLCPolicyResEntity> resList = new ArrayList<POLCPolicyResEntity>();
				POLCPolicyResEntity resEntity = new POLCPolicyResEntity();
				resEntity.setFqn(fqn);
				resList.add(resEntity);
				saveEntity.setPolicyResList(resList);

				saveEntity.getPolicyConditionList().get(0).setFqn(fqn);

			} else {
				// 否则为类型
				saveEntity.setPType(1);
				// 类型的新增，无fqn，不需要操作reslist等
			}

		}

		saveEntity.setPName(policyManageView.getPolicyName().getText());
//		saveEntity.setDescription(policyManageView.getPolicyDes().getText());
		saveEntity.setDescription(setDescription(saveEntity));
		if (policyManageView.getImmediatelyRadio().isSelected()) {
			saveEntity.setActive(1);
		} else {
			saveEntity.setActive(0);
		}

		POLCFrequencyFormat trigger = new POLCFrequencyFormat();
		trigger.setTime(0);
		if (policyManageView.getAplusAlarmNotifyView().getTriEveryRadioButton()
				.isSelected()) {
			trigger.setFrequencyType(0);
		} else {
			trigger.setFrequencyType(1);
			trigger.setTimes(Integer.valueOf(policyManageView
					.getAplusAlarmNotifyView().getTriSpinner().getModel()
					.getValue().toString()));
		}
		POLCFrequencyFormat fixed = new POLCFrequencyFormat();
		fixed.setTime(0);
		if (policyManageView.getAplusAlarmNotifyView()
				.getClearEveryRadioButton().isSelected()) {
			fixed.setFrequencyType(0);
		} else {
			fixed.setFrequencyType(1);
			fixed.setTimes(Integer.valueOf(policyManageView
					.getAplusAlarmNotifyView().getClearSpinner().getModel()
					.getValue().toString()));
		}

		POLCPolicyFrequency frequency = new POLCPolicyFrequency();
		frequency.setFixed(fixed);
		frequency.setTrigger(trigger);
		
		saveEntity.setFrequency(frequency);
		if (comboBox.getItemCount() > 0) {
			saveEntity.setPriority(Integer.valueOf(comboBox.getSelectedItem()
					.toString().split("/")[0]));
		}
		
		
		log.info("save pid is :" + saveEntity.getPid());
		return saveEntity;
	}

	private String setDescription(POLCPolicyEntity saveEntity){
		
		String des = AplusGuiConstant.EMPTY_STRING;
		JComboBox comboBox = policyManageView.getAplusAlarmNotifyView()
				.getLevelComboBox();
		if (comboBox.getItemCount() > 0) {
			des=des.concat(comboBox.getSelectedItem()
					.toString().split("/")[1]);
		}
		if (AplusPolicyControl.getInstance().getResName() != null
				&& AplusPolicyControl.getInstance().getResName().length() > 0){
			des = des.concat(" 资源： " + AplusPolicyControl.getInstance().getResName().split("/")[0]);
		}else{
			des = des.concat(" 类型/版本： " + saveEntity.getResType() +"/" + saveEntity.getResVersion());
		}
		
		POLCPolicyConditionEntity conditionEntity = saveEntity
				.getPolicyConditionList().get(0);
		des=des.concat(" "+conditionEntity.getFlag()+conditionEntity.getComparator()+conditionEntity.getThreshold());
		
		return des;
	}
	
	public static AplusPolicyManangerControl getInstance() {
		return instance;
	}

	@Override
	public void initData() {
		initAlarmLevelComboBox();
		initConditionComboBox();
	}

	private void initConditionComboBox() {
		List<DataDictionaryParameters> condition=null;
		try {
			condition = RestAction
					.findDictionary(RestContant.CONDITION);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(AplusPolicyControl.getInstance()
					.getView().getMainView(),
					"查询信息失败!", AplusGuiConstant.ERROR_MARK,
					JOptionPane.ERROR_MESSAGE);
			log.error(e.getMessage());
			return;
		}
		JComboBox comboBox = policyManageView.getThresholdCiComboBox();
		comboBox.removeAllItems();
		for (DataDictionaryParameters dataDictionaryParameters : condition) {
			comboBox.addItem(dataDictionaryParameters.getCode());
		}
		if (comboBox.getItemCount() > 0) {
			comboBox.setSelectedIndex(0);
		}
	}

	private void initAlarmLevelComboBox() {

		try {
			alarmLevel = RestAction.findDictionary(RestContant.ALARM_LEVEL);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(AplusPolicyControl.getInstance()
					.getView().getMainView(),
					"查询告警级别信息失败!", AplusGuiConstant.ERROR_MARK,
					JOptionPane.ERROR_MESSAGE);
			log.error(e.getMessage());
			return;
		}
		int[] level = new int[alarmLevel.size()];
		int i = 0;
		for (DataDictionaryParameters d : alarmLevel) {
			level[i] = Integer.valueOf(d.getCode());
			i++;
		}
		Arrays.sort(level);
		JComboBox comboBox = policyManageView.getAplusAlarmNotifyView()
				.getLevelComboBox();
		comboBox.removeAllItems();
		for (int j : level) {
			for (DataDictionaryParameters d : alarmLevel) {
				if (Integer.valueOf(d.getCode()) == j) {
					comboBox.addItem(d.getCode() + "/" + d.getDetail());
//					break;
				}
			}
		}

		if (comboBox.getItemCount() > 0) {
			comboBox.setSelectedIndex(0);
		}

	}

	@Override
	public void initListener() {
		policyManageView.getBackButton().addActionListener(
				new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						policyManageView.setVisible(false);
					}
				});

		policyManageView.getTotalTable().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				int r = policyManageView.getTotalTable().getSelectedRow();
				String unit = (String) policyManageView.getTotalTable()
						.getModel().getValueAt(r, 2);
				policyManageView.getUnitLabel().setText(unit);
			}
		});
		policyManageView.getSaveButton().addActionListener(
				new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						// 修改保存
						savePolicy(AplusGuiConstant.DIALOG_OPERMODE_EDIT);
					}
				});
		policyManageView.getSavenAddButton().addActionListener(
				new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						// 增加保存
						savePolicy(AplusGuiConstant.DIALOG_OPERMODE_ADD);
					}
				});

		policyManageView.getMetricAdd().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				metricAdd();
			}
		});

		policyManageView.getMetricDelete().addActionListener(
				new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						metricDelete();
					}
				});
	}

	private void savePolicy(int operMode){
		String checkResult = checkSave();
		if (checkResult.length()==0) {
			if(RestAction.savePolicy(getSaveEntity(operMode))){
				JOptionPane.showMessageDialog(AplusPolicyControl.getInstance()
						.getView().getMainView(), "保存策略成功!",
						AplusGuiConstant.MESSAGE_MARK, JOptionPane.INFORMATION_MESSAGE);
				
				reset();
				if(AplusGuiConstant.DIALOG_OPERMODE_EDIT == operMode){
					policyManageView.setVisible(false);
				}
			}else{
				JOptionPane.showMessageDialog(AplusPolicyControl.getInstance()
						.getView().getMainView(), "保存策略失败!",
						AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
			}
		} else {
			JOptionPane.showMessageDialog(AplusPolicyControl.getInstance()
					.getView().getMainView(),checkResult,
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
		}
	}
	
	/**
	 * 增加策略到已有策略
	 * 
	 * @author wuhao
	 * @date 2015-4-25 下午12:00:00
	 */
	private void metricAdd() {

		int count = policyManageView.getTotalTable().getSelectedRowCount();
		if (count != 1) {
			JOptionPane.showMessageDialog(AplusPolicyControl.getInstance()
					.getView().getMainView(), "请选择一条记录!",
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
			return;
		}
		// 判断阈值是否为空
		Object o = policyManageView.getThreshold().getText();
		if (o != null && o.toString().length() > 0) {

			// 增加，并关闭阈值选择
			DefaultTableModel model = ((DefaultTableModel) policyManageView
					.getTotalTable().getModel());
			DefaultTableModel hadmodel = ((DefaultTableModel) policyManageView
					.getHadTable().getModel());
			int index = policyManageView.getTotalTable().getSelectedRow();
			Vector<Object> v = new Vector<Object>();
			v.add(model.getValueAt(index, 0));
			v.add(model.getValueAt(index, 1));
			v.add(model.getValueAt(index, 2));
			model.removeRow(index);
			hadmodel.addRow(v);

			setCount();

		} else {
			JOptionPane.showMessageDialog(AplusPolicyControl.getInstance()
					.getView().getMainView(), "请录入阈值",
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * 删除策略到总策略
	 * 
	 * @author wuhao
	 * @date 2015-4-25 下午12:00:30
	 */
	private void metricDelete() {

		int count = policyManageView.getHadTable().getSelectedRowCount();
		if (count != 1) {
			JOptionPane.showMessageDialog(AplusPolicyControl.getInstance()
					.getView().getMainView(), "请选择一条记录!",
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
			return;
		}

		// 删除，并放开阈值选择
		DefaultTableModel model = ((DefaultTableModel) policyManageView
				.getTotalTable().getModel());
		DefaultTableModel hadmodel = ((DefaultTableModel) policyManageView
				.getHadTable().getModel());

		Vector<Object> v = new Vector<Object>();
		v.add(hadmodel.getValueAt(0, 0));
		v.add(hadmodel.getValueAt(0, 1));
		v.add(hadmodel.getValueAt(0, 2));
		hadmodel.removeRow(0);
		model.addRow(v);

		setCount();

	}

	public AplusPolicyManageView getView() {
		return policyManageView;
	}

	/**
	 * 重置界面
	 * 
	 * @author wuhao
	 * @date 2015-4-24 上午11:27:06
	 */
	public void reset() {

		((DefaultTableModel) policyManageView.getTotalTable().getModel())
				.getDataVector().clear();
		policyManageView.getTotalLabel().setText(
				AplusGuiConstant.TOTAL_STRING + "      ");
		policyManageView.getHadLabel().setText(
				AplusGuiConstant.TOTAL_STRING + "      ");
		((DefaultTableModel) policyManageView.getHadTable().getModel())
				.getDataVector().clear();

		policyManageView.getPolicyName().setText(AplusGuiConstant.EMPTY_STRING);
		policyManageView.getPolicyDes().setText(AplusGuiConstant.EMPTY_STRING);
		policyManageView.getThresholdCiComboBox().setSelectedIndex(0);
		policyManageView.getThreshold().setText(AplusGuiConstant.EMPTY_STRING);

//		policyManageView.getAplusAlarmNotifyView().getLevelComboBox()
//				.removeAllItems();
		policyManageView.getAplusAlarmNotifyView().getTriEveryRadioButton()
				.setSelected(true);
		policyManageView.getAplusAlarmNotifyView().getClearEveryRadioButton()
				.setSelected(true);
		policyManageView.getAplusAlarmNotifyView().getTriSpinner().getModel()
				.setValue(0);
		policyManageView.getAplusAlarmNotifyView().getClearSpinner().getModel()
				.setValue(0);
		policyManageView.getAplusAlarmNotifyView().getContextTextArea()
				.setText(AplusGuiConstant.EMPTY_STRING);

		policyManageView.getImmediatelyRadio().setSelected(true);

	}

	/**
	 * 更新策略个数
	 * 
	 * @author wuhao
	 * @date 2015-4-25 下午12:06:38
	 */
	private void setCount() {
		DefaultTableModel model = ((DefaultTableModel) policyManageView
				.getTotalTable().getModel());
		DefaultTableModel hadmodel = ((DefaultTableModel) policyManageView
				.getHadTable().getModel());
		policyManageView.getTotalLabel().setText(
				AplusGuiConstant.TOTAL_STRING + model.getRowCount());
		// policyManageView.getTotalTable().updateUI();

		policyManageView.getHadLabel().setText(
				AplusGuiConstant.TOTAL_STRING + hadmodel.getRowCount());
		// policyManageView.getHadTable().updateUI();

		if (hadmodel.getRowCount() == 0) {
			policyManageView.getThresholdCiComboBox().setEnabled(true);
			policyManageView.getThreshold().setEnabled(true);
			policyManageView.getMetricAdd().setEnabled(true);
			policyManageView.getMetricDelete().setEnabled(false);
		} else {
			policyManageView.getThresholdCiComboBox().setEnabled(false);
			policyManageView.getThreshold().setEnabled(false);
			policyManageView.getMetricAdd().setEnabled(false);
			policyManageView.getMetricDelete().setEnabled(true);
		}
	}

	/**
	 * 获取指标信息，显示到界面上
	 * 
	 * @param type
	 * @param version
	 * @param fqn
	 * @param metric
	 * @author wuhao
	 * @date 2015-4-25 下午12:04:39
	 */
	private void initAllMetric(String type, String version, String fqn,
			String metric) {
		List<AplusMetricEntity> list=null;
		try {
			list = RestAction.getMetricInfo(type, version,
					fqn);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(AplusPolicyControl.getInstance()
					.getView().getMainView(),
					"查询指标信息失败!", AplusGuiConstant.ERROR_MARK,
					JOptionPane.ERROR_MESSAGE);
			log.error(e.getMessage());
			return;
		}
		if (list != null) {
			DefaultTableModel model = ((DefaultTableModel) policyManageView
					.getTotalTable().getModel());
			DefaultTableModel hadmodel = ((DefaultTableModel) policyManageView
					.getHadTable().getModel());

			for (AplusMetricEntity aplusMetricEntity : list) {
				Vector<Object> v = new Vector<Object>();
				v.add(aplusMetricEntity.getMetricCode());
				v.add(aplusMetricEntity.getMetricName());
				v.add(aplusMetricEntity.getMetricUnit());
				if (metric != null
						&& aplusMetricEntity.getMetricCode().equals(metric)) {
					hadmodel.addRow(v);
				} else {

					model.addRow(v);
				}
			}
			setCount();

		}
	}
}

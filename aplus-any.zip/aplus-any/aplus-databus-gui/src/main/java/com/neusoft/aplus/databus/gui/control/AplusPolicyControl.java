package com.neusoft.aplus.databus.gui.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.dubbo.common.json.JSON;
import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.databus.gui.constant.AplusGuiConstant;
import com.neusoft.aplus.databus.gui.rest.RestAction;
import com.neusoft.aplus.databus.gui.view.tabView.AplusPolicyManageView;
import com.neusoft.aplus.databus.gui.view.tabView.AplusPolicyView;
import com.neusoft.aplus.model.dbentity.table.AplusMetricEntity;
import com.neusoft.aplus.policy.biz.service.model.POLCPolicyEntity;
import com.neusoft.aplus.policy.biz.service.model.POLCPolicyParameters;

/**
 * @author wuhao
 * @date 2015-4-17 上午10:30:09
 */
public class AplusPolicyControl extends AplusBaseControl {

	private AplusPolicyView policyView;// 策略视图
	private AplusPolicyManageView policyManageView;
	private static AplusPolicyControl instance = new AplusPolicyControl();
	private String resName = null;
	private List<POLCPolicyEntity> policyList = new ArrayList<POLCPolicyEntity>();
	private static Logger log = LoggerFactory
			.getLogger(AplusPolicyControl.class);

	private AplusPolicyControl() {
		super();
		policyView = new AplusPolicyView();
		policyManageView = AplusPolicyManangerControl.getInstance().getView();
		initData();
		initListener();
	}

	public static AplusPolicyControl getInstance() {
		return instance;
	}

	@Override
	public void initData() {
		policyManageView.getEventRadio().setEnabled(false);
		policyManageView.getProperRadio().setEnabled(false);
	}

	@Override
	public void initListener() {

		policyView.getQueryButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				processQuery();
			}
		});

		policyView.getResetButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				processReset();
			}
		});
		policyView.getAddButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				showPolicyManageView(AplusGuiConstant.DIALOG_OPERMODE_ADD);
			}
		});
		policyView.getAlterButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				showPolicyManageView(AplusGuiConstant.DIALOG_OPERMODE_EDIT);
			}
		});
		policyView.getDeleteButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				processDelete();
			}
		});
	}

	/**
	 * 删除选定的策略
	 * 
	 * @author wuhao
	 * @date 2015-4-17 下午5:36:16
	 */
	private void processDelete() {

		int count = policyView.getPolicyTable().getSelectedRowCount();
		if (count != 1) {
			JOptionPane.showMessageDialog(policyView.getMainView(), "请选择一条记录!",
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
			return;
		}

		DefaultTableModel model = (DefaultTableModel) policyView
				.getPolicyTable().getModel();
		int index = policyView.getPolicyTable().getSelectedRow();
		String pid = model.getValueAt(index, 4).toString();

		if (RestAction.DeletePolicy(pid)) {
			JOptionPane.showMessageDialog(policyView.getMainView(), "删除策略成功!",
					AplusGuiConstant.MESSAGE_MARK,
					JOptionPane.INFORMATION_MESSAGE);
			// model.removeRow(index);
			processQuery();
			policyView.getPolicyTable().updateUI();
		} else {
			JOptionPane.showMessageDialog(policyView.getMainView(), "删除策略失败!",
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
		}

	}

	public void initMetricNameComboBox(String item) {
		// 初始化指标名
		if (policyView.getMetricNameComboBox().isEnabled()) {

			String typeVersion = item;
			JComboBox box = policyView.getMetricNameComboBox();
			box.removeAllItems();
			List<AplusMetricEntity> list = null;
			try {
				list = RestAction.getMetricInfo(typeVersion.split(" ")[0],
						typeVersion.split(" ")[1], null);
			} catch (IOException e) {
				JOptionPane.showMessageDialog(policyView.getMainView(),
						"查询指标信息失败!", AplusGuiConstant.ERROR_MARK,
						JOptionPane.ERROR_MESSAGE);
				log.error(e.getMessage());
								return;
			}
			for (AplusMetricEntity aplusMetricEntity : list) {
				box.addItem(aplusMetricEntity.getMetricCode() + "/"
						+ aplusMetricEntity.getMetricName());
			}
			if (list != null && list.size() > 0) {
				box.setSelectedIndex(0);
			}
			policyView.updateUI();
		}
	}

	/**
	 * 弹出策略增加/维护界面
	 * 
	 * @param operMode
	 * @author wuhao
	 * @date 2015-4-17 下午5:36:29
	 */
	private void showPolicyManageView(int operMode) {

		AplusPolicyManangerControl.getInstance().reset();

		if (operMode == AplusGuiConstant.DIALOG_OPERMODE_EDIT) {
			int count = policyView.getPolicyTable().getSelectedRowCount();
			if (count != 1) {
				JOptionPane.showMessageDialog(policyView.getMainView(),
						"请选择一条记录!", AplusGuiConstant.ERROR_MARK,
						JOptionPane.ERROR_MESSAGE);
				return;
			}

			DefaultTableModel model = (DefaultTableModel) policyView
					.getPolicyTable().getModel();
			int index = policyView.getPolicyTable().getSelectedRow();
			if (index == -1) {
				return;
			}
			String pid = model.getValueAt(index, 4).toString();
			POLCPolicyEntity entity = null;
			for (POLCPolicyEntity policyEntity : policyList) {
				if (policyEntity.getPid().equals(pid)) {
					entity = policyEntity;
					break;
				}
			}
			AplusPolicyManangerControl.getInstance().initFrame(entity);
			AplusPolicyManangerControl.getInstance().getView()
					.getSavenAddButton().setEnabled(false);
			AplusPolicyManangerControl.getInstance().getView().getSaveButton()
					.setEnabled(true);

		} else {
			if (policyView.getDeviceTypeComboBox().getSelectedItem() != null
					&& policyView.getDeviceTypeComboBox().getSelectedItem()
							.toString().length() > 0) {
				String typeVersion = policyView.getDeviceTypeComboBox()
						.getSelectedItem().toString();

				AplusPolicyManangerControl.getInstance().getView()
						.getSavenAddButton().setEnabled(true);
				AplusPolicyManangerControl.getInstance().getView()
						.getSaveButton().setEnabled(false);
				AplusPolicyManangerControl.getInstance().initFrame(
						typeVersion.split(" ")[0], typeVersion.split(" ")[1]);
			}

		}
		policyManageView.setOperMode(operMode);
		policyManageView.setLocationRelativeTo(policyView.getMainView());
		policyManageView.setVisible(true);
	}

	/**
	 * 查询条件重置
	 * 
	 * @author wuhao
	 * @date 2015-4-17 下午2:21:13
	 */
	private void processReset() {
		if (policyView.getDeviceTypeComboBox().getItemCount() > 0) {
			policyView.getDeviceTypeComboBox().setSelectedIndex(0);
		}
		if (policyView.getMetricNameComboBox().getItemCount() > 0) {
			policyView.getMetricNameComboBox().setSelectedIndex(0);
		}
		policyView.getPolicyNameText().setText(AplusGuiConstant.EMPTY_STRING);
	}

	/**
	 * 查询策略
	 * 
	 * @author wuhao
	 * @date 2015-4-17 下午2:21:22
	 */
	private void processQuery() {
		POLCPolicyParameters parameter = new POLCPolicyParameters();
		// parameter.getMapParameters()
		if (policyView.getPolicyNameText().getText() != null
				&& policyView.getPolicyNameText().getText().toString().trim()
						.length() > 0) {
			parameter.getMapParameters().put(POLCPolicyParameters.PNAME,
					policyView.getPolicyNameText().getText().toString().trim());
		}
		if (getResName() != null && getResName().length() > 0) {
			parameter.getMapParameters().put(POLCPolicyParameters.FQN,
					getResName().split("/")[1]);
		}
		if (policyView.getDeviceTypeComboBox().getSelectedItem() != null
				&& policyView.getDeviceTypeComboBox().getSelectedItem()
						.toString().length() > 0) {
			String typeVersion = policyView.getDeviceTypeComboBox()
					.getSelectedItem().toString();

			parameter.getMapParameters().put(POLCPolicyParameters.RESTYPE,
					typeVersion.split(" ")[0]);
			parameter.getMapParameters().put(POLCPolicyParameters.RESVERSION,
					typeVersion.split(" ")[1]);
		}
		if (policyView.getMetricNameComboBox().getSelectedItem() != null
				&& policyView.getMetricNameComboBox().getSelectedItem()
						.toString().length() > 0) {
			String metric = policyView.getMetricNameComboBox()
					.getSelectedItem().toString();

			parameter.getMapParameters().put(POLCPolicyParameters.FLAG,
					metric.split("/")[0]);
		}
		
		Map<String, Object> resultMap=null;
		try {
			resultMap = RestAction.findPolicy(parameter);
		
		if (resultMap != null) {

			
				List<POLCPolicyEntity> policyEntityList = JSONUtil
						.getComplexObject(JSON.json(resultMap.get("itemList")),
								new TypeReference<List<POLCPolicyEntity>>() {
								});

				DefaultTableModel model = (DefaultTableModel) policyView
						.getPolicyTable().getModel();
				model.getDataVector().clear(); // 清除表格数据

				for (POLCPolicyEntity polcpolicyentity : policyEntityList) {
					Vector<Object> v = new Vector<Object>();

					v.add(polcpolicyentity.getPName());
					if (polcpolicyentity.getActive() == 1) {
						v.add("生效");
					} else {
						v.add("未生效");
					}
					if (polcpolicyentity.getPolicyConditionList() != null
							&& polcpolicyentity.getPolicyConditionList().size() > 0) {
						v.add(polcpolicyentity.getPolicyConditionList().get(0)
								.getFlag());
					} else {
						v.add(AplusGuiConstant.EMPTY_STRING);
					}
					v.add(polcpolicyentity.getDescription());
					v.add(polcpolicyentity.getPid());
					model.addRow(v);

				}

				this.policyList = policyEntityList;
		} }catch (IOException e) {
				JOptionPane.showMessageDialog(policyView.getMainView(),
						"查询数据放回格式不正确!", AplusGuiConstant.ERROR_MARK,
						JOptionPane.ERROR_MESSAGE);
				log.error(e.getMessage());
								return;
			}

	}

	public AplusPolicyView getView() {
		return policyView;
	}

	public String getResName() {
		return resName;
	}

	public void setResName(String resName) {
		this.resName = resName;
	}
}

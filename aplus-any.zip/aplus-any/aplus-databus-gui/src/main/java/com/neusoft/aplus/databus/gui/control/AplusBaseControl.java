package com.neusoft.aplus.databus.gui.control;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neusoft.aplus.common.util.FileUtil;

/**
 * 界面控制类的基类
 * 
 * @author WanWei
 * @date 2015-4-14 下午4:38:46
 */
public abstract class AplusBaseControl {
	
	private static Logger log = LoggerFactory.getLogger(AplusBaseControl.class);

	// 对应的配置文件路径
	private static final String CONFPATH = "/conf/data.properties";

	protected String propsPath;

	protected Properties props;

	public AplusBaseControl() {
		propsPath = FileUtil.getRepositoryPath(CONFPATH);
		props = new Properties();
		try {
			InputStream input = new BufferedInputStream(new FileInputStream(
					propsPath));
			props.load(input);
		} catch (Exception e) {
			log.warn("加载配置文件[" + propsPath +"] 失败, 界面无初始化数据", e);
			props = null;
		}
	}

	/**
	 * 保存配置文件
	 */
	protected void saveProperty() {
		try {
			if (props != null) {
				OutputStream Output = new BufferedOutputStream(
						new FileOutputStream(propsPath));
				props.store(Output, "");
			}
		} catch (Exception e) {
			log.error("找不到配置文件[" + propsPath + " ], 数据不会被缓存", e);
		}

	}
	
	/**
	 * 初始化界面展现数据
	 * 
	 * @author WanWei
	 * @date 2015-4-14 下午4:49:30
	 */
	public abstract void initData(); 
	
	
	/**
	 * 初始化事件监听
	 * 
	 * @author WanWei
	 * @date 2015-4-14 下午4:49:52
	 */
	public abstract void initListener();

}

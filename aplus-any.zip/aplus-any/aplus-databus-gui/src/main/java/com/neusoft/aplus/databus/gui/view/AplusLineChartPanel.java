package com.neusoft.aplus.databus.gui.view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.util.Date;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.panel.CrosshairOverlay;
import org.jfree.chart.plot.Crosshair;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Minute;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.RectangleAnchor;

import com.neusoft.aplus.model.bizentity.AplusHistoryMetricData;
import com.neusoft.aplus.model.bizentity.AplusMetricDataPoint;

/**
 * 用来渲染历史监控数据的折线图Panel
 * 
 * @author WanWei
 * @date 2015-4-16 下午2:49:47
 */
public class AplusLineChartPanel extends ChartPanel {

	private static final long serialVersionUID = -5825628963948964445L;

	private JFreeChart chart;

	private Crosshair xCrosshair;
	
	private Crosshair[] yCrosshairs;
	
	private AplusHistoryMetricData data;
	
	public AplusLineChartPanel(JFreeChart chart, AplusHistoryMetricData data) {
		super(chart);
		this.data = data;
		this.chart = chart;
		initPanel();
	}

	/**
	 * 
	 * 初始化折线图元素
	 * 
	 * @author WanWei
	 * @date 2015-4-16 下午3:01:40
	 */
	private void initPanel() {
		this.setMouseWheelEnabled(true);

		CrosshairOverlay localCrosshairOverlay = new CrosshairOverlay();
		xCrosshair = new Crosshair((0.0D / 0.0D), Color.GRAY,
				new BasicStroke(0.0F));
		xCrosshair.setLabelVisible(false);
		localCrosshairOverlay.addDomainCrosshair(xCrosshair);
		yCrosshairs = new Crosshair[3];
		for (int i = 0; i < 3; i++) {
			yCrosshairs[i] = new Crosshair((0.0D / 0.0D), Color.GRAY,
					new BasicStroke(0.0F));
			yCrosshairs[i].setLabelVisible(true);
			if (i % 2 != 0) {
				yCrosshairs[i].setLabelAnchor(RectangleAnchor.TOP_RIGHT);
			}
			localCrosshairOverlay.addRangeCrosshair(yCrosshairs[i]);
		}
//		this.addChartMouseListener(new ChartMouseListener() {
//			public void chartMouseClicked(ChartMouseEvent paramChartMouseEvent) {
//			}
//
//			public void chartMouseMoved(ChartMouseEvent paramChartMouseEvent) {
//				Rectangle2D localRectangle2D = AplusLineChartPanel.this
//						.getScreenDataArea();
//				JFreeChart localJFreeChart = paramChartMouseEvent.getChart();
//				XYPlot localXYPlot = (XYPlot) localJFreeChart.getPlot();
//				ValueAxis localValueAxis = localXYPlot.getDomainAxis();
//				double d1 = localValueAxis.java2DToValue(paramChartMouseEvent
//						.getTrigger().getX(), localRectangle2D,
//						RectangleEdge.BOTTOM);
//				xCrosshair.setValue(d1);
//				for (int i = 0; i < 3; i++) {
//					double d2 = DatasetUtilities.findYValue(
//							localXYPlot.getDataset(), i, d1);
//					yCrosshairs[i].setValue(d2);
//				}
//			}
//		});
		this.addOverlay(localCrosshairOverlay);
		this.setVisible(true);
		this.setSize(400, 400);

//		button.addActionListener(new ActionListener() {
//
////			@Override
////			public void actionPerformed(ActionEvent e) {
////
////				System.out.println("!!!!!!!!!!!!!!!!!");
////
////			}
//		});
//		this.add(button);

	}

	/**
	 * 为折线图设置数据
	 * 
	 * @param data
	 * @author WanWei
	 * @date 2015-4-17 上午10:29:34
	 */
	public void setData(AplusHistoryMetricData data) {
		this.data = data;
		XYPlot localXYPlot = (XYPlot) chart.getPlot();
		localXYPlot.setDataset(createDataset(data.getDataPoints()));
	}
	
	/**
	 * 获取折线图数据
	 * @return
	 * @author WanWei
	 * @date 2015-4-28 下午3:47:57
	 */
	public AplusHistoryMetricData getData() {
		return data;
	}

	/**
	 * 创建折线图实例
	 * 
	 * @param title
	 * @param yTitle
	 * @param paramXYDataset
	 * @return
	 * @author WanWei
	 * @date 2015-4-16 下午3:40:57
	 */
	public static JFreeChart createChart(String title, String yTitle,
			List<AplusMetricDataPoint> dataPoints) {
		XYDataset paramXYDataset = createDataset(dataPoints);
		JFreeChart localJFreeChart = ChartFactory.createTimeSeriesChart(title,
				"时间", yTitle, paramXYDataset, true, true, false);
		XYPlot localXYPlot = (XYPlot) localJFreeChart.getPlot();
		localXYPlot.setDomainPannable(true);
		localXYPlot.setRangePannable(true);
		XYLineAndShapeRenderer localXYLineAndShapeRenderer = (XYLineAndShapeRenderer) localXYPlot
				.getRenderer();
		localXYLineAndShapeRenderer.setBaseShapesVisible(true);
		localXYLineAndShapeRenderer.setBaseShapesFilled(true);
		NumberAxis localNumberAxis = (NumberAxis) localXYPlot.getRangeAxis();
		localNumberAxis.setStandardTickUnits(NumberAxis
				.createIntegerTickUnits());
		return localJFreeChart;
	}
	
	public Crosshair getxCrosshair() {
		return xCrosshair;
	}

	public Crosshair[] getyCrosshairs() {
		return yCrosshairs;
	}

	/**
	 * 构建折线图的数据集
	 * 
	 * @param dataPoints
	 * @return
	 * @author WanWei
	 * @date 2015-4-16 下午3:44:45
	 */
	private static XYDataset createDataset(List<AplusMetricDataPoint> dataPoints) {
		// 按照时间排序
//		Collections.sort(dataPoints, new Comparator<AplusMetricDataPoint>() {
//
//			@Override
//			public int compare(AplusMetricDataPoint point1,
//					AplusMetricDataPoint point2) {
//				if (point1.getRecordTime() < point2.getRecordTime()) {
//					return -1;
//				} else if (point1.getRecordTime() > point2.getRecordTime()) {
//					return 1;
//				}
//				return 0;
//			}
//
//		});
		TimeSeries max = new TimeSeries("最大值");
		TimeSeries min = new TimeSeries("最小值");
		TimeSeries avg = new TimeSeries("平均值");
		for (AplusMetricDataPoint dataPoint : dataPoints) {
			// Day day = new Day(new Date(dataPoint.getRecordTime()));
			max.add(new Minute(new Date(dataPoint.getRecordTime())),
					(Number) dataPoint.getMaxValue());
			min.add(new Minute(new Date(dataPoint.getRecordTime())),
					(Number) dataPoint.getMinValue());
			avg.add(new Minute(new Date(dataPoint.getRecordTime())),
					(Number) dataPoint.getAvgValue());
		}

		TimeSeriesCollection timeSeriesCollection = new TimeSeriesCollection();
		timeSeriesCollection.addSeries(max);
		timeSeriesCollection.addSeries(avg);
		timeSeriesCollection.addSeries(min);

		return timeSeriesCollection;
	}
}

package com.neusoft.aplus.databus.gui.rest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.Representation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.dubbo.common.json.JSON;
import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.cmdb.model.AplusDeviceWithAlarmCnt;
import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.model.dbentity.table.AplusMetricEntity;
import com.neusoft.aplus.policy.biz.service.model.POLCAlertParameters;
import com.neusoft.aplus.policy.biz.service.model.POLCPolicyAlertOperationParameters;
import com.neusoft.aplus.policy.biz.service.model.POLCPolicyEntity;
import com.neusoft.aplus.policy.biz.service.model.POLCPolicyParameters;
import com.neusoft.aplus.service.core.transcoding.biz.service.bo.model.DataDictionaryParameters;

/**
 * 调用Rest的接口
 * 
 * @author wuhao
 * @date 2015-4-21 上午11:33:07
 */
public class RestAction {
	private static RestClient client = new RestClient(Protocol.HTTP);
	private static Logger log = LoggerFactory.getLogger(RestAction.class);

	/**
	 * 获取指定节点下的设备类别和类型版本
	 * 
	 * @param node
	 * @return
	 * @author wuhao
	 * @throws IOException
	 * @date 2015-4-21 上午11:38:39
	 */
	public static List<Map<String, Object>> findAllCategoryAndDeviceType()
			throws IOException {

		try {
			Reference uri = new Reference(
					RestContant.getUri(RestContant.CATEGORYS));
			Response res = client.get(uri);

			String resultStr = res.getEntity().getText().toString();

			List<Map<String, Object>> list = JSONUtil.getComplexObject(
					resultStr, new TypeReference<List<Map<String, Object>>>() {
					});
			return list;
		} catch (IOException e) {
			throw e;
		} catch (RuntimeException e) {
			throw e;
		}
	}

	public static boolean importDeviceInfo(Map<String, Object> map) {

		Reference uri = new Reference(RestContant.getUri(RestContant.IMPORT));
		String jsonString = JSONUtil.getJsonString(map);
		Representation data = new JsonRepresentation(jsonString);

		log.info("importDeviceInfo data is :" + jsonString);

		Response res = client.post(uri, data);

		log.info("importDeviceInfo result is :" + res);
		if (res.getStatus().getCode() == 200)
			return true;
		return false;
	}

	/**
	 * 根据查询条件，查询设备信息
	 * 
	 * @return
	 * @author wuhao
	 * @throws IOException
	 * @date 2015-4-22 下午1:48:12
	 */
	public static List<AplusDeviceWithAlarmCnt> findDeviceInfo(String category,
			String type, String version, String name) throws IOException {

		String uriStr = RestContant.getUri(RestContant.DEVICES);
		boolean first = true;
		if (category != null && !category.isEmpty()) {
			uriStr = uriStr.concat("?category=" + category);
			first = false;
		}

		if (type != null && !type.isEmpty()) {
			if (first) {
				uriStr = uriStr.concat("?deviceType=" + type);
				first = false;
			} else {
				uriStr = uriStr.concat("&deviceType=" + type);
			}
		}
		if (version != null && !version.isEmpty()) {
			if (first) {
				uriStr = uriStr.concat("?deviceVersion=" + version);
				first = false;
			} else {
				uriStr = uriStr.concat("&deviceVersion=" + version);
			}
		}
		if (name != null && !name.isEmpty()) {
			if (first) {
				uriStr = uriStr.concat("?name=" + name);
				first = false;
			} else {
				uriStr = uriStr.concat("&name=" + name);
			}
		}

		Reference uri = new Reference(uriStr);
		log.info("findDeviceInfo uri is :" + uriStr);
		Response res = client.get(uri);
		try {

			String text = res.getEntity().getText().toString();
			Map<String, Object> map = JSONUtil.getComplexObject(text,
					new TypeReference<Map<String, Object>>() {
					});
			List<AplusDeviceWithAlarmCnt> list = JSONUtil.getComplexObject(
					JSON.json(map.get("deviceList")),
					new TypeReference<List<AplusDeviceWithAlarmCnt>>() {
					});

			return list;
		} catch (IOException e) {
			throw e;
		}
	}

	/**
	 * 分页查询未处理告警
	 * 
	 * @param page
	 * @param pageSize
	 * @author wuhao
	 * @param paramMap
	 * @throws IOException
	 * @date 2015-4-23 上午8:39:53
	 */
	public static Map<String, Object> findUnFixedAlarm(int page, int pageSize,
			POLCAlertParameters parameter) throws IOException {

		// String uriStr = RestContant.getUri(RestContant.ALARM, "10.3.11.41",
		// "8182");
		String uriStr = RestContant.getUri(RestContant.ALARM);
		uriStr = uriStr.concat("/pageno/").concat(String.valueOf(page))
				.concat("/pagesize/").concat(String.valueOf(pageSize));
		Reference uri = new Reference(uriStr);

		log.info("findUnFixedAlarm url is :" + uriStr);

		String jsonString = JSONUtil.getJsonString(parameter);
		Representation data = new JsonRepresentation(jsonString);

		log.info("findUnFixedAlarm param is :" + jsonString);

		Response res = client.post(uri, data);
		try {
			String text = res.getEntity().getText().toString();
			log.info("findUnFixedAlarm result is :" + text);

			Map<String, Object> map = JSONUtil.getComplexObject(text,
					new TypeReference<Map<String, Object>>() {
					});

			return map;

		} catch (IOException e) {
			throw e;
		}
	}

	/**
	 * 获取历史采集数据
	 * 
	 * @param list
	 * @return
	 * @author wuhao
	 * @throws IOException 
	 * @date 2015-4-25 下午2:02:11
	 */
	public static Map<String, Object> findHistoryDatas(
			List<Map<String, Object>> list) throws IOException {

		String uriStr = RestContant.getUri(RestContant.HISTORY);
		Reference uri = new Reference(uriStr);

		log.info("findHistoryDatas url is :" + uriStr);

		String jsonString = JSONUtil.getJsonString(list);
		Representation data = new JsonRepresentation(jsonString);

		log.info("findHistoryDatas param is :" + jsonString);

		Response res = client.post(uri, data);
		try {
			String text = res.getEntity().getText().toString();

			log.info("findHistoryDatas result is :" + text);

			Map<String, Object> map = JSONUtil.getComplexObject(text,
					new TypeReference<Map<String, Object>>() {
					});

			return map;

		} catch (IOException e) {
			throw e;
		}
		
	}

	/**
	 * 分页查询已确认告警
	 * 
	 * @param page
	 * @param pageSize
	 * @param paramMap
	 * @author wuhao
	 * @throws IOException
	 * @date 2015-4-23 上午8:51:40
	 */
	public static Map<String, Object> findFixedAlarm(int page, int pageSize,
			POLCAlertParameters parameter) throws IOException {

		// String uriStr = RestContant.getUri(RestContant.ALARM_FIXED,
		// "10.3.11.41", "8182");
		String uriStr = RestContant.getUri(RestContant.ALARM_FIXED);
		uriStr = uriStr.concat("/pageno/").concat(String.valueOf(page))
				.concat("/pagesize/").concat(String.valueOf(pageSize));
		Reference uri = new Reference(uriStr);

		log.info("findFixedAlarm url is :" + uriStr);

		String jsonString = JSONUtil.getJsonString(parameter);
		Representation data = new JsonRepresentation(jsonString);

		log.info("findFixedAlarm param is :" + jsonString);

		Response res = client.post(uri, data);
		try {
			String text = res.getEntity().getText().toString();
			Map<String, Object> map = JSONUtil.getComplexObject(text,
					new TypeReference<Map<String, Object>>() {
					});

			return map;
		} catch (IOException e) {
			throw e;
		}

	}

	/**
	 * 查询告警级别
	 * 
	 * @return
	 * @author wuhao
	 * @throws IOException
	 * @date 2015-4-23 上午9:41:41
	 */
	public static List<DataDictionaryParameters> findDictionary(String url)
			throws IOException {

		List<DataDictionaryParameters> dataDictionaryParametersList = null;

		String uriStr = RestContant.getUri(url, "10.0.65.85", "8182");
		// String uriStr = RestContant.getUri(url, "10.1.5.94", "8182");
		// String uriStr = RestContant.getUri(url, "10.3.11.41", "8182");
		// String uriStr = RestContant.getUri(url);
		log.info(uriStr);
		Reference uri = new Reference(uriStr);
		Response res = client.get(uri);

		try {
			String text = res.getEntity().getText().toString();
			log.info(text);
			dataDictionaryParametersList = JSONUtil.getComplexObject(text,
					new TypeReference<List<DataDictionaryParameters>>() {
					});
		} catch (IOException e) {
			throw e;
		}

		return dataDictionaryParametersList;
	}

	/**
	 * 根据多个活跃告警Id把多个活跃告警处理为历史告警
	 * 
	 * @return
	 * @author wuhao
	 * @date 2015-4-23 下午2:26:12
	 */
	public static boolean ConfirmAlarm(List<String> idList) {
		// String uriStr = RestContant.getUri(RestContant.ALARM_FIX,
		// "10.3.11.41",
		// "8182");
		String uriStr = RestContant.getUri(RestContant.ALARM_FIX);
		Reference uri = new Reference(uriStr);
		log.info("ConfirmAlarm url is :" + uriStr);

		List<POLCPolicyAlertOperationParameters> parameterList = new ArrayList<POLCPolicyAlertOperationParameters>();
		for (String id : idList) {
			POLCPolicyAlertOperationParameters p = new POLCPolicyAlertOperationParameters();
			p.setSimilarid(id);
			parameterList.add(p);
		}

		String jsonString = JSONUtil.getJsonString(parameterList);
		Representation data = new JsonRepresentation(jsonString);

		log.info("ConfirmAlarm param is :" + jsonString);

		Response res = client.post(uri, data);
		log.info("ConfirmAlarm result is :" + res);
		if (res.getStatus().getCode() == 200)
			return true;
		return false;

	}

	/**
	 * 删除历史告警
	 * 
	 * @param idList
	 * @return
	 * @author wuhao
	 * @date 2015-4-23 下午2:52:40
	 */
	public static boolean DeleteAlarm(List<String> idList) {
		// String uriStr = RestContant.getUri(RestContant.ALARM_DELETE,
		// "10.3.11.41", "8182");
		String uriStr = RestContant.getUri(RestContant.ALARM_DELETE);
		Reference uri = new Reference(uriStr);
		log.info("DeleteAlarm url is :" + uriStr);
		List<Integer> ids = new ArrayList<Integer>();
		for (String id : idList) {
			ids.add(Integer.valueOf(id));
		}

		String jsonString = JSONUtil.getJsonString(ids);
		Representation data = new JsonRepresentation(jsonString);

		log.info("DeleteAlarm param is :" + jsonString);

		Response res = client.post(uri, data);
		log.info("DeleteAlarm result is :" + res);
		if (res.getStatus().getCode() == 200)
			return true;
		return false;

	}

	/**
	 * 根据策略id，删除单个策略
	 * 
	 * @param pid
	 * @return
	 * @author wuhao
	 * @date 2015-4-23 下午4:22:46
	 */
	public static boolean DeletePolicy(String pid) {
		// String uriStr = RestContant.getUri(RestContant.POLICY_DELETE,
		// "10.3.11.41", "8182") + pid;
		String uriStr = RestContant.getUri(RestContant.POLICY_DELETE) + pid;
		Reference uri = new Reference(uriStr);
		Response res = client.delete(uri);
		log.info("DeleteAlarm result is :" + res);
		if (res.getStatus().getCode() == 200)
			return true;
		return false;
	}

	/**
	 * 根据查询条件查询策略
	 * 
	 * @param parameter
	 * @author wuhao
	 * @throws IOException
	 * @date 2015-4-24 下午2:05:55
	 */
	public static Map<String, Object> findPolicy(POLCPolicyParameters parameter)
			throws IOException {
		// String uriStr = RestContant.getUri(RestContant.POLICY_QUERY,
		// "10.3.11.41", "8182");
		String uriStr = RestContant.getUri(RestContant.POLICY_QUERY);
		Reference uri = new Reference(uriStr);

		log.info("findPolicy url is :" + uriStr);

		String jsonString = JSONUtil.getJsonString(parameter);
		Representation data = new JsonRepresentation(jsonString);

		log.info("findPolicy param is :" + jsonString);

		Response res = client.post(uri, data);
		try {
			String text = res.getEntity().getText().toString();
			log.info("findPolicy result is :" + text);
			Map<String, Object> map = JSONUtil.getComplexObject(text,
					new TypeReference<Map<String, Object>>() {
					});

			return map;
		} catch (IOException e) {
			throw e;
		}

	}

	/**
	 * 保存策略
	 * 
	 * @param entity
	 * @return
	 * @author wuhao
	 * @date 2015-4-25 下午12:45:03
	 */
	public static boolean savePolicy(POLCPolicyEntity entity) {
		// String uriStr = RestContant.getUri(RestContant.POLICY_SAVE,
		// "10.3.11.41", "8182");
		String uriStr = RestContant.getUri(RestContant.POLICY_SAVE);
		Reference uri = new Reference(uriStr);

		String jsonString = JSONUtil.getJsonString(entity);
		Representation data = new JsonRepresentation(jsonString);
		log.info("savePolicy jsonString is :" + jsonString);
		Response res = client.post(uri, data);
		log.info("savePolicy result is :" + res);
		if (res.getStatus().getCode() == 200)
			return true;
		return false;
	}

	/**
	 * 根据设备类型和设备版本获取设备的指标信息
	 * 
	 * @param deviceType
	 * @param deviceVersion
	 * @return
	 * @author wuhao
	 * @throws IOException
	 * @date 2015-4-24 下午2:06:07
	 */
	public static List<AplusMetricEntity> getMetricInfo(String deviceType,
			String deviceVersion, String fqn) throws IOException {
		String uriStr = RestContant.getUri(RestContant.METRIC);

		boolean first = true;
		if (deviceType != null && !deviceType.isEmpty()) {
			if (first) {
				uriStr = uriStr.concat("?deviceType=" + deviceType);
				first = false;
			} else {
				uriStr = uriStr.concat("&deviceType=" + deviceType);
			}
		}
		if (deviceVersion != null && !deviceVersion.isEmpty()) {
			if (first) {
				uriStr = uriStr.concat("?deviceVersion=" + deviceVersion);
				first = false;
			} else {
				uriStr = uriStr.concat("&deviceVersion=" + deviceVersion);
			}
		}
		if (fqn != null && !fqn.isEmpty()) {
			if (first) {
				uriStr = uriStr.concat("?fqn=" + fqn);
				first = false;
			} else {
				uriStr = uriStr.concat("&fqn=" + fqn);
			}
		}

		if (first)
			return null;

		Reference uri = new Reference(uriStr);
		log.info("getMetricInfo uri is :" + uriStr);
		Response res = client.get(uri);
		try {

			String text = res.getEntity().getText().toString();

			log.info("getMetricInfo result is :" + text);
			Map<String, Object> map = JSONUtil.getComplexObject(text,
					new TypeReference<Map<String, Object>>() {
					});
			List<AplusMetricEntity> list = JSONUtil.getComplexObject(
					JSON.json(map.get("metricList")),
					new TypeReference<List<AplusMetricEntity>>() {
					});

			return list;
		} catch (IOException e) {
			throw e;
		}

	}

}

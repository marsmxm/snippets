package com.neusoft.aplus.databus.gui.control;

import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.Enumeration;
import java.util.List;
import java.util.regex.Pattern;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neusoft.aplus.cmdb.model.AplusDeviceWithAlarmCnt;
import com.neusoft.aplus.databus.gui.constant.AplusGuiConstant;
import com.neusoft.aplus.databus.gui.rest.RestAction;
import com.neusoft.aplus.databus.gui.rest.RestContant;
import com.neusoft.aplus.databus.gui.view.AplusDataBusLoginDialog;
import com.neusoft.aplus.databus.gui.view.AplusDataBusLoginView;
import com.neusoft.aplus.databus.gui.view.AplusDataBusNodeDialog;
import com.neusoft.aplus.databus.gui.view.AplusDataBusNodeListView;
import com.neusoft.aplus.databus.gui.view.AplusMainView;

/**
 * GUI主页面的控制类
 * 
 * @author WanWei
 * @date 2015-4-14 下午4:36:23
 */
public class AplusMainControl extends AplusBaseControl implements
		ActionListener, ListSelectionListener, MenuListener {

	private static Logger log = LoggerFactory
			.getLogger(AplusMainControl.class);

	private AplusMainView mainView;

	private AplusDataBusNodeListView nodeView;

	private AplusDataBusNodeDialog nodeDialog;

	private AplusDataBusLoginView loginView;

	private AplusDataBusLoginDialog loginDialog;

	private static AplusMainControl instance = new AplusMainControl();

	private AplusMainControl() {
		super();
		nodeDialog = new AplusDataBusNodeDialog();
		mainView = new AplusMainView();
		nodeView = new AplusDataBusNodeListView();
		loginDialog = new AplusDataBusLoginDialog();
		loginView = new AplusDataBusLoginView();

		initData();
		initListener();
	}

	/**
	 * 单例模式获取控制类实例
	 * 
	 * @return
	 * @author WanWei
	 * @date 2015-4-14 下午4:52:07
	 */
	public static AplusMainControl getInstance() {
		return instance;
	}

	@Override
	public void initData() {
		if (props != null) {
			String nodes = props.getProperty(AplusGuiConstant.NODE_CONF_NAME);
			if ((nodes != null) && (!nodes.isEmpty())) {
				// TODO 暂时未做数据格式正确性校验
				String[] nodeAry = nodes.trim().split(
						AplusGuiConstant.NODE_SEP_FOR_CONF);
				for (String node : nodeAry) {
					nodeView.addDataToNodeList(node);
				}
			}
		}
	}

	@Override
	public void initListener() {
		mainView.getFileMenu().addMenuListener(this);
		mainView.getAddMenuItem().addActionListener(this);
		mainView.getEditMenuItem().addActionListener(this);
		mainView.getDeleteMenuItem().addActionListener(this);
		mainView.getExitMenuItem().addActionListener(this);
		mainView.getAboutMenuItem().addActionListener(this);
		// nodeView.getNodeList().addListSelectionListener(this);
		nodeView.getNodeList().addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 2) {
					String nodeName = (String) nodeView.getNodeList()
							.getSelectedValue();
					nodelistDoubleClick(nodeName);
				}
			}
		});

		nodeDialog.getView().getConfirmButton().addActionListener(this);
		nodeDialog.getView().getCancelButton().addActionListener(this);

		loginDialog.getView().getConfirmButton().addActionListener(this);
		loginDialog.getView().getCancelButton().addActionListener(this);
		loginDialog.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				DisposeLoginAndMain();
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(mainView.getAddMenuItem())) {
			showNodeDialog(null, null, mainView,
					AplusGuiConstant.DIALOG_OPERMODE_ADD);
			saveDataBusNodes();
		}

		if (e.getSource().equals(mainView.getEditMenuItem())) {
			// TODO 选中一个节点才可编辑
			String node = (String) nodeView.getNodeList().getSelectedValue();
			// 程序设计如此, 不用做数据有效性检查
			String[] elements = node.split(":");
			String nodeIP = elements[0];
			int port = Integer.parseInt(elements[1]);
			showNodeDialog(nodeIP, port, mainView,
					AplusGuiConstant.DIALOG_OPERMODE_EDIT);
			saveDataBusNodes();
		}

		if (e.getSource().equals(mainView.getDeleteMenuItem())) {
			// TODO 选中一个节点才可删除
			int rerurnVar = JOptionPane.showConfirmDialog(mainView,
					"请确认是否删除所选节点?", AplusGuiConstant.CONFIRM_MARK,
					JOptionPane.YES_NO_OPTION);
			if (rerurnVar == JOptionPane.YES_OPTION) {
				nodeView.removeSelected();
			}
			saveDataBusNodes();
		}

		if (e.getSource().equals(mainView.getExitMenuItem())) {
			int rerurnVar = JOptionPane.showConfirmDialog(mainView,
					"请确认是否退出客户端?", AplusGuiConstant.CONFIRM_MARK,
					JOptionPane.YES_NO_OPTION);
			if (rerurnVar == JOptionPane.YES_OPTION) {
				JFrame frame = ((JFrame) mainView.getRootPane().getParent());
				// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(false);
				frame.dispose();
				System.exit(0);// 结束java进程
			}
		}

		if (e.getSource().equals(mainView.getAboutMenuItem())) {
			// TODO
		}

		if (e.getSource().equals(nodeDialog.getView().getConfirmButton())) {
			processNodeDialogConfirm();
		}

		if (e.getSource().equals(nodeDialog.getView().getCancelButton())) {
			nodeDialog.setVisible(false);
		}
		if (e.getSource().equals(loginDialog.getView().getCancelButton())) {
			DisposeLoginAndMain();
		}
		if (e.getSource().equals(loginDialog.getView().getConfirmButton())) {
			processLoginDialogConfirm();
		}
	}

	/**
	 * 关闭登录界面和主界面 点击登录界面的取消按钮或右上角关闭按钮时触发
	 * 
	 * @author wuhao
	 * @date 2015-4-16 下午4:12:57
	 */
	private void DisposeLoginAndMain() {
		loginDialog.dispose();
		mainView.getMainFrame().dispose();
	}

	/**
	 * DataBus Gui 登录确认操作
	 * 
	 * @author wuhao
	 * @date 2015-4-16 下午3:53:03
	 */
	@SuppressWarnings("deprecation")
	private void processLoginDialogConfirm() {
		String userStr = loginDialog.getView().getUserTextField().getText();
		String passStr = loginDialog.getView().getPassTextField().getText();

		if (userStr.isEmpty() || passStr.isEmpty()) {
			JOptionPane.showMessageDialog(loginDialog, "用户名密码不能为空!",
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
			return;
		}
		if (userStr.equals("dbus") && passStr.equals("dbus")) {
			loginDialog.setVisible(false);
			mainView.getMainFrame().setExtendedState(Frame.NORMAL);
			AplusPolicyManangerControl.getInstance().initData();
			AplusAlarmControl.getInstance().initData();
		} else {
			JOptionPane.showMessageDialog(loginDialog, "用户名密码错误!",
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
			return;
		}
	}

	/**
	 * DataBus节点对话框的确认操作
	 * 
	 * @author WanWei
	 * @date 2015-4-15 下午1:57:49
	 */
	private void processNodeDialogConfirm() {

		String ipStr = nodeDialog.getView().getIPTextField().getText();
		String portStr = nodeDialog.getView().getPortTextField().getText();
		if (ipStr.isEmpty() || portStr.isEmpty()) {
			JOptionPane.showMessageDialog(nodeDialog, "IP地址和端口不能为空!",
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
			return;
		}
		Pattern ipPattern = Pattern
				.compile("((25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1?\\d?\\d)");
		if (!ipPattern.matcher(ipStr).matches()) {
			JOptionPane.showMessageDialog(nodeDialog, "IP地址格式不正确,请重新输入!",
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
			return;
		}
		int operMode = nodeDialog.getOperMode();
		String nodeValue = ipStr.concat(AplusGuiConstant.NODE_SEP).concat(
				portStr);
		if (operMode == AplusGuiConstant.DIALOG_OPERMODE_ADD) {

			if (nodeView.getModel().contains(nodeValue)) {
				JOptionPane
						.showMessageDialog(nodeDialog, "该节点已经存在!",
								AplusGuiConstant.WARN_MARK,
								JOptionPane.WARNING_MESSAGE);
				return;
			} else {
				nodeView.addDataToNodeList(nodeValue);
			}
		} else {
			int index = nodeView.getNodeList().getSelectedIndex();
			nodeView.removeSelected();
			nodeView.getModel().insertElementAt(nodeValue, index);
			nodeView.getNodeList().setSelectedIndex(index);
		}
		nodeDialog.setVisible(false);
	}

	/**
	 * 
	 * 将已经添加到视图中的DataBus节点缓存到配置文件中
	 * 
	 * @author WanWei
	 * @date 2015-4-18 上午11:18:01
	 */
	private void saveDataBusNodes() {
		StringBuffer nodes = new StringBuffer();
		Enumeration<?> it = nodeView.getModel().elements();
		while (it.hasMoreElements()) {
			if (nodes.length() > 0) {
				nodes.append(AplusGuiConstant.NODE_SEP_FOR_CONF);
			}
			nodes.append(it.nextElement());
		}
		if (nodes.length() > 0) {
			props.setProperty(AplusGuiConstant.NODE_CONF_NAME, nodes.toString());
			saveProperty();
		}
	}

	/**
	 * 选中某个DataBus节点后, 引发主页分隔条右侧Panel的操作
	 */
	public void valueChanged(ListSelectionEvent event) {
		String node = (String) nodeView.getNodeList().getSelectedValue();
		// 程序设计如此, 不用做数据有效性检查
		// String[] elements = node.split(":");
		// String nodeIP = elements[0];
		// int port = Integer.parseInt(elements[1]);
		AplusWorkSpaceControl.getInstance().getView().setNavigation(node);
	
		initTypeTree(node);

	}

	/**
	 * 节点list双击事件
	 * 
	 * @param nodeName
	 * @author wuhao
	 * @date 2015-4-21 下午2:59:23
	 */
	private void nodelistDoubleClick(String nodeName) {
		AplusWorkSpaceControl.getInstance().getView().setNavigation(nodeName);
		RestContant.ip = nodeName.split(":")[0];
		RestContant.port=nodeName.split(":")[1];
		initTypeTree(nodeName);
	}

	/**
	 * 根据Databus节点，初始化设备类型信息
	 * 
	 * @param node
	 * @author wuhao
	 * @date 2015-4-21 下午2:26:38
	 */
	private void initTypeTree(String node) {
		
		List<AplusDeviceWithAlarmCnt> list=null;
		try {
//			list = RestAction
//					.findAllCategoryAndDeviceType();
			try {
				list  = RestAction.findDeviceInfo(null,null,null,null);
			} catch (IOException e) {
				JOptionPane.showMessageDialog(mainView,
						"查询告警级别信息失败!", AplusGuiConstant.ERROR_MARK,
						JOptionPane.ERROR_MESSAGE);
				log.error(e.getMessage());
				return;
			}
			if (list != null) {
				AplusCenterControl.getInstance().initTypeTree(list);
				}
		} catch (RuntimeException e) {
			JOptionPane
			.showMessageDialog(nodeDialog, "服务端连接异常!",
					AplusGuiConstant.WARN_MARK,
					JOptionPane.WARNING_MESSAGE);
		} 
	}

	/**
	 * 弹出node节点编辑对话框
	 * 
	 * @param ip
	 * @param port
	 * @param parent
	 *            对话框模态施加对象
	 * @param operMode
	 *            操作标记 新增或编辑
	 * @author WanWei
	 * @date 2015-4-14 下午5:48:18
	 */
	public void showNodeDialog(String ip, Integer port, JComponent parent,
			int operMode) {
		nodeDialog.getView().getIPTextField()
				.setText(AplusGuiConstant.EMPTY_STRING);
		nodeDialog.getView().getPortTextField()
				.setText(AplusGuiConstant.EMPTY_STRING);

		if (ip != null) {
			nodeDialog.getView().getIPTextField().setText(ip);
		}
		if (port != null) {
			nodeDialog.getView().getPortTextField().setText(port.toString());
		}
		nodeDialog.setLocationRelativeTo(parent);
		nodeDialog.setOperMode(operMode);
		nodeDialog.setVisible(true);

	}

	public void showLoginDialog(JComponent parent) {
		loginDialog.setLocationRelativeTo(parent);
		loginDialog.setVisible(true);
	}

	public AplusMainView getMainView() {
		return mainView;
	}

	public AplusDataBusNodeListView getNodeView() {
		return nodeView;
	}

	public AplusDataBusLoginView getLoginView() {
		return loginView;
	}

	@Override
	public void menuCanceled(MenuEvent arg0) {
		// do nothing

	}

	@Override
	public void menuDeselected(MenuEvent arg0) {
		// do nothing
	}

	@Override
	public void menuSelected(MenuEvent arg0) {
		if (nodeView.getNodeList().isSelectionEmpty()) {
			mainView.getEditMenuItem().setEnabled(false);
			mainView.getDeleteMenuItem().setEnabled(false);
		} else {
			mainView.getEditMenuItem().setEnabled(true);
			mainView.getDeleteMenuItem().setEnabled(true);
		}

	}
}

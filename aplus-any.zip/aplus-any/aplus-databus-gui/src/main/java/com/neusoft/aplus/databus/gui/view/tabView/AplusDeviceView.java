package com.neusoft.aplus.databus.gui.view.tabView;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import com.neusoft.aplus.databus.gui.view.AplusMainView;
import com.neusoft.aplus.databus.gui.view.AplusViewUtil;

/**
 * 设备信息视图类
 * 
 * @author wuhao
 * @date 2015-4-14 下午2:46:42
 */
public class AplusDeviceView extends JPanel {

	private static final long serialVersionUID = 2910638634855554743L;

	// private static Logger log = Logger.getLogger(AplusDeviceView.class);
	// AplusDeviceView的主Panel，所有的控件都基于此。
	private JPanel northPanel = null;
	private JPanel tablePanel = null;

	private JLabel deviceTypeLabel = null;
	private JLabel resNameLabel = null;

	private JComboBox deviceTypeComboBox = null;
	private JTextField resNameText = null;

	private JButton queryButton = null;
	private JButton resetButton = null;
	private JButton importButton = null;
	private JButton deviceInfoButton = null;

	private JTable deviceTable = null;

	private AplusMainView mainView = null;

	public AplusMainView getMainView() {
		return mainView;
	}

	public void setMainView(AplusMainView mainView) {
		this.mainView = mainView;
	}

	public AplusDeviceView() {
		init();
	}

	private void init() {
		this.setLayout(new BorderLayout());

		this.add(getNorthPanel(), BorderLayout.NORTH);
		this.add(getTablePanel(), BorderLayout.CENTER);
	}

	public JPanel getNorthPanel() {
		if (northPanel == null) {
			northPanel = AplusViewUtil.createBorderLayoutPanel();

			JPanel westPanel = AplusViewUtil.createGridLayoutPanel(2, 1,0,-5);

			// 查询条件第一行
			JPanel upPanel = AplusViewUtil.createFlowLayoutPanel();
			upPanel.add(getDeviceTypeLabel());
			upPanel.add(getDeviceTypeComboBox());
			upPanel.add(getResNameLabel());
			upPanel.add(getResNameText());

			JPanel downPanel = AplusViewUtil.createFlowLayoutPanel();

			westPanel.add(upPanel);
			westPanel.add(downPanel);

			JPanel buttonPanel = AplusViewUtil
					.createGridLayoutPanel(2, 1, 0, 5);
			
			buttonPanel.add(getQueryButton());
			buttonPanel.add(getResetButton());

			northPanel.add(westPanel, BorderLayout.CENTER);
			northPanel.add(buttonPanel, BorderLayout.EAST);

			Border border = AplusViewUtil.createPanelBorder("查询条件");
			northPanel.setBorder(border);
		}
		return northPanel;
	}

	public JPanel getTablePanel() {
		if (tablePanel == null) {
			tablePanel = AplusViewUtil.createBorderLayoutPanel();

			JScrollPane scroll = new JScrollPane();
			scroll.setViewportView(getDeviceTable());
			scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

			setColumnSize();

			JPanel buttonPanel = AplusViewUtil.createGridLayoutPanel(2, 1, 0, 3);
			buttonPanel.add(getImportButton());
			buttonPanel.add(getDeviceInfoButton());

			JPanel eastPanel = AplusViewUtil.createBorderLayoutPanel();
			JPanel blankLabel = new JPanel();

			Dimension blankSize = new Dimension((int) getImportButton()
					.getSize().getWidth(),
					(int) (scroll.getSize().getHeight() - getImportButton()
							.getSize().getHeight() * 2));
			blankLabel.setMaximumSize(blankSize);
			blankLabel.setMinimumSize(blankSize);
			
			eastPanel.add(buttonPanel, BorderLayout.SOUTH);
			eastPanel.add(blankLabel, BorderLayout.CENTER);

			tablePanel.add(scroll, BorderLayout.CENTER);
			tablePanel.add(eastPanel, BorderLayout.EAST);

			Border border = AplusViewUtil.createPanelBorder("设备列表");
			tablePanel.setBorder(border);

		}
		return tablePanel;
	}

	private void setColumnSize() {
		TableColumnModel cm = getDeviceTable().getColumnModel(); // 表格的列模型
		cm.getColumn(3).setPreferredWidth(250);
		cm.getColumn(4).setPreferredWidth(250);
	}

	@SuppressWarnings("serial")
	public JTable getDeviceTable() {
		if (deviceTable == null) {
			DefaultTableModel tableModel = new DefaultTableModel();
			tableModel.addColumn("设备名称");
			tableModel.addColumn("设备类型");
			tableModel.addColumn("设备版本");
			tableModel.addColumn("位置");
			tableModel.addColumn("其他");

			deviceTable = new JTable(tableModel){
				public boolean isCellEditable(int row, int column) {
					return false;
				};
			};
			deviceTable.setEnabled(true);
			
			deviceTable.setAutoCreateRowSorter(true);
			deviceTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			deviceTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		}

		return deviceTable;
	}

	public JLabel getDeviceTypeLabel() {
		if (deviceTypeLabel == null) {
			deviceTypeLabel = new JLabel("设备类型:");
		}
		return deviceTypeLabel;
	}

	public JLabel getResNameLabel() {
		if (resNameLabel == null) {
			resNameLabel = new JLabel("  资源名称:");
		}
		return resNameLabel;
	}

	public JComboBox getDeviceTypeComboBox() {
		if (deviceTypeComboBox == null) {
			deviceTypeComboBox = AplusViewUtil.getComboBox(200,AplusViewUtil.comboBoxdefaulheight);
		}
		return deviceTypeComboBox;
	}

	public JTextField getResNameText() {
		if (resNameText == null) {
			resNameText = AplusViewUtil.createJTextFiled();
		}
		return resNameText;
	}

	public JButton getQueryButton() {
		if (queryButton == null) {
			queryButton = AplusViewUtil.createButton("查询");
		}
		return queryButton;
	}

	public JButton getResetButton() {
		if (resetButton == null) {
			resetButton = AplusViewUtil.createButton("重置");
		}
		return resetButton;
	}

	public JButton getImportButton() {
		if (importButton == null) {
			importButton = AplusViewUtil.createButton("导入设备");
		}
		return importButton;
	}

	public JButton getDeviceInfoButton() {
		if (deviceInfoButton == null) {
			deviceInfoButton = AplusViewUtil.createButton("设备详情");
		}
		return deviceInfoButton;
	}

}

package com.neusoft.aplus.databus.gui.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.dubbo.common.json.JSON;
import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.databus.gui.constant.AplusGuiConstant;
import com.neusoft.aplus.databus.gui.rest.RestAction;
import com.neusoft.aplus.databus.gui.rest.RestContant;
import com.neusoft.aplus.databus.gui.view.tabView.AplusAlarmView;
import com.neusoft.aplus.policy.biz.service.model.POLCAlertEntity;
import com.neusoft.aplus.policy.biz.service.model.POLCAlertFixedEntity;
import com.neusoft.aplus.policy.biz.service.model.POLCAlertParameters;
import com.neusoft.aplus.service.core.transcoding.biz.service.bo.model.DataDictionaryParameters;

/**
 * @author wuhao
 * @date 2015-4-17 上午10:31:18
 */
public class AplusAlarmControl extends AplusBaseControl {

	private AplusAlarmView alarmView = null;// 告警视图
	private static AplusAlarmControl instance = new AplusAlarmControl();
	private String resName = null;
	private List<DataDictionaryParameters> dataDictionaryParametersList = null;
	private static Logger log = LoggerFactory
			.getLogger(AplusAlarmControl.class);

	// private

	private AplusAlarmControl() {
		super();
		alarmView = new AplusAlarmView();
		// initData();
		initListener();
	}

	public static AplusAlarmControl getInstance() {
		return instance;
	}

	@Override
	public void initData() {
		// 初始化告警级别
		try {
			dataDictionaryParametersList = RestAction
					.findDictionary(RestContant.ALARM_LEVEL);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(alarmView.getMainView(),
					"查询告警级别信息失败!", AplusGuiConstant.ERROR_MARK,
					JOptionPane.ERROR_MESSAGE);
			log.error(e.getMessage());
			return;
		}
		int[] level = new int[dataDictionaryParametersList.size()];
		int i = 0;
		for (DataDictionaryParameters d : dataDictionaryParametersList) {
			level[i] = Integer.valueOf(d.getCode());
			i++;
		}
		Arrays.sort(level);

		JComboBox alarmLevelComboBox = alarmView.getArarmLevelComboBox();
		alarmLevelComboBox.removeAllItems();
		for (int j : level) {
			for (DataDictionaryParameters d : dataDictionaryParametersList) {
				if (Integer.valueOf(d.getCode()) == j) {
					alarmLevelComboBox.addItem(d.getDetail());
					break;
				}
			}
		}
	}

	@Override
	public void initListener() {
		alarmView.getQueryButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				alarmView.setCurrPage(1);
				processPageQuery();
				setButtonEnable();
			}
		});

		alarmView.getResetButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				processReset();
			}
		});
		alarmView.getConfirmButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				processConfirm();
			}
		});
		alarmView.getDeleteButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				processDelete();
			}
		});
		alarmView.getFirstButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				alarmView.setCurrPage(1);
				processPageQuery();
			}
		});

		alarmView.getPreButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				alarmView.setCurrPage(alarmView.getCurrPage() - 1);
				processPageQuery();

			}
		});
		alarmView.getNextButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				alarmView.setCurrPage(alarmView.getCurrPage() + 1);
				processPageQuery();
			}
		});
		alarmView.getLastButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				alarmView.setCurrPage(alarmView.getTotalPage());
				processPageQuery();
			}
		});
	}

	public AplusAlarmView getView() {
		return alarmView;
	}

	private void processConfirm() {
		List<String> idList = getAlarmId();
		if (idList.size() > 0) {
			if (RestAction.ConfirmAlarm(idList)) {
				JOptionPane.showMessageDialog(alarmView.getMainView(),
						"批量确认告警成功!", AplusGuiConstant.MESSAGE_MARK,
						JOptionPane.INFORMATION_MESSAGE);
				setValueAfterOperate("已确认告警");
			} else {
				JOptionPane.showMessageDialog(alarmView.getMainView(),
						"批量确认告警失败!", AplusGuiConstant.ERROR_MARK,
						JOptionPane.ERROR_MESSAGE);
			}
		}

	}

	/***
	 * 删除历史数据
	 * 
	 * @author wuhao
	 * @date 2015-4-23 上午7:46:54
	 */
	private void processDelete() {
		List<String> idList = getAlarmId();
		if (idList.size() > 0) {
			if (RestAction.DeleteAlarm(idList)) {
				JOptionPane.showMessageDialog(alarmView.getMainView(),
						"批量删除历史成功!", AplusGuiConstant.MESSAGE_MARK,
						JOptionPane.INFORMATION_MESSAGE);
				setValueAfterOperate("已删除历史");
			} else {
				JOptionPane.showMessageDialog(alarmView.getMainView(),
						"批量删除历史失败!", AplusGuiConstant.ERROR_MARK,
						JOptionPane.ERROR_MESSAGE);
			}
		}

	}

	private void setValueAfterOperate(String value) {
		DefaultTableModel model = (DefaultTableModel) alarmView.getAlarmTable()
				.getModel();

		for (int i = 0; i < model.getRowCount(); i++) {
			if (model.getValueAt(i, 0).toString().equals("true")) {
				model.setValueAt(value, i, 5);
			}
		}

		alarmView.getAlarmTable().updateUI();
	}

	/**
	 * 获取选中的告警id
	 * 
	 * @return
	 * @author wuhao
	 * @date 2015-4-23 下午2:10:51
	 */
	private List<String> getAlarmId() {
		List<String> idList = new ArrayList<String>();

		DefaultTableModel model = (DefaultTableModel) alarmView.getAlarmTable()
				.getModel();

		for (int i = 0; i < model.getRowCount(); i++) {
			if (model.getValueAt(i, 0).toString().equals("true")) {
				Object o = model.getValueAt(i, 5);
				if (o != null && o.toString().length() > 0) {
					JOptionPane.showMessageDialog(alarmView.getMainView(),
							"请选择未处理的数据!", AplusGuiConstant.ERROR_MARK,
							JOptionPane.ERROR_MESSAGE);
					idList.clear();
					return idList;
				}
				idList.add(model.getValueAt(i, 7).toString());
			}
		}

		if (idList.size() == 0) {
			JOptionPane.showMessageDialog(alarmView.getMainView(),
					"请至少选择一条数据!", AplusGuiConstant.ERROR_MARK,
					JOptionPane.ERROR_MESSAGE);
		}
		return idList;
	}

	/**
	 * 每次点击查询时，保存当前的查询条件
	 * 
	 * @author wuhao
	 * @date 2015-4-23 上午7:49:28
	 */
	private POLCAlertParameters getQueryParam() {

		POLCAlertParameters parameter = new POLCAlertParameters();

		if (alarmView.getResourcesNameText().getText() != null
				&& alarmView.getResourcesNameText().getText().length() > 0) {
			parameter.getMapParameters().put(POLCAlertParameters.RESNAME,
					alarmView.getResourcesNameText().getText());
		}
		if (alarmView.getDeviceTypeComboBox().getSelectedItem() != null
				&& alarmView.getDeviceTypeComboBox().getSelectedItem()
						.toString().length() > 0) {
			String typeVersion = alarmView.getDeviceTypeComboBox()
					.getSelectedItem().toString();

			parameter.getMapParameters().put(POLCAlertParameters.RESTYPE,
					typeVersion.split(" ")[0]);
			parameter.getMapParameters().put(POLCAlertParameters.RESVERSION,
					typeVersion.split(" ")[1]);
		}
		if (alarmView.getArarmLevelComboBox().getSelectedItem() != null
				&& alarmView.getArarmLevelComboBox().getSelectedItem()
						.toString().length() > 0) {

			String alarmStr = alarmView.getArarmLevelComboBox()
					.getSelectedItem().toString();
			String alarmId = "";
			for (DataDictionaryParameters p : dataDictionaryParametersList) {
				if (p.getDetail().equals(alarmStr)) {
					alarmId = p.getCode();
					break;
				}
			}
			parameter.getMapParameters().put(POLCAlertParameters.PRIORITY,
					Integer.valueOf(alarmId));
		}
		return parameter;
	}

	/**
	 * 每次点击查询时，设置删除历史和告警确认按钮是否可以用
	 * 
	 * @author wuhao
	 * @date 2015-4-23 上午7:50:09
	 */
	private void setButtonEnable() {
		if (alarmView.getUndoneRadio().isSelected()) {
			alarmView.getDeleteButton().setEnabled(false);
			alarmView.getConfirmButton().setEnabled(true);
		} else {
			alarmView.getDeleteButton().setEnabled(true);
			alarmView.getConfirmButton().setEnabled(false);
		}
	}

	/**
	 * 查询条件重置
	 * 
	 * @author wuhao
	 * @date 2015-4-23 上午7:44:55
	 */
	private void processReset() {
		if (alarmView.getDeviceTypeComboBox().getItemCount() > 0) {
			alarmView.getDeviceTypeComboBox().setSelectedIndex(0);
		}
		if (alarmView.getArarmLevelComboBox().getItemCount() > 0) {
			alarmView.getArarmLevelComboBox().setSelectedIndex(0);
		}
		alarmView.getUndoneRadio().setSelected(true);
		alarmView.getResourcesNameText().setText(AplusGuiConstant.EMPTY_STRING);

	}

	private void processPageQuery() {
		int currPage = alarmView.getCurrPage();
		int pageSize = alarmView.getPageSize();

		int currCount = 0;
		Map<String, Object> resultMap = null;
		try {
		// 判断告警类型
		if (alarmView.getUndoneRadio().isSelected()) {
			resultMap = RestAction.findUnFixedAlarm(currPage, pageSize,
					getQueryParam());// 未处理

		} else {
			resultMap = RestAction.findFixedAlarm(currPage, pageSize,
					getQueryParam());// 历史

		}

		// 获取list 和count
		if (resultMap != null) {
			

				currCount = JSONUtil.getComplexObject(
						JSON.json(resultMap.get("totalSize")),
						new TypeReference<Integer>() {
						});

				if (alarmView.getUndoneRadio().isSelected()) {
					List<POLCAlertEntity> alertEntityList = JSONUtil
							.getComplexObject(
									JSON.json(resultMap.get("itemList")),
									new TypeReference<List<POLCAlertEntity>>() {
									});

					if (alertEntityList.size() == 0) {
						// 如果查询时，后台数据减少了，则可能查不到数据
						JOptionPane.showMessageDialog(alarmView.getMainView(),
								"当前页无查询结果!", AplusGuiConstant.ERROR_MARK,
								JOptionPane.ERROR_MESSAGE);
					}
					DefaultTableModel model = (DefaultTableModel) alarmView
							.getAlarmTable().getModel();
					model.getDataVector().clear(); // 清除表格数据

					for (POLCAlertEntity polcalertentity : alertEntityList) {
						Vector<Object> v = new Vector<Object>();
						v.add(new Boolean(false));
						v.add(polcalertentity.getPriority());
						v.add(polcalertentity.getContent());
						v.add(polcalertentity.getResName());
						v.add(polcalertentity.getCreateTime());
						v.add("");
						v.add("未处理告警");
						v.add(polcalertentity.getSimilarid());
						model.addRow(v);

					}

				} else {
					List<POLCAlertFixedEntity> alertEntityList = JSONUtil
							.getComplexObject(
									JSON.json(resultMap.get("itemList")),
									new TypeReference<List<POLCAlertFixedEntity>>() {
									});

					if (alertEntityList.size() == 0) {
						// 如果查询时，后台数据减少了，则可能查不到数据
						JOptionPane.showMessageDialog(alarmView.getMainView(),
								"当前页无查询结果!", AplusGuiConstant.MESSAGE_MARK,
								JOptionPane.INFORMATION_MESSAGE);
					}
					DefaultTableModel model = (DefaultTableModel) alarmView
							.getAlarmTable().getModel();
					model.getDataVector().clear(); // 清除表格数据

					for (POLCAlertFixedEntity polcalertentity : alertEntityList) {
						Vector<Object> v = new Vector<Object>();
						v.add(new Boolean(false));
						v.add(polcalertentity.getPriority());
						v.add(polcalertentity.getContent());
						v.add(polcalertentity.getResName());
						v.add(polcalertentity.getCreateTime());
						v.add("");
						v.add("历史告警");
						v.add(polcalertentity.getId());
						model.addRow(v);

					}
				}}
			} catch (IOException e) {
				JOptionPane.showMessageDialog(alarmView.getMainView(),
						"查询数据放回格式不正确!", AplusGuiConstant.ERROR_MARK,
						JOptionPane.ERROR_MESSAGE);
				log.error(e.getMessage());
			}
		
		getCurrTotalResult(pageSize, currPage, currCount);
	}

	/**
	 * 每次查询时调用，获取当前数据量。根据当前数据量设置分页按钮状态。
	 * 
	 * @author wuhao
	 * @date 2015-4-20 上午9:28:57
	 */
	private void getCurrTotalResult(int pageSize, int currPage, int currCount) {

		// TODO 调用接口，获取数据量。
		int pageCount = currCount / pageSize;// 总页数
		if (currCount % pageSize != 0) {
			pageCount++;
		}

		if (pageCount > currPage) {
			if (currPage != 1) {
				setPageButtonEnable(AplusGuiConstant.PAGE_MIDDLE);// 总页数大于当前页，且当前页不是第一页，则当前页为中间页。
			} else {
				setPageButtonEnable(AplusGuiConstant.PAGE_FIRST);// 总页数大于当前页，且当前页是第一页，则当前页为第一页。
			}
		} else if (pageCount == currPage) {
			if (currPage != 1) {
				setPageButtonEnable(AplusGuiConstant.PAGE_LAST);// 总页数等于当前页，且当前页不是第一页，则当前页为尾页。
			} else {
				setPageButtonEnable(AplusGuiConstant.PAGE_SINGLE);// 总页数等于当前页，且当前页是第一页，则总共只有一页。
			}
		}
	}

	/**
	 * 设置分页按钮的可用性
	 * 
	 * @author wuhao
	 * @date 2015-4-18 下午2:12:15
	 */
	private void setPageButtonEnable(int pageStatus) {
		if (pageStatus == AplusGuiConstant.PAGE_FIRST) {
			alarmView.getFirstButton().setEnabled(false);
			alarmView.getPreButton().setEnabled(false);
			alarmView.getNextButton().setEnabled(true);
			alarmView.getLastButton().setEnabled(true);
		} else if (pageStatus == AplusGuiConstant.PAGE_MIDDLE) {
			alarmView.getFirstButton().setEnabled(true);
			alarmView.getPreButton().setEnabled(true);
			alarmView.getNextButton().setEnabled(true);
			alarmView.getLastButton().setEnabled(true);
		} else if (pageStatus == AplusGuiConstant.PAGE_LAST) {
			alarmView.getFirstButton().setEnabled(true);
			alarmView.getPreButton().setEnabled(true);
			alarmView.getNextButton().setEnabled(false);
			alarmView.getLastButton().setEnabled(false);
		} else if (pageStatus == AplusGuiConstant.PAGE_SINGLE) {
			alarmView.getFirstButton().setEnabled(false);
			alarmView.getPreButton().setEnabled(false);
			alarmView.getNextButton().setEnabled(false);
			alarmView.getLastButton().setEnabled(false);
		}
	}

	public String getResName() {
		return resName;
	}

	public void setResName(String resName) {
		this.resName = resName;
	}
}

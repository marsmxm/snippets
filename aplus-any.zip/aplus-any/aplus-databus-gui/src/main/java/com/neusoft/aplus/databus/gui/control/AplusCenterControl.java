package com.neusoft.aplus.databus.gui.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import javax.swing.JComboBox;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

import com.alibaba.fastjson.JSONObject;
import com.neusoft.aplus.cmdb.model.AplusDeviceWithAlarmCnt;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.databus.gui.constant.AplusGuiConstant;
import com.neusoft.aplus.databus.gui.view.AplusCenterView;
import com.neusoft.aplus.model.bizentity.DeviceTypeId;

/**
 * 业务主界面控制类
 * 
 * @author wuhao
 * @date 2015-4-16 下午5:08:53
 */
public class AplusCenterControl extends AplusBaseControl {

	private AplusCenterView centerView;

	private static AplusCenterControl instance = new AplusCenterControl();
	private Map<String, List<String>> typeMap = null;

	private AplusCenterControl() {
		super();
		centerView = new AplusCenterView();

		AplusDeviceControl.getInstance().getView()
				.setMainView(centerView.getMainView());
		AplusPolicyControl.getInstance().getView()
				.setMainView(centerView.getMainView());
		AplusAlarmControl.getInstance().getView()
				.setMainView(centerView.getMainView());
		AplusPointControl.getInstance().getView()
		.setMainView(centerView.getMainView());

		initData();
		initListener();
	}

	@Override
	public void initData() {
		// 初始化树状图
		initTreeList();
		centerView.getTabPanel().setEnabledAt(0, false);
		centerView.getTabPanel().setEnabledAt(1, false);
		centerView.getTabPanel().setEnabledAt(2, false);
		centerView.getTabPanel().setEnabledAt(3, false);
		// 告警级别
	}

	// 初始化设备类型
	private void initDeviceType(List<String> deviceTypeList) {

		initDeviceTypeComboBox(AplusDeviceControl.getInstance().getView()
				.getDeviceTypeComboBox(), deviceTypeList);

		initDeviceTypeComboBox(AplusPointControl.getInstance().getView()
				.getDeviceTypeComboBox(), deviceTypeList);

		initDeviceTypeComboBox(AplusAlarmControl.getInstance().getView()
				.getDeviceTypeComboBox(), deviceTypeList);

		initDeviceTypeComboBox(AplusPolicyControl.getInstance().getView()
				.getDeviceTypeComboBox(), deviceTypeList);

	}

	private void initDeviceTypeComboBox(JComboBox comboBox,
			List<String> deviceTypeList) {

		comboBox.removeAllItems();
		for (String typeVersion : deviceTypeList) {
			comboBox.addItem(typeVersion);
		}

		if (comboBox.getItemCount() > 0) {
			comboBox.setSelectedIndex(0);
		}
	}

	/**
	 * 设置后视图当前在操作的类别
	 * 
	 * @param name
	 * @author wuhao
	 * @date 2015-4-21 下午5:59:08
	 */
	private void setResName(String resName) {
		AplusPolicyControl.getInstance().setResName(resName);
		AplusPointControl.getInstance().setResName(resName);
		AplusAlarmControl.getInstance().setResName(resName);
		AplusAlarmControl.getInstance().getView().getResourcesNameText()
				.setText(resName.split("/")[0]);
		AplusPointControl.getInstance().getView().getResNameText()
				.setText(resName.split("/")[0]);

		if (resName.equals(AplusGuiConstant.EMPTY_STRING)) {
			setCompomentEnabled(true);// 全部，类型
		} else {

			setCompomentEnabled(false);// 设备
		}
	}

	private void setCompomentEnabled(boolean bool) {
		AplusAlarmControl.getInstance().getView().getResourcesNameText()
				.setEnabled(bool);
		AplusPointControl.getInstance().getView().getResNameText()
				.setEnabled(bool);
	}

	// 初始化树状图
	private void initTreeList() {
		// centerView.getTypeTree();
	}

	@Override
	public void initListener() {
		centerView.getSearchText().addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				fliterTreeType();
				super.keyPressed(e);
			}
		});
		centerView.getSearchButton().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				centerView.getSearchText().setText(
						AplusGuiConstant.EMPTY_STRING);
				fliterTreeType();
			}
		});
		centerView.getTypeTree().addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if (e.getClickCount() == 2) {
					TreePath selPath = centerView.getTypeTree()
							.getPathForLocation(e.getX(), e.getY());
					if (selPath != null && getTypeMap() != null) {
						TreeNode node = (TreeNode) selPath
								.getLastPathComponent();
						initTabView(node);
					}
				}
			}
		});
	}

	/**
	 * 根据树节点，显示对应的视图
	 * 
	 * @author wuhao
	 * @date 2015-4-21 下午5:27:55
	 */
	void initTabView(TreeNode node) {

		if (node.getParent() == null) {// 如果选择了根节点，则初始化设备视图
			setResName(AplusGuiConstant.EMPTY_STRING);
			initDeviceType(AplusGuiConstant.TREE_ROOT, node);
			AplusPolicyControl.getInstance().getView().getMetricNameComboBox()
					.removeAllItems();
			AplusPolicyControl.getInstance().getView().getMetricNameComboBox()
					.setEnabled(false);
			AplusPolicyControl.getInstance().getView().getAddButton()
					.setEnabled(false);
			AplusWorkSpaceControl.getInstance().getView()
					.setSubNavigation(node.toString());

			centerView.getTabPanel().setEnabledAt(0, true);
			centerView.getTabPanel().setEnabledAt(1, true);
			centerView.getTabPanel().setEnabledAt(2, true);
			centerView.getTabPanel().setEnabledAt(3, true);
		} else if (node.isLeaf()) {// 如果选择了设备节点
			setResName(node.toString());

			initDeviceType(AplusGuiConstant.TREE_TYPE, node);
			AplusPolicyControl.getInstance().getView().getMetricNameComboBox()
					.setEnabled(true);
			AplusPolicyControl.getInstance().getView().getAddButton()
					.setEnabled(true);
			initChildNodeSelected();

			AplusWorkSpaceControl
					.getInstance()
					.getView()
					.setSubNavigation(node.getParent().getParent().toString(),
							node.getParent().toString(), node.toString());

			centerView.getTabPanel().setEnabledAt(0, false);
			centerView.getTabPanel().setEnabledAt(1, true);
			centerView.getTabPanel().setEnabledAt(2, true);
			centerView.getTabPanel().setEnabledAt(3, true);

		} else {// 如果选择了设备类型节点，则显示设备视图，且设备类型固定
			setResName(AplusGuiConstant.EMPTY_STRING);
			initDeviceType(AplusGuiConstant.TREE_CATEGORY, node);
			AplusPolicyControl.getInstance().getView().getMetricNameComboBox()
					.setEnabled(true);
			AplusPolicyControl.getInstance().getView().getAddButton()
					.setEnabled(true);
			AplusWorkSpaceControl
					.getInstance()
					.getView()
					.setSubNavigation(node.getParent().toString(),
							node.toString());

			centerView.getTabPanel().setEnabledAt(0, true);
			centerView.getTabPanel().setEnabledAt(1, true);
			centerView.getTabPanel().setEnabledAt(2, true);
			centerView.getTabPanel().setEnabledAt(3, true);
		}

	}

	/**
	 * 根据选择的节点，初始化设备类型comboBox
	 * 
	 * @param treeNodeSelected
	 * @param node
	 * @author wuhao
	 * @date 2015-4-22 下午5:45:16
	 */
	private void initDeviceType(int treeNodeSelected, TreeNode node) {

		List<String> typeList = new ArrayList<String>();

		if (treeNodeSelected == AplusGuiConstant.TREE_ROOT) {
			for (String key : getTypeMap().keySet()) {
				typeList.add(key);
			}
		} else if (treeNodeSelected == AplusGuiConstant.TREE_TYPE) {
			typeList.add(node.getParent().toString());
			AplusPolicyControl.getInstance().initMetricNameComboBox(
					node.getParent().toString());
		} else if (treeNodeSelected == AplusGuiConstant.TREE_CATEGORY) {
			String selected_category = node.toString();
			typeList.add(selected_category);
			AplusPolicyControl.getInstance().initMetricNameComboBox(
					selected_category);
		}

		initDeviceType(typeList);
	}

	/**
	 * 设备类型节点选择
	 * 
	 * @author wuhao
	 * @date 2015-4-21 下午5:45:55
	 */
	private void initChildNodeSelected() {

		int index = centerView.getTabPanel().getSelectedIndex();
		// 如果当前选择的是设备视图，则默认跳到策略视图
		if (index == 0) {
			centerView.getTabPanel().setSelectedIndex(1);
		}
	}

	/**
	 * 过滤数据
	 * 
	 * @author wuhao
	 * @date 2015-4-21 下午3:49:09
	 */
	private void fliterTreeType() {
		if (getTypeMap() != null) {
			String text = centerView.getSearchText().getText().toString()
					.toLowerCase();
			if (text.isEmpty()) {
				initTypeTree(getTypeMap());
			} else {
				initTypeTreeByText(text);
			}
		}
	}

	/**
	 * 根据过滤条件初始化tree
	 * 
	 * @param text
	 * @author wuhao
	 * @date 2015-4-21 下午4:46:24
	 */
	private void initTypeTreeByText(String text) {
		Map<String, List<String>> map = getTypeMap();
		DefaultTreeModel model = (DefaultTreeModel) centerView.getTypeTree()
				.getModel();
		MutableTreeNode root = (MutableTreeNode) model.getRoot();
		// 清空
		while (root.getChildCount() != 0) {
			root.remove(0);
		}
		int categoryCount = 0;
		for (String category : map.keySet()) {
			if (category.toLowerCase().indexOf(text) != -1) {
				DefaultMutableTreeNode categorynode = new DefaultMutableTreeNode(
						category);
				List<String> list = typeMap.get(category);
				for (String string : list) {
					categorynode.add(new DefaultMutableTreeNode(string));
				}
				model.insertNodeInto(categorynode,
						(MutableTreeNode) model.getRoot(), categoryCount);
				categoryCount++;
			} else {
				DefaultMutableTreeNode categorynode = null;
				List<String> list = typeMap.get(category);
				for (String string : list) {
					if (string.toLowerCase().indexOf(text) != -1) {
						if (categorynode == null) {
							categorynode = new DefaultMutableTreeNode(category);
						}
						categorynode.add(new DefaultMutableTreeNode(string));
					}

				}
				if (categorynode != null) {
					model.insertNodeInto(categorynode,
							(MutableTreeNode) model.getRoot(), categoryCount);
					categoryCount++;
				}
			}
		}
		centerView.getTypeTree().updateUI();

	}

	/**
	 * 初始化树装图
	 * 
	 * @param map
	 * @author wuhao
	 * @date 2015-4-22 上午11:34:04
	 */
	@SuppressWarnings("unchecked")
	public void initTypeTree(List<AplusDeviceWithAlarmCnt> list) {

		Map<String, List<String>> typeMap = new HashMap<String, List<String>>();

		for (AplusDeviceWithAlarmCnt cnt : list) {
			String typeVersion = cnt.getDeviceType() + " "
					+ cnt.getDeviceVersion();
			if (typeMap.containsKey(typeVersion)) {
				typeMap.get(typeVersion)
						.add(cnt.getName() + "/" + cnt.getFqn());
			} else {
				List<String> deviceList = new ArrayList<String>();
				deviceList.add(cnt.getName() + "/" + cnt.getFqn());
				typeMap.put(typeVersion, deviceList);
			}
		}

		setTypeMap(typeMap);
		initTypeTree(typeMap);
	}

	private void initTypeTree(Map<String, List<String>> typeMap) {
		DefaultTreeModel model = (DefaultTreeModel) centerView.getTypeTree()
				.getModel();
		MutableTreeNode root = (MutableTreeNode) model.getRoot();
		// 清空
		while (root.getChildCount() != 0) {
			root.remove(0);
		}
		int categoryCount = 0;
		for (String category : typeMap.keySet()) {
			DefaultMutableTreeNode categorynode = new DefaultMutableTreeNode(
					category);
			List<String> list = typeMap.get(category);
			for (String string : list) {
				categorynode.add(new DefaultMutableTreeNode(string));
			}
			model.insertNodeInto(categorynode,
					(MutableTreeNode) model.getRoot(), categoryCount);
			categoryCount++;
		}
		centerView.getTypeTree().updateUI();
	}

	/**
	 * 单例模式
	 * 
	 * @return
	 * @author wuhao
	 * @date 2015-4-16 下午5:11:36
	 */
	public static AplusCenterControl getInstance() {
		return instance;
	}

	public AplusCenterView getView() {
		return centerView;
	}

	public Map<String, List<String>> getTypeMap() {
		return typeMap;
	}

	public void setTypeMap(Map<String, List<String>> typeMap) {
		this.typeMap = typeMap;
	}
}

package com.neusoft.aplus.databus.gui.view.tabView;

import java.awt.Component;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import javax.swing.AbstractCellEditor;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.ui.RectangleEdge;

import com.neusoft.aplus.databus.gui.view.AplusLineChartPanel;
import com.neusoft.aplus.model.bizentity.AplusHistoryMetricData;
import com.neusoft.aplus.model.bizentity.AplusMetricDataPoint;

/**
 * @author wuhao
 * @date 2015-4-20 下午3:31:56
 */
public class AplusChartRender extends AbstractCellEditor implements TableCellRenderer, TableCellEditor{

	
	private static final long serialVersionUID = -4364502006041367064L;
	
	private AplusLineChartPanel panel = null;
	
	public AplusChartRender(){
		panel = new AplusLineChartPanel(AplusLineChartPanel.createChart("","",new ArrayList<AplusMetricDataPoint>(0)),null);
		panel.addChartMouseListener(new ChartMouseListener() {
			public void chartMouseClicked(ChartMouseEvent paramChartMouseEvent) {
			}

			public void chartMouseMoved(ChartMouseEvent paramChartMouseEvent) {
				Rectangle2D localRectangle2D = panel
						.getScreenDataArea();
				JFreeChart localJFreeChart = paramChartMouseEvent.getChart();
				XYPlot localXYPlot = (XYPlot) localJFreeChart.getPlot();
				ValueAxis localValueAxis = localXYPlot.getDomainAxis();
				double d1 = localValueAxis.java2DToValue(paramChartMouseEvent
						.getTrigger().getX(), localRectangle2D,
						RectangleEdge.BOTTOM);
				panel.getxCrosshair().setValue(d1);
				for (int i = 0; i < 3; i++) {
					double d2 = DatasetUtilities.findYValue(
							localXYPlot.getDataset(), i, d1);
					panel.getyCrosshairs()[i].setValue(d2);
				}
			}
		});
	}

	@Override
	public Component getTableCellRendererComponent(JTable table, Object value,
			boolean isSelected, boolean hasFocus, int row, int column) {
		panel.setData((AplusHistoryMetricData)value);
		return panel;
	}

	@Override
	public Object getCellEditorValue() {
		return panel.getData();
	}

	@Override
	public Component getTableCellEditorComponent(JTable table, Object value,
			boolean isSelected, int row, int column) {
		panel.setData((AplusHistoryMetricData)value);
		return panel;
	}

}

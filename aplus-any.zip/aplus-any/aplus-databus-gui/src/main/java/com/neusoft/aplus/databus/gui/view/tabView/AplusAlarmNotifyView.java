package com.neusoft.aplus.databus.gui.view.tabView;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextArea;

import com.neusoft.aplus.databus.gui.view.AplusBaseView;

/**
 * @author wuhao
 * @date 2015-4-20 下午1:33:04
 */
public class AplusAlarmNotifyView extends AplusBaseView{

	private static final long serialVersionUID = 4338417151285593891L;

	public AplusAlarmNotifyView(){
		initLayout("AlarmNotifyView.xml");
	}
	
	public JRadioButton getAlarmRadioButton(){
		return (JRadioButton)injection.getComponentById("databus_alarm_button");
	}
	public JRadioButton getEventRadioButton(){
		return (JRadioButton)injection.getComponentById("databus_event_button");
	}
	public JRadioButton getTriEveryRadioButton(){
		return (JRadioButton)injection.getComponentById("databus_tri_every_button");
	}
	public JRadioButton getTriCountRadioButton(){
		return (JRadioButton)injection.getComponentById("databus_tri_count_button");
	}
	public JRadioButton getClearEveryRadioButton(){
		return (JRadioButton)injection.getComponentById("databus_clear_every_button");
	}
	public JRadioButton getClearCountRadioButton(){
		return (JRadioButton)injection.getComponentById("databus_clear_count_button");
	}
	public JTextArea getContextTextArea(){
		return (JTextArea)injection.getComponentById("databus_context_area");
	}
	public JButton getAddButton(){
		return (JButton)injection.getComponentById("databus_add_button");
	}
	public JSpinner getTriSpinner(){
		return (JSpinner)injection.getComponentById("databus_tri_count_spinner");
	}
	public JSpinner getClearSpinner(){
		return (JSpinner)injection.getComponentById("databus_clear_count_spinner");
	}
	public JComboBox getLevelComboBox(){
		return (JComboBox)injection.getComponentById("databus_level_combobox");
	}
	
}

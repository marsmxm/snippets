package com.neusoft.aplus.databus.gui.view;

import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.border.EtchedBorder;

/**
 * GUI工具的主页视图
 * 
 * @author WanWei
 * @date 2015-4-13 下午8:02:23
 */
public class AplusMainView extends AplusBaseView {

	private static final long serialVersionUID = -882155348584755147L;
	
	//定义菜单，暂不用国际化
	private JMenu fileMenu = new JMenu("文件");
	
	private JMenu helpMenu = new JMenu("帮助");
	
	//菜单项
	private JMenuItem addMenuItem = new JMenuItem("添加节点");
	
	private JMenuItem editMenuItem = new JMenuItem("编辑节点");
	
	private JMenuItem deleteMenuItem = new JMenuItem("删除节点");
	
	private JMenuItem exitMenuItem = new JMenuItem("退出");
	
	private JMenuItem aboutMenuItem = new JMenuItem("关于...");
	
	private JFrame mainFrame = null;
	
	public JFrame getMainFrame() {
		return mainFrame;
	}

	public void setMainFrame(JFrame mainFrame) {
		this.mainFrame = mainFrame;
	}

	public AplusMainView(){
		initLayout("DataBusMainView.xml");
		initView();
	}
	
	/**
	 * 初始化界面元素
	 * 
	 * @author WanWei
	 * @date 2015-4-14 下午2:08:06
	 */
	private void initView(){
		//设置分隔条的位置
		JSplitPane workspace = getWorkSpacePanel();
		workspace.setDividerLocation(200);
		
		initMenu();
		
		initStatusBar();
	}
	
	/**
	 * 初始化菜单栏
	 * 
	 * @author WanWei
	 * @date 2015-4-14 下午2:33:43
	 */
	private void initMenu(){
		fileMenu.add(addMenuItem);
		fileMenu.addSeparator();
		fileMenu.add(editMenuItem);
		fileMenu.addSeparator();
		fileMenu.add(deleteMenuItem);
		fileMenu.addSeparator();
		fileMenu.add(exitMenuItem);
		fileMenu.addSeparator();
		helpMenu.add(aboutMenuItem);
		JMenuBar menuBar = getMenuBar();
		menuBar.setBorder(new EtchedBorder());
		menuBar.add(fileMenu);
		menuBar.add(helpMenu);
	}
	
	/**
	 * 初始化菜单栏
	 * 
	 * @author WanWei
	 * @date 2015-4-14 下午3:29:30
	 */
	private void initStatusBar(){
		JToolBar statusBar = getStatusBar();
		statusBar.setFloatable(false);//禁止浮动
		statusBar.setBorder(new EtchedBorder());
		//TODO 状态栏的功能未定
		statusBar.add(new JLabel("状态栏"));
		statusBar.addSeparator(new Dimension(300,30));
		
	}
	
	/**
	 * 取得工作空间的Panel
	 * @return
	 * @author WanWei
	 * @date 2015-4-14 下午2:03:12
	 */
	public JSplitPane getWorkSpacePanel(){
		return (JSplitPane)injection.getComponentById("main_workspace_panel");
	}
	
	/**
	 * 获取菜单栏
	 * @return
	 * @author WanWei
	 * @date 2015-4-14 下午2:04:12
	 */
	public JMenuBar getMenuBar(){
		return (JMenuBar)injection.getComponentById("main_menubar");
	}
	
	/**
	 * 获取状态栏
	 * @return
	 * @author WanWei
	 * @date 2015-4-14 下午2:06:48
	 */
	public JToolBar getStatusBar(){
		return (JToolBar)injection.getComponentById("main_status_bar");
	}
	
	public JMenu getFileMenu() {
		return fileMenu;
	}

	public JMenuItem getAddMenuItem() {
		return addMenuItem;
	}

	public JMenuItem getEditMenuItem() {
		return editMenuItem;
	}

	public JMenuItem getDeleteMenuItem() {
		return deleteMenuItem;
	}

	public JMenuItem getExitMenuItem() {
		return exitMenuItem;
	}

	public JMenuItem getAboutMenuItem() {
		return aboutMenuItem;
	}

}

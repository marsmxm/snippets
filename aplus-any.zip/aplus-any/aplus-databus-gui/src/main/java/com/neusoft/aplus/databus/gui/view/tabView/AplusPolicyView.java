package com.neusoft.aplus.databus.gui.view.tabView;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import com.neusoft.aplus.databus.gui.view.AplusMainView;
import com.neusoft.aplus.databus.gui.view.AplusViewUtil;

/**
 * 设备信息视图类
 * 
 * @author wuhao
 * @date 2015-4-14 下午2:46:42
 */
public class AplusPolicyView extends JPanel {

	private static final long serialVersionUID = 2910638634855554743L;

	// private static Logger log = Logger.getLogger(AplusPolicyView.class);
	// AplusDeviceView的主Panel，所有的控件都基于此。
	private JPanel northPanel = null;
	private JPanel tablePanel = null;

	private JLabel deviceTypeLabel = null;
	private JLabel policyNameLabel = null;
	private JLabel metricNameLabel = null;

	private JComboBox deviceTypeComboBox = null;
	private JTextField policyNameText = null;
	private JComboBox metricNameComboBox = null;

	private JButton queryButton = null;
	private JButton resetButton = null;
	private JButton addButton = null;
	private JButton alterButton = null;
	private JButton deleteButton = null;

	private JTable policyTable = null;

	private AplusMainView mainView = null;

	public AplusMainView getMainView() {
		return mainView;
	}

	public void setMainView(AplusMainView mainView) {
		this.mainView = mainView;
	}

	public AplusPolicyView() {
		init();
	}

	private void init() {
		this.setLayout(new BorderLayout());

		this.add(getNorthPanel(), BorderLayout.NORTH);
		this.add(getTablePanel(), BorderLayout.CENTER);
	}

	public JPanel getNorthPanel() {
		if (northPanel == null) {

			northPanel = AplusViewUtil.createBorderLayoutPanel();

			JPanel westPanel = AplusViewUtil.createGridLayoutPanel(2, 1,0,-5);

			// 查询条件第一行
			JPanel upPanel = AplusViewUtil.createFlowLayoutPanel();
			upPanel.add(getDeviceTypeLabel());
			upPanel.add(getDeviceTypeComboBox());
			upPanel.add(getPolicyNameLabel());
			upPanel.add(getPolicyNameText());

			JPanel downPanel = AplusViewUtil.createFlowLayoutPanel();
			downPanel.add(getMetricNameLabel());
			downPanel.add(getMetricNameComboBox());

			westPanel.add(upPanel);
			westPanel.add(downPanel);

			JPanel buttonPanel = AplusViewUtil
					.createGridLayoutPanel(2, 1, 0, 5);
			buttonPanel.add(getQueryButton());
			buttonPanel.add(getResetButton());

			northPanel.add(westPanel, BorderLayout.CENTER);
			northPanel.add(buttonPanel, BorderLayout.EAST);

			Border border = AplusViewUtil.createPanelBorder("查询条件");
			northPanel.setBorder(border);

		}
		return northPanel;
	}

	public JPanel getTablePanel() {
		if (tablePanel == null) {
			tablePanel = AplusViewUtil.createBorderLayoutPanel();

			JScrollPane scroll = new JScrollPane(getPolicyTable());
			scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

			setColumnSize();

			// 查询按钮Panel
			JPanel buttonPanel = AplusViewUtil.createGridLayoutPanel(3, 1, 0, 5);
			buttonPanel.add(getAddButton(), BorderLayout.NORTH);
			buttonPanel.add(getAlterButton(), BorderLayout.CENTER);
			buttonPanel.add(getDeleteButton(), BorderLayout.SOUTH);

			JPanel eastPanel = AplusViewUtil.createBorderLayoutPanel();
			JPanel blankLabel = new JPanel();

			eastPanel.add(buttonPanel, BorderLayout.SOUTH);
			eastPanel.add(blankLabel, BorderLayout.CENTER);

			tablePanel.add(scroll, BorderLayout.CENTER);
			tablePanel.add(eastPanel, BorderLayout.EAST);

			Border border = AplusViewUtil.createPanelBorder("设备列表");
			tablePanel.setBorder(border);

		}
		return tablePanel;
	}

	private void setColumnSize() {
		TableColumnModel cm = getPolicyTable().getColumnModel(); // 表格的列模型
		cm.getColumn(3).setPreferredWidth(250);
		
		TableColumn tc = getPolicyTable().getTableHeader().getColumnModel()
				.getColumn(4);
		tc.setMaxWidth(0);
		tc.setPreferredWidth(0);
		tc.setWidth(0);
		tc.setMinWidth(0);
		getPolicyTable().getTableHeader().getColumnModel().getColumn(4)
				.setMaxWidth(0);
		getPolicyTable().getTableHeader().getColumnModel().getColumn(4)
				.setMinWidth(0);
	}

	@SuppressWarnings("serial")
	public JTable getPolicyTable() {
		if (policyTable == null) {
			DefaultTableModel tableModel = new DefaultTableModel();
			tableModel.addColumn("策略名称");
			tableModel.addColumn("是否生效");
			tableModel.addColumn("指标");
			tableModel.addColumn("内容");
			tableModel.addColumn("策略id");
			
			policyTable = new JTable(tableModel){
				public boolean isCellEditable(int row, int column) {
					return false;
				};
			};
			policyTable.setAutoCreateRowSorter(true);
			policyTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			policyTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		}
		return policyTable;
	}

	public JLabel getDeviceTypeLabel() {
		if (deviceTypeLabel == null) {
			deviceTypeLabel = new JLabel("设备类型:");
		}
		return deviceTypeLabel;
	}

	public JLabel getPolicyNameLabel() {
		if (policyNameLabel == null) {
			policyNameLabel = new JLabel(" 策略名称:");
		}
		return policyNameLabel;
	}

	public JLabel getMetricNameLabel() {
		if (metricNameLabel == null) {
			metricNameLabel = new JLabel("  指标名:");
		}
		return metricNameLabel;
	}

	public JComboBox getDeviceTypeComboBox() {
		if (deviceTypeComboBox == null) {
			deviceTypeComboBox = AplusViewUtil.getComboBox(200,AplusViewUtil.comboBoxdefaulheight);
		}
		return deviceTypeComboBox;
	}

	public JComboBox getMetricNameComboBox() {
		if (metricNameComboBox == null) {
			metricNameComboBox = AplusViewUtil.getComboBox(200,AplusViewUtil.comboBoxdefaulheight);
		}
		return metricNameComboBox;
	}

	public JTextField getPolicyNameText() {
		if (policyNameText == null) {
			policyNameText = AplusViewUtil.createJTextFiled();
			// ((AbstractDocument)
			// resNameText.getDocument()).setDocumentFilter(new IPFilter());
		}
		return policyNameText;
	}

	public JButton getQueryButton() {
		if (queryButton == null) {
			queryButton = AplusViewUtil.createButton("查询");
		}
		return queryButton;
	}

	public JButton getResetButton() {
		if (resetButton == null) {
			resetButton = AplusViewUtil.createButton("重置");
		}
		return resetButton;
	}

	public JButton getAddButton() {
		if (addButton == null) {
			addButton = AplusViewUtil.createButton("添加策略");
		}
		return addButton;
	}

	public JButton getAlterButton() {
		if (alterButton == null) {
			alterButton = AplusViewUtil.createButton("修改策略");
		}
		return alterButton;
	}

	public JButton getDeleteButton() {
		if (deleteButton == null) {
			deleteButton = AplusViewUtil.createButton("删除策略");
		}
		return deleteButton;
	}

}

package com.neusoft.aplus.databus.gui.view.tabView;

import java.util.LinkedList;
import java.util.List;

import javax.swing.table.DefaultTableModel;

import com.neusoft.aplus.model.bizentity.AplusHistoryMetricData;

/**
 * @author wuhao
 * @date 2015-4-20 下午4:00:59
 */
public class AplusChartTableModel extends DefaultTableModel {

	private static final long serialVersionUID = -7066077499703839317L;

	private List<AplusHistoryMetricData> list = new LinkedList<AplusHistoryMetricData>();

	public List<AplusHistoryMetricData> getList() {
		return list;
	}

	public void setList(List<AplusHistoryMetricData> list) {
		this.list = list;
	}

	@Override
	public void addRow(Object[] rowData) {
		if((rowData != null) && (rowData.length > 0)){
			list.add((AplusHistoryMetricData)rowData[0]);
		}
		super.addRow(rowData);
	}

	@Override
	public Class<?> getColumnClass(int columnIndex) {
		return AplusHistoryMetricData.class;
	}

	@Override
	public Object getValueAt(int row, int column) {
		// p.button.addActionListener(new ActionListener() {
		//
		// @Override
		// public void actionPerformed(ActionEvent e) {
		//
		// System.out.println("AAAAAAAA");
		//
		// }
		// });
		//
		// return p;

		if (getList().size() > 0) {
			return list.get(row);
		} else {
			return null;
		}
	}

}

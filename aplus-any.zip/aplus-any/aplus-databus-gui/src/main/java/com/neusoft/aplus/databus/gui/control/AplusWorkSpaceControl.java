package com.neusoft.aplus.databus.gui.control;

import com.neusoft.aplus.databus.gui.view.AplusDataBusWorkSpaceView;

/**
 * 获取工作区的控制类
 * 
 * @author WanWei
 * @date 2015-4-16 上午11:26:00
 */
public class AplusWorkSpaceControl extends AplusBaseControl{
	
	private static AplusWorkSpaceControl instance = new AplusWorkSpaceControl();
	
	private AplusDataBusWorkSpaceView view;
	
	private AplusWorkSpaceControl() {
		super();
		view = new AplusDataBusWorkSpaceView();
		initData();
		initListener();
	}
	
	/**
	 * 单例模式获取
	 * 
	 * @return
	 * @author WanWei
	 * @date 2015-4-14 下午5:38:41
	 */
	public static AplusWorkSpaceControl getInstance() {
		return instance;
	}
	
	@Override
	public void initData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void initListener() {
		// TODO Auto-generated method stub
		
	}
	
	public AplusDataBusWorkSpaceView getView() {
		return view;
	}
}

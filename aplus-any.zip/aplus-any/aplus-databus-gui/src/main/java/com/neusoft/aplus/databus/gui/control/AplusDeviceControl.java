package com.neusoft.aplus.databus.gui.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neusoft.aplus.cmdb.model.AplusDeviceWithAlarmCnt;
import com.neusoft.aplus.databus.gui.constant.AplusGuiConstant;
import com.neusoft.aplus.databus.gui.rest.RestAction;
import com.neusoft.aplus.databus.gui.view.AplusDataBusFileChooserDialog;
import com.neusoft.aplus.databus.gui.view.AplusExcelUtil;
import com.neusoft.aplus.databus.gui.view.tabView.AplusDeviceView;
import com.neusoft.aplus.model.dbentity.table.AplusConnectionEntity;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;

/**
 * @author wuhao
 * @date 2015-4-17 上午10:23:07
 */
public class AplusDeviceControl extends AplusBaseControl {

	private AplusDeviceView deviceView;// 设备视图
	private AplusDataBusFileChooserDialog fileChooserDialog;
	private static AplusDeviceControl instance = new AplusDeviceControl();
	private static Logger log = LoggerFactory
			.getLogger(AplusDeviceControl.class);

	private AplusDeviceControl() {
		super();
		deviceView = new AplusDeviceView();
		fileChooserDialog = new AplusDataBusFileChooserDialog();
		initData();
		initListener();
	}

	public static AplusDeviceControl getInstance() {
		return instance;
	}

	@Override
	public void initData() {
	}

	@Override
	public void initListener() {
		deviceView.getQueryButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				processQuery();
			}
		});
		deviceView.getResetButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				processReset();
			}
		});
		deviceView.getImportButton().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				showFileChooserDialog();
			}
		});
		deviceView.getDeviceInfoButton().addActionListener(
				new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						processDeviceInfo();
					}
				});

		fileChooserDialog.getConfirmButton().addActionListener(
				new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						processImport();
					}
				});
		fileChooserDialog.getCancelButton().addActionListener(
				new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						fileChooserDialog.setVisible(false);
					}
				});
		fileChooserDialog.getImportButton().addActionListener(
				new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						processFileChoose();
					}
				});

	}

	/**
	 * 设备详情
	 * 
	 * @author wuhao
	 * @date 2015-4-22 下午2:18:25
	 */
	private void processDeviceInfo() {

		if (deviceView.getDeviceTable().getSelectedRowCount() != 1) {
			JOptionPane.showMessageDialog(deviceView.getMainView(), "请选择一条设备!",
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
			return;
		}

		// 获取选择的数据
		int index = deviceView.getDeviceTable().getSelectedRow();
		String type = deviceView.getDeviceTable().getValueAt(index, 1)
				.toString();
		String version = deviceView.getDeviceTable().getValueAt(index, 2)
				.toString();
		String name =  deviceView.getDeviceTable().getValueAt(index, 0)
				.toString();

		DefaultTreeModel model = (DefaultTreeModel) AplusCenterControl
				.getInstance().getView().getTypeTree().getModel();
		MutableTreeNode root = (MutableTreeNode) model.getRoot();
		Enumeration<?> childRen = root.children();
		DefaultMutableTreeNode selectedNode = null;
		while (childRen.hasMoreElements()) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) childRen
					.nextElement();
			boolean got = false;
			if (node.toString().equals(type + " " + version)) {
				Enumeration<?> types = node.children();
				while (types.hasMoreElements()) {
					DefaultMutableTreeNode childnode = (DefaultMutableTreeNode) types
							.nextElement();
					if (childnode.toString().split("/")[0].equals(name)) {
						got = true;
						selectedNode = childnode;
						break;

					}
				}
			}
			if (got) {
				break;
			}
		}

		if (selectedNode != null)
			AplusCenterControl.getInstance().initTabView(selectedNode);
	}

	/**
	 * 执行文件导入操作
	 * 
	 * @author wuhao
	 * @date 2015-4-17 下午2:23:11
	 */
	private void processImport() {
		String fileAbsolutePath = fileChooserDialog.getFileNameText().getText();
		if (fileAbsolutePath.isEmpty()) {
			JOptionPane.showMessageDialog(deviceView.getMainView(),
					"Excel不能为空!", AplusGuiConstant.ERROR_MARK,
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		Map<String, Object> map = AplusExcelUtil
				.parseExcelForDevice(fileAbsolutePath);
		if (map != null) {

			if (RestAction.importDeviceInfo(map)) {
				JOptionPane.showMessageDialog(deviceView.getMainView(),
						"Excel文 件导入成功!", AplusGuiConstant.MESSAGE_MARK,
						JOptionPane.INFORMATION_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(deviceView.getMainView(),
						"Excel文 件导入失败!", AplusGuiConstant.ERROR_MARK,
						JOptionPane.ERROR_MESSAGE);
			}

		} else {

			JOptionPane.showMessageDialog(deviceView.getMainView(),
					"Excel文 件解析失败!", AplusGuiConstant.ERROR_MARK,
					JOptionPane.ERROR_MESSAGE);
		}

		fileChooserDialog.setVisible(false);

	}

	/**
	 * 文件选择操作
	 * 
	 * @author wuhao
	 * @date 2015-4-17 下午2:22:21
	 */
	private void processFileChoose() {
		int result = fileChooserDialog.getFileChooser().showOpenDialog(
				deviceView.getMainView());
		if (result == JFileChooser.APPROVE_OPTION) {
			fileChooserDialog.getFileNameText().setText(
					fileChooserDialog.getFileChooser().getSelectedFile()
							.getAbsolutePath());
		}
	}

	/**
	 * 弹出文件选择框
	 * 
	 * @author wuhao
	 * @date 2015-4-17 下午2:21:47
	 */
	private void showFileChooserDialog() {

		fileChooserDialog.getFileNameText().setText(
				AplusGuiConstant.EMPTY_STRING);
		fileChooserDialog.setLocationRelativeTo(deviceView.getMainView());
		fileChooserDialog.setVisible(true);
	}

	/**
	 * 查询条件重置
	 * 
	 * @author wuhao
	 * @date 2015-4-17 下午2:21:13
	 */
	private void processReset() {
		if (deviceView.getDeviceTypeComboBox().getItemCount() > 0) {
			deviceView.getDeviceTypeComboBox().setSelectedIndex(0);
		}
		deviceView.getResNameText().setText(AplusGuiConstant.EMPTY_STRING);
	}

	/**
	 * 查询设备
	 * 
	 * @author wuhao
	 * @date 2015-4-17 下午2:21:22
	 */
	private void processQuery() {

		// String category = getCurrCategory();
		Object typeVersion = deviceView.getDeviceTypeComboBox()
				.getSelectedItem();
		String name = deviceView.getResNameText().getText();
		String type = null;
		String version = null;
		if (typeVersion != null && typeVersion.toString().length() > 0) {
			type = typeVersion.toString().split(" ")[0];
			version = typeVersion.toString().split(" ")[1];
		}

		if (type == null && name.isEmpty()) {
			JOptionPane.showMessageDialog(deviceView.getMainView(),
					"请至少输入一个查询条件!", AplusGuiConstant.ERROR_MARK,
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		List<AplusDeviceWithAlarmCnt> deviceList=null;
		try {
			deviceList = RestAction.findDeviceInfo(
					null, type, version, name);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(deviceView.getMainView(),
					"查询设备信息失败!", AplusGuiConstant.ERROR_MARK,
					JOptionPane.ERROR_MESSAGE);
			log.error(e.getMessage());
		}

		DefaultTableModel model = (DefaultTableModel) deviceView
				.getDeviceTable().getModel();
		model.getDataVector().clear(); // 清除表格数据
		if (deviceList != null) {
			for (AplusDeviceWithAlarmCnt aplusDeviceEntity : deviceList) {
				Vector<Object> v = new Vector<Object>();
				v.add(aplusDeviceEntity.getName());
				v.add(aplusDeviceEntity.getDeviceType());
				v.add(aplusDeviceEntity.getDeviceVersion());
				v.add(aplusDeviceEntity.getLocation());

				HashMap<String, String> map = (HashMap<String, String>) aplusDeviceEntity
						.getAttr();
				if (map != null) {
					v.add(map.toString());
				}
				model.addRow(v);
			}
		}
	}

	public AplusDeviceView getView() {
		return deviceView;
	}
}

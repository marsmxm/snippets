package com.neusoft.aplus.databus.gui.rest;

import com.neusoft.aplus.databus.gui.constant.AplusGuiConstant;

/**
 * Rest接口常量
 * 
 * @author wuhao
 * @date 2015-4-21 上午11:33:54
 */
public class RestContant {

	public static String ip = null;
	public static String port = null;

	//设备
	static String CATEGORYS = "/api/aplus/databus/categorys";// 获取设备类别和类型版本
	static String DEVICES = "/api/aplus/databus/devices";// 获取设备信息
	static String METRIC = "/api/aplus/databus/metrics";//指标信息
	static String IMPORT = "/api/aplus/databus/deviceconnections";//导入
	static String HISTORY = "/api/aplus/databus/historicaldatas";//历史信息
	
	//告警
	static String ALARM = "/api/aplus/alert/retrieve/conditionspaging";//查询活动的告警
	static String ALARM_FIXED = "/api/aplus/alert/retrieve/fixed/conditionspaging/paging";//查询历史告警
	static String ALARM_FIX=  "/api/aplus/alert/operate/similarids";//确认告警
	static String ALARM_DELETE = "/api/aplus/fixedalert/delete/more";//删除告警
	
	//策略
	static String POLICY_DELETE ="/api/aplus/policy/delete/pid/"; //删除单个策略
	static String POLICY_SAVE ="/api/aplus/policy/addorupdate"; //保存策略
	static String POLICY_QUERY="/api/aplus/policy/retrieve/conditionspaging/pageno/0/pagesize/0";//根据查询条件查询策略
	
	//字典表
	public static String ALARM_LEVEL="/api/aplus/transcoding/retrieve/conditionspaging/parentId/policy_condition_type";
//	public static String ALARM_LEVEL="/api/aplus/transcoding/retrieve/conditionspaging/parentId/policy_alert_level";
	public static String CONDITION="/api/aplus/transcoding/retrieve/conditionspaging/parentId/policy_condition_comparator";
	public static String ATTR="/api/aplus/transcoding/retrieve/conditionspaging/parentId/policy_attr_comparator";
	
	static String HTTPS = "http://";

	static String getUri(String restName) {
		return RestContant.HTTPS + ip + AplusGuiConstant.NODE_SEP + port
				+ restName;
	}
	static String getUri(String restName,String tempip,String tempport) {
		return RestContant.HTTPS + tempip + AplusGuiConstant.NODE_SEP + tempport
				+ restName;
	}
}

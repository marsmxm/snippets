package com.neusoft.aplus.databus.gui.view.tabView;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumnModel;

import com.neusoft.aplus.databus.gui.view.AplusLineChartPanel;
import com.neusoft.aplus.databus.gui.view.AplusMainView;
import com.neusoft.aplus.databus.gui.view.AplusViewUtil;

/**
 * 
 * @author wuhao
 * @date 2015-4-18 上午10:06:34
 */
public class AplusPointView extends JPanel {

	private static final long serialVersionUID = 2910638634855554743L;

	// private static Logger log = Logger.getLogger(AplusPolicyView.class);
	// AplusDeviceView的主Panel，所有的控件都基于此。
	private JPanel northPanel = null;
	private JPanel tablePanel = null;

	private JLabel deviceTypeLabel = null;
	private JLabel policyNameLabel = null;
	private JLabel metricNameLabel = null;
	private JLabel hourLabel = null;

	private ButtonGroup group = null;
	private JRadioButton oneHourRadio = null;
	private JRadioButton fourHourRadio = null;
	private JRadioButton eightHourRadio = null;
	private JRadioButton oneDayRadio = null;

	private JComboBox deviceTypeComboBox = null;
	private JTextField resNameText = null;
	private JComboBox metricNameComboBox = null;

	private JButton addButton = null;
	private JButton deleteButton = null;

	private AplusMainView mainView = null;

	public AplusMainView getMainView() {
		return mainView;
	}

	public void setMainView(AplusMainView mainView) {
		this.mainView = mainView;
	}

	private JTable pointTable = null;

	private AplusLineChartPanel chartPanel = null;

	public AplusLineChartPanel getChartPanel() {
		if (chartPanel == null) {
			// chartPanel = new AplusLineChartPanel(chart);
		}
		return chartPanel;
	}

	public AplusPointView() {
		init();
	}

	private void init() {

		this.setLayout(new BorderLayout());

		this.add(getNorthPanel(), BorderLayout.NORTH);
		this.add(getTablePanel(), BorderLayout.CENTER);
	}

	public JPanel getNorthPanel() {
		if (northPanel == null) {
			northPanel = AplusViewUtil.createBorderLayoutPanel();

			JPanel westPanel = AplusViewUtil.createGridLayoutPanel(3, 1,0,-5);;

			// 查询条件第一行
			JPanel upPanel = AplusViewUtil.createFlowLayoutPanel();
			upPanel.add(getDeviceTypeLabel());
			upPanel.add(getDeviceTypeComboBox());
			upPanel.add(getPolicyNameLabel());
			upPanel.add(getResNameText());

			JPanel middlePanel = AplusViewUtil.createFlowLayoutPanel();
			middlePanel.add(getMetricLevelLabel());
			middlePanel.add(getMetricNameComboBox());
			
			JPanel downPanel = AplusViewUtil.createFlowLayoutPanel();
			
			downPanel.add(getHourLabel());
			downPanel.add(getOneHourRadio());
			downPanel.add(getFourHourRadio());
			downPanel.add(getEightHourRadio());
			downPanel.add(getOneDayRadio());

			group = new ButtonGroup();
			group.add(getOneHourRadio());
			group.add(getFourHourRadio());
			group.add(getEightHourRadio());
			group.add(getOneDayRadio());
			getOneHourRadio().setSelected(true);

			westPanel.add(upPanel);
			westPanel.add(middlePanel);
			westPanel.add(downPanel);

			JPanel buttonPanel = AplusViewUtil
					.createGridLayoutPanel(3, 1, 5, 5);
			buttonPanel.add(new JLabel());
			buttonPanel.add(getAddButton());
			buttonPanel.add(getDeleteButton());

			
			northPanel.add(westPanel, BorderLayout.CENTER);
			northPanel.add(buttonPanel, BorderLayout.EAST);

			Border border = AplusViewUtil.createPanelBorder("查询条件");
			northPanel.setBorder(border);

		}
		return northPanel;
	}

	public JPanel getTablePanel() {
		if (tablePanel == null) {
			tablePanel = AplusViewUtil.createBorderLayoutPanel();

			JScrollPane scroll = new JScrollPane(getPonitTable());
			scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
			setColumnSize();

			tablePanel.add(scroll, BorderLayout.CENTER);
		}
		return tablePanel;
	}

	private void setColumnSize() {
		TableColumnModel cm = getPonitTable().getColumnModel(); // 表格的列模型
		cm.getColumn(0).setPreferredWidth(600);
		cm.getColumn(0).setCellEditor(new AplusChartRender());
		cm.getColumn(0).setCellRenderer(new AplusChartRender());
		getPonitTable().setRowHeight(300);

	}

	@SuppressWarnings("serial")
	public JTable getPonitTable() {
		if (pointTable == null) {
			AplusChartTableModel tableModel = new AplusChartTableModel();
			tableModel.addColumn("监控数据");
			
			pointTable = new JTable(tableModel){
				public boolean isCellEditable(int row, int column) {
					return true;
				};
			};
			pointTable.setAutoCreateRowSorter(true);
			pointTable.setEnabled(true);
			pointTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			pointTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			
			pointTable.getTableHeader().setVisible(false);  
//            DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();  
//            renderer.setPreferredSize(new Dimension(0, 0));  
//            pointTable.getTableHeader().setDefaultRenderer(renderer);  
		}
		return pointTable;
	}

	public JLabel getDeviceTypeLabel() {
		if (deviceTypeLabel == null) {
			deviceTypeLabel = new JLabel("设备类型:");
		}
		return deviceTypeLabel;
	}

	public JLabel getPolicyNameLabel() {
		if (policyNameLabel == null) {
			policyNameLabel = new JLabel("  资源名称:");
		}
		return policyNameLabel;
	}

	public JLabel getMetricLevelLabel() {
		if (metricNameLabel == null) {
			metricNameLabel = new JLabel("  指标名:");
		}
		return metricNameLabel;
	}

	public JLabel getHourLabel() {
		if (hourLabel == null) {
			hourLabel = new JLabel("   时长:");
		}
		return hourLabel;
	}

	public JComboBox getDeviceTypeComboBox() {
		if (deviceTypeComboBox == null) {
			deviceTypeComboBox = AplusViewUtil.getComboBox(200,AplusViewUtil.comboBoxdefaulheight);
		}
		return deviceTypeComboBox;
	}

	public JComboBox getMetricNameComboBox() {
		if (metricNameComboBox == null) {
			metricNameComboBox = AplusViewUtil.getComboBox(400,AplusViewUtil.comboBoxdefaulheight);
		}
		return metricNameComboBox;
	}

	public JTextField getResNameText() {
		if (resNameText == null) {
			resNameText = AplusViewUtil.createJTextFiled();
			// ((AbstractDocument)
			// resNameText.getDocument()).setDocumentFilter(new IPFilter());
		}
		return resNameText;
	}

	public JButton getAddButton() {
		if (addButton == null) {
			addButton = AplusViewUtil.createButton("加载");
		}
		return addButton;
	}

	public JButton getDeleteButton() {
		if (deleteButton == null) {
			deleteButton = AplusViewUtil.createButton("删除");
		}
		return deleteButton;
	}

	public JRadioButton getOneHourRadio() {
		if (oneHourRadio == null) {
			oneHourRadio = new JRadioButton("一小时");
		}
		return oneHourRadio;
	}

	public JRadioButton getFourHourRadio() {
		if (fourHourRadio == null) {
			fourHourRadio = new JRadioButton("四小时");
		}
		return fourHourRadio;
	}

	public JRadioButton getEightHourRadio() {
		if (eightHourRadio == null) {
			eightHourRadio = new JRadioButton("八小时");
		}
		return eightHourRadio;
	}

	public JRadioButton getOneDayRadio() {
		if (oneDayRadio == null) {
			oneDayRadio = new JRadioButton("二十四小时");
		}
		return oneDayRadio;
	}

	public JLabel getMetricNameLabel() {
		if (metricNameLabel == null) {
			metricNameLabel = new JLabel("  指标名:");
		}
		return metricNameLabel;
	}

}

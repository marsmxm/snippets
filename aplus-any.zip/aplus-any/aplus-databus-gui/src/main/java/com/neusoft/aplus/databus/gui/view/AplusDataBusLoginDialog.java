package com.neusoft.aplus.databus.gui.view;

import java.awt.BorderLayout;

import javax.swing.JDialog;
import javax.swing.WindowConstants;

/**
 * DataBus客户端登录界面
 * @author wuhao
 * @date 2015-4-16 上午11:38:29
 */
public class AplusDataBusLoginDialog extends JDialog {

	private static final long serialVersionUID = -7106510881888053515L;
	private final static String TITLE = "DataBus客户端登录";
	private AplusDataBusLoginView view;
	
	public AplusDataBusLoginDialog(){
		view = new AplusDataBusLoginView();
		this.setSize(400, 240);
		this.setTitle(TITLE);
		this.setModal(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(view,BorderLayout.CENTER);
		this.rootPane.setDefaultButton(view.getConfirmButton());
	}

	public AplusDataBusLoginView getView() {
		return view;
	}
}


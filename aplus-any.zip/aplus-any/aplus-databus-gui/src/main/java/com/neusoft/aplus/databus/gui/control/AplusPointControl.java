package com.neusoft.aplus.databus.gui.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neusoft.aplus.cmdb.model.AplusDeviceWithAlarmCnt;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.databus.gui.constant.AplusGuiConstant;
import com.neusoft.aplus.databus.gui.rest.RestAction;
import com.neusoft.aplus.databus.gui.view.AplusLineChartPanel;
import com.neusoft.aplus.databus.gui.view.tabView.AplusChartTableModel;
import com.neusoft.aplus.databus.gui.view.tabView.AplusPointView;
import com.neusoft.aplus.model.bizentity.AplusHistoryMetricData;
import com.neusoft.aplus.model.bizentity.AplusMetricDataPoint;
import com.neusoft.aplus.model.dbentity.table.AplusMetricEntity;

/**
 * @author wuhao
 * @date 2015-4-18 上午10:14:03
 */
public class AplusPointControl extends AplusBaseControl {

	private static Logger log = LoggerFactory
			.getLogger(AplusPointControl.class);
	private AplusPointView pointView;// 点图
	private static AplusPointControl instance = new AplusPointControl();
	private String resName = null;

	private AplusPointControl() {
		super();
		pointView = new AplusPointView();
		initData();
		initListener();
	}

	public static AplusPointControl getInstance() {
		return instance;
	}

	public AplusPointView getView() {
		return pointView;
	}

	@Override
	public void initData() {
	}

	@Override
	public void initListener() {
		pointView.getAddButton().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
//				loadProcess();
				loadProcessTest();
			}
		});
		pointView.getDeviceTypeComboBox().addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				if (pointView.getDeviceTypeComboBox().getSelectedItem() != null) {
					initMetric();
				}
			}
		});
		pointView.getDeleteButton().addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				deleteProcess();
				
			}
		});

	}

	/**
	 * 删除加载的数据
	 * 
	 * @author wuhao
	 * @date 2015-4-27 下午8:48:29
	 */
	private void deleteProcess(){
		
	}
	
	private void initMetric() {
		String typeVersion = pointView.getDeviceTypeComboBox()
				.getSelectedItem().toString();
		JComboBox box = pointView.getMetricNameComboBox();
		List<AplusMetricEntity> list=null;
		try {
			list = RestAction.getMetricInfo(
					typeVersion.split(" ")[0], typeVersion.split(" ")[1], null);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(pointView.getMainView(),
					"查询指标信息失败!", AplusGuiConstant.ERROR_MARK,
					JOptionPane.ERROR_MESSAGE);
			log.error(e.getMessage());
		}
		box.removeAllItems();
		if (list != null) {
			for (AplusMetricEntity aplusMetricEntity : list) {
				box.addItem(aplusMetricEntity.getMetricCode() + "/"
						+ aplusMetricEntity.getMetricName());
			}
			if (list != null && list.size() > 0) {
				box.setSelectedIndex(0);
			}
			pointView.updateUI();
		}

	}

	
	private void loadProcessTest(){
		AplusHistoryMetricData data = new AplusHistoryMetricData();
		data.setFqn("test");
		data.setName("cpu");
		data.setDisplayName("CPU");
	
		List<AplusMetricDataPoint> dps = new ArrayList<AplusMetricDataPoint>();
		for(int i = 0; i < 30; i++){
			AplusMetricDataPoint dp = new AplusMetricDataPoint();
			dp.setAvgValue(Math.random() * 50);
			dp.setMinValue(Math.random() * 30);
			dp.setMaxValue(Math.random() * 80);
			dp.setRecordTime(System.currentTimeMillis() + i * 300000);
			dps.add(dp);
		}
		data.setDataPoints(dps);
//		 AplusLineChartPanel panel = new AplusLineChartPanel(
//		 AplusLineChartPanel.createChart("",AplusGuiConstant.EMPTY_STRING, dps),null);
		
		 AplusChartTableModel model = (AplusChartTableModel)
		 pointView.getPonitTable().getModel();
		
		
		 model.addRow(new AplusHistoryMetricData[]{data});
	}
	
	private void loadProcess()  {

		// 判断 指标，fqn，间隔是否为空
		if (pointView.getResNameText().getText() == null
				|| pointView.getResNameText().getText().toString().length() == 0) {
			JOptionPane.showMessageDialog(pointView.getMainView(), "资源名称不能为空!",
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
			return;
		}
		if (pointView.getMetricNameComboBox().getItemCount() == 0
				|| pointView.getMetricNameComboBox().getSelectedItem() == null) {
			JOptionPane.showMessageDialog(pointView.getMainView(), "指标信息不能为空!",
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);
			return;
		}
		String fqn = AplusGuiConstant.EMPTY_STRING;

		if (!pointView.getResNameText().isEnabled()) {
			fqn = getResName().split("/")[1];
		} else {
			// 根据type，version，name找对应的fqn
			String name = pointView.getResNameText().getText();
			String typeVersion = pointView.getDeviceTypeComboBox()
					.getSelectedItem().toString();
			List<AplusDeviceWithAlarmCnt> deviceList=null;
			try {
				deviceList = RestAction
						.findDeviceInfo(null, typeVersion.split(" ")[0],
								typeVersion.split(" ")[1], name);
			} catch (IOException e) {
				JOptionPane.showMessageDialog(pointView.getMainView(),
						"查询设备信息失败!", AplusGuiConstant.ERROR_MARK,
						JOptionPane.ERROR_MESSAGE);
				log.error(e.getMessage());
			}
			if (deviceList != null && deviceList.size() > 0) {
				AplusDeviceWithAlarmCnt aplusDeviceEntity = deviceList.get(0);
				fqn = aplusDeviceEntity.getFqn();
			}
		}
		if (fqn.equals(AplusGuiConstant.EMPTY_STRING)) {

			JOptionPane.showMessageDialog(pointView.getMainView(), " 找不到资源对应的数据，无法获取监控信息!",
					AplusGuiConstant.ERROR_MARK, JOptionPane.ERROR_MESSAGE);

		} else {
			// 采集历史数据
			List<Map<String, Object>> list = Lists.newArrayList();
			Map<String, Object> map = Maps.newHashMap();
			List<String> metriclist = Lists.newArrayList();
			// metriclist.add(pointView.getMetricNameComboBox().getSelectedItem()
			// .toString().split("/")[0]);  //TODO open

			fqn = "fqn_opc_test"; //TODO delete
			map.put("FQN", fqn);
			
			metriclist.add("Random.Int4");//TODO delete
			map.put("METRIC_LIST", metriclist);
			int interval = 0;
			if (pointView.getOneDayRadio().isSelected())
				interval = 86400000;
			else if (pointView.getOneHourRadio().isSelected()) {
				interval = 3600000;
			} else if (pointView.getFourHourRadio().isSelected()) {
				interval = 14400000;
			} else if (pointView.getEightHourRadio().isSelected()) {
				interval = 28800000;
			}
			
			interval  = 100400000;//TODO delete
			map.put("INTERVAL", String.valueOf(interval));
			map.put("POINTS_NUM", 100);
			list.add(map);

			Map<String, Object> resultmap=null;
			try {
				resultmap = RestAction.findHistoryDatas(list);
			} catch (IOException e) {
				JOptionPane.showMessageDialog(pointView.getMainView(),
						"查询监控数据失败!", AplusGuiConstant.ERROR_MARK,
						JOptionPane.ERROR_MESSAGE);
				log.error(e.getMessage());
				return;
			}
			if (resultmap != null) {
				Object o = resultmap.get(fqn);
				if (o != null) {

					List<AplusHistoryMetricData> monitorList = JSONUtil
							.getObjectList(o.toString(),
									AplusHistoryMetricData.class);
					if (monitorList != null && monitorList.size()>0) {
						
						AplusHistoryMetricData data = monitorList.get(0);
						List<AplusMetricDataPoint> pointData = data
								.getDataPoints();
						String xInfo  = pointView.getResNameText().getText() + AplusGuiConstant.NODE_SEP +metriclist.get(0);
						
						data = new AplusHistoryMetricData();
						data.setFqn("test");
						data.setName("cpu");
						data.setDisplayName("CPU");
					
						List<AplusMetricDataPoint> dps = new ArrayList<AplusMetricDataPoint>();
						for(int i = 0; i < 30; i++){
							AplusMetricDataPoint dp = new AplusMetricDataPoint();
							dp.setAvgValue(Math.random() * 50);
							dp.setMinValue(Math.random() * 30);
							dp.setMaxValue(Math.random() * 80);
							dp.setRecordTime(System.currentTimeMillis() + i * 300000);
							dps.add(dp);
						}
						data.setDataPoints(dps);
						 AplusChartTableModel model = (AplusChartTableModel)pointView.getPonitTable().getModel();
						 model.addRow(new AplusHistoryMetricData[]{data});
								 
//						 AplusLineChartPanel panel = new AplusLineChartPanel(
//						 AplusLineChartPanel.createChart(xInfo,AplusGuiConstant.EMPTY_STRING, dps));
//						
//						 AplusChartTableModel model = (AplusChartTableModel)
//						 pointView.getPonitTable().getModel();
//						 Vector<Object> v = new Vector<Object>();
//						 v.add(panel);
//						 model.addRow(v);
					}
				}
			}
		}
	}

	public String getResName() {
		return resName;
	}

	public void setResName(String resName) {
		this.resName = resName;
	}
}

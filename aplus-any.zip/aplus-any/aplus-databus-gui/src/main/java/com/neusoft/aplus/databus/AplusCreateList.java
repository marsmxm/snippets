package com.neusoft.aplus.databus;

import java.util.ArrayList;
import java.util.List;

import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;

/**
 * 假数据生成类，便于后期清理
 * 
 * @author wuhao
 * @date 2015-4-17 上午10:47:53
 */
public class AplusCreateList {

	public static List<AplusDeviceEntity> getDeviceTypeList() {
		// 假数据
		List<AplusDeviceEntity> deviceTypeList = new ArrayList<AplusDeviceEntity>();
		AplusDeviceEntity entity1 = new AplusDeviceEntity();
		entity1.setDeviceType("PC");
		entity1.setDeviceVersion("HP");
		AplusDeviceEntity entity2 = new AplusDeviceEntity();
		entity2.setDeviceType("PC");
		entity2.setDeviceVersion("IBM");
		AplusDeviceEntity entity3 = new AplusDeviceEntity();
		entity3.setDeviceType("PC");
		entity3.setDeviceVersion("LONOVO");

		deviceTypeList.add(entity1);
		deviceTypeList.add(entity2);
		deviceTypeList.add(entity3);

		return deviceTypeList;
	}
	
	public static List<AplusDeviceEntity> getDeviceList() {
		// 假数据
		List<AplusDeviceEntity> deviceTypeList = new ArrayList<AplusDeviceEntity>();
		AplusDeviceEntity entity1 = new AplusDeviceEntity();
		entity1.setDeviceType("PC");
		entity1.setDeviceVersion("HP");
		entity1.setName("sam's hp pc");
		entity1.setAttr("{\"位置\":\"111\",\"phone_num\":\"18855669988\",\"leader\":\"baolx1\"}");
		AplusDeviceEntity entity2 = new AplusDeviceEntity();
		entity2.setDeviceType("PC");
		entity2.setDeviceVersion("IBM");
		entity2.setName("zh_ch's hp pc");
		entity2.setAttr("{\"位置\":\"222\",\"phone_num\":\"13948548484\",\"leader\":\"baolx1\"}");
		AplusDeviceEntity entity3 = new AplusDeviceEntity();
		entity3.setDeviceType("PC");
		entity3.setDeviceVersion("LONOVO");
		entity3.setName("wuhao's hp pc");
		entity3.setAttr("{\"位置\":\"333\",\"phone_num\":\"18698659596\",\"leader\":\"baolx1\"}");

		deviceTypeList.add(entity1);
		deviceTypeList.add(entity2);
		deviceTypeList.add(entity3);

		return deviceTypeList;
	}
	
//	private static List<AplusDeviceEntity> getAlarmList(){
//		
//	}
}

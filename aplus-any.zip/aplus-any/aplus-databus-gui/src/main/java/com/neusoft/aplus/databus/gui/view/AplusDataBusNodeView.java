package com.neusoft.aplus.databus.gui.view;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;

import com.neusoft.aplus.databus.gui.view.filter.IPFilter;
import com.neusoft.aplus.databus.gui.view.filter.PortNumberFilter;


/**
 * 新增、修改DataBus节点界面
 * 
 * @author WanWei
 * @date 2015-4-14 下午5:26:28
 */
public class AplusDataBusNodeView extends AplusBaseView {

	private static final long serialVersionUID = -7358576494239061195L;
	
	public AplusDataBusNodeView(){
		initLayout("DataBusNodeView.xml");
		initView();
	}
	
	/**
	 * 初始化界面元素
	 * 
	 * @author WanWei
	 * @date 2015-4-14 下午2:56:34
	 */
	private void initView(){
		JTextField ipField = getIPTextField();
		JTextField portField = getPortTextField();
		//添加输入限制
		((AbstractDocument) ipField.getDocument()).setDocumentFilter(new IPFilter());
		((AbstractDocument) portField.getDocument()).setDocumentFilter(new PortNumberFilter());
	
	}
	
	/**
	 * 获取IP输入框
	 * @return
	 * @author WanWei
	 * @date 2015-4-14 下午5:31:11
	 */
	public JTextField getIPTextField(){
		return (JTextField)injection.getComponentById("databus_node_ip_field");
	}
	
	/**
	 * 获取端口输入框
	 * @return
	 * @author WanWei
	 * @date 2015-4-14 下午5:31:28
	 */
	public JTextField getPortTextField(){
		return (JTextField)injection.getComponentById("databus_noder_port_field");
	}
	
	/**
	 * 获取确认按钮
	 * @return
	 * @author WanWei
	 * @date 2015-4-14 下午5:31:46
	 */
	public JButton getConfirmButton(){
		return (JButton)injection.getComponentById("confirm_button");
	}
	
	/**
	 * 获取取消按钮
	 * @return
	 * @author WanWei
	 * @date 2015-4-14 下午5:32:08
	 */
	public JButton getCancelButton(){
		return (JButton)injection.getComponentById("cancel_button");
	}
}

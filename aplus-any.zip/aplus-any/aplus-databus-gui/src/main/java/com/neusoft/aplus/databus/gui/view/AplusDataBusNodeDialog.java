package com.neusoft.aplus.databus.gui.view;

import java.awt.BorderLayout;

import javax.swing.JDialog;
import javax.swing.WindowConstants;

import com.neusoft.aplus.databus.gui.constant.AplusGuiConstant;

/**
 * DataBus节点编辑对话框
 * @author WanWei
 * @date 2015-4-15 下午1:32:48
 */
public class AplusDataBusNodeDialog extends JDialog {
	
	private static final long serialVersionUID = 8404939935102278837L;
	
	private AplusDataBusNodeView view;
		
	//操作模式 新增or编辑
	private int operMode = AplusGuiConstant.DIALOG_OPERMODE_ADD;
	
	public AplusDataBusNodeDialog(){
		view = new AplusDataBusNodeView();
		this.setSize(400, 240);
		this.setModal(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(view,BorderLayout.CENTER);
		this.rootPane.setDefaultButton(view.getConfirmButton());
	}

	public AplusDataBusNodeView getView() {
		return view;
	}
	
	public int getOperMode() {
		return operMode;
	}

	public void setOperMode(int operMode) {
		this.operMode = operMode;
		if(operMode == AplusGuiConstant.DIALOG_OPERMODE_ADD){
			this.setTitle("添加DataBus节点");
		}else{
			this.setTitle("编辑DataBus节点");
		}
	}
}

package com.neusoft.aplus.databus.gui.view;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

/**
 * DataBus节点Panel
 * 
 * @author WanWei
 * @date 2015-4-14 下午2:49:30
 */
public class AplusDataBusNodeListView extends AplusBaseView {

	private static final long serialVersionUID = -7358576494239061195L;
	
	//列表的数据模型
	private DefaultListModel model = new DefaultListModel();
	
	//存放内容为字符串，形式：{DataBus前置机IP}：{DataBus提供的Rest服务端口}
	private JList nodeList;
	
	public AplusDataBusNodeListView(){
		initLayout("DataBusNodeListView.xml");
		initView();
	}
	
	/**
	 * 初始化界面元素
	 * 
	 * @author WanWei
	 * @date 2015-4-14 下午2:56:34
	 */
	private void initView(){
		nodeList = new JList(model);
		nodeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		getDataBusNodeScrollPane().setViewportView(nodeList);
	}
	
	/**
	 * 添加数据至节点列表
	 * 
	 * @param data
	 * @author WanWei
	 * @date 2015-4-14 下午3:02:54
	 */
	public void addDataToNodeList(Object data){
		model.addElement(data);
	}
	
	/**
	 * 删除选中的数据
	 * 
	 * @author WanWei
	 * @date 2015-4-14 下午3:04:03
	 */
	public void removeSelected(){
		model.removeElement(nodeList.getSelectedValue());
	}
	
	/**
	 * 获取滚动Panel
	 * 
	 * @return
	 * @author WanWei
	 * @date 2015-4-14 下午2:52:23
	 */
	public JScrollPane getDataBusNodeScrollPane(){
		return (JScrollPane)injection.getComponentById("databus_node_scrollpane");
	}
	
	public DefaultListModel getModel() {
		return model;
	}

	public JList getNodeList() {
		return nodeList;
	}

}

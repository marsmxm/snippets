package com.neusoft.aplus.databus.gui.view;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import com.neusoft.aplus.common.util.FileUtil;

/**
 * 负责加载xml文件的工具类
 * 
 * @author WanWei
 * @date 2013-5-10 上午10:33:54
 */
public class AplusXmlLoader {
	
	//布局XML文件的存放位置
	private final static String XMLPATH = "view-xml";
	
	/**
	 * 加载xml文件并返回文件流
	 * 需要注意关闭流
	 * @param xml
	 * @return InputStream
	 */
	public InputStream loadViewXml(String xml) throws FileNotFoundException {
		String filePath = FileUtil.getRepositoryPath(XMLPATH.concat(File.separator).concat(xml));
		InputStream input = new FileInputStream(filePath);
		return input;
	}

}

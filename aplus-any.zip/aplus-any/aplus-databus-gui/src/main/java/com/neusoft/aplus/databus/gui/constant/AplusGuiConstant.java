package com.neusoft.aplus.databus.gui.constant;

/**
 * GUI用到的一些常量
 * 
 * @author WanWei
 * @date 2015-4-15 下午2:16:29
 */
public interface AplusGuiConstant {

	String ERROR_MARK = "错误消息";

	String CONFIRM_MARK = "确认消息";

	String WARN_MARK = "警告消息";

	String MESSAGE_MARK = "通知消息";

	String EMPTY_STRING = "";

	String TOTAL_STRING = "总计：";

	// IP和端口之间的分割符
	String NODE_SEP = ":";

	// 节点在配置文件中的分隔符
	String NODE_SEP_FOR_CONF = ",";

	// 节点在配置文件中的属性名
	String NODE_CONF_NAME = "databus_nodes";

	String NAVIGATION_SEP = ">";

	// 新增模式
	int DIALOG_OPERMODE_ADD = 0;

	// 编辑模式
	int DIALOG_OPERMODE_EDIT = 1;

	// 分页状态
	// 第一页
	int PAGE_FIRST = 0;
	// 中间
	int PAGE_MIDDLE = 1;
	// 最后一页
	int PAGE_LAST = 2;
	// 只有一页
	int PAGE_SINGLE = 3;
	
	//树形图选择状态
	int TREE_ROOT = 1;//根
	int TREE_CATEGORY = 2;//类别
	int TREE_TYPE = 3;//类型
}

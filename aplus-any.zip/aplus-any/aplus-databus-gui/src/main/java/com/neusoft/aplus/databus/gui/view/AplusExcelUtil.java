package com.neusoft.aplus.databus.gui.view;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.neusoft.aplus.cmdb.model.ActionConst;
import com.neusoft.aplus.model.dbentity.table.AplusConnectionEntity;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;

/**
 * excel工具类
 * 
 * @author wuhao
 * @date 2015-4-25 上午8:46:33
 */
public class AplusExcelUtil {

	/**
	 * 解析excel
	 * 
	 * @param filename
	 * @return
	 * @author wuhao
	 * @date 2015-4-25 上午9:31:16
	 */
	public static Map<String, Object> parseExcelForDevice(String filename) {
		boolean is2003 = false;
		if (VersionExcel.isExcel2003(filename)) {
			is2003 = true;
		} else {
			is2003 = false;
		}

		List<AplusDeviceEntity> deviceList = null;
		List<AplusConnectionEntity> connList = null;
		Map<String, AplusConnectionEntity> aces = null;
		// 第一步：创建WokBook（工作薄）
		File f = new File(filename);
		Workbook workbook = null;

		AplusDeviceEntity ade = null;
		AplusConnectionEntity ace = null;

		try {
			InputStream stream = new FileInputStream(f);
			if (is2003) {
				// POIFSFileSystem system = new POIFSFileSystem(new
				// FileInputStream(f)); //大神写法
				workbook = new HSSFWorkbook(stream);
			} else {
				workbook = new XSSFWorkbook(stream);
			}
			// 第二部：获得Sheet（工作表）
			Sheet sheet = workbook.getSheetAt(0);
			// Sheet sheet = workbook.getSheet("fqn");
			if (sheet.getPhysicalNumberOfRows() <= 1) {
				return null;
			}

			// 第三部：根据row和column来获取cell中的value
			aces = new LinkedHashMap<String, AplusConnectionEntity>();
			deviceList = new ArrayList<AplusDeviceEntity>();
			for (Row row : sheet) {
				if (row.getRowNum() > 0) {
					for (@SuppressWarnings("unused")
					Cell cell : row) {
						ade = new AplusDeviceEntity();
						ade.setFqn(getStringCellValue(row.getCell(0)));// Fqn
						ade.setName(getStringCellValue(row.getCell(1)));
						ade.setIp(getStringCellValue(row.getCell(2)));
						ade.setCategory(getStringCellValue(row.getCell(3)));
						ade.setDeviceType(getStringCellValue(row.getCell(4)));
						ade.setDeviceVersion(getStringCellValue(row.getCell(5)));
						ade.setLocation(getStringCellValue(row.getCell(6)));
						ade.setAttr(getStringCellValue(row.getCell(7)));
						ade.setCreateDate(new Date(System.currentTimeMillis()));
						ace = new AplusConnectionEntity();
						ace.setActive(getStringCellValue(row.getCell(8))
								.equalsIgnoreCase("true") ? true : false);
						ace.setConInfo(getStringCellValue(row.getCell(9)));
						// Fqn做key 连接信息做value
						aces.put(getStringCellValue(row.getCell(0)), ace);
					}
					// 添加资源设备信息
					deviceList.add(ade);
				}
			}
			// 设置uuid
			setUuid(deviceList, aces);

			connList = new ArrayList<AplusConnectionEntity>();
			// map转换成list
			connList = mapTransitionList(aces);// ades:设备资源信息集 ;list_aces:连接信息集

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (workbook != null) {
//				stream.
//				try {
//					
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
			}
		}

		Map<String, Object> map = new HashMap<String, Object>();
		map.put(ActionConst.DEVICE_LIST, deviceList);
		map.put(ActionConst.CONN_LIST, connList);
		return map;
	}

	/**
	 * 设置Uuid
	 * 
	 * @param ades
	 *            资源设备信息集
	 * @param aces
	 *            连接信息集
	 */
	@SuppressWarnings("rawtypes")
	public static void setUuid(List<AplusDeviceEntity> ades,
			Map<String, AplusConnectionEntity> aces) {
		Map<String, List> m_fqns = getFqnWithMoreDevices(aces);
		// 是同一连接信息的资源设备保持同一个uuid
		boolean b = false;
		List<List<String>> l_fqns = getListFON(m_fqns);
		// 存在一个连接对应多个设备的情况
		if (l_fqns.size() != 0) {
			// 设置资源设备的uuid
			for (List<String> fqns : l_fqns) {
				String uuid = UUID.randomUUID().toString();
				for (AplusDeviceEntity ade : ades) {
					for (String fqn : fqns) {
						// System.out.println("ade:"+ade.getFqn().equals(fqn) +
						// ade.getFqn() + "==" + fqn);
						b = ade.getFqn().equals(fqn);
						if (b) {
							ade.setConUuid(uuid);
							break;
						} else if (!containt(ade.getFqn(), l_fqns)) {// 防止多次循环覆盖之前的赋值。
							ade.setConUuid(UUID.randomUUID().toString());
						}
					}
				}
			}
			// 没有一个连接对应多个设备的情况
		} else {
			for (AplusDeviceEntity ade : ades) {
				ade.setConUuid(UUID.randomUUID().toString());
			}
		}
		// 设置连接信息的uuid
		for (String key : aces.keySet()) {
			aces.get(key).setConUuid(getUuid(ades, key));
		}
	}

	public static boolean containt(String fqn, List<List<String>> mm) {
		for (List<String> fqns : mm) {
			for (String fqn2 : fqns) {
				if (fqn2.equals(fqn)) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * 获取 和资源设备相同的uuid
	 */
	public static String getUuid(List<AplusDeviceEntity> ades, String fqn) {
		String uuid = "";
		for (AplusDeviceEntity ade : ades) {
			if (ade.getFqn().equals(fqn)) {
				uuid = ade.getConUuid();
			}
		}
		return uuid;
	}

	/**
	 * 根据类型获取cell的值
	 */
	public static String getStringCellValue(Cell cell) {
		String cellValue = null;
		switch (cell.getCellType()) {
		case HSSFCell.CELL_TYPE_NUMERIC: // 数字
			cellValue = cell.getNumericCellValue() + "";
			break;

		case HSSFCell.CELL_TYPE_STRING: // 字符串
			cellValue = cell.getStringCellValue();
			break;

		case HSSFCell.CELL_TYPE_BOOLEAN: // Boolean
			cellValue = cell.getBooleanCellValue() + "";
			break;

		case HSSFCell.CELL_TYPE_FORMULA: // 公式
			cellValue = cell.getCellFormula() + "";
			break;

		case HSSFCell.CELL_TYPE_BLANK: // 空值
			cellValue = " ";
			break;

		case HSSFCell.CELL_TYPE_ERROR: // 故障
			cellValue = "非法字符";
			break;

		default:
			cellValue = "未知类型";
			break;
		}

		return cellValue;
	}

	/**
	 * 将map转换成list
	 */
	public static List<AplusConnectionEntity> mapTransitionList(
			Map<String, AplusConnectionEntity> map) {
		List<AplusConnectionEntity> list = new ArrayList<AplusConnectionEntity>();
		Iterator<Entry<String, AplusConnectionEntity>> iter = map.entrySet()
				.iterator(); // 获得map的Iterator
		while (iter.hasNext()) {
			Entry<String, AplusConnectionEntity> entry = iter.next();
			list.add(entry.getValue());
		}
		// 去除重复的过程
		for (int i = 0; i < list.size() - 1; i++) {
			for (int j = list.size() - 1; j > i; j--) {
				if (list.get(j).equals(list.get(i))) {
					list.remove(j);
				}
			}
		}
		return list;
	}

	/**
	 * 得到多个设备连接同一条的连接信息
	 */
	@SuppressWarnings("rawtypes")
	public static Map<String, List> getFqnWithMoreDevices(
			Map<String, AplusConnectionEntity> aces) {
		List<String> fqns = new ArrayList<String>();
		List<Integer> counts = new ArrayList<Integer>();

		Map<String, List> result = new LinkedHashMap<String, List>();
		int count = 0;
		for (String ace : aces.keySet()) {
			count = getSameValueNum(aces, aces.get(ace));
			if (count > 1) {
				counts.add(count);
				fqns.add(ace);
			}
		}
		result.put("fqns", fqns);
		result.put("counts", counts);
		return result;
	}

	/**
	 * 获取map中相同value的个数
	 */
	public static int getSameValueNum(Map<String, AplusConnectionEntity> aces,
			AplusConnectionEntity ace) {
		int count = 0;
		for (AplusConnectionEntity ace2 : aces.values()) {
			// System.out.println(ace2.equals(ace));
			if (ace2.equals(ace)) {
				count++;
			}
		}

		return count;
	}

	/**
	 * 将找出来的重复连接信息进行分组包装,方便与添加uuid
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static List<List<String>> getListFON(Map<String, List> mm) {
		List<List<String>> result = new ArrayList<List<String>>();
		List<String> data = null;
		List<String> fqns = mm.get("fqns");
		List<Integer> counts = mm.get("counts");
		for (int i = 0; i < fqns.size(); i = i + counts.get(i)) {
			data = new ArrayList<String>();
			for (int j = i; j < counts.get(i) + i; j++) {
				data.add(fqns.get(j));
			}
			result.add(data);
		}
		return result;
	}

	/**
	 * 判定excel的版本
	 */
	static class VersionExcel {
		public static boolean isExcel2003(String filePath) {
			return filePath.matches("^.+\\.(?i)(xls)$");
		}

		public static boolean isExcel2007(String filePath) {
			return filePath.matches("^.+\\.(?i)(xlsx)$");
		}
	}
}

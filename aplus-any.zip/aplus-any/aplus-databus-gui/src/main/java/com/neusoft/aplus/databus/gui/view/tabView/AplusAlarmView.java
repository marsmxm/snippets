package com.neusoft.aplus.databus.gui.view.tabView;

import java.awt.BorderLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import com.neusoft.aplus.databus.gui.view.AplusMainView;
import com.neusoft.aplus.databus.gui.view.AplusViewUtil;

/**
 * 设备信息视图类
 * 
 * @author wuhao
 * @date 2015-4-14 下午2:46:42
 */
public class AplusAlarmView extends JPanel {

	private static final long serialVersionUID = 2910638634855554743L;

	private JPanel northPanel = null;
	private JPanel tablePanel = null;

	private JLabel deviceTypeLabel = null;
	private JLabel policyNameLabel = null;
	private JLabel alarmLeveLabel = null;
	private JLabel typeLabel = null;

	private ButtonGroup group = null;
	private JRadioButton undoneRadio = null;
	private JRadioButton hisRadio = null;

	private JComboBox deviceTypeComboBox = null;
	private JTextField resourcesNameText = null;
	private JComboBox alarmLevelComboBox = null;

	private JButton queryButton = null;
	private JButton resetButton = null;
	private JButton confirmButton = null;
	private JButton deleteButton = null;
	private JButton firstButton = null;
	private JButton preButton = null;
	private JButton nextButton = null;
	private JButton lastButton = null;

	private AplusMainView mainView = null;

	public AplusMainView getMainView() {
		return mainView;
	}

	public void setMainView(AplusMainView mainView) {
		this.mainView = mainView;
	}

	private JTable alarmTable = null;
	private int currPage = 0;// 当前页
	private int totalPage = 0;// 总页数
	private int pageSize = 20;// 每页数据量

	public AplusAlarmView() {
		init();
	}

	private void init() {

		this.setLayout(new BorderLayout());

		this.add(getNorthPanel(), BorderLayout.NORTH);
		this.add(getTablePanel(), BorderLayout.CENTER);
	}

	public JPanel getNorthPanel() {
		if (northPanel == null) {
			northPanel = AplusViewUtil.createBorderLayoutPanel();

			JPanel westPanel = AplusViewUtil.createGridLayoutPanel(2, 1, 0, -5);

			// 查询条件第一行
			JPanel upPanel = AplusViewUtil.createFlowLayoutPanel();
			upPanel.add(getDeviceTypeLabel());
			upPanel.add(getDeviceTypeComboBox());
			upPanel.add(getPolicyNameLabel());
			upPanel.add(getResourcesNameText());

			JPanel downPanel = AplusViewUtil.createFlowLayoutPanel();
			downPanel.add(getArarmLevelLabel());
			downPanel.add(getArarmLevelComboBox());
			downPanel.add(getTypeLabel());
			downPanel.add(getUndoneRadio());
			downPanel.add(getHisRadio());

			group = new ButtonGroup();
			group.add(getUndoneRadio());
			group.add(getHisRadio());
			getUndoneRadio().setSelected(true);

			westPanel.add(upPanel);
			westPanel.add(downPanel);

			JPanel buttonPanel = AplusViewUtil
					.createGridLayoutPanel(2, 1, 0, 5);
			buttonPanel.add(getQueryButton());
			buttonPanel.add(getResetButton());

			northPanel.add(westPanel, BorderLayout.CENTER);
			northPanel.add(buttonPanel, BorderLayout.EAST);

			Border border = AplusViewUtil.createPanelBorder("查询条件");
			northPanel.setBorder(border);

		}
		return northPanel;
	}

	public JPanel getTablePanel() {
		if (tablePanel == null) {
			tablePanel = AplusViewUtil.createBorderLayoutPanel();

			JScrollPane scroll = new JScrollPane(getAlarmTable());
			scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

			setColumnSize();
			// 查询按钮Panel
			JPanel buttonPanel = AplusViewUtil
					.createGridLayoutPanel(6, 1, 0, 5);
			buttonPanel.add(getFirstButton());
			buttonPanel.add(getPreButton());
			buttonPanel.add(getNextButton());
			buttonPanel.add(getLastButton());
			buttonPanel.add(getConfirmButton());
			buttonPanel.add(getDeleteButton());

			JPanel eastPanel = AplusViewUtil.createBorderLayoutPanel();
			JPanel blankLabel = new JPanel();

			eastPanel.add(buttonPanel, BorderLayout.SOUTH);
			eastPanel.add(blankLabel, BorderLayout.CENTER);

			tablePanel.add(scroll, BorderLayout.CENTER);
			tablePanel.add(eastPanel, BorderLayout.EAST);

			Border border = AplusViewUtil.createPanelBorder("设备列表");
			tablePanel.setBorder(border);

		}
		return tablePanel;
	}

	private void setColumnSize() {
		TableColumnModel cm = getAlarmTable().getColumnModel(); // 表格的列模型
		cm.getColumn(0).setPreferredWidth(30);
		cm.getColumn(0).setPreferredWidth(30);
		cm.getColumn(2).setPreferredWidth(150);
		cm.getColumn(4).setPreferredWidth(150);

		TableColumn tc = getAlarmTable().getTableHeader().getColumnModel()
				.getColumn(7);
		tc.setMaxWidth(0);
		tc.setPreferredWidth(0);
		tc.setWidth(0);
		tc.setMinWidth(0);
		getAlarmTable().getTableHeader().getColumnModel().getColumn(7)
				.setMaxWidth(0);
		getAlarmTable().getTableHeader().getColumnModel().getColumn(7)
				.setMinWidth(0);

	}

	@SuppressWarnings("serial")
	public JTable getAlarmTable() {
		if (alarmTable == null) {
			DefaultTableModel tableModel = new DefaultTableModel() {
				@Override
				public Class<?> getColumnClass(int columnIndex) {
					if (columnIndex == 0)
						return Boolean.class;
					return super.getColumnClass(columnIndex);
				}
			};
			tableModel.addColumn("选择");
			tableModel.addColumn("级别");
			tableModel.addColumn("内容");
			tableModel.addColumn("关联设备");
			tableModel.addColumn("发生时间");
			tableModel.addColumn("处理状态");
			tableModel.addColumn("确认");
			tableModel.addColumn("告警id");

			alarmTable = new JTable(tableModel) {
				public boolean isCellEditable(int row, int column) {
					if (column == 0)
						return true;
					else
						return false;
				};
			};
			// alarmTable.setEnabled(false);
			alarmTable.setAutoCreateRowSorter(true);
			alarmTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			alarmTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		}
		return alarmTable;
	}

	public JLabel getDeviceTypeLabel() {
		if (deviceTypeLabel == null) {
			deviceTypeLabel = new JLabel("设备类型:");
		}
		return deviceTypeLabel;
	}

	public JLabel getPolicyNameLabel() {
		if (policyNameLabel == null) {
			policyNameLabel = new JLabel("  资源名称:");
		}
		return policyNameLabel;
	}

	public JLabel getArarmLevelLabel() {
		if (alarmLeveLabel == null) {
			alarmLeveLabel = new JLabel("告警级别:");
		}
		return alarmLeveLabel;
	}

	public JLabel getTypeLabel() {
		if (typeLabel == null) {
			typeLabel = new JLabel("   性质:");
		}
		return typeLabel;
	}

	public JComboBox getDeviceTypeComboBox() {
		if (deviceTypeComboBox == null) {
			deviceTypeComboBox = AplusViewUtil.getComboBox(200,
					AplusViewUtil.comboBoxdefaulheight);
		}
		return deviceTypeComboBox;
	}

	public JComboBox getArarmLevelComboBox() {
		if (alarmLevelComboBox == null) {
			alarmLevelComboBox = AplusViewUtil.getComboBox(200,
					AplusViewUtil.comboBoxdefaulheight);
		}
		return alarmLevelComboBox;
	}

	public JTextField getResourcesNameText() {
		if (resourcesNameText == null) {
			resourcesNameText = AplusViewUtil.createJTextFiled();
		}
		return resourcesNameText;
	}

	public JButton getQueryButton() {
		if (queryButton == null) {
			queryButton = AplusViewUtil.createButton("查询");
		}
		return queryButton;
	}

	public JButton getResetButton() {
		if (resetButton == null) {
			resetButton = AplusViewUtil.createButton("重置");
		}
		return resetButton;
	}

	public JButton getConfirmButton() {
		if (confirmButton == null) {
			confirmButton = AplusViewUtil.createButton("确认告警");
		}
		return confirmButton;
	}

	public JButton getDeleteButton() {
		if (deleteButton == null) {
			deleteButton = AplusViewUtil.createButton("删除历史");
		}
		return deleteButton;
	}

	public JButton getFirstButton() {
		if (firstButton == null) {
			firstButton = AplusViewUtil.createButton("首页");
		}
		return firstButton;
	}

	public JButton getPreButton() {
		if (preButton == null) {
			preButton = AplusViewUtil.createButton("上一页");
		}
		return preButton;
	}

	public JButton getNextButton() {
		if (nextButton == null) {
			nextButton = AplusViewUtil.createButton("下一页");
		}
		return nextButton;
	}

	public JButton getLastButton() {
		if (lastButton == null) {
			lastButton = AplusViewUtil.createButton("尾页");
		}
		return lastButton;
	}

	public JRadioButton getUndoneRadio() {
		if (undoneRadio == null) {
			undoneRadio = new JRadioButton("未处理");
		}
		return undoneRadio;
	}

	public JRadioButton getHisRadio() {
		if (hisRadio == null) {
			hisRadio = new JRadioButton("历史");
		}
		return hisRadio;
	}

	public int getCurrPage() {
		return currPage;
	}

	public void setCurrPage(int currPage) {
		this.currPage = currPage;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getPageSize() {
		return pageSize;
	}

}

package com.neusoft.aplus.databus.gui.view.filter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

/**
 * IP输入限制
 * @author WanWei
 * @date 2013-5-20 下午2:50:35
 */
public class IPFilter extends DocumentFilter {

    private int maxLength = 15;

    private Pattern numPattern = Pattern.compile("[0-9.]*");
    
    private Pattern sepPattern = Pattern.compile("[.]");

    @Override
    public void insertString(FilterBypass fb, int offset, String string,
            AttributeSet attr) throws BadLocationException {
        if ((fb.getDocument().getLength() + string.length()) > maxLength) {
            return;
        }
        Matcher isIP = numPattern.matcher(string);
        Matcher isSep = sepPattern.matcher(string);
        if (offset == 0) {
            if (isSep.matches()) {
                return;
            }
        }
        if (!isIP.matches()) {
            return;
        }

        super.insertString(fb, offset, string, attr);
    }

    @Override
    public void replace(FilterBypass fb, int offset, int length, String text,
            AttributeSet attrs) throws BadLocationException {
        if ((fb.getDocument().getLength() + text.length() - length) > maxLength) {
            return;
        }
        Matcher isNum = numPattern.matcher(text);
        Matcher isSep = sepPattern.matcher(text);
        if (offset == 0) {
            if (isSep.matches()) {
                return;
            }
        }
        if (!isNum.matches()) {
            return;
        }

        super.replace(fb, offset, length, text, attrs);
    }
}

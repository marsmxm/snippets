package com.neusoft.aplus.databus.gui.view;

import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 * @author wuhao
 * @date 2015-4-16 上午11:39:41
 */
public class AplusDataBusLoginView extends AplusBaseView  {

	private static final long serialVersionUID = 5808954735972598794L;
	
	public AplusDataBusLoginView(){
		initLayout("DataBusLoginView.xml");
		initView();
	}
	
	private void initView(){
	}
	
	public JTextField getUserTextField(){
		return (JTextField)injection.getComponentById("databus_login_user_field");
	}
	
	public JPasswordField getPassTextField(){
		return (JPasswordField)injection.getComponentById("databus_login_pass_field");
	}
	

	public JButton getConfirmButton(){
		return (JButton)injection.getComponentById("login_button");
	}
	
	public JButton getCancelButton(){
		return (JButton)injection.getComponentById("cancel_button");
	}
}

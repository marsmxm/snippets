package com.neusoft.aplus.databus.gui.view.tabView;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AbstractDocument;

import com.neusoft.aplus.databus.gui.constant.AplusGuiConstant;
import com.neusoft.aplus.databus.gui.view.AplusViewUtil;
import com.neusoft.aplus.databus.gui.view.filter.IPFilter;

/**
 * 设备信息视图类
 * 
 * @author wuhao
 * @date 2015-4-14 下午2:46:42
 */
public class AplusPolicyManageView extends JDialog {

	private static final long serialVersionUID = 2910638634855554743L;

	// private static Logger log = Logger.getLogger(AplusDeviceView.class);
	// AplusDeviceView的主Panel，所有的控件都基于此。
	private JPanel mainPanel = null;
	private JPanel northPanel = null;
	private JPanel tablePanel = null;
	private JPanel buttonPanel = null;

	private JLabel resNameLabel = null; // 资源名称
	private JLabel totalLabel = null;// 总计值
	private JLabel hadLabel = null;// 已有值
	private JLabel unitLabel = null;//单位

	public JLabel getUnitLabel() {
		if(unitLabel==null){
			unitLabel=new JLabel();
		}
		return unitLabel;
	}

	private JButton savenaddButton = null;// 保存并新增
	private JButton saveButton = null;// 保存
	private JButton backButton = null;// 返回
	private JButton addButton = null;// 添加参数

	private ButtonGroup typegroup = null;
	private JRadioButton metricRadio = null;
	private JRadioButton properRadio = null;

	private JTable totalTable = null;
	private JTable hadTable = null;

	private ButtonGroup effectgroup = null; // 生效设置的buttongroup
	private JRadioButton immediatelyRadio = null;// 立即生效
	private JRadioButton noeffectRadio = null; // 暂时不生效

	private ButtonGroup notifygroup = null; // 通知类型的buttongroup
	private JRadioButton alarmRadio = null;// 告警
	private JRadioButton eventRadio = null; // 事件

	private ButtonGroup triggergroup = null;// 触发的buttongroup
	private JRadioButton everyTriRadio = null;// 每次条件满足触发
	private JRadioButton countTriRadio = null; // 连续到达几次时触发

	private ButtonGroup cleargroup = null;// 清除的buttongroup
	private JRadioButton everyClearRadio = null;// 一旦条件不满足时清除
	private JRadioButton countClearRadio = null; // 连续到达几次时清除

	private AplusAlarmNotifyView aplusAlarmNotifyView;
	
	private JButton metricAdd=null;
	private JButton metricDelete=null;

	private JTextField policyName = null;
	private JTextField threshold = null;
	private JComboBox thresholdCiComboBox = null;


	public JComboBox getThresholdCiComboBox() {
		if (thresholdCiComboBox == null) {
			thresholdCiComboBox = AplusViewUtil.getComboBox(288,
					AplusViewUtil.comboBoxdefaulheight);
			thresholdCiComboBox.addItem(">");
			thresholdCiComboBox.addItem("<");
			thresholdCiComboBox.addItem(">=");
			thresholdCiComboBox.addItem("<=");
			thresholdCiComboBox.addItem("=");
			thresholdCiComboBox.addItem("!=");
		}
		return thresholdCiComboBox;
	}

	private JTextArea policyDes = null;

	public void setPolicyDes(JTextArea policyDes) {
		this.policyDes = policyDes;
	}

	// 操作模式 新增or编辑
	private int operMode = AplusGuiConstant.DIALOG_OPERMODE_ADD;

	public AplusPolicyManageView() {
		init();
	}

	private void init() {
		mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());

		mainPanel.add(getNorthPanel(), BorderLayout.NORTH);
		mainPanel.add(getCenterPanel(), BorderLayout.CENTER);
		mainPanel.add(getButtonPanel(), BorderLayout.SOUTH);

		buttonGroupInit();

		this.add(mainPanel);

		this.setSize(627, 717);
		this.setResizable(false);
		this.setModal(true);
	}

	private Component getButtonPanel() {
		if (buttonPanel == null) {
			buttonPanel = AplusViewUtil.createFlowLayoutPanel();
			buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
			buttonPanel.add(getSavenAddButton());
			buttonPanel.add(getSaveButton());
			buttonPanel.add(getBackButton());
		}
		return buttonPanel;
	}

	public JPanel getNorthPanel() {
		if (northPanel == null) {
			northPanel = AplusViewUtil.createFlowLayoutPanel();

			northPanel.add(new JLabel("资源名称："));
			northPanel.add(getResNameLabel());
		}
		return northPanel;
	}

	public JPanel getCenterPanel() {
		if (tablePanel == null) {
			tablePanel = AplusViewUtil.createBorderLayoutPanel();

			// 基本信息panel
			JPanel basePanel = AplusViewUtil.createBorderLayoutPanel();

			JPanel baseUpPanel = AplusViewUtil.createFlowLayoutPanel();
			baseUpPanel.add(new JLabel("策略名称："));
			baseUpPanel.add(getPolicyName());

			JPanel baseDownPanel = AplusViewUtil.createFlowLayoutPanel();
			baseDownPanel.add(new JLabel("    描述："));
			baseDownPanel.add(getPolicyDes());

			basePanel.add(baseUpPanel, BorderLayout.NORTH);
			basePanel.add(baseDownPanel, BorderLayout.CENTER);
			basePanel.setBorder(AplusViewUtil.createPanelBorder("基本信息"));

			// 生效设置panel
			JPanel effectPanel = AplusViewUtil.createGridLayoutPanel(2, 1, 0,
					-5);
			effectPanel.add(getImmediatelyRadio());
			effectPanel.add(getNoeffectRadio());
			effectPanel.setBorder(AplusViewUtil.createPanelBorder("生效设置"));

			// 阈值设置panel
			JPanel thresholdPanel = AplusViewUtil.createGridLayoutPanel(2, 1,
					0, -5);

			JPanel thresholdUpPanel = AplusViewUtil.createFlowLayoutPanel();
			thresholdUpPanel.add(new JLabel("  运算符："));
			thresholdUpPanel.add(getThresholdCiComboBox());

			JPanel thresholdDownPanel = AplusViewUtil.createFlowLayoutPanel();
			thresholdDownPanel.add(new JLabel("    阈值："));
			thresholdDownPanel.add(getThreshold());
			thresholdDownPanel.add(getUnitLabel());

			thresholdPanel.add(thresholdUpPanel);
			thresholdPanel.add(thresholdDownPanel);
			thresholdPanel.setBorder(AplusViewUtil.createPanelBorder("阈值设置"));

			// 通知panel
			JPanel notifyPanel = AplusViewUtil.createBorderLayoutPanel();

			notifyPanel.add(getAplusAlarmNotifyView(), BorderLayout.CENTER);
			notifyPanel.setBorder(AplusViewUtil.createPanelBorder("通知"));

			JPanel tableNorthPanel = AplusViewUtil.createGridLayoutPanel(2, 1);
			tableNorthPanel.add(thresholdPanel);
			tableNorthPanel.add(effectPanel);

			JPanel borPanel = AplusViewUtil.createBorderLayoutPanel();
			borPanel.add(basePanel, BorderLayout.NORTH);
			borPanel.add(tableNorthPanel, BorderLayout.CENTER);

			JPanel centerPanel = AplusViewUtil.createBorderLayoutPanel();
			centerPanel.add(notifyPanel, BorderLayout.CENTER);
			centerPanel.add(borPanel, BorderLayout.NORTH);

			centerPanel.setBorder(AplusViewUtil.createPanelBorder());

			tablePanel.add(centerPanel, BorderLayout.EAST);
			tablePanel.add(getLeftPanel(), BorderLayout.CENTER);

		}
		return tablePanel;
	}

	private JPanel getLeftPanel() {

		JPanel leftPanel = AplusViewUtil.createGridLayoutPanel(2, 1);

		JPanel leftUpPanel = AplusViewUtil.createBorderLayoutPanel();

		JPanel leftUpRadioPanel = AplusViewUtil.createFlowLayoutPanel();
		leftUpRadioPanel.add(getMetricRadio());
		leftUpRadioPanel.add(getProperRadio());
		
		JPanel leftNorth1Panel = AplusViewUtil.createBorderLayoutPanel();
		leftNorth1Panel.add(getTotalLabel(),BorderLayout.CENTER);
		leftNorth1Panel.add(getMetricAdd(),BorderLayout.EAST);

		JPanel leftNorthPanel = AplusViewUtil.createBorderLayoutPanel();
		leftNorthPanel.add(leftUpRadioPanel, BorderLayout.CENTER);
		leftNorthPanel.add(leftNorth1Panel, BorderLayout.SOUTH);

		leftNorth1Panel.setBorder(AplusViewUtil.createPanelBorder());

		JScrollPane totalscrollPane = new JScrollPane();
		totalscrollPane
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		totalscrollPane
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		totalscrollPane.setViewportView(getTotalTable());

		leftUpPanel.add(totalscrollPane, BorderLayout.CENTER);
		leftUpPanel.add(leftNorthPanel, BorderLayout.NORTH);

		JPanel leftDownPanel = AplusViewUtil.createBorderLayoutPanel();

		JPanel leftUp2RadioPanel = AplusViewUtil.createFlowLayoutPanel();
		leftUp2RadioPanel.add(new JLabel("已有策略"));
		
		JPanel leftUp3RadioPanel = AplusViewUtil.createBorderLayoutPanel();
		leftUp3RadioPanel.add(getHadLabel(),BorderLayout.CENTER);
		leftUp3RadioPanel.add(getMetricDelete(),BorderLayout.EAST);

		JPanel leftNorth2Panel = AplusViewUtil.createBorderLayoutPanel();
		leftNorth2Panel.add(leftUp2RadioPanel, BorderLayout.CENTER);
		leftNorth2Panel.add(leftUp3RadioPanel, BorderLayout.SOUTH);

		leftUp3RadioPanel.setBorder(AplusViewUtil.createPanelBorder());

		JScrollPane hadscrollPane = new JScrollPane();
		hadscrollPane
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		hadscrollPane
				.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		hadscrollPane.setViewportView(getHadTable());

		leftDownPanel.add(hadscrollPane, BorderLayout.CENTER);
		leftDownPanel.add(leftNorth2Panel, BorderLayout.NORTH);

		leftPanel.add(leftUpPanel);
		leftPanel.add(leftDownPanel);

		getTotalLabel().setText(AplusGuiConstant.TOTAL_STRING + "      ");
		getHadLabel().setText(AplusGuiConstant.TOTAL_STRING + "      ");

		return leftPanel;
	}

	private void buttonGroupInit() {
		cleargroup = new ButtonGroup();
		cleargroup.add(getEveryClearRadio());
		cleargroup.add(getCountClearRadio());
		getEveryClearRadio().setSelected(true);

		triggergroup = new ButtonGroup();
		triggergroup.add(getEveryTriRadio());
		triggergroup.add(getCountTriRadio());
		getEveryTriRadio().setSelected(true);

		effectgroup = new ButtonGroup();
		effectgroup.add(getImmediatelyRadio());
		effectgroup.add(getNoeffectRadio());
		getImmediatelyRadio().setSelected(true);

		notifygroup = new ButtonGroup();
		notifygroup.add(getAlarmRadio());
		notifygroup.add(getEventRadio());
		getAlarmRadio().setSelected(true);

		typegroup = new ButtonGroup();
		typegroup.add(getMetricRadio());
		typegroup.add(getProperRadio());
		getMetricRadio().setSelected(true);
	}

	public JLabel getResNameLabel() {
		if (resNameLabel == null) {
			resNameLabel = new JLabel("");
		}
		return resNameLabel;
	}

	public JButton getSavenAddButton() {
		if (savenaddButton == null) {
			savenaddButton = AplusViewUtil.createButton("保存并新增");
		}
		return savenaddButton;
	}

	public JButton getSaveButton() {
		if (saveButton == null) {
			saveButton = AplusViewUtil.createButton("保存");
		}
		return saveButton;
	}

	public JButton getBackButton() {
		if (backButton == null) {
			backButton = AplusViewUtil.createButton("返回");
		}
		return backButton;
	}

	public JRadioButton getMetricRadio() {
		if (metricRadio == null) {
			metricRadio = new JRadioButton("指标");
		}
		return metricRadio;
	}

	public JRadioButton getProperRadio() {
		if (properRadio == null) {
			properRadio = new JRadioButton("属性");
		}
		return properRadio;
	}

	public JRadioButton getImmediatelyRadio() {
		if (immediatelyRadio == null) {
			immediatelyRadio = new JRadioButton("立即生效");
		}
		return immediatelyRadio;
	}

	public JRadioButton getNoeffectRadio() {
		if (noeffectRadio == null) {
			noeffectRadio = new JRadioButton("暂时不生效");
		}
		return noeffectRadio;
	}

	public JRadioButton getAlarmRadio() {
		if (alarmRadio == null) {
			alarmRadio = aplusAlarmNotifyView.getAlarmRadioButton();
		}
		return alarmRadio;
	}

	public JRadioButton getEventRadio() {
		if (eventRadio == null) {
			eventRadio = aplusAlarmNotifyView.getEventRadioButton();
		}
		return eventRadio;
	}

	public JRadioButton getEveryTriRadio() {
		if (everyTriRadio == null) {
			everyTriRadio = aplusAlarmNotifyView.getTriEveryRadioButton();
		}
		return everyTriRadio;
	}

	public JRadioButton getCountTriRadio() {
		if (countTriRadio == null) {
			countTriRadio = aplusAlarmNotifyView.getTriCountRadioButton();
		}
		return countTriRadio;
	}

	public JRadioButton getEveryClearRadio() {
		if (everyClearRadio == null) {
			everyClearRadio = aplusAlarmNotifyView.getClearEveryRadioButton();
		}
		return everyClearRadio;
	}

	public JRadioButton getCountClearRadio() {
		if (countClearRadio == null) {
			countClearRadio = aplusAlarmNotifyView.getClearCountRadioButton();
		}
		return countClearRadio;
	}

	public JButton getAddButton() {
		if (addButton == null) {
			addButton = aplusAlarmNotifyView.getAddButton();
		}
		return addButton;
	}

	public JLabel getTotalLabel() {
		if (totalLabel == null) {
			totalLabel = new JLabel();
		}
		return totalLabel;
	}

	public JLabel getHadLabel() {
		if (hadLabel == null) {
			hadLabel = new JLabel();
		}
		return hadLabel;
	}

	public JTable getTotalTable() {
		if (totalTable == null) {
			totalTable = new JTable();

			DefaultTableModel tableModel = new DefaultTableModel();
			tableModel.addColumn("指标代码");
			tableModel.addColumn("指标名称");
			tableModel.addColumn("指标单位");

			totalTable = new JTable(tableModel) {
	
				private static final long serialVersionUID = -3255127205977283054L;

				public boolean isCellEditable(int row, int column) {
					return false;
				}
			};
			totalTable.setAutoCreateRowSorter(true);
			totalTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			totalTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			totalTable.getTableHeader().setVisible(false);
			DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
			renderer.setPreferredSize(new Dimension(0, 0));
			totalTable.getTableHeader().setDefaultRenderer(renderer);
		}
		return totalTable;
	}

	public JTable getHadTable() {
		if (hadTable == null) {
			hadTable = new JTable();
			
			DefaultTableModel tableModel = new DefaultTableModel();
			tableModel.addColumn("指标代码");
			tableModel.addColumn("指标名称");
			tableModel.addColumn("指标单位");

			hadTable = new JTable(tableModel){
				
				private static final long serialVersionUID = -5678036296700789941L;

				public boolean isCellEditable(int row, int column) {
					return false;
				}
			};
			hadTable.setAutoCreateRowSorter(true);
			hadTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			hadTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			hadTable.getTableHeader().setVisible(false);  
            DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();  
            renderer.setPreferredSize(new Dimension(0, 0));  
            hadTable.getTableHeader().setDefaultRenderer(renderer);  
		}
		return hadTable;
	}

	public int getOperMode() {
		return operMode;
	}

	public void setOperMode(int operMode) {
		this.operMode = operMode;
		if (operMode == AplusGuiConstant.DIALOG_OPERMODE_ADD) {
			this.setTitle("添加策略");
		} else {
			this.setTitle("编辑策略");
		}
	}

	public AplusAlarmNotifyView getAplusAlarmNotifyView() {
		if (aplusAlarmNotifyView == null) {
			aplusAlarmNotifyView = new AplusAlarmNotifyView();
		}
		return aplusAlarmNotifyView;
	}

	public void setAplusAlarmNotifyView(
			AplusAlarmNotifyView aplusAlarmNotifyView) {
		this.aplusAlarmNotifyView = aplusAlarmNotifyView;
	}

	public JTextField getPolicyName() {
		if (policyName == null) {
			policyName = AplusViewUtil.createJTextFiled(40);
		}
		return policyName;
	}

	public JTextArea getPolicyDes() {
		if (policyDes == null) {
			policyDes = new JTextArea(3, 40);
		}
		return policyDes;
	}
	public JButton getMetricAdd() {
		if (metricAdd == null) {
			metricAdd = AplusViewUtil.createButton("增加");
		}
		return metricAdd;
	}

	public JButton getMetricDelete() {
		if (metricDelete == null) {
			metricDelete = AplusViewUtil.createButton("删除");
		}
		return metricDelete;
	}
	public JTextField getThreshold() {
		if (threshold == null) {
			threshold = AplusViewUtil.createJTextFiled(30);
			((AbstractDocument) threshold.getDocument()).setDocumentFilter(new IPFilter());
		}
		return threshold;
	}
}

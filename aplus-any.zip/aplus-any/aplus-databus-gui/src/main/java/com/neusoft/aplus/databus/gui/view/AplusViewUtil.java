package com.neusoft.aplus.databus.gui.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.AbstractDocument;
import javax.swing.text.DocumentFilter;

/**
 * @author wuhao
 * @date 2015-4-14 下午3:39:52
 */
public class AplusViewUtil {

	public static int comboBoxdefaulwidth = 100;
	public static int comboBoxdefaulheight = 20;
	public static int buttondefaulwidth = 90;
	public static int buttondefaulheight = 25;
	public static int textFileddefaultcolumns = 15;

	private static FontUIResource fontUIRes;

	public static JPanel createBorderLayoutPanel() {
		JPanel returnPanel = new JPanel();
		returnPanel.setLayout(new BorderLayout());
		return returnPanel;
	}

	public static JPanel createFlowLayoutPanel() {
		JPanel returnPanel = new JPanel();
		returnPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		return returnPanel;
	}

	public static JPanel  createGridLayoutPanel(int rows, int cols,int hgap,int vgap) {
		JPanel returnPanel = new JPanel();
		GridLayout grid = new GridLayout(rows, cols);
		grid.setHgap(hgap);
		grid.setVgap(vgap);
		returnPanel.setLayout(grid);
		
		return returnPanel;
	}
	
	public static JPanel createGridLayoutPanel(int rows, int cols) {
		JPanel returnPanel = new JPanel();
		returnPanel.setLayout(new GridLayout(rows,cols));
		
		return returnPanel;
	}

	public static JTextField createJTextFiled() {
		return createJTextFiled(textFileddefaultcolumns, null);
	}

	public static JTextField createJTextFiled(int len) {
		return createJTextFiled(len, null);
	}

	public static JTextField createJTextFiled(int len, DocumentFilter filter) {

		JTextField textField = new JTextField(len);
		if (filter != null) {
			((AbstractDocument) textField.getDocument())
					.setDocumentFilter(filter);
		}
		return textField;
	}

	public static JComboBox getComboBox() {
		return getComboBox(comboBoxdefaulwidth, comboBoxdefaulheight);
	}

	public static JComboBox getComboBox(int width, int height) {
		JComboBox comboBox = new JComboBox();
		Dimension dimension = new Dimension(width, height);
		comboBox.setEditable(false);
		comboBox.setMaximumSize(dimension);
		comboBox.setMinimumSize(dimension);
		comboBox.setPreferredSize(dimension);

		return comboBox;
	}

	public static Border createPanelBorder(String title) {
		Border statPanelBorder = BorderFactory.createTitledBorder(
				BorderFactory.createTitledBorder(""), title, TitledBorder.LEFT,
				TitledBorder.TOP, fontUIRes);

		return statPanelBorder;
	}
	
	public static Border createPanelBorder() {
		Border statPanelBorder = BorderFactory.createTitledBorder(
				BorderFactory.createTitledBorder(""), null, TitledBorder.LEFT,
				TitledBorder.TOP, fontUIRes);

		return statPanelBorder;
	}

	public static JButton createButton(String name) {
		return createButton(buttondefaulwidth, buttondefaulheight, name);
	}

	public static JButton createButton(int width, int height, String name) {
		JButton button = new JButton(name);
		Dimension dimension = new Dimension(width, height);
		button.setMaximumSize(dimension);
		button.setMinimumSize(dimension);
		button.setPreferredSize(dimension);

//		button.setBorder(new EmptyBorder(20,20,20,20));
		
		return button;
	}
}

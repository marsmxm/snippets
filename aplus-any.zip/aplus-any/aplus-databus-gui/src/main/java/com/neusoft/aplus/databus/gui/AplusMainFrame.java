package com.neusoft.aplus.databus.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Enumeration;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.StandardChartTheme;
import org.jvnet.substance.skin.SubstanceFieldOfWheatLookAndFeel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neusoft.aplus.common.util.FileUtil;
import com.neusoft.aplus.databus.gui.constant.AplusGuiConstant;
import com.neusoft.aplus.databus.gui.control.AplusCenterControl;
import com.neusoft.aplus.databus.gui.control.AplusMainControl;
import com.neusoft.aplus.databus.gui.control.AplusWorkSpaceControl;
import com.neusoft.aplus.databus.gui.view.AplusCenterView;
import com.neusoft.aplus.databus.gui.view.AplusDataBusNodeListView;
import com.neusoft.aplus.databus.gui.view.AplusDataBusWorkSpaceView;
import com.neusoft.aplus.databus.gui.view.AplusMainView;

/**
 * GUI窗口
 * 
 * @author WanWei
 * @date 2015-4-13 下午8:24:18
 */
public class AplusMainFrame {

	private static Logger log = LoggerFactory.getLogger(AplusMainFrame.class);

	// 主窗口
	private JFrame mainFrame;

	private final static String TITLE = "DataBus管理客户端";

	private AplusMainView mainView;

	private AplusDataBusNodeListView nodeView;

	private AplusDataBusWorkSpaceView workspaceView;

	private AplusCenterView centerView;

	/**
	 * 初始化
	 */
	public AplusMainFrame() {
		mainFrame = new JFrame(TITLE);

		// 默认大小
		Dimension mainframeSize = new Dimension(1060, 720);
		mainFrame.setSize(mainframeSize);

		// 最小size
		Dimension MinimumSize = new Dimension(940, 600);
		mainFrame.setMinimumSize(MinimumSize);

		// 允许最大化
		mainFrame.setResizable(true);

		mainFrame.setLocationRelativeTo(null);
		mainFrame.setLayout(new BorderLayout());
		
		//设置除标题外其他界面元素的字体
		InitGlobalFont(new Font("宋体", Font.PLAIN, 13));
		
		initFrameLogo();
		initJfreeChartStandard();
		initMainFrameUI();

		mainFrame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowevent) {
				int rerurnVar = JOptionPane.showConfirmDialog(mainView,
						"请确认是否退出客户端?", AplusGuiConstant.CONFIRM_MARK,
						JOptionPane.YES_NO_OPTION);
				if (rerurnVar == JOptionPane.NO_OPTION) {
					mainFrame
							.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
					return;
				} else {
					mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				}
			}
		});

	}

	/**
	 * 初始化窗体LOGO图标
	 * 
	 * @author WanWei
	 * @date 2015-4-13 下午8:51:32
	 */
	private void initFrameLogo() {
		Toolkit tk = Toolkit.getDefaultToolkit();
		Image image = tk.createImage(FileUtil.getRepositoryPath("logo.png"));
		mainFrame.setIconImage(image);
	}

	/**
	 * 初始化主窗口中的元素
	 */
	private void initMainFrameUI() {
		mainView = AplusMainControl.getInstance().getMainView();
		nodeView = AplusMainControl.getInstance().getNodeView();
		workspaceView = AplusWorkSpaceControl.getInstance().getView();
		centerView = AplusCenterControl.getInstance().getView();
		centerView.setMainView(mainView);
		workspaceView.getWorkSpacePanel().add(centerView, BorderLayout.CENTER);
		mainView.getWorkSpacePanel().setLeftComponent(nodeView);
		mainView.getWorkSpacePanel().setRightComponent(workspaceView);
		mainFrame.add(mainView, BorderLayout.CENTER);
		mainView.setMainFrame(mainFrame);
	}

	/**
	 * 
	 * 初始化画图工具的主题
	 * 
	 * @author WanWei
	 * @date 2015-4-16 下午5:28:51
	 */
	private void initJfreeChartStandard() {

		// 创建主题样式
		StandardChartTheme standardChartTheme = new StandardChartTheme("CN");
		// 设置标题字体
		standardChartTheme.setExtraLargeFont(new Font("宋体", Font.BOLD, 18));
		// 设置图例的字体
		standardChartTheme.setRegularFont(new Font("宋体", Font.PLAIN, 14));
		// 设置轴向的字体
		standardChartTheme.setLargeFont(new Font("宋体", Font.PLAIN, 14));
		// 应用主题样式
		ChartFactory.setChartTheme(standardChartTheme);
	}

	/**
	 * 是否显示主窗口
	 */
	public void showMainFrame(final boolean display) {
		Runnable run = new Runnable() {// 实例化更新组件的线程
			public void run() {
				mainFrame.setVisible(display);

			}
		};
		SwingUtilities.invokeLater(run);
	}

	/**
	 * 统一设置界面的字体
	 * 
	 * @param font
	 * @author WanWei
	 * @date 2015-4-18 上午11:43:26
	 */
	private static void InitGlobalFont(Font font) {
		FontUIResource fontRes = new FontUIResource(font);
		for (Enumeration<Object> keys = UIManager.getDefaults().keys(); keys
				.hasMoreElements();) {
			Object key = keys.nextElement();
			Object value = UIManager.get(key);
			if (value instanceof FontUIResource) {
				UIManager.put(key, fontRes);
			}
		}
	}

	public static void main(String[] args) {
		try {
			// 设置主题
			UIManager.setLookAndFeel(new SubstanceFieldOfWheatLookAndFeel());
			JDialog.setDefaultLookAndFeelDecorated(true);
			JFrame.setDefaultLookAndFeelDecorated(true);
		} catch (Exception e) {
			log.warn("设置首选主题失败，将使用系统默认主题!");
		}

		AplusMainFrame mf = new AplusMainFrame();
		mf.showMainFrame(true);
		 AplusMainControl.getInstance().showLoginDialog(AplusMainControl.getInstance().getMainView());
	}

}

package com.neusoft.aplus.databus.gui.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import com.neusoft.aplus.databus.gui.view.filter.ExcelFileFilter;

/**
 * @author wuhao
 * @date 2015-4-16 下午2:05:36
 */
public class AplusDataBusFileChooserDialog extends JDialog {

	private static final long serialVersionUID = -2996622748224669325L;
	private JFileChooser fileChooser = null;
	
	private JButton confirmButton = null;
	private JButton importButton = null;
	private JButton cancelButton = null;
	
	private JTextField fileNameText = null;

	public AplusDataBusFileChooserDialog() {

		this.setTitle("导入设备");
		init();
	}

	private void init() {

		this.setSize(430, 100);
		this.setModal(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		this.getContentPane().setLayout(new BorderLayout());

		JPanel selectPanel = AplusViewUtil.createFlowLayoutPanel();
		selectPanel.add(new JLabel("Excel选择:"));
		selectPanel.add(getFileNameText());
		selectPanel.add(getImportButton());

		JPanel buttonPanel = AplusViewUtil.createFlowLayoutPanel();
		buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
		buttonPanel.add(getConfirmButton());
		buttonPanel.add(getCancelButton());

		this.getContentPane().add(selectPanel, BorderLayout.NORTH);
		this.getContentPane().add(buttonPanel, BorderLayout.CENTER);

	}

	public JFileChooser getFileChooser() {
		if (fileChooser == null) {

			fileChooser = new JFileChooser();
			fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			fileChooser.addChoosableFileFilter(new ExcelFileFilter());
		}
		return fileChooser;
	}

	public JButton getConfirmButton() {
		if (confirmButton == null) {
			confirmButton = AplusViewUtil.createButton("确认");
		}
		return confirmButton;
	}

	public JButton getCancelButton() {
		if (cancelButton == null) {
			cancelButton = AplusViewUtil.createButton("取消");
		}
		return cancelButton;
	}

	public JButton getImportButton() {
		if (importButton == null) {
			importButton = AplusViewUtil.createButton(30, 20, "...");
		}
		return importButton;
	}
	
	public JTextField getFileNameText() {
		if (fileNameText == null) {
			fileNameText = AplusViewUtil.createJTextFiled(40);
		}
		return fileNameText;
	}

}

package com.neusoft.aplus.databus.gui.view.filter;

import java.io.File;

import javax.swing.filechooser.FileFilter;

/**
 * @author WanWei
 * @date 2013-12-4 上午11:14:53
 */
public class ExcelFileFilter extends FileFilter {
	public boolean accept(File f) { // 设定可用的文件的后缀名
		if (f.getName().endsWith(".xls")||f.getName().endsWith(".xlsx") || f.isDirectory()) {
			return true;
		}
		return false;
	}

	public String getDescription() {
		return "Excel文件(*.xls(x))";
	}
}

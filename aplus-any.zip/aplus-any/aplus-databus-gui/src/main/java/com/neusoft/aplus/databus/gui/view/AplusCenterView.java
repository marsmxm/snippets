package com.neusoft.aplus.databus.gui.view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.ScrollPaneConstants;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import com.alibaba.fastjson.JSONObject;
import com.neusoft.aplus.databus.gui.constant.AplusGuiConstant;
import com.neusoft.aplus.databus.gui.control.AplusAlarmControl;
import com.neusoft.aplus.databus.gui.control.AplusDeviceControl;
import com.neusoft.aplus.databus.gui.control.AplusPointControl;
import com.neusoft.aplus.databus.gui.control.AplusPolicyControl;
import com.neusoft.aplus.databus.gui.view.tabView.AplusAlarmView;
import com.neusoft.aplus.databus.gui.view.tabView.AplusDeviceView;
import com.neusoft.aplus.databus.gui.view.tabView.AplusPointView;
import com.neusoft.aplus.databus.gui.view.tabView.AplusPolicyView;

/**
 * @author wuhao
 * @date 2015-4-16 上午11:02:31
 */
public class AplusCenterView extends JPanel {

	private static final long serialVersionUID = 1519187837280921400L;
	// AplusDeviceView的主Panel，所有的控件都基于此。
	private JTabbedPane tabPanel = null;
	private JPanel treePanel = null;

	private AplusDeviceView deviceView = null;// 设备视图
	private AplusPolicyView policyView = null;// 策略视图
	private AplusAlarmView alarmView = null;// 告警视图
	private AplusPointView pointView = null;// 点图

	private JButton searchButton = null;// TreeList的查询按钮
	private JTree typeTree = null; // treeList
	private JTextField searchText = null;// 查询条件

	private AplusMainView mainView = null;

	public AplusCenterView() {
		init();
	}

	private void init() {
		this.setLayout(new BorderLayout());

		deviceView = AplusDeviceControl.getInstance().getView();
		policyView = AplusPolicyControl.getInstance().getView();
		alarmView = AplusAlarmControl.getInstance().getView();
		pointView = AplusPointControl.getInstance().getView();

		this.add(getTreePanel(), BorderLayout.WEST);
		this.add(getTabPanel(), BorderLayout.CENTER);
	}

	public JTabbedPane getTabPanel() {
		if (tabPanel == null) {
			tabPanel = new JTabbedPane();
			tabPanel.addTab("设备", deviceView);
			tabPanel.addTab("策略", policyView);
			tabPanel.addTab("告警", alarmView);
			tabPanel.addTab("监控", pointView);

			tabPanel.setBorder(AplusViewUtil.createPanelBorder());
		}
		return tabPanel;
	}

	private Component getTreePanel() {
		if (treePanel == null) {
			treePanel = AplusViewUtil.createBorderLayoutPanel();

			JPanel searchPanel = AplusViewUtil.createFlowLayoutPanel();
			searchPanel.add(getSearchText());
			searchPanel.add(getSearchButton());

			JScrollPane treeScollPanel = new JScrollPane(getTypeTree());
			treeScollPanel
					.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			treeScollPanel
					.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
			treeScollPanel.setBorder(AplusViewUtil.createPanelBorder());

			treePanel.add(searchPanel, BorderLayout.NORTH);
			treePanel.add(treeScollPanel, BorderLayout.CENTER);
		}
		return treePanel;
	}

	public JTree getTypeTree() {
		if (typeTree == null) {
			DefaultMutableTreeNode top = new DefaultMutableTreeNode("全部");
			typeTree = new JTree(top);
		}
		return typeTree;
	}

	public JTextField getSearchText() {
		if (searchText == null) {
			searchText = AplusViewUtil.createJTextFiled(10);
		}
		return searchText;
	}

	public JButton getSearchButton() {
		if (searchButton == null) {
			searchButton = AplusViewUtil.createButton(60,
					AplusViewUtil.buttondefaulheight, "清除");
		}
		return searchButton;
	}

	public AplusMainView getMainView() {
		return mainView;
	}

	public void setMainView(AplusMainView mainView) {
		this.mainView = mainView;
	}
}

package com.neusoft.aplus.databus.gui.view;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import javax.swing.JComponent;
//import org.apache.log4j.Logger;
import com.neusoft.aplus.uigenerator.framework.LayoutInjection;



/**
 * GUI所有界面视图的基类
 * 
 * @author WanWei
 * @date 2015-4-13 下午8:06:33
 */
public class AplusBaseView extends JComponent{

	private static final long serialVersionUID = -7261038460442391400L;
	
//	private static Logger log = Logger.getLogger(AplusBaseView.class);
		
	//处理界面布局
	protected LayoutInjection injection;
	
	protected void initLayout(String xml){
		try{
			AplusXmlLoader loader = new AplusXmlLoader();
			InputStream input = loader.loadViewXml(xml);
			injection = new LayoutInjection(this, input);
			injection.injectLayout();
			input.close();
		} catch(FileNotFoundException e){
//			log.error("加载界面布局文件[" + xml + "]失败,系统异常退出", e);
			System.exit(1);
		} catch (IOException ex) {
			//不处理异常
//			log.warn(ex.getMessage(), ex);
		} 
	}

}

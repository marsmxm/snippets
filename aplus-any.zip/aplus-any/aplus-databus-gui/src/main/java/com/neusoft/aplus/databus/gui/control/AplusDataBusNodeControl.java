//package com.neusoft.aplus.databus.gui.control;
//
//import java.awt.BorderLayout;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//import javax.swing.JComponent;
//import javax.swing.JDialog;
//import javax.swing.WindowConstants;
//
//import com.neusoft.aplus.databus.gui.view.AplusDataBusNodeView;
//
///**
// * 新增、修改、删除DataBus节点的控制类
// * 
// * @author WanWei
// * @date 2015-4-14 下午5:36:12
// */
//public class AplusDataBusNodeControl extends AplusBaseControl implements ActionListener {
//
//	private static AplusDataBusNodeControl instance = new AplusDataBusNodeControl();
//	
//	private AplusDataBusNodeView view;
//	
//	//对话框
//	private JDialog dialog;
//	
//	private AplusDataBusNodeControl() {
//		super();
//		initDialog();
//		initData();
//		initListener();
//	}
//	
//	@Override
//	public void initData() {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void initListener() {
//		view.getConfirmButton().addActionListener(this);
//		view.getCancelButton().addActionListener(this);
//	}
//	
//	/**
//	 * 构建对话框
//	 * 
//	 * @author WanWei
//	 * @date 2015-4-14 下午6:03:29
//	 */
//	private void initDialog(){
//		view = new AplusDataBusNodeView();
//		dialog = new JDialog();
//		dialog.setTitle("DataBus节点");
//		dialog.setSize(400, 240);
//		dialog.setModal(true);
//		dialog.setResizable(false);
//		dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
//		dialog.getContentPane().setLayout(new BorderLayout());
//		dialog.getContentPane().add(view,BorderLayout.CENTER);
//	}
//	
//	/**
//	 * 单例模式获取
//	 * 
//	 * @return
//	 * @author WanWei
//	 * @date 2015-4-14 下午5:38:41
//	 */
//	public static AplusDataBusNodeControl getInstance() {
//		return instance;
//	}
//	
//	
//	@Override
//	public void actionPerformed(ActionEvent e) {
//		
//		//确认按钮
//		if (e.getSource().equals(view.getCancelButton())) {
//			//TODO
//		}
//		
//		//取消按钮
//		if (e.getSource().equals(view.getCancelButton())) {
//			dialog.setVisible(false);
//		}
//		
//	}
//	
//	/**
//	 * 弹出node节点编辑对话框
//	 * @param ip
//	 * @param port
//	 * @param parent
//	 * 			对话框模态施加对象
//	 * @author WanWei
//	 * @date 2015-4-14 下午5:48:18
//	 */
//	public void showNodeDialog(String ip, Integer port, JComponent parent){
//		view.getIPTextField().setText(null);
//		view.getPortTextField().setText(null);
//		
//		if(ip != null){
//			view.getIPTextField().setText(ip);
//		}
//		if(port != null){
//			view.getPortTextField().setText(port.toString());
//		}
//		dialog.setLocationRelativeTo(parent);
//		dialog.setVisible(true);
//		
//	}
//	
//	public AplusDataBusNodeView getView() {
//		return view;
//	}
//	
//
//
//}

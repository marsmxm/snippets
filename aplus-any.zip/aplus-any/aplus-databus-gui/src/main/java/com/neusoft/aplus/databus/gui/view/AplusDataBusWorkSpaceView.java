package com.neusoft.aplus.databus.gui.view;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

import com.neusoft.aplus.databus.gui.constant.AplusGuiConstant;
import com.neusoft.aplus.databus.gui.rest.RestContant;

/**
 * 工作区界面
 * 
 * @author WanWei
 * @date 2015-4-16 上午10:58:15
 */
public class AplusDataBusWorkSpaceView extends AplusBaseView {

	private static final long serialVersionUID = 8980263491410849495L;

	public AplusDataBusWorkSpaceView(){
		initLayout("DataBusWorkSpaceView.xml");
		initView();
	}
	
	/**
	 * 初始化界面元素
	 * 
	 * @author WanWei
	 * @date 2015-4-14 下午2:56:34
	 */
	private void initView(){
		getNavigationLabel().setBorder(new EtchedBorder());
		getWorkSpacePanel().setLayout(new BorderLayout());
	
	}
	
	/**
	 * 获取导航Label
	 * 
	 * @return
	 * @author WanWei
	 * @date 2015-4-16 上午11:01:26
	 */
	public JLabel getNavigationLabel(){
		return (JLabel)injection.getComponentById("databus_navigation_label");
	}
	
	
	/**
	 * 获取工作区的滚动面板
	 * 
	 * @return
	 * @author WanWei
	 * @date 2015-4-16 上午11:01:26
	 */
	public JPanel getWorkSpacePanel(){
		JPanel panel =  (JPanel)injection.getComponentById("databus_workspace_pane");
		return panel;
	}
	
	/**
	 * 设置导航信息
	 * 
	 * @param text
	 * @author WanWei
	 * @date 2015-4-16 上午11:10:42
	 */
	public void setNavigation(String text){
		String navigation = AplusGuiConstant.NAVIGATION_SEP.concat(text);
		getNavigationLabel().setText(navigation);
	}
	
	/**
	 * 保持导航已有信息不变，在其后设置内容
	 * 
	 * @param text
	 * @author WanWei
	 * @date 2015-4-16 上午11:10:42
	 */
	public void setSubNavigation(String... text){
		String navigation = AplusGuiConstant.EMPTY_STRING;
		for(String str : text){
			navigation = navigation.concat(AplusGuiConstant.NAVIGATION_SEP).concat(str);
		}
		getNavigationLabel().setText(RestContant.ip.concat(AplusGuiConstant.NODE_SEP).concat(RestContant.port).concat(navigation));
	}
}

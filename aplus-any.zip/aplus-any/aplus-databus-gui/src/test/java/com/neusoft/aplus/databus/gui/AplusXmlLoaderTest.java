package com.neusoft.aplus.databus.gui;

//import org.junit.Assert;
//import org.junit.Test;

import com.neusoft.aplus.databus.gui.view.AplusXmlLoader;

/**
 * 视图布局加载类测试
 * 
 * @author WanWei
 * @date 2015-4-13 下午7:25:42
 */
public class AplusXmlLoaderTest {
	
//	@Test
//	public void testLoaderXml() {
//		AplusXmlLoader loader = new AplusXmlLoader();
//		try{
//			loader.loadViewXml("PSDBrowserMonitorView.xml");
//		}catch(Exception e){
//			Assert.fail();
//		}
//	}

}

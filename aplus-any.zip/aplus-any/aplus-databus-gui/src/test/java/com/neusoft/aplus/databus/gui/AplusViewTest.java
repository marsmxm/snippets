package com.neusoft.aplus.databus.gui;

import java.awt.Dimension;

import javax.swing.JFrame;

import com.neusoft.aplus.databus.gui.view.*;
import com.neusoft.aplus.databus.gui.view.tabView.AplusAlarmNotifyView;
import com.neusoft.aplus.model.dbentity.table.AplusActionEntity;

/**
 * @author wuhao
 * @date 2015-4-14 下午4:58:00
 */
public class AplusViewTest extends JFrame {

	public AplusViewTest() {
		
		this.setTitle("组件测试");

		AplusAlarmNotifyView view = new AplusAlarmNotifyView();
		this.getContentPane().add(view);

		Dimension mainframeSize = new Dimension(400, 265);
		this.setSize(mainframeSize);

		// 最小size
		Dimension MinimumSize = new Dimension(400, 265);
		this.setMinimumSize(MinimumSize);

		// 允许最大化
		this.setResizable(true);

//		try{
//			//设置主题
//			UIManager.setLookAndFeel(new SubstanceFieldOfWheatLookAndFeel());
//			JDialog.setDefaultLookAndFeelDecorated(true);
//			JFrame.setDefaultLookAndFeelDecorated(true);
//		}catch(Exception e){
//		}
		
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	public static void main(String[] args) {
			new AplusViewTest();
	}
}

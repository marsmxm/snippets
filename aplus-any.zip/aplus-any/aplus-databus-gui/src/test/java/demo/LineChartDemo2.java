package demo;

import java.awt.Dimension;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

import com.neusoft.aplus.databus.gui.view.AplusLineChartPanel;
import com.neusoft.aplus.model.bizentity.AplusMetricDataPoint;

public class LineChartDemo2 extends ApplicationFrame {
	public LineChartDemo2(String paramString) {
		super(paramString);
		JPanel localJPanel = new AplusLineChartPanel(AplusLineChartPanel.createChart("zzzz", "kk", createDataset()));//createDemoPanel();
		localJPanel.setPreferredSize(new Dimension(500, 270));
		setContentPane(localJPanel);
	}

	
	private static List<AplusMetricDataPoint> createDataset() {
		List<AplusMetricDataPoint> dps = new ArrayList<AplusMetricDataPoint>();
		for(int i = 0; i < 30; i++){
			AplusMetricDataPoint dp = new AplusMetricDataPoint();
			dp.setAvgValue(Math.random() * 50);
			dp.setMinValue(Math.random() * 30);
			dp.setMaxValue(Math.random() * 80);
			dp.setRecordTime(System.currentTimeMillis() + i * 300000);
			dps.add(dp);
		}
		
//		XYSeries localXYSeries1 = new XYSeries("First");
//		localXYSeries1.add(1.0D, 1.0D);
//		localXYSeries1.add(2.0D, 4.0D);
//		localXYSeries1.add(3.0D, 3.0D);
//		localXYSeries1.add(4.0D, 5.0D);
//		localXYSeries1.add(5.0D, 5.0D);
//		localXYSeries1.add(6.0D, 7.0D);
//		localXYSeries1.add(7.0D, 7.0D);
//		localXYSeries1.add(8.0D, 8.0D);
//		XYSeries localXYSeries2 = new XYSeries("Second");
//		localXYSeries2.add(1.0D, 5.0D);
//		localXYSeries2.add(2.0D, 7.0D);
//		localXYSeries2.add(3.0D, 6.0D);
//		localXYSeries2.add(4.0D, 8.0D);
//		localXYSeries2.add(5.0D, 4.0D);
//		localXYSeries2.add(6.0D, 4.0D);
//		localXYSeries2.add(7.0D, 2.0D);
//		localXYSeries2.add(8.0D, 1.0D);
//		XYSeries localXYSeries3 = new XYSeries("Third");
//		localXYSeries3.add(3.0D, 4.0D);
//		localXYSeries3.add(4.0D, 3.0D);
//		localXYSeries3.add(5.0D, 2.0D);
//		localXYSeries3.add(6.0D, 3.0D);
//		localXYSeries3.add(7.0D, 6.0D);
//		localXYSeries3.add(8.0D, 3.0D);
//		localXYSeries3.add(9.0D, 4.0D);
//		localXYSeries3.add(10.0D, 3.0D);
//		XYSeriesCollection localXYSeriesCollection = new XYSeriesCollection();
//		localXYSeriesCollection.addSeries(localXYSeries1);
//		localXYSeriesCollection.addSeries(localXYSeries2);
//		localXYSeriesCollection.addSeries(localXYSeries3);
		return dps;
	}

//	private static JFreeChart createChart(XYDataset paramXYDataset) {
//		JFreeChart localJFreeChart = ChartFactory.createXYLineChart(
//				"Line Chart Demo 2", "X", "Y", paramXYDataset,
//				PlotOrientation.VERTICAL, true, true, false);
//		XYPlot localXYPlot = (XYPlot) localJFreeChart.getPlot();
//		localXYPlot.setDomainPannable(true);
//		localXYPlot.setRangePannable(true);
//		XYLineAndShapeRenderer localXYLineAndShapeRenderer = (XYLineAndShapeRenderer) localXYPlot
//				.getRenderer();
//		localXYLineAndShapeRenderer.setBaseShapesVisible(true);
//		localXYLineAndShapeRenderer.setBaseShapesFilled(true);
//		NumberAxis localNumberAxis = (NumberAxis) localXYPlot.getRangeAxis();
//		localNumberAxis.setStandardTickUnits(NumberAxis
//				.createIntegerTickUnits());
//		return localJFreeChart;
//	}

//	public static JPanel createDemoPanel() {
//		JFreeChart localJFreeChart = createChart(createDataset());
//		final ChartPanel localChartPanel = new ChartPanel(localJFreeChart);
//		localChartPanel.setMouseWheelEnabled(true);
//	
//		CrosshairOverlay localCrosshairOverlay = new CrosshairOverlay();
//		final Crosshair xCrosshair = new Crosshair((0.0D / 0.0D), Color.GRAY,
//				new BasicStroke(0.0F));
//		xCrosshair.setLabelVisible(true);
//		localCrosshairOverlay.addDomainCrosshair(xCrosshair);
//		final Crosshair[] yCrosshairs = new Crosshair[3];
//		for (int i = 0; i < 3; i++) {
//			yCrosshairs[i] = new Crosshair((0.0D / 0.0D), Color.GRAY,
//					new BasicStroke(0.0F));
//			yCrosshairs[i].setLabelVisible(true);
//			if (i % 2 != 0)
//				yCrosshairs[i].setLabelAnchor(RectangleAnchor.TOP_RIGHT);
//			localCrosshairOverlay.addRangeCrosshair(yCrosshairs[i]);
//		}
//		localChartPanel.addChartMouseListener(new ChartMouseListener(){
//			public void chartMouseClicked(ChartMouseEvent paramChartMouseEvent) {
//			}
//
//			public void chartMouseMoved(ChartMouseEvent paramChartMouseEvent) {
//				Rectangle2D localRectangle2D = localChartPanel.getScreenDataArea();
//				JFreeChart localJFreeChart = paramChartMouseEvent.getChart();
//				XYPlot localXYPlot = (XYPlot) localJFreeChart.getPlot();
//				ValueAxis localValueAxis = localXYPlot.getDomainAxis();
//				double d1 = localValueAxis.java2DToValue(paramChartMouseEvent
//						.getTrigger().getX(), localRectangle2D, RectangleEdge.BOTTOM);
//				xCrosshair.setValue(d1);
//				for (int i = 0; i < 3; i++) {
//					double d2 = DatasetUtilities.findYValue(localXYPlot.getDataset(),
//							i, d1);
//					yCrosshairs[i].setValue(d2);
//				}
//			}
//		});
//		localChartPanel.addOverlay(localCrosshairOverlay);
//		return localChartPanel;
//	}

	

	public static void main(String[] paramArrayOfString) {
	    //创建主题样式  
	    StandardChartTheme standardChartTheme=new StandardChartTheme("CN");  
	    //设置标题字体  
	    standardChartTheme.setExtraLargeFont(new Font("隶书",Font.BOLD,18));  
	    //设置图例的字体  
	    standardChartTheme.setRegularFont(new Font("宋书",Font.PLAIN,14));  
	    //设置轴向的字体  
	    standardChartTheme.setLargeFont(new Font("宋书",Font.PLAIN,14));  
	    //应用主题样式  
	    ChartFactory.setChartTheme(standardChartTheme);  
		LineChartDemo2 localLineChartDemo2 = new LineChartDemo2(
				"JFreeChart: LineChartDemo2.java");
		localLineChartDemo2.pack();
		RefineryUtilities.centerFrameOnScreen(localLineChartDemo2);
		localLineChartDemo2.setVisible(true);
	}
}
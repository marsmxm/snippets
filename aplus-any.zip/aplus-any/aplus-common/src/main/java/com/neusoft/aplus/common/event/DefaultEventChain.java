package com.neusoft.aplus.common.event;

import java.util.List;

import com.google.common.collect.Lists;

/**
 * 事件链模型中默认的事件链
 * @author zh_ch
 * @param <T>
 * @date 2014-12-16 下午2:56:14
 */
public class DefaultEventChain extends EventChain<Boolean> {
	private List<Event> events = Lists.newArrayList();
	private Integer index = 0;
	private Input input;
	private Output output;
	
	public DefaultEventChain(Input input, Output output) {
		this.input = input;
		this.output = output;
	}
	
	/**
	 * 事件链异步执行方法
	 */
	@Override
	public Boolean call() throws Exception {
		try {
			fireEvents(this);
		} catch(Exception e) {
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}

	/**
	 * 向事件链中添加单个事件
	 */
	@Override
	public EventChain<Boolean> addEvent(Event e) {
		events.add(e);
		return this;
	}

	/**
	 * 向事件链中添加事件集合
	 */
	@Override
	public EventChain<Boolean> addEvents(Event... es) {
		for (int i = 0; i < es.length; i++) {
			events.add(es[i]);
		}
		return this;
	}
	
	@Override
	public EventChain<Boolean> addEvents(List<Event> eventList) {
		for (int i = 0; i < eventList.size(); i++) {
			events.add(eventList.get(i));
		}
		return this;
	}

	/**
	 * 执行事件链
	 */
	@Override
	public void fireEvents(EventChain<Boolean> chain) {
		fireEvents(input, output, chain);
	}
	
	/**
	 * 执行事件链，带入事件链输入和输出
	 */
	@Override
	public void fireEvents(Input input, Output output, EventChain<Boolean> chain) {
		if (index.intValue() == events.size()) {
			return;
		}
		events.get(index++).fireEvent(input, output, chain);
	}
}

package com.neusoft.aplus.common.exception.internationalize;

import java.lang.reflect.Field;
import java.util.List;

import org.apache.log4j.Logger;

import com.neusoft.aplus.common.exception.annotation.MessageCN;
import com.neusoft.aplus.common.exception.annotation.MessageUS;

/**
 * 批量导入异常信息，生成国际化文件
 * 
 * @author guo.tc
 * @date 2014-6-24 下午1:30:39
 */
public class ExceptionInfoImpl implements IExceptionInfo {
	private static Logger log = Logger.getLogger(ExceptionInfoImpl.class);

	/**
	 * 导入异常信息到国际化文件
	 */
	public void exmportErrorMsg(List<String> exceptions) {
		// 处理所有异常信息类
		for (String classname : exceptions) {
			Field[] fields = null;
			try {
				// 取得异常信息类中定义的变量信息
				fields = Class.forName(classname).getDeclaredFields();
			} catch (SecurityException e) {
				log.error("", e);
			} catch (ClassNotFoundException e) {
				log.error("[" + classname + " ]不存在，请确认！", e);
			}
			// 处理所有定义的变量信息
			for (Field field : fields) {
				// 取得变量权限
				// boolean accessFlag = field.isAccessible();
				// 设定读取权限
				// field.setAccessible(true);
				// if (field.isAccessible()) {
				if (field.getName().equals("serialVersionUID")) {
					continue;
				}
				Object okey = null;
				try {
					// 取得变量的值
					okey = field.get(0);
				} catch (IllegalArgumentException e) {
					// log.error("", e);
				} catch (IllegalAccessException e) {
					// log.error("", e);
				}
				if (okey == null) {
					continue;
				}
				String prop_key = okey.toString();
				String prop_value_CN = "";
				String prop_value_US = "";
				// 取得中文注解信息
				if (field.isAnnotationPresent(MessageCN.class)) {
					MessageCN info = (MessageCN) field
							.getAnnotation(MessageCN.class);
					prop_value_CN = info.value();
					// 保存信息岛国际化文件
					PropertisHandler.setCNValue(prop_key, prop_value_CN);
				}
				// 取得英文注解信息
				if (field.isAnnotationPresent(MessageUS.class)) {
					MessageUS info = (MessageUS) field
							.getAnnotation(MessageUS.class);
					prop_value_US = info.value();
					// 保存信息岛国际化文件
					PropertisHandler.setUSValue(prop_key, prop_value_US);
				}
				// }
				// 设定读取权限
				// field.setAccessible(accessFlag);
			}
		}
		// 保存数据到文件
		PropertisHandler.propStore();
	}
}

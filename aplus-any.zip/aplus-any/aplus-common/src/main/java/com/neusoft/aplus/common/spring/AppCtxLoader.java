package com.neusoft.aplus.common.spring;
/**
 * @author zh_ch
 * @date 2015年3月18日 上午9:45:45
 */
public class AppCtxLoader {
	public static void loadSpringCtx() {
		ApplicationContextFactory.initialize(PathConst.FILES);
	}
}

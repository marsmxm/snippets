package com.neusoft.aplus.common.zmq.client.connector;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.zeromq.ZMQ;

import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.util.JSONUtil;

/**
 * 创建connector类的管理者，持有所有connector对象
 * 
 * @author MaHan
 *
 * @date 2015年5月27日
 */
public class ConnectorManager {
	private static Logger log = LoggerFactory.getLogger(ConnectorManager.class);
	private static ZMQ.Context context = ZMQ.context(1);
	private static List<Connector> connectors = new ArrayList<Connector>();
	// 从zookeeper上获取的当前服务地址的配置信息(包括服务端各socket的ip、端口)
	private static Map<String, String> addressMap;

	private ConnectorManager() {
	}

	/**
	 * 当前服务消失时调用
	 * 
	 * @author MaHan
	 * @date 2015年5月27日
	 */
	public static void close() {
		log.info("close() 被触发");
		for (Connector connector : connectors) {
			connector.disconnect();
		}
		log.info("close() 方法结束");
	}

	/**
	 * 新服务出现后进行连接配置
	 * 
	 * @param data
	 * @author MaHan
	 * @date 2015年5月27日
	 */
	public static void connect(String data) {
		log.info("connect() 被触发");
		ConnectorManager.addressMap = transformData(data);
		for (Connector connector : connectors) {
			connector.connect(addressMap.get(connector.getAddresskey()));
			connector.setNewMaster(true);
		}
	}

	public static synchronized Connector create(int socketType,
			String addressKey, boolean isBind) {
		Connector connector = new Connector(context);
		connector.setSocketType(socketType);
		connector.setAddresskey(addressKey);
		connector.setBind(isBind);
		connector.setAddress(addressMap == null ? null : addressMap
				.get(addressKey));
		connectors.add(connector);
		log.info("create connector " + addressKey + "|" + socketType);
		return connector;
	}

	// 服务端数据以JSON格式存储
	private static Map<String, String> transformData(String data) {
		return JSONUtil.getComplexObject(data,
				new TypeReference<Map<String, String>>() {
				});
	}

}

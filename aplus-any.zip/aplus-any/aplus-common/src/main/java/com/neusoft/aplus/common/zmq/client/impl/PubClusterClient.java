package com.neusoft.aplus.common.zmq.client.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.zeromq.ZFrame;
import org.zeromq.ZMQ;
import org.zeromq.ZMsg;
import org.zeromq.ZMQ.PollItem;

import com.neusoft.aplus.common.zmq.client.api.Publisher;
import com.neusoft.aplus.common.zmq.client.connector.Connector;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;

/**
 * 封装了高可用模式下Publisher的send方法 该方法在未收到服务端回复时，send方法会保存阻塞等待
 * 
 * @author MaHan
 *
 * @date 2015年5月27日
 */
public class PubClusterClient implements Publisher {
	private static Logger log = LoggerFactory.getLogger(PubClusterClient.class);
	private ZMQ.Socket req;
	private Connector reqConn;

	private PubClusterClient() {
	}

	public static PubClusterClient buider() {
		return new PubClusterClient();
	}

	public PubClusterClient setReqConn(Connector conn) {
		this.reqConn = conn;
		return this;
	}

	@Override
	public synchronized Boolean send(String topic, String msg) {
		try {
			return handleSend(topic, msg.getBytes());
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public synchronized Boolean send(String topic, byte[] msg) {
		try {
			return handleSend(topic, msg);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public synchronized Boolean send(String topic, ZMQMessage msg) {
		if(null != topic && !topic.equals(msg.getTopic())){
			msg.setTopic(topic);
		}
		try {
			return handleSend(topic, msg.toString().getBytes());
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	private ZMsg makeZMsg(String topic, byte[] msg) {
		ZMsg zMsg = new ZMsg();
		if (topic != null && topic.length() > 0) {
			zMsg.add(new ZFrame(topic));
		} else {
			zMsg.add(new ZFrame(""));
		}
		zMsg.add(new ZFrame(msg));
		return zMsg;
	}

	private Boolean handleSend(String topic, byte[] msg) throws Exception {
		if (null == topic || topic.trim().length() == 0) {
			log.error("设置了非法的主题,主题不可为空");
			throw new Exception("设置了非法的主题,主题不可为空");
		}
		while (!Thread.currentThread().isInterrupted()) {
			ZMsg zMsg = makeZMsg(topic, msg);
			if (!reqConn.isConnected()) {
				log.debug("pub connector 未连接");
				sleep(300);
				continue;
			} else if (reqConn.isNewMaster()) {
				connect();
			}
			log.info("pub发送" + zMsg);
			zMsg.send(req);

			while (reqConn.isConnected() && !reqConn.isNewMaster()) {
				PollItem items[] = { new PollItem(req, ZMQ.Poller.POLLIN) };
				int rc = ZMQ.poll(items, 1, 500);
				if (rc == -1) {
					log.warn("interrupted");
					break;
				}
				if (items[0].isReadable()) {
					byte[] recv = req.recv();
					log.info("pub收到：" + new String(recv));
					return true;
				}
			}
		}
		return false;
	}

	private void connect() {
		log.info("pubclient connect()连接");
		if (req != null) {
			log.info("pubclient req关闭");
			req.setLinger(0);
			req.close();
		}
		req = reqConn.createSocket();
		if (reqConn.isBind()) {
			req.bind(reqConn.getAddress());
		} else {
			req.connect(reqConn.getAddress());
		}
		reqConn.setNewMaster(false);
	}

	private void sleep(long time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}

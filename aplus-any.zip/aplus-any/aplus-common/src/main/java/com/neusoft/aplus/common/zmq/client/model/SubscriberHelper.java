//package com.neusoft.aplus.common.zmq.client.model;
//
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Set;
//
//import com.neusoft.aplus.common.zmq.client.api.IDoBusiness;
//
///**
// * 封装了订阅者的主题及相关处理方法的信息
// * 
// * @author MaHan
// *
// * @date 2015年5月27日
// */
//
//public class SubscriberHelper {
//
//	private Map<String, IDoBusiness> map = new HashMap<String, IDoBusiness>();
//	private IDoBusiness defaultBusiness;
//
//	public SubscriberHelper() {
//	}
//
//	public SubscriberHelper(String topic, IDoBusiness business) {
//		handleConfig(topic, business);
//	}
//
//	public void add(String topic, IDoBusiness business) {
//		handleConfig(topic, business);
//	}
//
//	public Set<String> getTopic() {
//		return map.keySet();
//	}
//
//	public IDoBusiness getBusiness(String topic) {
//		return map.get(topic);
//	}
//
//	private void handleConfig(String topic, IDoBusiness business) {
//		if (topic == null || topic.length() <= 0) {
//			map.put("", business);
//		} else {
//			map.put(topic, business);
//		}
//	}
//
//	public Map<String, IDoBusiness> getMap() {
//		return map;
//	}
//
//	public IDoBusiness getDefaultBusiness() {
//		return defaultBusiness;
//	}
//
//	public void setDefaultBusiness(IDoBusiness defaultBusiness) {
//		this.defaultBusiness = defaultBusiness;
//	}
//
//}
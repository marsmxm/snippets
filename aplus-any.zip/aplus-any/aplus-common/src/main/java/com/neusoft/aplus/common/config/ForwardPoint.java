package com.neusoft.aplus.common.config;

import java.net.MalformedURLException;
import java.net.URL;

import org.apache.log4j.Logger;

import com.neusoft.aplus.common.exception.RestException;

/**
 * 记录请求转发的IP和端口
 * 
 * @author WanWei
 * @date 2014-6-24 下午7:17:01
 */
public class ForwardPoint {
	
	private static Logger log = Logger.getLogger(ForwardPoint.class);
	
	//是否需要集成跳转
	private static boolean needForward = false;
	
	private static String ip;
	
	private static int port = -1;
	
	private static String protocol;
	
	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		ForwardPoint.protocol = protocol;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		ForwardPoint.ip = ip;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		ForwardPoint.port = port;
	}
	
	public boolean isNeedForward() {
		return needForward;
	}
	public void setNeedForward(boolean needForward) {
		ForwardPoint.needForward = needForward;
	}
	
	/**
	 * 获取ip和port的组合形式
	 * @return String
	 * @author WanWei
	 * @date 2014-6-24 下午7:32:59
	 */
	public static String getForwardPath(){
		return ip.concat(":") + port;
	}
	
	/**
	 * 获取ip和port的组合形式
	 * @return String
	 * @author WanWei
	 * @date 2014-6-24 下午7:32:59
	 */
	public static URL getForwardURL(){
		URL url = null;
		try{
			url = new URL(protocol, ip, port, "");
		}catch(MalformedURLException mue){
			log.error(mue.getMessage(), mue);
			String [] params ={protocol,ip,String.valueOf(port)}; 
			RestException.throwException(RestException.CODE_REST_EXCEPTION_URLERRORINFO, 
					mue, params, null);
		}
		return url;
	}
}

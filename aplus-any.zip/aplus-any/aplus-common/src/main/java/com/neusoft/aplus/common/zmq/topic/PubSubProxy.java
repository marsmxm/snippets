package com.neusoft.aplus.common.zmq.topic;

import org.zeromq.ZMQ;

/**
 * @author zh_ch
 * @date 2015-2-10 下午12:38:38
 */
public class PubSubProxy implements Runnable {
	private ZMQ.Context context;
	private TopicConf configuration;
	private Thread thread;

	public PubSubProxy(ZMQ.Context context, TopicConf configuration) {
		this.configuration = configuration;
		this.context = context;
	}

	@Override
	public void run() {
		ZMQ.Socket frontend = context.socket(ZMQ.XSUB);
		frontend.bind(configuration.getFrontend());
		ZMQ.Socket backend = context.socket(ZMQ.XPUB);
		backend.bind(configuration.getBackend());
		// 针对高可用部署模式的配置
		String proxyResp = configuration.getProxyResp();
		if (proxyResp != null && !proxyResp.isEmpty()) {
			ZMQ.Socket respSocket = context.socket(ZMQ.REP);
			respSocket.bind(proxyResp);
		}
		ZMQ.proxy(frontend, backend, null);
		frontend.close();
		backend.close();
		context.term();
	}

	/**
	 * 代理启动方法
	 *
	 * @author zh_ch
	 * @date 2015年4月16日 下午1:24:08
	 */
	public void start() {
		this.thread = new Thread(this);
		thread.start();
	}
}

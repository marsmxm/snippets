package com.neusoft.aplus.common.db;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.impl.SessionImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neusoft.aplus.model.dbentity.Page;
import com.neusoft.aplus.model.dbentity.SqlMapEntity;

/**
 * 基类，所有DAO均需继承此基类
 * 
 * @author WanWei
 * @date 2014-6-24 上午14:44:38
 * @param <T>
 */
@SuppressWarnings("unchecked")
public abstract class AbstractHibernateDao<T> {

	private static final Log log = LogFactory
			.getLog(AbstractHibernateDao.class);

	private Class<T> persistentClass;

	protected static final int BATCH_SIZE = 1000;

	// 支持的数据库类型
	private static final String DB_TYPE_POSTGRESQL = "postgresql";

	private static final String DB_TYPE_MYSQL = "mysql";

	// TODO 未来会支持的数据库
	// private static final String DB_TYPE_ORACLE = "oracle";

	@Autowired
	@Qualifier("sessionFactory")
	protected SessionFactory sessionFactory;

	protected AbstractHibernateDao(Class<T> persistentClass, SessionFactory f) {
		this.persistentClass = persistentClass;
		sessionFactory = f;
	}

	protected AbstractHibernateDao() {

		Type type = this.getClass().getGenericSuperclass();
		persistentClass = (Class<T>) ((ParameterizedType) type)
				.getActualTypeArguments()[0];
	}

	public Class<T> getPersistentClass() {
		return persistentClass;
	}

	public Session getSession() {
		try {
			// 没有设置事务的话这个方法会报错
			return sessionFactory.getCurrentSession();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;

	}

	public SessionFactory getFactory() {
		return sessionFactory;
	}

	public void flushSession() {
		try {
			getSession().flush();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
	}

	public T findById(Serializable id) {
		try {
			return findById(id, false);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;

	}

	public T get(Serializable id) {
		try {
			return (T) getSession().get(getPersistentClass(), id);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	public T findById(Serializable id, boolean lock) {
		try {
			return lock ? (T) getSession().load(getPersistentClass(), id,
					LockMode.UPGRADE) : (T) getSession().load(
					getPersistentClass(), id);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	protected Criteria createCriteria() {
		try {
			return getSession().createCriteria(persistentClass);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	protected Query createQuery(String s) {
		try {
			return getSession().createQuery(s);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	protected Query createQuery(String s, Object... params) {
		try {
			Query query = getSession().createQuery(s);
			for (int i = 0; i < params.length; i++) {
				query.setParameter(i, params[i]);
			}
			return query;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	public List<T> findAll() {
		try {
			return getSession().createCriteria(getPersistentClass()).list();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	public List<T> find(String s, Object... params) {
		try {
			return createQuery(s, params).list();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	public T findUniqueBy(String propertyName, Object value) {
		try {
			return (T) findUniqueBy(persistentClass, propertyName, value);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	public T findUniqueBy(Class<T> entityClass, String propertyName,
			Object value) {
		try {
			if (propertyName == null) {
				return null;
			}
			T t = (T) createCriteria(entityClass,
					Restrictions.eq(propertyName, value)).uniqueResult();
			return t;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	public Criteria createCriteria(Class<T> entityClass,
			Criterion... criterions) {
		try {
			Criteria criteria = getSession().createCriteria(entityClass);
			for (Criterion c : criterions) {
				criteria.add(c);
			}
			return criteria;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	public Collection<T> findAllOrderByName() {
		try {
			return getSession().createCriteria(getPersistentClass())
					.addOrder(Order.asc("name")).list();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	public int size() {
		try {
			return ((Number) getSession().createQuery(
					"select count(*) from " + getPersistentClass().getName())
					.uniqueResult()).intValue();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return -1;
	}

	public int size(Collection<T> coll) {
		try {
			return ((Number) getSession().createFilter(coll, "select count(*)")
					.uniqueResult()).intValue();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return -1;
	}

	public void merge(T entity) {
		try {
			getSession().merge(entity);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
	}

	public Serializable save(T entity) throws HibernateException {
		try {
			return getSession().save(entity);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	public void saveOrUpdate(T entity) {
		try {
			getSession().saveOrUpdate(entity);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
	}

	/**
	 * 批量更新数据
	 * 
	 * @param entities
	 * @author WanWei
	 * @date 2015-3-20 下午12:19:34
	 */
	public void batchSaveOrUpdate(List<T> entities) {
		if (entities == null || entities.isEmpty()) {
			log.warn("传入参数为空  entities: " + entities);
			return;
		}

		int count = 0;
		for (T entity : entities) {
			saveOrUpdate(entity);
			count++;
			if (count % BATCH_SIZE == 0) {
				flushSession();
				clear();
			}
		}
	}

	public void update(T entity) {
		try {
			getSession().update(entity);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
	}

	public void remove(T entity) {
		try {
			getSession().delete(entity);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
	}

	/**
	 * 批量删除
	 * 
	 * @param entities
	 * @author hanbq
	 * @date 2015-3-20 下午8:36:27
	 */
	public void batchRemove(List<T> entities) {
		if (entities == null || entities.isEmpty()) {
			log.warn("传入参数为空  entities: " + entities);
			return;
		}
		int count = 0;
		for (T entity : entities) {
			getSession().delete(entity);
			count++;
			if (count % BATCH_SIZE == 0) {
				flushSession();
				clear();
			}
		}
	}

	public void evict(T entity) {
		try {
			getSession().evict(entity);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
	}

	public void clear() {
		try {
			getSession().clear();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
	}

	/**
	 * 支持单表的分页查询
	 * 
	 * @param page
	 * @param pageCount
	 * @param hql
	 * @param params
	 * @return Page<T>
	 * @author WanWei
	 * @date 2014-6-24 下午3:10:53
	 */
	public Page<T> getPagedResult(Integer page, Integer pageCount, String hql,
			Object... params) {
		try {
			String counthql = hql.substring(hql.toLowerCase().indexOf("from"));
			int orderByIndex = counthql.toLowerCase().indexOf("order by");
			if (orderByIndex > 0) {
				counthql = counthql.substring(0, orderByIndex);
			}
			counthql = "select count(*) " + counthql;
			int sumCount = ((Number) createQuery(counthql, params)
					.uniqueResult()).intValue();

			Query query = createQuery(hql, params);
			if (page != null && pageCount != null && page > 0 && pageCount > 0) {
				query.setMaxResults(pageCount);
				query.setFirstResult((page - 1) * pageCount);
			}
			Page<T> pageData = new Page<T>();
			pageData.setTotalSize(sumCount);
			pageData.setItemList(query.list());

			return pageData;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	/**
	 * 分页查询
	 * @param page
	 * @param pageCount
	 * @param hql
	 * @param params
	 * @return
	 * @author zh_ch
	 * @date 2015年4月10日 下午4:10:32
	 */
	public Page<T> getPagedResult(int page, int pageCount,
			List<Criterion> criterions) {
		return getPagedResult(page, pageCount, criterions, null, null);
	}

	/**
	 * 分页查询
	 * @param page
	 * @param pageCount
	 * @param criterions
	 * @param alias
	 * @return
	 * @author hanbq
	 * @date 2015-5-7 下午3:02:50
	 */
	public Page<T> getPagedResult(int page, int pageCount,
			List<Criterion> criterions, Map<String, List<Criterion>> alias, List<Order> orders) {
		try {
			Criteria countCriteria = createCriteria();
			Criteria pageCriteria = createCriteria();
			builtPagedCriteria(countCriteria, pageCriteria, criterions, alias, orders);
			return setAndGetPage(countCriteria, pageCriteria, page, pageCount);

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	/**
	 * 生成条件
	 * @param countCriteria
	 * @param pageCriteria
	 * @param criterions
	 * @param alias
	 * @author hanbq
	 * @date 2015-5-7 下午3:01:44
	 */
	private void builtPagedCriteria(Criteria countCriteria,
			Criteria pageCriteria, List<Criterion> criterions,
			Map<String, List<Criterion>> alias, List<Order> orders) {
		if (Objects.equal(criterions, null)) {
			criterions = Lists.newArrayList();
		}

		if (Objects.equal(alias, null)) {
			alias = Maps.newHashMap();
		}

		if (Objects.equal(orders, null)) {
			orders = Lists.newArrayList();
		}
		
		Iterator<Entry<String, List<Criterion>>> iter = alias.entrySet()
				.iterator();
		while (iter.hasNext()) {
			Entry<String, List<Criterion>> entry = iter.next();
			Criteria countCriteriaIn = countCriteria.createCriteria(entry.getKey());
			Criteria pageCriteriaIn = pageCriteria.createCriteria(entry.getKey());
			pageCriteria.setFetchMode(entry.getKey(), FetchMode.SELECT);
			pageCriteriaIn.setFetchMode(entry.getKey(), FetchMode.SELECT);
			for (Criterion cri : entry.getValue()) {
				countCriteriaIn.add(cri);
				pageCriteriaIn.add(cri);
			}
		}
		
		for (Criterion criterion : criterions) {
			countCriteria.add(criterion);
			pageCriteria.add(criterion);
		}
		
		for(Order order:orders ){
			pageCriteria.addOrder(order);
		}
	}

	
	/**
	 * 获取查询结果
	 * @param countCriteria
	 * @param pageCriteria
	 * @param page
	 * @param pageCount
	 * @return
	 * @author hanbq
	 * @date 2015-5-7 下午3:02:26
	 */
	private Page<T> setAndGetPage(Criteria countCriteria,
			Criteria pageCriteria, int page, int pageCount) {
		int sumCount = Integer.parseInt(countCriteria
				.setProjection(Projections.rowCount()).uniqueResult()
				.toString());

		if (pageCount != 0 && page != 0) {
			pageCriteria.setMaxResults(pageCount);
			pageCriteria.setFirstResult((page - 1) * pageCount);
		}

		Page<T> pageData = new Page<T>();
		pageData.setTotalSize(sumCount);
		pageData.setItemList(pageCriteria.list());

		return pageData;
	}

	/**
	 * 获取原生态sql总记录数
	 * 
	 * @param hql
	 * @return
	 * @author hanbq
	 * @date 2015-5-6 上午10:44:08
	 */
	public int getSQLResultCount(String hql, Object... params) {
		String counthql = hql.substring(hql.toLowerCase().indexOf("from"));
		int orderByIndex = counthql.toLowerCase().indexOf("order by");
		if (orderByIndex > 0) {
			counthql = counthql.substring(0, orderByIndex);
		}
		counthql = "select count(0) " + counthql;
		int sumCount = ((Number) createSQLQuery(counthql, params)
				.uniqueResult()).intValue();
		return sumCount;
	}

	/**
	 * 使用数据库原生sql查询
	 * 
	 * @param s
	 * @param params
	 * @return SQLQuery
	 */
	protected SQLQuery createSQLQuery(String s, List<Object> params) {
		try {
			SQLQuery query = getSession().createSQLQuery(s);
			if ((params != null) && (!params.isEmpty())) {
				int size = params.size();
				for (int i = 0; i < size; i++) {
					query.setParameter(i, params.get(i));
				}
			}
			return query;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	/**
	 * 使用数据库原生sql查询
	 * 
	 * @param s
	 * @param params
	 * @return SQLQuery
	 */
	protected SQLQuery createSQLQuery(String s, Object... params) {
		try {
			SQLQuery query = getSession().createSQLQuery(s);
			if (params != null && params.length != 0) {
				int length = params.length;
				for (int i = 0; i < length; i++) {
					query.setParameter(i, params[i]);
				}
			}
			return query;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			// 这里会抛出异常
			AplusHibernateException.parseException(e);
		}
		// 如果有异常，不会走到这
		return null;
	}

	/**
	 * 使用sqlid，读取xm文件中的sql
	 * 
	 * @param sqlId
	 * @param params
	 * @return SQLQuery
	 */
	public SQLQuery createSQLQueryBySqlId(String sqlId, Object... params) {
		String sqlStr = null;
		SqlMapEntity sqlMapEntity = SqlMapEntity.getInstance();
		HashMap<String, String> sqlMap = sqlMapEntity.getSqlMap();
		if (sqlMap.containsKey(sqlId)) {
			sqlStr = sqlMap.get(sqlId);
		}
		if (sqlStr != null) {
			SQLQuery query = createSQLQuery(sqlStr, params);
			return query;
		} else {
			// AplusHibernateException.parseException(new a);
			return null;
		}
	}

	/**
	 * 使用sqlid，读取xm文件中的sql
	 * 
	 * @param sqlId
	 * @param params
	 * @return SQLQuery
	 */
	protected SQLQuery createSQLQueryBySqlId(String sqlId, List<Object> params) {
		String sqlStr = null;
		SqlMapEntity sqlMapEntity = SqlMapEntity.getInstance();
		HashMap<String, String> sqlMap = sqlMapEntity.getSqlMap();
		if (sqlMap.containsKey(sqlId)) {
			sqlStr = sqlMap.get(sqlId);
		}
		if (sqlStr != null) {
			SQLQuery query = createSQLQuery(sqlStr, params);
			return query;
		} else {
			return null;
		}
	}

	/**
	 * 基于prepareStatement执行sql语句，不适用hibernate进行批量sql语句的执行
	 * 
	 * @param connection
	 * @param sql
	 * @param bts
	 * @author WanWei
	 * @date 2014-3-26 下午3:47:45
	 */
	public void executePreparedStatement(String sql, Object[] params) {
		Connection connection = null;
		try {
			connection = getSession().connection();
			if (connection != null) {

				boolean autoCommit = connection.getAutoCommit();
				connection.setAutoCommit(false);
				PreparedStatement ps = connection.prepareStatement(sql);

				int length = params.length;
				for (int i = 1; i < length + 1; i++) {
					ps.setObject(i, params[i - 1]);
				}
				ps.execute();

				connection.commit();
				connection.setAutoCommit(autoCommit);
				ps.close();
				getSession().flush();
				getSession().clear();
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			try {
				if (connection == null) {
					connection = getSession().connection();
				}
				executePreparedStatementSingle(connection, sql, params);
				return;
			} catch (Exception ex) {
				log.error(e.getMessage(), e);
				// 这里会抛出异常
				AplusHibernateException.parseException(e);
			}
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (Exception e) {
					log.error(e.getMessage(), e);
					// 这里会抛出异常
					AplusHibernateException.parseException(e);
				}
			}
		}
	}

	/**
	 * 执行sql，传入批量参数
	 * 
	 * @param connection
	 * @param sql
	 * @param params
	 *            二维数组，每行代表一批参数
	 * @author Mu Xian Ming
	 * @date 2015-4-17
	 */
	public void executeBatchPreparedStatement(String sql, Object[][] params) {
		Connection connection = null;
		try {
			connection = getSession().connection();
			if (connection != null) {

				boolean autoCommit = connection.getAutoCommit();
				connection.setAutoCommit(false);
				PreparedStatement ps = connection.prepareStatement(sql);

				int rows = params.length;
				for (int i = 0; i < rows; i++) {
					int length = params[i].length;
					for (int j = 1; j < length + 1; j++) {
						ps.setObject(j, params[i][j - 1]);
					}
					ps.addBatch();
				}
				ps.executeBatch();

				connection.commit();
				connection.setAutoCommit(autoCommit);
				ps.close();
				getSession().flush();
				getSession().clear();
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			if (e instanceof BatchUpdateException) {
				log.error(((BatchUpdateException) e).getNextException());
			}
			try {
				if (connection == null) {
					connection = getSession().connection();
				}
				executePreparedStatementSingle(connection, sql, params);
				return;
			} catch (Exception ex) {
				log.error(e.getMessage(), e);
				// 这里会抛出异常
				AplusHibernateException.parseException(e);
			}
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (Exception e) {
					log.error(e.getMessage(), e);
					// 这里会抛出异常
					AplusHibernateException.parseException(e);
				}
			}
		}
	}

	/**
	 * 某些数据库服务批量执行如下形式的sql语句， 如：select now();select now();...
	 * 等以分号分隔的sql语句，需要拆分后单独执行
	 * 
	 * @param connection
	 * @param sqls
	 * @author WanWei
	 * @date 2014-3-25 下午5:14:38
	 */
	private void executePreparedStatementSingle(Connection connection,
			String sqls, Object[] params) throws Exception {
		boolean autoCommit = connection.getAutoCommit();
		connection.setAutoCommit(false);
		String[] sqlArray = sqls.split(";");
		for (int i = 0; i < sqlArray.length; i++) {
			if (!sqlArray[i].trim().isEmpty()) {
				PreparedStatement ps = connection.prepareStatement(sqlArray[i]);
				ps.setObject(1, params[i]);
				ps.execute();
				ps.close();
			}
		}
		connection.commit();
		connection.setAutoCommit(autoCommit);
		getSession().flush();
		getSession().clear();
	}

	/**
	 * 通用的limit函数，在业务代码中拼sql时，涉及到limit的sql语句是采用此 函数，否则可能会导致sql执行出错
	 * Postgresql、Mysql的limit写法有所区别，故提供统一的limit方法 提供类似Mysql limit start, off的功能
	 * 
	 * @param start
	 * @param offset
	 * @return String
	 * @author WanWei
	 * @date 2014-4-13 下午3:42:10
	 */
	public String limit(int start, int off) {
		String dialect = ((SessionImpl) getSession()).getFactory().getDialect()
				.getClass().getName();
		StringBuffer limitBuffer = new StringBuffer();
		if (dialect.toLowerCase().indexOf(DB_TYPE_POSTGRESQL) != -1) {
			limitBuffer.append(" LIMIT ").append(off).append(" OFFSET ")
					.append(start).append(" ");
		} else if (dialect.toLowerCase().indexOf(DB_TYPE_MYSQL) != -1) {
			limitBuffer.append(" LIMIT ").append(start).append(",").append(off)
					.append(" ");
		} else {
			log.error("未识别数据库类型[" + dialect + "] limit 命令无效!");
			// 抛出异常
			AplusHibernateException.throwException(
					AplusHibernateException.UNKNOWN_DB_DIALECT_EXCEPTION, null,
					null, null);
		}

		return limitBuffer.toString();

	}
	
	public Integer getSequence(String sequenceName) {
		SQLQuery query = createSQLQuery("select nextval (:sequenceName) "); 
		query.setParameter("sequenceName", sequenceName);
		return ((Number)query.uniqueResult()).intValue();
	}
    
}
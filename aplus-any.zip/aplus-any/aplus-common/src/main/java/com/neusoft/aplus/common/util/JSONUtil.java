package com.neusoft.aplus.common.util;

import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;

/**
 * @author zh_ch
 * @date 2015-2-10 下午4:04:33
 */
public final class JSONUtil {
	/**
	 * 对象转化为json字符串
	 * @param obj
	 * @return
	 * @author zh_ch
	 * @date 2015-2-12 下午2:16:52
	 */
	public static String getJsonString(Object object) {
		return JSON.toJSONString(object);
	}

	/**
	 * 将json字符串转化为T类型的实例
	 * @param jsonString
	 * @param T
	 * @return
	 * @author zh_ch
	 * @date 2015-2-12 下午2:17:31
	 */
	public static <T> T getSimpleObject(String jsonString, Class<T> clazz) {
		return  JSON.parseObject(jsonString, clazz);
	}

	/**
	 * 将json字符串转化为T类型的列表
	 * @param jsonString
	 * @param T
	 * @return
	 * @author zh_ch
	 * @date 2015-2-12 下午2:19:24
	 */
	public static <T> List<T> getObjectList(String text, Class<T> clazz) {
		return JSON.parseArray(text, clazz);
	}

	/**
	 * 将json字符串转化为复杂类型
	 * @param jsonString
	 * @param T
	 * @param E
	 * @return
	 * @author zh_ch
	 * @date 2015-2-12 下午2:20:02
	 */
	public static <T> T getComplexObject(String text, TypeReference<T> type) {
		return JSON.parseObject(text, type);
	}
	
	/**
	 * 从json对象转为java对象
	 * @param json
	 * @param clazz
	 * @return
	 * @author zh_ch
	 * @date 2015年4月24日 下午2:37:38
	 */
	public static <T> T getSimpleObject(JSON json, Class<T> clazz) {
		return JSON.toJavaObject(json, clazz);
	}
}

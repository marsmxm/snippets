package com.neusoft.aplus.common.netty;
/**
 * 将消息包装后通过netty传输
 * 
 * 接收端通过bodyClass将body通过fastjson反序列化
 * 
 * @author Mu Xian Ming
 * @date 2015年2月3日 上午11:07:59
 */
public class MessageWrapper {
	private Class<?> bodyClass;
	private String body;
	
	public Class<?> getBodyClass() {
		return bodyClass;
	}
	public void setBodyClass(Class<?> klass) {
		this.bodyClass = klass;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
}

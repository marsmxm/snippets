package com.neusoft.aplus.common.config;

import java.util.Map;

/**
 * @author zh_ch
 * @date 2015年6月11日 上午9:53:46
 */
public final class NettyServerConf {
	private Map<String, String> cmdProcConf;
	private Map<String, String> nettyConf;
	private Map<String, String> zmqTopicConf;
	private String tmpImportPath;
	private String alarmAddress;
	private String tableDumpDir;

	// nettyConfig配置中的key值常量
	public static final class NettyConst {
		// netty服务端的相关配置key
		public static final String NETTY_SERVER_PORT = "hostPort";
		public static final String NETTY_SERVER_IP = "hostIp";
		public static final String NETTY_CLIENT_IP = "clientIp";
		public static final String NETTY_CLIENT_Port = "clientPort";
		public static final String IS_NETTY_SERVER_SSL = "SSL";
	}

	// zmqTopicConfig配置中的key值常量
	public static final class ZmqTopicConst {
		public static final String FRONT_END = "frontend";
		public static final String BACK_END = "backend";
		public static final String PROXY_RESP = "proxyResp";
		public static final String SUB_CNT = "subCnt";
		public static final String PROXY_STARTER = "proxyStarter";
		public static final String EXTERNAL_CONFIG = "externalConfig";
	}

	// commandProcessConfig配置中的key值常量
	public static final class CmdProcConst {
		public static final String CMD_KEY_DB_METRIC = "metricEntityCommand";
		public static final String CMD_KEY_DB_CONN = "connEntityCommand";
		public static final String CMD_KEY_DB_DEVICE = "deviceEntityCommand";
		public static final String CMD_KEY_DB_ACTION = "actionEntityCommand";
		public static final String CMD_KEY_DB_DEVICE_ATTR = "deviceAttrEntityCommand";
		public static final String CMD_KEY_DB_DEVICE_PARENT = "deviceParentEntityCommand";
		public static final String CMD_KEY_DB_I18N = "deviceI18NEntityCommand";
		public static final String CMD_KEY_SYNC_METRIC = "metricSyncCommand";
	}

	public Map<String, String> getCmdProcConf() {
		return cmdProcConf;
	}

	public void setCmdProcConf(Map<String, String> cmdProcConf) {
		this.cmdProcConf = cmdProcConf;
	}

	public Map<String, String> getNettyConf() {
		return nettyConf;
	}

	public void setNettyConf(Map<String, String> nettyConf) {
		this.nettyConf = nettyConf;
	}

	public Map<String, String> getZmqTopicConf() {
		return zmqTopicConf;
	}

	public void setZmqTopicConf(Map<String, String> zmqTopicConf) {
		this.zmqTopicConf = zmqTopicConf;
	}

	public String getTmpImportPath() {
		return tmpImportPath;
	}

	public void setTmpImportPath(String tmpImportPath) {
		this.tmpImportPath = tmpImportPath;
	}

	public String getTableDumpDir() {
		return tableDumpDir;
	}

	public void setTableDumpDir(String tableDumpDir) {
		this.tableDumpDir = tableDumpDir;
	}

	public String getAlarmAddress() {
		return alarmAddress;
	}

	public void setAlarmAddress(String alarmAddress) {
		this.alarmAddress = alarmAddress;
	}
}

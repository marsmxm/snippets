package com.neusoft.aplus.common.zmq.queue;

import org.apache.commons.lang.StringUtils;
import org.zeromq.ZMQ;
import org.zeromq.ZMQ.Context;



import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.ZMQException;

/**
 * Queue模式pull端，从push端接收消息
 * 
 * @author zh_ch
 * @date 2014-12-27 下午1:29:48
 */
public final class Puller {
	private ZMQ.Context ctx;
	private ZMQ.Socket pull;
	private ZMQ.Socket req;
	private QueueConf queueConf;

	public Puller() {

	}

	public Puller(Context ctx, QueueConf queueConf) {
		super();
		this.ctx = ctx;
		this.queueConf = queueConf;
	}

	public ZMQ.Context getCtx() {
		return ctx;
	}

	public void setCtx(ZMQ.Context ctx) {
		this.ctx = ctx;
	}

	public ZMQ.Socket getPull() {
		return pull;
	}

	public void setPull(ZMQ.Socket pull) {
		this.pull = pull;
	}

	public ZMQ.Socket getReq() {
		return req;
	}

	public void setReq(ZMQ.Socket req) {
		this.req = req;
	}

	public QueueConf getQueueConf() {
		return queueConf;
	}

	public void setQueueConf(QueueConf queueConf) {
		this.queueConf = queueConf;
	}

	/**
	 * 检查queueConf，初始化pull和req
	 * 
	 * @return
	 * @author zh_ch
	 * @date 2014-12-27 下午5:24:20
	 */
	public Puller waitForReceiveMsg() {
		checkPullerNameAndAddr();
		pull = ctx.socket(ZMQ.PULL);
		pull.connect(queueConf.getPushend());

		req = ctx.socket(ZMQ.REQ);
		req.connect(queueConf.getRespend());
		return this;
	}

	/**
	 * pull端接收消息
	 * 
	 * @return
	 * @author zh_ch
	 * @date 2014-12-27 下午1:49:21
	 */
	public String recvStr() {
		String recv = pull.recvStr();
		if (recv.startsWith(ZMQConst.QUEUE_HELLO)) {
			return handleDetectMsg(recv);
		}
		return recv;
	}

	/**
	 * 销毁上下文
	 * 
	 * @author zh_ch
	 * @date 2014-12-27 下午4:59:22
	 */
	public void destroy() {
		pull.close();
		req.close();
		ctx.term();
	}

	/**
	 * 处理push端探测消息的私有方法，如果为hello消息，则返回ready消息及puller名称
	 * 
	 * @param recv
	 * @return
	 * @author zh_ch
	 * @date 2014-12-27 下午3:37:50
	 */
	private String handleDetectMsg(String recv) {
		String msg = ZMQConst.QUEUE_READY + ZMQConst.SEPERATOR
				+ queueConf.getPullerName();
		req.send(msg);
		req.recvStr();
		return null;
	}

	/**
	 * 检查pullerName是否为空
	 * 
	 * @author zh_ch
	 * @date 2014-12-27 下午4:47:59
	 */
	private void checkPullerNameAndAddr() {
		if (StringUtils.isBlank(queueConf.getPullerName())) {
			ZMQException.throwException(ZMQException.PULLNAME_NULL);
		}

		if (StringUtils.isBlank(queueConf.getPushend())) {
			ZMQException.throwException(ZMQException.PUSHEND_NULL);
		}

		if (StringUtils.isBlank(queueConf.getRespend())) {
			ZMQException.throwException(ZMQException.PUSH_RESPEND_NULL);
		}
	}
}

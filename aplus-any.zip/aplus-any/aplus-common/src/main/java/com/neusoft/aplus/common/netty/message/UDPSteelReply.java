package com.neusoft.aplus.common.netty.message;
/**
 * @author Mu Xian Ming
 * @date 2015年4月22日 下午3:28:20
 */
public class UDPSteelReply extends Reply {

}

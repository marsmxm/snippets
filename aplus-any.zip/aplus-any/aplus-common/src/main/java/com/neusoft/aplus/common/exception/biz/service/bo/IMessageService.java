package com.neusoft.aplus.common.exception.biz.service.bo;

import com.neusoft.aplus.common.exception.AplusException;

/**
 * @author guo.tc
 * @date 2014-6-30 上午11:22:34
 */
public interface IMessageService {
//	public List<ExceptionInfo> listMsgs();
	public void saveMsg(AplusException ex);
}

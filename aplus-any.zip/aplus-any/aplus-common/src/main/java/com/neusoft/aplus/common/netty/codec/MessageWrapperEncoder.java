package com.neusoft.aplus.common.netty.codec;

import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageEncoder;

import java.util.List;

import com.alibaba.fastjson.JSON;
import com.neusoft.aplus.common.netty.MessageWrapper;
import com.neusoft.aplus.common.netty.message.Message;

/**
 * MessageWrapper编码器
 *
 * Netty组件，参见com.neusoft.aplus.probe.inquirer.biz.AgentInitializer
 *
 * 将MessageWrapper编码成对应的JSON字符串
 * 
 * @author Mu Xian Ming
 * @date 2015年2月2日 下午1:13:58
 */
public class MessageWrapperEncoder extends MessageToMessageEncoder<Message> {
//	private static Logger logger = Logger.getLogger(MessageWrapperEncoder.class);
	
	@Override
	protected void encode(ChannelHandlerContext ctx, Message msg, List<Object> out)
			throws Exception {
//		logger.debug("Encoding msg: " + msg);
		MessageWrapper wrapper = new MessageWrapper();
		wrapper.setBodyClass(msg.getClass());
		wrapper.setBody(JSON.toJSONString(msg));
		String result = JSON.toJSONString(wrapper);
		out.add(result + "\n");
	}

}

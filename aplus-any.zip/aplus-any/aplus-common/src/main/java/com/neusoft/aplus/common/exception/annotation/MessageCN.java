package com.neusoft.aplus.common.exception.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 异常码对应中文注解
 * @author guo.tc
 * @date 2014-6-23 下午1:51:15
 */
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface MessageCN {
	String value() default "";
}

package com.neusoft.aplus.common.zmq.client.impl;

import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.zeromq.ZMQ;
import org.zeromq.ZMsg;
import org.zeromq.ZMQ.PollItem;

import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.common.zmq.client.api.IDoBusiness;
import com.neusoft.aplus.common.zmq.client.api.Subscriber;
import com.neusoft.aplus.common.zmq.client.connector.Connector;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;

/**
 * 封装了高可用模式下的Subscriber 不断接受指定主题的信息，并根据创建时设置的方法对消息做处理
 * 
 * @author MaHan
 *
 * @date 2015年5月27日
 */
public class SubClusterClient implements Subscriber {

	private static Logger log = LoggerFactory.getLogger(SubClusterClient.class);
	private ZMQ.Socket sub;
	private Connector subConn;
	private Map<String, IDoBusiness> businessMap;

	private SubClusterClient() {
	}

	public static SubClusterClient builder() {
		return new SubClusterClient();
	}

	public SubClusterClient setSubConn(Connector subConn) {
		this.subConn = subConn;
		return this;
	}
	
	public SubClusterClient setBusinessMap(Map<String, IDoBusiness> businessMap){
		this.businessMap = businessMap;
		return this;
	}

	@Override
	public void run() {
		while (!Thread.currentThread().isInterrupted()) {
			if (!subConn.isConnected()) {
				log.debug("sub connector 未连接");
				sleep(300);
				continue;
			} else if (subConn.isNewMaster()) {
				connect();
				setTopic();
			}

			while (subConn.isConnected() && !subConn.isNewMaster()) {
				PollItem items[] = { new PollItem(sub, ZMQ.Poller.POLLIN) };
				int rc = ZMQ.poll(items, 1, 500);
				if (rc == -1) {
					log.warn("Interrupted");
					break;
				}
				if (items[0].isReadable()) {
					ZMsg zMsg = ZMsg.recvMsg(sub);
					if(!handleZmsg(zMsg)){
						continue;
					}
					log.info("sub收到：" + zMsg);
					continue;
				}
			}
		}
	}

	private boolean handleZmsg(ZMsg zMsg) {
		IDoBusiness doBusiness = businessMap.get(new String(zMsg
				.getFirst().getData()));
		if (doBusiness != null) {
			doBusiness.handleRecv(JSONUtil.getSimpleObject(new String(zMsg
					.getLast().getData()), ZMQMessage.class));
			return true;
		} else {
			log.info(zMsg + "没有设置对应的处理方法");
			return false;
		}
	}

	private void connect() {
		log.info("subclient connect()连接");
		if (sub != null) {
			log.info("subclient req关闭");
			sub.setLinger(0);
			sub.close();
		}
		sub = subConn.createSocket();
		if (subConn.isBind()) {
			sub.bind(subConn.getAddress());
		} else {
			sub.connect(subConn.getAddress());
		}
		subConn.setNewMaster(false);
	}

	private void setTopic() {
		Set<String> topicSet = businessMap.keySet();
		log.info("设置订阅主题" + topicSet);
		for (String topic : topicSet) {
			sub.subscribe(topic.getBytes());
		}
	}

	private void sleep(long time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}

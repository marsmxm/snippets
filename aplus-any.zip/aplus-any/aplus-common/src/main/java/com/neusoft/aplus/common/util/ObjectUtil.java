package com.neusoft.aplus.common.util;

/**
 * 对象工具类
 * 
 * @author wuhao
 * @date 2014-12-25 下午12:14:06
 */
public class ObjectUtil {

	/**
	 * 判斷字符串是否为非负数字
	 * 
	 * @param str
	 * @return
	 * @author wuhao
	 * @date 2014-12-25 下午12:14:41
	 */
	public static boolean isNumeric(String str) {

		if (str == null || str.length() == 0) {
			return false;
		}
		for (int i = 0; i < str.length(); i++) {
			if (!Character.isDigit(str.charAt(i))) {
				return false;
			}
		}
		return true;
	}
}

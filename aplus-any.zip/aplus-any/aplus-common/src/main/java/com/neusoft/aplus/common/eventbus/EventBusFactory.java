package com.neusoft.aplus.common.eventbus;

import com.google.common.eventbus.EventBus;

/**
 * 事件总线工厂类
 *
 * 现在采集端的进程内通信主要都是用EventBus实现，
 * 事件触发大多在aplus-databus工程下的PluginManager，
 * 时间处理在aplus-probe-inquirer有各种事件的handler
 * 
 * @author Mu Xian Ming
 * @date 2015年1月13日 下午3:54:42
 */
public class EventBusFactory {
	private EventBusFactory() {
	}

	private static class EventBusHolder {
		static final EventBus eventBus = new EventBus();
	}

	public static EventBus getEventBus() {
		return EventBusHolder.eventBus;
	}
}

package com.neusoft.aplus.common.exception.biz.service.dao;

import java.util.Map;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.common.exception.AplusException;
import com.neusoft.aplus.common.util.TransUtil;
import com.neusoft.aplus.model.dbentity.exception.ExceptionEntity;

/**
 * 信息保存到DB
 * 
 * @author guo.tc
 * @date 2014-6-27 下午4:46:07
 */
@Repository
public class MessageDao extends AbstractHibernateDao<ExceptionEntity> {

	@Autowired
	protected MessageDao(@Qualifier("sessionFactory") SessionFactory f) {
		super(ExceptionEntity.class, f);
	}


	/**
	 * 保存数据到DB
	 */
	public void saveMsg(AplusException ex) {
		if (null == ex){
			return;
		}
		ExceptionEntity info = new ExceptionEntity();

		String eCode = ex.getEcode();
		String stackMsg = ex.getOriginMessage();
		Map<String, Object> keyPoints = ex.getkeyPoints();
		info.seteCode(eCode);
		
		if (null != stackMsg) {
			info.setStackMsg(stackMsg);
		}
		if (null != keyPoints) {
			info.setKeyPoints(TransUtil.ObjectToByte(keyPoints));
		}
		
		info.setDatetime(System.currentTimeMillis());
		saveOrUpdate(info);
	}

}

package com.neusoft.aplus.common.schedule;

import java.util.List;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.neusoft.aplus.common.config.NettyClientConf;
import com.neusoft.aplus.common.util.SpringUtil;

/**
 * 循环调度DelayedObject的调度器
 * 
 * 当存入的DelayedObject经过delay时间后可用时，使用ITaskHandler成员
 * 处理该DelayedObject，然后reset DelayedObject，等待下次调度
 * 
 * @author Mu Xian Ming
 * @date 2015年3月11日 下午2:31:15
 */
public class DelayedTaskScheduler<T> implements Runnable {
	private static Logger logger = 
			LoggerFactory.getLogger(DelayedTaskScheduler.class);
	private final long interval; // scheduler轮询delayQueue的间隔，单位ms
	private Thread thread;
	private ThreadFactory threadFactory;
	private DelayQueue<DelayedObject<T>> q = new DelayQueue<DelayedObject<T>>();
	private ITaskHandler<T> handler;
	private volatile boolean running = false;
	private ExecutorService pool = Executors.newCachedThreadPool();
	private final int maxTaskNum;
	
	/**
	 * 
	 * @param handler 用于处理DelayedObject中实际数据的ITaskHandler
	 * @param interval 调度器每隔interval时间后查看是否有可用的DelayedObject
	 */
	private DelayedTaskScheduler(ITaskHandler<T> handler, long interval) {
		this.handler = handler;
		this.interval = interval;
		NettyClientConf config = SpringUtil.getBean(NettyClientConf.class);
		maxTaskNum = config.getDataPushTaskMaxNum();
	}
	
	public static <E> DelayedTaskScheduler<E> newInstance() {
		return new DelayedTaskScheduler<E>(null, 1000);
	}
	
	public static <E> DelayedTaskScheduler<E> newInstance(ITaskHandler<E> handler) {
		return new DelayedTaskScheduler<E>(handler, 1000);
	}
	
	public static <E> DelayedTaskScheduler<E> newInstance(ITaskHandler<E> handler, long interval) {
		return new DelayedTaskScheduler<E>(handler, interval);
	}
	
	public synchronized void setThreadFactory(ThreadFactory threadFactory) {
		this.threadFactory = threadFactory;
	}
	
	public ITaskHandler<T> getHandler() {
		return handler;
	}

	public void setHandler(ITaskHandler<T> handler) {
		this.handler = handler;
	}

	public void addTask(DelayedObject<T> dtask) {
		if (q.size() >= maxTaskNum) {
			removeOldestTasks();
		}
		q.offer(dtask);
	}
	
	private void removeOldestTasks() {
		long maxAge = Long.MIN_VALUE;
		long currentTime = System.currentTimeMillis();
		String removeID = "";
		for (DelayedObject<T> dobj : q) {
			long age = dobj.getAge(currentTime);
			if (age > maxAge) {
				maxAge = age;
				removeID = dobj.getID();
			}
		}
		logger.warn("由于达到采集任务数量上限，推送任务{}将被终止", removeID);
		removeTasks(removeID);
	}
	
	public int removeTasks(String id) {
		int counter = 0;
		for (DelayedObject<T> task : q) {
			if (task.getID().equals(id)) {
				if (q.remove(task)) { counter++; }
			}
		}
		return counter;
	}
	
	public boolean hasTask(String id) {
		for (DelayedObject<T> task : q) {
			if (task.getID().equals(id)) {
				return true;
			}
		}
		return false;
	}
	
	public synchronized void start() {
		if (running) {
            throw new IllegalStateException("Scheduler is already running");
        }
		Preconditions.checkNotNull(handler);
		running = true;
		if (threadFactory != null) {
			thread = threadFactory.newThread(this);
		} else {
			thread = new Thread(this);
		}
		thread.start();
	}
	
	public synchronized void stop() throws Exception {
        stop(interval);
    }

    public synchronized void stop(long stopInterval) throws Exception {
        if (!running) {
            throw new IllegalStateException("Scheduler is not running");
        }
        running = false;
        try {
            thread.join(stopInterval);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

	@Override
	public void run() {
		List<DelayedObject<T>> sink = Lists.newArrayList();
		while(running) {
			if (q.drainTo(sink) > 0) {
				for (final DelayedObject<T> dobj : sink) {
					q.add(dobj.reset());
					logger.debug("开始处理任务{}", dobj.getID());
					pool.execute(new Runnable() {
						@Override
						public void run() {
							handler.handle(dobj.getData());
						}
					});
				}
				sink.clear();
			}
			try {
				TimeUnit.MILLISECONDS.sleep(interval);
			} catch (InterruptedException ignored) {
			}
		}
	}
	
	@Override
	public String toString() {
		return "new DelayedTaskScheduler(interval=" + interval + ", "
				+ "handler=" + handler + ")";
	}
}

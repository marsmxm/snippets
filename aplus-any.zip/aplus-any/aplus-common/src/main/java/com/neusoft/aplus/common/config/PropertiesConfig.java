package com.neusoft.aplus.common.config;

/**
 * 配置文件的相关属性
 * 
 * @author Wuhao
 * @date 2014-7-24 上午11:29:52
 */
public class PropertiesConfig {

	// Exception的路径
	private static String exceptionUrl;
	// 连结次数
	private static String connectTimes;

	public static String getConnectTimes() {
		return connectTimes;
	}

	public static void setConnectTimes(String connectTimes) {
		PropertiesConfig.connectTimes = connectTimes;
	}
	
	public String getPropertiesConnectTime() {
		return connectTimes;
	}

	public String getExceptionUrl() {
		return exceptionUrl;
	}

	public void setExceptionUrl(String exceptionUrl) {
		PropertiesConfig.exceptionUrl = exceptionUrl;
	}

	public static String getPropertiesExceptionUrl() {
		return exceptionUrl;
	}

}

package com.neusoft.aplus.common.exception.biz.service.bo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.neusoft.aplus.common.exception.AplusException;
import com.neusoft.aplus.common.exception.biz.service.dao.MessageDao;

/**
 * 信息保存service
 * @author guo.tc
 * @date 2014-6-27 下午12:43:47
 */
@Service
@Transactional
public class MessageService implements IMessageService{
	
	@Autowired
	private MessageDao messageDao;
	
	public MessageService(){
		
	}
	
	public void saveMsg(AplusException ex) {
		messageDao.saveMsg(ex);
	}

}

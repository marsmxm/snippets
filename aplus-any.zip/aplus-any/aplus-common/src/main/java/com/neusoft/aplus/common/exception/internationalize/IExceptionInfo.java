package com.neusoft.aplus.common.exception.internationalize;

import java.util.List;

/**
 * 导入国际化文件处理接口
 * @author guo.tc
 * @date 2014-6-24 下午1:25:54
 */
public interface IExceptionInfo {
	void exmportErrorMsg(List<String> exceptions);
}

package com.neusoft.aplus.common.exception.internationalize;

import java.util.List;

/**
 * 导入异常信息服务类
 * @author guo.tc
 * @date 2014-6-24 下午1:37:59
 */
public class ExceptionInfoService {

	private static IExceptionInfo exceptionInfo;
	private static List<String> exceptions;

	public ExceptionInfoService() {
	}

	public IExceptionInfo getExceptionInfo() {
		return exceptionInfo;
	}

	public void setExceptionInfo(IExceptionInfo exceptionInfo) {
		ExceptionInfoService.exceptionInfo = exceptionInfo;
	}

	public List<String> getExceptions() {
		return exceptions;
	}

	public void setExceptions(List<String> exceptions) {
		ExceptionInfoService.exceptions = exceptions;
	}

	/**
	 * 导出国际化属性文件
	 * @param flg 只在true时导出文件
	 * @author guo.tc
	 * @date 2014-6-27 上午9:18:17
	 */
	public static void exportInternationalFile(boolean flg){
		if(flg)
			exceptionInfo.exmportErrorMsg(exceptions);
	}
}

package com.neusoft.aplus.common.zmq.client.launch;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.Watcher.Event.EventType;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.data.Stat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neusoft.aplus.common.config.ZMQConfig;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.common.zmq.client.api.IProcessHandler;

public class ZkClient implements Watcher, Runnable {
	private static Logger log = LoggerFactory.getLogger(ZkClient.class);
	private static int SESSION_TIMEOUT = 3000;
	private static String MASTER_ZNODE = "/MASTER";
	private static String MASTER_DATA_ZNODE = MASTER_ZNODE + "/CONFIG";

	private IProcessHandler handler;

	private ZooKeeper zk;
	private String connection;
	private CountDownLatch connectedSemaphore = new CountDownLatch(1);

	@SuppressWarnings("unchecked")
	public ZkClient(IProcessHandler handler) {
		Map<String, String> configMap = (HashMap<String, String>) ApplicationContextFactory
				.getBean("zmqClientConfig");
		connection = configMap.get(ZMQConfig.ZOOKEEPER_ADDRESS);
		this.handler = handler;
	}

	@Override
	public void run() {

		try {
			zk = new ZooKeeper(connection, SESSION_TIMEOUT, this);
			connectedSemaphore.await();
			doIt();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		while (true) {
		}
	}

	public void process(WatchedEvent event) {
		EventType eventType = event.getType();

		if (KeeperState.SyncConnected == event.getState()
				&& EventType.None == eventType && null == event.getPath()) {
			connectedSemaphore.countDown();
			return;
		}

		try {
			zk.exists(MASTER_DATA_ZNODE, true);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (MASTER_DATA_ZNODE.equals(event.getPath())) {
			if (EventType.NodeDeleted == eventType) {
				log.warn("服务端已停止，等待重新选举主服务....");
				handler.onMasterMissing();
				log.info("zkClient处理完 onMasterMissing事件");
				return;
			}
			if (EventType.NodeDataChanged == eventType
					|| EventType.NodeCreated == eventType) {
				log.info("新服务被应用....");
				try {
					doIt();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	private void doIt() throws Exception {
		Stat exists = zk.exists(MASTER_DATA_ZNODE, true);
		if (null == exists) {
			log.info("未检测到sever端未启动");
			return;
		}
		byte[] data = zk.getData(MASTER_DATA_ZNODE, true, null);

		handler.onMasterSelected(new String(data));
	}
}

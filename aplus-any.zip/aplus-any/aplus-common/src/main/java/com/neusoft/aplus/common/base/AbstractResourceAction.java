package com.neusoft.aplus.common.base;

import com.neusoft.aplus.common.exception.RestException;
import org.restlet.data.Method;
import org.restlet.representation.Representation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * BaseAction基类的子类，继承自该基类的Action可根据需要实现
 * {@link #represent()}获取资源、{@link #removeRepresentations()}删除资源、<br/>
 * {@link #acceptRepresentation(Representation)}创建资源
 * 和{@link #storeRepresentation(Representation)}更新资源方法。<br/>
 * 如果访问到没有复写的方法,会抛出{@link RestException#CODE_UNSUPPORT_HTTP_METHOD_TYPE_ERROR}
 *
 * @author li.hzh
 * @date 2015-04-17 15:50:38
 */
public abstract class AbstractResourceAction extends BaseAction {

	private static final Logger logger = LoggerFactory.getLogger(AbstractResourceAction.class);

	@Override
	public void acceptRepresentation(Representation entity) {
		logger.warn("不支持的HTTP请求类型: [{}].", Method.POST.getName());
		RestException.throwException(RestException.CODE_UNSUPPORT_HTTP_METHOD_TYPE_ERROR, new String[]{Method.POST.getName()});
	}

	@Override
	public Representation represent() {
		logger.warn("不支持的HTTP请求类型: [{}].", Method.GET.getName());
		RestException.throwException(RestException.CODE_UNSUPPORT_HTTP_METHOD_TYPE_ERROR, new String[]{Method.GET.getName()});
		return null;
	}

	@Override
	public void removeRepresentations() {
		logger.warn("不支持的HTTP请求类型: [{}].", Method.DELETE.getName());
		RestException.throwException(RestException.CODE_UNSUPPORT_HTTP_METHOD_TYPE_ERROR, new String[]{Method.DELETE.getName()});
	}

	@Override
	public void storeRepresentation(Representation entity) {
		logger.warn("不支持的HTTP请求类型: [{}].", Method.PUT.getName());
		RestException.throwException(RestException.CODE_UNSUPPORT_HTTP_METHOD_TYPE_ERROR, new String[]{Method.PUT.getName()});
	}

}

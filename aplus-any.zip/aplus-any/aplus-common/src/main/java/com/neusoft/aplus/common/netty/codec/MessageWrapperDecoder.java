package com.neusoft.aplus.common.netty.codec;

import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageDecoder;

import java.util.List;

import com.alibaba.fastjson.JSON;
import com.neusoft.aplus.common.netty.MessageWrapper;

/**
 * MessageWrapper解码器
 *
 * Netty组件，参见com.neusoft.aplus.probe.inquirer.biz.AgentInitializer
 * 
 * 将JSON字符串解码成MessageWrapper对象，之后将MessageWrapper
 * 中包含的Message对象反序列化之后放到pipeline
 * 
 * @author Mu Xian Ming
 * @date 2015年2月2日 下午1:13:58
 */
public class MessageWrapperDecoder extends  MessageToMessageDecoder<String> {
//	private static Logger logger = Logger.getLogger(MessageWrapperDecoder.class);
	
	@Override
	protected void decode(ChannelHandlerContext ctx, String msg,
			List<Object> out) throws Exception {
//		logger.debug("Decoding msg: " + msg);
		MessageWrapper wrapper = JSON.parseObject(msg, MessageWrapper.class);
		out.add(JSON.parseObject(wrapper.getBody(), wrapper.getBodyClass()));
	}

}

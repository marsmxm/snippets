package com.neusoft.aplus.common.base;

import org.apache.log4j.Logger;
import org.restlet.Application;
import org.restlet.Restlet;
import org.restlet.resource.ServerResource;
import org.restlet.routing.Router;

import com.neusoft.aplus.common.config.ForwardPoint;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;

/**
 * 负责建立请求URL同处理类action之间的匹配关系
 * 
 * @author WanWei
 * @date 2014-6-6 下午4:18:35
 */
public class BaseApplication extends Application {

	private static Logger log = Logger.getLogger(BaseApplication.class);

	private static Router router;

	/**
	 * 获取rest的router
	 * 
	 * @return Router
	 * @author WanWei
	 * @date 2014-6-25 下午8:12:04
	 */
	private Router getRouter() {
		// 不会有多线程调用这个方法
		if (router == null) {
			router = (Router) super.getInboundRoot();
		}
		return router;
	}

	/**
	 * 绑定请求的uri和其处理类
	 * 
	 * @param uri
	 * @param targetClass
	 * @author WanWei
	 * @date 2014-6-25 下午8:13:30
	 */
	public void attach(String uri, Class<? extends ServerResource> targetClass) {
		getRouter().attach(uri, targetClass);
	}
	
	/**
	 * 绑定请求的uri和有filter的处理类
	 * 
	 * @param uri
	 * @param restlet
	 * @author WanWei
	 * @date 2015-3-20 上午11:04:10
	 */
	public void attach(String uri, Restlet restlet) {
		getRouter().attach(uri, restlet);
	}

	public Restlet createInboundRoot() {
		Router router = new Router(getContext());
		ForwardPoint forwardPoint = ApplicationContextFactory.getBean(
				"forwardConfig", ForwardPoint.class);
		
		if (forwardPoint != null && forwardPoint.isNeedForward()) {
			router.attachDefault(ForwardAction.class);
			log.info("添加跳转路由");
		}
		return router;
	}
}

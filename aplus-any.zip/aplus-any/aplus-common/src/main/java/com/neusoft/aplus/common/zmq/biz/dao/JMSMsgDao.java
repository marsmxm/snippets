package com.neusoft.aplus.common.zmq.biz.dao;

import java.util.List;

import com.neusoft.aplus.model.jms.JMSMessageEntity;

/**
 * 
 * @author MaHan
 *
 * @date 2015年5月6日
 */
public interface JMSMsgDao {
	/**
	 *  获取所有持久化的待发送的消息队列
	 * @return 所有消息队列列表
	 * @author MaHan
	 * @date 2015年5月6日
	 */
	List<JMSMessageEntity> listAll();

	/**
	 * 新增一条消息
	 * @param msgEntity
	 * JMS消息体
	 * @return 唯一Id
	 * @author MaHan
	 * @date 2015年5月6日
	 */
	String addMsg(JMSMessageEntity msgEntity);

	/**
	 * 移除一条信息
	 * @param id
	 * 消息Id
	 * @author MaHan
	 * @date 2015年5月6日
	 */
	void removeMsg(String id);
}

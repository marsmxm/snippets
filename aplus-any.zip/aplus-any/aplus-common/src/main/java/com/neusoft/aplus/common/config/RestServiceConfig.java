package com.neusoft.aplus.common.config;

import org.restlet.data.Protocol;

/**
 * 配置Rest服务的相关内容，包括启动端口号、最大连接数、协议等
 * 
 * @author WanWei
 * @date 2014-6-26 下午1:49:52
 */
public class RestServiceConfig {
	
	public final static String PROTOCOL_HTTP = "http";
	
	public final static String PROTOCOL_HTTPS = "https";
	
	private final static int DEFAULT_REST_PORT = 8182;
	
	private final static String DEFAULT_MAX_THREADS = "200";
	
	//服务支持的最大并发连接数，当请求超过此设置时，会出现排队等待处理的情况
	//默认限制的最大连接数为200
	public static String maxThreads = DEFAULT_MAX_THREADS;
	
	//支持http和https设置, 默认使用http协议
	public static String protocol = PROTOCOL_HTTP;
	
	//默认使用8182端口
	public static int port = DEFAULT_REST_PORT;


	public String getProtocol() {
		return protocol;
	}

	/**
	 * 获取Rest服务当前使用的协议
	 * @return Protocol
	 * @author WanWei
	 * @date 2014-6-26 下午3:51:03
	 */
	public static Protocol getRestProtocol() {
		if(PROTOCOL_HTTPS.equals(protocol)){
			return Protocol.HTTPS;
		}
		return Protocol.HTTP;
	}
	
	/**
	 * 如果配置的protocol不是http或https,则使用http
	 * @param protocol
	 * @author WanWei
	 * @date 2014-6-26 下午2:10:47
	 */
	public void setProtocol(String protocol) {
		if(PROTOCOL_HTTP.equals(protocol) || PROTOCOL_HTTPS.equals(protocol)){
			RestServiceConfig.protocol = protocol;
		}
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		RestServiceConfig.port = port;
	}
	
	public String getMaxThreads() {
		return maxThreads;
	}

	public void setMaxThreads(String max) {
		RestServiceConfig.maxThreads = max;
	}

}

package com.neusoft.aplus.common.config;

/**
 * ZMQ配置类，包括zookeeper地址，ZMQ服务器前后端地址和pub、sub的连接地址
 */
public class ZMQConfig {

	public final static String ISCLUSTER = "isCluster";
	public final static String ZOOKEEPER_ADDRESS = "zookeeper_address"; // zookeeper地址
	public final static String SEVICE_REP = "sevice_rep"; // 服务器与pub端通信地址
	public final static String SEVICE_PUB = "sevice_pub"; // 服务器与sub端通信地址
	public final static String PUBLISHER_REQ = "publisher_req"; // pub端连接地址
	public final static String SUBSCRIBER_SUB = "subscriber_sub"; // sub端连接地址
}

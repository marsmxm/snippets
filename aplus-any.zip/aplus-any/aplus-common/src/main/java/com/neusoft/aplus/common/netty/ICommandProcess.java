package com.neusoft.aplus.common.netty;

import com.neusoft.aplus.common.netty.message.AbstractCommand;
import com.neusoft.aplus.common.netty.message.Reply;

/**
 * @author zh_ch
 * @date 2015-2-5 下午3:48:10
 */
public interface ICommandProcess {
	public Reply executeCommand(AbstractCommand command);
}

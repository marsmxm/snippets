package com.neusoft.aplus.common.cache.impl;

import java.io.File;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import com.neusoft.aplus.common.cache.api.DCacheService;
import com.neusoft.aplus.common.util.FileUtil;

/**
 * 分布式缓存服务实现类
 * (为将分布式缓存 改为本地模式时，暂将此类移植common下)
 * @author MaHan
 *
 * @date 2015年5月25日
 */
public class DCacheServiceImpl implements DCacheService {
	
	private static Logger log = LoggerFactory.getLogger(DCacheServiceImpl.class);
	// 初始化缓存管理器
//	private static CacheManager cacheManager = CacheManager.create("ehcache.xml");
	private static CacheManager cacheManager = CacheManager.create(getAbsolutePath("ehcache"));

	private static String getAbsolutePath(String path){
		String springPath = FileUtil.getRepositoryPath(path);
		File dir = new File(springPath);
		File[] files = dir.listFiles();
		if(files!=null && files.length>0){
			String p = files[0].getAbsolutePath().trim();
			System.out.println(p);
			return p;
		}
		return null;
	}
	
	
	
	public void initCacheManager() {
//		cacheManager = CacheConfigUtil.getCacheManager();
		log.debug("ehcache 初始化");
		System.out.println("ehcache init");
	}

	@Override
	public boolean isInCache(String cacheName, String key) {
		if(!cacheManager.cacheExists(cacheName))
			return false;
		Cache cache = cacheManager.getCache(cacheName);
		return cache.isKeyInCache(key);
	}

	@Override
	public Object get(String cacheName, String key) {
		if(!isInCache(cacheName, key))
			return null;
		Cache cache = cacheManager.getCache(cacheName);
		return cache.get(key).getObjectValue();
	}

	@Override
	public void put(String cacheName, String key, Object value) {
		if(!cacheManager.cacheExists(cacheName))
			return;
		Cache cache = cacheManager.getCache(cacheName);
		cache.put(new Element(key,value));
	}

	@Override
	public void remove(String cacheName, String key) {
		if(!isInCache(cacheName, key))
			return;
		cacheManager.getCache(cacheName).remove(key);
	}

	@Override
	public String[] getAllCacheNames() {
		return cacheManager.getCacheNames();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object> getKeys(String cacheName) {
		if(!cacheManager.cacheExists(cacheName)) 
			return null;
		Cache cache = cacheManager.getCache(cacheName);
		List<Object> list = cache.getKeys();
		return list;
	}

}

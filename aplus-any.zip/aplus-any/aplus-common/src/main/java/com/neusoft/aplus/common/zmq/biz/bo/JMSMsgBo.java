package com.neusoft.aplus.common.zmq.biz.bo;

import com.neusoft.aplus.common.zmq.model.ZMQMessage;

import java.util.List;

/**
 * @author li.hzh
 * @date 2015-05-04 14:39
 */
public interface JMSMsgBo {

	/**
	 * 获取所有持久化的待发送的消息队列
	 *
	 * @return 所有消息队列列表
	 * @author li.hzh
	 * @date 2015-05-04 14:40:35
	 */
	List<ZMQMessage> listAll();

	/**
	 * 新增一条消息
	 *
	 * @param msgEntity
	 * 		JMS消息体
	 *
	 * @return 唯一Id
	 * @author li.hzh
	 * @date 2015-05-04 15:44:52
	 */
	String addMsg(ZMQMessage zmqMessage);

	/**
	 * 移除一条信息
	 *
	 * @param id
	 * 		消息Id
	 *
	 * @author li.hzh
	 * @date 2015-05-04 16:06:14
	 */
	void removeMsg(String id);

}

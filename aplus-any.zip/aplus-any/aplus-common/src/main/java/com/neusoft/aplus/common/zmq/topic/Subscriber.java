package com.neusoft.aplus.common.zmq.topic;

import org.apache.commons.lang.StringUtils;
import org.zeromq.ZMQ;
import org.zeromq.ZMQ.Context;

import com.neusoft.aplus.common.util.AplusStringUtils;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.ZMQException;

/**
 * Sub端，提供启动pub/sub代理、rut/del代理、接收pub发送的消息
 * 
 * @author zh_ch
 * @date 2014-12-25 下午6:57:00
 */
public final class Subscriber {
	private ZMQ.Context ctx;
	private ZMQ.Socket sub;
	private ZMQ.Socket req;
	private TopicConf topicConf;

	public Subscriber() {
	}

	public Subscriber(Context ctx, TopicConf topicConf) {
		super();
		this.ctx = ctx;
		this.topicConf = topicConf;
	}

	public ZMQ.Context getCtx() {
		return ctx;
	}

	public void setCtx(ZMQ.Context ctx) {
		this.ctx = ctx;
	}

	public TopicConf getTopicConf() {
		return topicConf;
	}

	public void setTopicConf(TopicConf topicConf) {
		this.topicConf = topicConf;
	}

	/**
	 * 与pub完成握手，通知pub发送消息，等待接收pub端发送的消息
	 * 
	 * @return
	 * @author zh_ch
	 * @date 2014-12-25 下午7:53:19
	 */
	public Subscriber waitForReceiveMsg() {
		checkAddrForSub();
		sub = ctx.socket(ZMQ.SUB);
		sub.connect(topicConf.getBackend());
		sub.subscribe(ZMQConst.TOPIC_HELLO.getBytes());
		if (StringUtils.isBlank(topicConf.getSubscription())) {
			sub.subscribe("".getBytes());
		} else {
			sub.subscribe(topicConf.getSubscription().getBytes());
		}

		req = ctx.socket(ZMQ.REQ);

		return this;
	}

	/**
	 * 接收消息字符串,如果消息为hello_sub则为pub端探测sub端是否连接的消息，需单独处理
	 * 
	 * @return
	 * @author zh_ch
	 * @date 2014-12-26 上午11:50:38
	 */
	public String recvStr() {
		String rev = sub.recvStr();
		if (rev.startsWith(ZMQConst.TOPIC_HELLO)) {
			return handleDetectMsg(rev);
		}
		return rev;
	}

	/**
	 * 处理pub端探测消息私有方法
	 * 
	 * @param str
	 * @return
	 * @author zh_ch
	 * @date 2014-12-27 上午9:51:39
	 */
	private String handleDetectMsg(String str) {
		String addr = AplusStringUtils.parseStr(str, ZMQConst.SEPERATOR, 1);
		req.connect(addr);
		String msg = ZMQConst.TOPIC_READY + ZMQConst.SEPERATOR
				+ this.hashCode();
		req.send(msg);
		req.recvStr();
		req.disconnect(addr);
		return null;
	}

	/**
	 * 销毁上下文
	 * 
	 * @author zh_ch
	 * @date 2014-12-26 上午11:51:26
	 */
	public void destroy() {
		sub.close();
		req.close();
		ctx.term();
	}

	/**
	 * 线程中启动pub-sub代理
	 * 
	 * @author zh_ch
	 * @date 2014-12-25 下午9:10:41
	 */
	public void initAndRunPubSubProxy() {
		if (StringUtils.isNotBlank(topicConf.getFrontend())
				&& StringUtils.isNotBlank(topicConf.getBackend())) {
			new Thread(new PubSubProxy(ctx, topicConf)).start();
		}
	}

	/**
	 * 检查pub/sub proxy后端地址是否配置
	 * 
	 * @author zh_ch
	 * @date 2014-12-27 下午4:24:52
	 */
	private void checkAddrForSub() {
		if (StringUtils.isBlank(topicConf.getBackend())) {
			ZMQException.throwException(ZMQException.PUSH_RESPEND_NULL);
		}
	}
	
	/**
	 * 设置接收消息有效时间，过期则receive null。
	 * @param millisecond
	 */
	public void setTimeout(int millisecond) {
		sub.setReceiveTimeOut(millisecond);
	}
}

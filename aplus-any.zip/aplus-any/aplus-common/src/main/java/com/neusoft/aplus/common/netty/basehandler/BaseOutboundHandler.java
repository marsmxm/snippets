package com.neusoft.aplus.common.netty.basehandler;
/**
 * @author zh_ch
 * @date 2015-2-5 上午9:57:50
 */
public class BaseOutboundHandler {

}

package com.neusoft.aplus.common.zmq.client.api;

/**
 * Zookeeper监听处理接口，当监听的服务出现变化时进行对应处理
 */
public interface IProcessHandler {

	/**
	 * 服务端主节点消失的处理函数
	 * 
	 * @author MaHan
	 * @date 2015年5月27日
	 */
	public void onMasterMissing();

	/**
	 * 服务端有新主出现的处理函数
	 * 
	 * @author MaHan
	 * @date 2015年5月27日
	 */
	public void onMasterSelected(String data);

}

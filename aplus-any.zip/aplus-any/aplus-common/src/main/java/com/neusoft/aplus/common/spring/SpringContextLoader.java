package com.neusoft.aplus.common.spring;

import com.google.common.collect.Lists;
import com.neusoft.aplus.common.util.FileUtil;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Spring容器加载类，用于初始化Spring容器
 *
 * @author li.hzh
 * @date 2015-05-07 17:53
 */
public class SpringContextLoader {

	private static Logger log = LoggerFactory.getLogger(SpringContextLoader.class);

	private static String SPRING_PATH = File.separator.concat("spring");
	private static String SPRING_FILE_PREFIX = "applicationContext";

	public static void load() {
		load(null);
	}
	
	public static void load(List<String> filterList) {
		load(filterList, null);
	}
	
	public static void load(List<String> filterList, String springDir) {
		String springPath = null;
		if (StringUtils.isNotBlank(springDir)) {
			springPath = springDir;
		} else {
			springPath = FileUtil.getRepositoryPath(SPRING_PATH);
		}
		File dir = new File(springPath);
		List<String> springFiles = new ArrayList<String>(0);
		FileUtil.filterFile(dir, springFiles, filterList, SPRING_FILE_PREFIX, FileUtil.XML_FILE_SUFFIX);
		if (springFiles.isEmpty()) {
			log.warn("[{}]下没有发现spring配置文件。", springPath);
			return;
		}
		String[] springFileArray = convertToSpringFilePathArray(springFiles);
		log.debug("最终加载的spring配置文件：" + springFiles);
		ApplicationContextFactory.initialize(springFileArray);
	}


	/**
	 * 转换成Spring认识的绝对路径格式，兼容linux、windows、macos系统
	 *
	 * @param files
	 *
	 * @author li.hzh
	 * @date 2015-04-15 17:54:06
	 */
	private static String[] convertToSpringFilePathArray(List<String> files) {
		String[] springConfigFiles = new String[files.size()];
		for (int i = 0; i < files.size(); i++) {
			String springFilePath = "file:" + files.get(i);
			springConfigFiles[i] = springFilePath;
		}
		return springConfigFiles;
	}

}

package com.neusoft.aplus.common.spring;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * Spring文件加载类
 * 
 * @author WanWei
 * @date 2014-6-24 下午5:03:50
 */
public class ApplicationContextFactory {

	private static final Log log = LogFactory
			.getLog(ApplicationContextFactory.class);
	private static ApplicationContext context = null;

	/**
	 * 通过文件系统加载器加载Spring配置文件
	 * 
	 * @param files
	 * @author WanWei
	 * @date 2014-6-24 下午5:06:15
	 */
	public static void initialize(String[] files) {
		if (files != null) {
			context = new FileSystemXmlApplicationContext(files);
		}
	}

	/**
	 * 根据指定的注入类的类型获取该类被Spring管理的实例
	 * 
	 * @param type
	 * @return
	 * @author WanWei
	 * @date 2014-6-24 下午5:07:43
	 */
	public static <T> T getBean(Class<T> type) {
		if (context == null) {
			log.warn("Spring context has not bean initilaized!");
			return null;
		}
		return context.getBean(type);
	}

	/**
	 * 根据指定的注入类的Id，获取该类被Spring管理的实例
	 * 
	 * @param beanId
	 * @param requiredType
	 * @return
	 * @author WanWei
	 * @date 2014-6-24 下午5:08:16
	 */
	public static <T> T getBean(String beanId, Class<T> requiredType) {
		if (context == null) {
			log.warn("Spring context has not bean initilaized!");
			return null;
		}
		return context.getBean(beanId, requiredType);
	}

	/**
	 * 根据指定的注入类的Id，获取该类被Spring管理的实例，未添加泛型
	 * 
	 * @param beanId
	 * @return
	 * @author WanWei
	 * @date 2014-6-24 下午5:08:31
	 */
	public static Object getBean(String beanId) {
		if (context == null) {
			log.warn("Spring context has not bean initilaized!");
			return null;
		}
		return context.getBean(beanId);
	}
	
	/**
	 * @Description: 获取同一类的bean
	 * @author lu.z
	 * @date 2015年4月20日 下午3:57:41 
	 * @param @param type
	 * @param @param includeNonSingletons
	 * @param @param allowEagerInit
	 * @param @return
	 * @return Map<String,T>
	 * @throws
	 */
	public static <T> Map<String, T> getBeansOfType(Class<T> type, boolean includeNonSingletons, boolean allowEagerInit){
		if (context == null) {
			log.warn("Spring context has not bean initilaized!");
			return null;
		}
		return context.getBeansOfType(type, includeNonSingletons, allowEagerInit);
	}
}

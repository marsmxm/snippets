package com.neusoft.aplus.common.cache.impl;


import java.util.List;

import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.cache.api.CacheService;
import com.neusoft.aplus.common.cache.api.DCacheService;
import com.neusoft.aplus.common.util.JSONUtil;

public class CacheServiceImpl implements CacheService {
	
	private DCacheService dcs;
	
	public void setDcs(DCacheService dcs) {
		this.dcs = dcs;
	}

	@Override
	public String[] getAllCacheNames() {
		return dcs.getAllCacheNames();
	}

	@Override
	public List<Object> getKeys(String cacheName) {
		return dcs.getKeys(cacheName);
	}

	@Override
	public boolean isInCache(String cacheName, String key) {
		return dcs.isInCache(cacheName, key);
	}

	@Override
	public void remove(String cacheName, String key) {
		dcs.remove(cacheName, key);
	}

	@Override
	public Object get(String cacheName, String key) {
		return dcs.get(cacheName, key);
	}

	@Override
	public void put(String cacheName, String key, Object value) {
		dcs.put(cacheName, key, value);
	}

	@Override
	public void putObject(String cacheName, String key, Object value) {
		String jsonValue = JSONUtil.getJsonString(value);
		dcs.put(cacheName, key, jsonValue);
	}

	@Override
	public <T> T getSimpleObject(String cacheName, String key, Class<T> clazz) {
		String jsonValue = (String) dcs.get(cacheName, key);
		T value = JSONUtil.getSimpleObject(jsonValue, clazz);
		return value;
	}

	@Override
	public <T> T getComplexObject(String cacheName, String key,	TypeReference<T> type) {
		String jsonValue = (String) dcs.get(cacheName, key);
		T value = JSONUtil.getComplexObject(jsonValue, type);
		return value;
	}
	
}


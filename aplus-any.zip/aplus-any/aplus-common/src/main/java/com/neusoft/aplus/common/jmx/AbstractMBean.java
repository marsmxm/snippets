package com.neusoft.aplus.common.jmx;

import java.lang.management.ManagementFactory;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;


/**
 * JMX管理实现类的基类，默认会注册到JConsole服务中去
 * TODO HTTP服务会在自监控组件中做出来
 * 
 * @author WanWei
 * @date 2014-7-28 下午4:24:17
 */
public abstract class AbstractMBean implements BeanFactoryPostProcessor {
	
	//默认JMX服务的名称
	public final static String DEFAULT_JMX_SERVICE_NAME = "Neusoft DCIM";
	
	public abstract String getMBeanName();
	
	public abstract Object getCurrentMBean();
	
	private static Logger log = Logger.getLogger(AbstractMBean.class);
			
	public void postProcessBeanFactory(ConfigurableListableBeanFactory arg0)
			throws BeansException {
		try{
			//将jmx管理器注册至系统服务
			MBeanServer server = ManagementFactory.getPlatformMBeanServer();
			String serviceName = DEFAULT_JMX_SERVICE_NAME;//暂时不用做成可配置
	        String mbeanName = getMBeanName();
	        
	        if((mbeanName == null) || (mbeanName.isEmpty())){
	        	if(getCurrentMBean() == null){
	        		log.error("JMX管理类未实现[AbstractMBean getCurrentMBean()]方法，JMX服务无法注册");
	        		System.exit(1);//直接退出，帮助纠正错误
	        	}
	        	mbeanName = getCurrentMBean().getClass().getName();
	        }
			ObjectName name = new ObjectName(serviceName + ":type=" + mbeanName);
	        server.registerMBean(getCurrentMBean(), name);
		}catch(Exception e){
			log.error("JMX服务注册失败, 系统自监控服务无法启动", e);
			System.exit(1);//直接退出，帮助纠正错误
		}
	}

}

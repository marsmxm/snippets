package com.neusoft.aplus.common.zmq.biz.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.neusoft.aplus.common.db.AbstractHibernateDao;
import com.neusoft.aplus.common.zmq.biz.dao.JMSMsgDao;
import com.neusoft.aplus.model.jms.JMSMessageEntity;

@Repository
public class JMSMsgDaoImpl extends AbstractHibernateDao<JMSMessageEntity>
		implements JMSMsgDao {

	@SuppressWarnings("unchecked")
	@Override
	public List<JMSMessageEntity> listAll() {
		return createQuery("from JMSMessageEntity ").list();
	}

	@Override
	public String addMsg(JMSMessageEntity msgEntity) {
		save(msgEntity);
		return msgEntity.getId();
	}

	@Override
	public void removeMsg(String id) {
		String hql = "delete JMSMessageEntity jms where jms.id = ?";
		createQuery(hql, id).executeUpdate();
	}

}

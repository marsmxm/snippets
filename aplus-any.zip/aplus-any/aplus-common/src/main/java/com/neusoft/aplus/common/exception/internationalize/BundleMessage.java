package com.neusoft.aplus.common.exception.internationalize;

import java.io.UnsupportedEncodingException;
import java.text.MessageFormat;

import com.neusoft.aplus.common.exception.RestException;

/**
 * 取得指定信息
 * 
 * @author guo.tc
 * @date 2014-6-23 下午3:03:58
 */
public class BundleMessage {

	/**
	 * 取得指定的错误信息
	 * 
	 * @param bundleHandle
	 * @param name
	 * @param values
	 * @return
	 * @author guo.tc
	 * @throws UnsupportedEncodingException
	 * @date 2014-6-24 下午4:31:03
	 */
	public static String getMessage(String bundleKey, String name,
			Object values[]) {
		String mainErrorMessage = null;
		try {
			mainErrorMessage = new String(BundleHandler.getString(bundleKey,
					name).getBytes("ISO-8859-1"), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			String [] params ={bundleKey,name}; 
			RestException.throwException(RestException.BUNDLEMESSAGE_ENCODING_ERROR, 
					e, params, null);
		}
		if (values == null) {
			return mainErrorMessage;
		} else {
			MessageFormat format = new MessageFormat(mainErrorMessage);
			return format.format(((Object) (values)));
		}
	}
}

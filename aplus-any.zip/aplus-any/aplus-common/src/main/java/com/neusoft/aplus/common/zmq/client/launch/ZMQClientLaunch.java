//package com.neusoft.aplus.common.zmq.client.launch;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import com.neusoft.aplus.common.config.ZMQConfig;
//import com.neusoft.aplus.common.spring.ApplicationContextFactory;
//
//public class ZMQClientLaunch implements Runnable {
//
//	@SuppressWarnings("unchecked")
//	@Override
//	public void run() {
//		Map<String, String> configMap = (HashMap<String, String>) ApplicationContextFactory
//				.getBean("zmqClientConfig");
//		ZkClient zkClient = new ZkClient(
//				configMap.get(ZMQConfig.ZOOKEEPER_ADDRESS));
//		//zkClient.addHandler(new ClientLaunchHandler());
//		try {
//			zkClient.run();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
//}

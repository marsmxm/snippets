package com.neusoft.aplus.common.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;

/**
 * 与类，反射相关的工具类
 * 
 * @author Mu Xian Ming
 * @date 2015年1月9日 上午10:23:37
 */
public class ClassUtil {
	/**
	 * 得到一个类的所有常量的值
	 * 
	 * @param klass
	 *            常量值所属的类
	 * @return 包含所有常量值的数组
	 * @author Mu Xian Ming
	 * @date 2015年1月9日 下午4:28:41
	 */
	public static Object[] getAllConstValues(Class<?> klass) {
		Field[] fields = klass.getDeclaredFields();
		List<Object> result = new ArrayList<Object>();
		for (Field f : fields) {
			if (isConstStyle(f.getName())) {
				try {
					result.add(f.get(null));
				} catch (NullPointerException e) {
					// it's not a contant value, just continue
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
			}
		}

		return result.toArray();
	}

	/**
	 * 判断某个类里是否有某个常量值
	 * 
	 * @param klass
	 *            要判断的类
	 * @param value
	 *            要判断的值
	 * @return 有true，没有false
	 * @author Mu Xian Ming
	 * @date 2015年1月9日 下午4:30:50
	 */
	public static boolean hasConstValue(Class<?> klass, Object value) {
		Object[] values = getAllConstValues(klass);
		Arrays.sort(values);
		return Arrays.binarySearch(values, value) >= 0;
	}

	/**
	 * 判断字符串是否只含有下划线和大写字母
	 * 
	 * @param s
	 * @return
	 * @author Mu Xian Ming
	 * @date 2015年1月9日 下午4:45:01
	 */
	private static boolean isConstStyle(String s) {
		return StringUtils.isAllUpperCase(s.replaceAll("_", ""));
	}
}

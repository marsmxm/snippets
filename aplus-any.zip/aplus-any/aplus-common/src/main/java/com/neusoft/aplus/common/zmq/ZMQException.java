package com.neusoft.aplus.common.zmq;

import java.util.Map;

import com.neusoft.aplus.common.exception.AplusException;
import com.neusoft.aplus.common.exception.annotation.MessageCN;
import com.neusoft.aplus.common.exception.annotation.MessageUS;

/**
 * @author zh_ch
 * @date 2015-1-13 上午10:05:04
 */
public class ZMQException extends AplusException {
	private static final long serialVersionUID = 1L;

	//异常码范围800~900
	@MessageCN("代理前端地址为空")
	@MessageUS("Config of proxy frontend is null(empty)")
	public static final String FRONTEND_NULL = createExceptionCode(800);
	
	@MessageCN("发布者响应地址为空")
	@MessageUS("Respend of publisher is null(empty)") 
	public static final String PUB_RESPEND_NULL = createExceptionCode(801);
	
	@MessageCN("代理后端地址为空")
	@MessageUS("Config of proxy backend is null(empty)")
	public static final String BACKEND_NULL = createExceptionCode(802);
	
	@MessageCN("PUSH端推送地址为空")
	@MessageUS("Config of pushend is null(empty)")
	public static final String PUSHEND_NULL = createExceptionCode(803);
	
	@MessageCN("PUSH端的响应地址为空")
	@MessageUS("Respend of pusher is null(empty)")
	public static final String PUSH_RESPEND_NULL = createExceptionCode(804);
	
	@MessageCN("Pull端名字为空")
	@MessageUS("PullName is null(empty)")
	public static final String PULLNAME_NULL = createExceptionCode(805);
	
	@MessageCN("Sub端名字为空")
	@MessageUS("SubName is null(empty)")
	public static final String SUBNAME_NULL = createExceptionCode(806);
	
	public ZMQException(String code, Exception original, Object[] params,
			Map<String, Object> keyPoints) {
		super(code, original, params, keyPoints);	
	}
	
	public static void throwException(String exCode) {
		throwException(exCode, null, null, null);
	}
	
	public static void throwException(String exCode, Exception original,
			Object[] params, Map<String, Object> keyPoints) {
		new ZMQException(exCode, original, params, keyPoints).throwEx();
	}
	
	private static String createExceptionCode(int code) {
		return getFormatedNumber(ID_PLATFORM, code);
	}
}

package com.neusoft.aplus.common.netty.message;


/**
 * @author wuhao
 * @date 2015-6-23 下午4:38:23
 */
public class ControlReply extends Reply {
	private String timeStamp;

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
}

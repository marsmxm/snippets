package com.neusoft.aplus.common.netty.message;

import java.util.List;

import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusControlData;
import com.neusoft.aplus.model.bizentity.AplusDevice;

/**
 * @author zh_ch
 * @date 2015年6月23日 下午1:32:52
 */
public class ControlCommand extends AbstractCommand {
	private final String commandKey = "controlCommand";
	private AplusDevice aplusDevice;
	private AplusConnection aplusConn;
	private List<AplusControlData> controlDataList;
	private String timeStamp;//当前请求的唯一值，区分不同请求用，在RestAction赋值。

	public ControlCommand() {
	}

	public ControlCommand(AplusDevice aplusDevice, AplusConnection aplusConn,
			List<AplusControlData> controlDataList) {
		this.aplusConn = aplusConn;
		this.aplusDevice = aplusDevice;
		this.controlDataList = controlDataList;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	public AplusDevice getAplusDevice() {
		return aplusDevice;
	}

	public void setAplusDevice(AplusDevice aplusDevice) {
		this.aplusDevice = aplusDevice;
	}

	public AplusConnection getAplusConn() {
		return aplusConn;
	}

	public void setAplusConn(AplusConnection aplusConn) {
		this.aplusConn = aplusConn;
	}

	public String getCommandkey() {
		return commandKey;
	}

	public List<AplusControlData> getControlDataList() {
		return controlDataList;
	}

	public void setControlDataList(List<AplusControlData> controlDataList) {
		this.controlDataList = controlDataList;
	}
}

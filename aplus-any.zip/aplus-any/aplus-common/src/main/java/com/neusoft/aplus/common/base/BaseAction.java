package com.neusoft.aplus.common.base;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.restlet.Context;
import org.restlet.data.ChallengeResponse;
import org.restlet.data.CharacterSet;
import org.restlet.data.Language;
import org.restlet.data.MediaType;
import org.restlet.data.Reference;
import org.restlet.data.Status;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.ObjectRepresentation;
import org.restlet.representation.Representation;
import org.restlet.resource.Delete;
import org.restlet.resource.Get;
import org.restlet.resource.Post;
import org.restlet.resource.Put;
import org.restlet.resource.ResourceException;
import org.restlet.resource.ServerResource;

import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.exception.AplusException;
import com.neusoft.aplus.common.util.JSONUtil;

/**
 * 本类提供对REST中ServerResource的封装
 * 
 * @author WanWei
 * @date 2014-6-6 下午3:58:21
 */
public abstract class BaseAction extends ServerResource {

	private Map<String, Object> requestAttributes = null;

	@Override
	public Map<String, Object> getRequestAttributes() {
		if (requestAttributes == null) {
			requestAttributes = new HashMap<String, Object>();
			Map<String, Object> map = super.getRequestAttributes();
			for (String key : map.keySet()) {
				requestAttributes.put(key,
						Reference.decode(map.get(key).toString()));
			}
		}

		return requestAttributes;
	}

	/**
	 * 获取get参数
	 * @return
	 * @author zh_ch
	 * @date 2015年4月14日 下午4:47:01
	 */
	public Map<String, String> getRequestParameters() {
		return getRequest().getResourceRef().getQueryAsForm(Boolean.TRUE)
				.getValuesMap();
	}

	@Override
	public void doInit() {

	}

	@Override
	public Context getContext() {
		return getApplication().getContext();
	}

	public String getUserId() {
		String userId = null;
		ChallengeResponse challengeRes = getRequest().getChallengeResponse();
		if (challengeRes != null) {
			userId = challengeRes.getIdentifier();
		}
		return userId;
	}

	/**
	 * 处理Post请求 不要在子类中直接使用
	 * 
	 * @param entity
	 * @throws ResourceException
	 * @author WanWei
	 * @date 2014-7-18 下午2:37:22
	 */
	@Post
	public void doPost(Representation entity) throws ResourceException {
		try {
			acceptRepresentation(entity);
		} catch (AplusException e) {
			handleException(e);
		}
	}

	/**
	 * 处理get请求 不要在子类中直接使用
	 * 
	 * @return
	 * @throws ResourceException
	 * @author WanWei
	 * @date 2014-7-18 下午2:37:48
	 */
	@Get
	public Representation doGet() throws ResourceException {
		try {
			Representation rep = represent();
			return rep;
		} catch (AplusException e) {
			// 捕获到AplusException后直接返回
			return new ObjectRepresentation<Serializable>(e);
		}
	}

	/**
	 * 处理delete请求 不要在子类中直接使用
	 * 
	 * @throws ResourceException
	 * @author WanWei
	 * @date 2014-7-18 下午2:39:57
	 */
	@Delete
	public void doDelete() throws ResourceException {
		try {
			removeRepresentations();
		} catch (AplusException e) {
			handleException(e);
		}
	}

	/**
	 * 处理put请求 不要在子类中直接使用
	 * 
	 * @throws ResourceException
	 * @author WanWei
	 * @date 2014-7-18 下午2:39:57
	 */
	@Put
	public void doPut(Representation entity) throws ResourceException {
		try {
			storeRepresentation(entity);
		} catch (AplusException e) {
			handleException(e);
		}
	}

	/**
	 * 创建可用作rest传递的Object实例
	 * 
	 * @param serializable
	 * @return
	 * @author WanWei
	 * @date 2015-3-18 下午5:27:32
	 */
	public ObjectRepresentation<Serializable> createObjectRepresentation(
			Object serializable) {
		ObjectRepresentation<Serializable> representation = new ObjectRepresentation<Serializable>(
				(Serializable) serializable);
		representation.getLanguages().add(Language.ALL);
		representation.setCharacterSet(CharacterSet.UTF_8);
		return representation;
	}

	/**
	 * 创建可用作rest传递的Json实例
	 * 
	 * @param jsonString
	 * @return
	 * @author zh_ch
	 * @date 2015年4月2日 上午9:45:45
	 */
	public JsonRepresentation createJsonRepresentation(String jsonString) {
		JsonRepresentation representation = new JsonRepresentation(jsonString);
		representation.getLanguages().add(Language.ALL);
		representation.setCharacterSet(CharacterSet.UTF_8);
		return representation;
	}

	/**
	 * 获取非集合非Map对象 如Class A
	 * 
	 * @param entity
	 * @param T
	 * @return
	 * @author WanWei
	 * @date 2015-3-19 下午8:44:23
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getObjectFromRepresentation(Representation entity,
			Class<T> clazz) throws Exception {
		entity.setCharacterSet(CharacterSet.UTF_8);
		// 如果数据类型为JSON
		if (MediaType.APPLICATION_JSON.isCompatible(entity.getMediaType())) {
			JsonRepresentation jsonRep = new JsonRepresentation(entity);
			JSONObject jsonObj = jsonRep.getJsonObject();
			return JSONUtil.getSimpleObject(jsonObj.toString(), clazz);
		} else if (MediaType.APPLICATION_XML
				.isCompatible(entity.getMediaType())// 如果数据类型为XML
				|| MediaType.TEXT_XML.isCompatible(entity.getMediaType())) {
			// TODO
			return null;
		} else {// 数据类型为Object
			ObjectRepresentation<?> obj = new ObjectRepresentation<Serializable>(
					entity);
			return (T) obj.getObject();
		}
	}

	/**
	 * 获取List类型对象
	 * 
	 * @param entity
	 * @param T
	 * @return
	 * @throws Exception
	 * @author WanWei
	 * @date 2015-3-19 下午8:56:49
	 */
	@SuppressWarnings("unchecked")
	public static <T> List<T> getObjectsFromRepresentation(
			Representation entity, Class<T> clazz) throws Exception {
		entity.setCharacterSet(CharacterSet.UTF_8);
		// 如果数据类型为JSON
		if (MediaType.APPLICATION_JSON.isCompatible(entity.getMediaType())) {
			JsonRepresentation jsonRep = new JsonRepresentation(entity);
			JSONArray jsonObj = jsonRep.getJsonArray();
			return JSONUtil.getObjectList(jsonObj.toString(), clazz);
		} else if (MediaType.APPLICATION_XML
				.isCompatible(entity.getMediaType())// 如果数据类型为XML
				|| MediaType.TEXT_XML.isCompatible(entity.getMediaType())) {
			// TODO
			return null;
		} else {// 数据类型为Object
			ObjectRepresentation<?> obj = new ObjectRepresentation<Serializable>(
					entity);
			return (List<T>) obj.getObject();
		}
	}

	/**
	 * 获取Map类型对象
	 * 
	 * @param entity
	 * @param T
	 *            非集合类
	 * @param E
	 *            非集合类
	 * @return
	 * @throws Exception
	 * @author WanWei
	 * @date 2015-3-19 下午9:03:52
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getObjectsFromRepresentation(Representation entity,
			TypeReference<T> type) throws Exception {
		entity.setCharacterSet(CharacterSet.UTF_8);
		String jsonText = entity.getText();//获取text，用于多类型解析，object和array
		// 如果数据类型为JSON
		if (MediaType.APPLICATION_JSON.isCompatible(entity.getMediaType())) {
			JsonRepresentation jsonRep = new JsonRepresentation(jsonText);
			String text = null;
			try {
				JSONObject jsonObj = jsonRep.getJsonObject();
				text = jsonObj.toString();
			} catch (Exception ex) {
				jsonRep = new JsonRepresentation(jsonText);
				JSONArray jsonObj = jsonRep.getJsonArray();
				text = jsonObj.toString();
			}
			return JSONUtil.getComplexObject(text, type);
		} else if (MediaType.APPLICATION_XML
				.isCompatible(entity.getMediaType())// 如果数据类型为XML
				|| MediaType.TEXT_XML.isCompatible(entity.getMediaType())) {
			// TODO
			return null;
		} else {// 数据类型为Object
			ObjectRepresentation<?> obj = new ObjectRepresentation<Serializable>(
					entity);
			return (T) obj.getObject();
		}
	}

	/**
	 * 在没有任何错误的情况下 设置返回给客户端的数据
	 * 
	 * @param serializable
	 * @author WanWei
	 * @date 2015-3-18 下午5:31:21
	 */
	public void sendResponse(Object serializable) {
		ObjectRepresentation<Serializable> representation = createObjectRepresentation(serializable);
		representation.getLanguages().add(Language.ALL);
		representation.setCharacterSet(CharacterSet.UTF_8);
		getResponse().setEntity(representation);
		sendSuccess();
	}

	/**
	 * 返回给客户端json格式的数据，通过response.getEntityAsText可获取Json格式的字符串
	 * 
	 * @param jsonString
	 * @author zh_ch
	 * @date 2015年4月2日 上午9:48:14
	 */
	public void sendJsonResponse(String jsonString) {
		JsonRepresentation representation = createJsonRepresentation(jsonString);
		getResponse().setEntity(representation);
		sendSuccess();
	}

	/**
	 * 发送异常消息
	 * 
	 * @param jsonString
	 * @author zh_ch
	 * @date 2015年4月9日 下午2:39:27
	 */
	public void sendExceptionObjectResponse(Object serializable) {
		ObjectRepresentation<Serializable> representation = createObjectRepresentation(serializable);
		getResponse().setEntity(representation);
		sendServerError();
	}

	/**
	 * 无需返回值时 返回执行成功的状态
	 * 
	 * @param serializable
	 * @author WanWei
	 * @date 2015-3-18 下午5:31:21
	 */
	public void sendSuccess() {
		getResponse().setStatus(Status.SUCCESS_OK);
	}
	
	/**
	 * 发送服务器错误
	 * 
	 * @author zh_ch
	 * @date 2015年4月9日 下午2:39:45
	 */
	public void sendServerError() {
		getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
	}

	/**
	 * 捕获到AplusException后需要反馈给调用者
	 * 
	 * @param aplusException
	 * @author WanWei
	 * @date 2014-7-18 下午2:34:55
	 */
	private void handleException(AplusException aplusException) {
		ObjectRepresentation<Serializable> representation = createObjectRepresentation(aplusException);
		getResponse().setEntity(representation);
		// 是否用了这个方法就无须把异常给送回去了？ add by WanWei 2015-03-18 17:44:34 TODO 需要验证
		getResponse().setStatus(Status.SERVER_ERROR_INTERNAL, aplusException);
	}

	/**
	 * 子类中处理客户端Post请求的方法
	 * 
	 * @param entity
	 * @author WanWei
	 * @date 2014-12-5 下午7:48:43
	 */
	public abstract void acceptRepresentation(Representation entity);

	/**
	 * 子类中处理客户端Get请求的方法
	 * 
	 * @return
	 * @author WanWei
	 * @date 2014-12-5 下午7:49:20
	 */
	public abstract Representation represent();

	/**
	 * 子类中处理客户端Delete请求的方法
	 * 
	 * @author WanWei
	 * @date 2014-12-5 下午7:49:54
	 */
	public abstract void removeRepresentations();

	/**
	 * 子类中处理客户端Put请求的方法
	 * 
	 * @param entity
	 * @author WanWei
	 * @date 2014-12-5 下午7:50:24
	 */
	public abstract void storeRepresentation(Representation entity);

}

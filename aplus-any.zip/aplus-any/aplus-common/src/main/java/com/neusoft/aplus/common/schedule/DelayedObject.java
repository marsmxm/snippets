package com.neusoft.aplus.common.schedule;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

/**
 * 在延迟一段时间后可用的Object
 * 
 * 实现了java.util.concurrent.Delayed接口，可作为DelayQueue的元素
 * 
 * @author Mu Xian Ming
 * @date 2015年3月11日 下午1:32:26
 */
public class DelayedObject<T> implements Delayed {
	private final String id; // 用于批量处理DelayQueue中的任务
	private final T data;
	private final long createTime; // 实例的创建时间
	private final long delayTimeMillis; // 该实体变为可用前的延时
	private long availableTimeMillis;
	
	/**
	 * 
	 * @param data 实际的数据
	 * @param delay data可用前的延迟时间
	 * @param unit 延迟的时间单位
	 * @param id 用于批量管理DelayQueue中的DelayedObject
	 */
	public DelayedObject(T data, long delay, TimeUnit unit, String id) {
		this.data = data;
		this.delayTimeMillis = TimeUnit.MILLISECONDS.convert(delay, unit);
		this.availableTimeMillis = System.currentTimeMillis() + delayTimeMillis;
		this.id = id;
		this.createTime = System.currentTimeMillis();
	}
	
	public String getID() {
		return id;
	}
	
	public T getData() {
		return data;
	}
	
	public long getAge(long currentTime) {
		return currentTime - createTime;
	}
	
	/**
	 * 将delay重置为初始值
	 * 
	 * 用于实现循环任务
	 * 
	 * @return delay重置后的该实例
	 */
	public DelayedObject<T> reset() {
		this.availableTimeMillis = System.currentTimeMillis() + delayTimeMillis;
		return this;
	}
	
	@Override
	public long getDelay(TimeUnit unit) {
		long diff = availableTimeMillis - System.currentTimeMillis();
		return unit.convert(diff, TimeUnit.MILLISECONDS);
	}

	@Override
	public int compareTo(Delayed o) {
		if (this.availableTimeMillis < ((DelayedObject<?>) o).availableTimeMillis) {
			return -1;
		}
		if (this.availableTimeMillis > ((DelayedObject<?>) o).availableTimeMillis) {
			return 1;
		}
		return 0;
	}

	@Override
	public String toString() {
		return "new " + getClass().getName() 
				+ "(data=" + data.toString() + ", availableTime=" + availableTimeMillis+ ")"; 
	}

}

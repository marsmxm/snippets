package com.neusoft.aplus.common.schedule;
/**
 * @author Mu Xian Ming
 * @date 2015年3月11日 下午3:00:04
 */
public interface ITaskHandler<T> {
	void handle(T task);
}

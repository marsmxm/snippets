package com.neusoft.aplus.common.zmq.client.launch;

import com.neusoft.aplus.common.zmq.client.api.IProcessHandler;
import com.neusoft.aplus.common.zmq.client.connector.ConnectorManager;

/**
 * Zookeeper监听接口实现类
 */
public class ClientLaunchHandler implements IProcessHandler {

	@Override
	public void onMasterMissing() {
		ConnectorManager.close();
	}

	@Override
	public void onMasterSelected(String data) {
		ConnectorManager.connect(data);
	}
}

package com.neusoft.aplus.common.netty.message;

import java.util.List;

import com.neusoft.aplus.model.bizentity.AplusMsgAction;

/**
 * 实体入库命令
 * 
 * 由Client端向Server端发送，该对象中不同的Key常量对应了
 * 不同的Entity类型的命令，Server端通过Key来决定如何
 * 处理相应的EntityCommand
 * 
 * EntityCommand中对应的Entity会被转换成JSON字符串，存入
 * entities列表中。如果是更新的命令，则会将更新前后的Entity
 * 分别存入oldEntities和newEntities列表中
 * 
 * @author Mu Xian Ming
 * @date 2015年2月2日 上午10:37:44
 */
public class EntityCommand extends AbstractCommand {
	private AplusMsgAction action;
	private Class<?> entityClass;
	private List<String> entities;
	private List<String> oldEntities; // for update action
	private List<String> newEntities; // for update action

	public AplusMsgAction getAction() {
		return action;
	}

	public void setAction(AplusMsgAction action) {
		this.action = action;
	}

	public Class<?> getEntityClass() {
		return entityClass;
	}

	public void setEntityClass(Class<?> klass) {
		this.entityClass = klass;
	}

	public List<String> getEntities() {
		return entities;
	}

	public void setEntities(List<String> entities) {
		this.entities = entities;
	}

	public List<String> getOldEntities() {
		return oldEntities;
	}

	public void setOldEntities(List<String> oldEntities) {
		this.oldEntities = oldEntities;
	}

	public List<String> getNewEntities() {
		return newEntities;
	}

	public void setNewEntities(List<String> newEntities) {
		this.newEntities = newEntities;
	}

}

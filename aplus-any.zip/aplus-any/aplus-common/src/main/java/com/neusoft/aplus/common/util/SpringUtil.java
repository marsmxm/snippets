package com.neusoft.aplus.common.util;

import java.util.Map;

import com.neusoft.aplus.common.spring.ApplicationContextFactory;

/**
 * @author zh_ch
 * @date 2015年5月6日 上午9:07:03
 */
public class SpringUtil {
	public static <T> T getBean(Class<T> T) {
		return ApplicationContextFactory.getBean(T);
	}

	public static <T> T getBean(String beanId, Class<T> requiredType) {
		return ApplicationContextFactory.getBean(beanId, requiredType);
	}

	public static Object getBean(String beanId) {
		return ApplicationContextFactory.getBean(beanId);
	}

	public static <T> Map<String, T> getBeansOfType(Class<T> type,
			boolean includeNonSingletons, boolean allowEagerInit) {
		return ApplicationContextFactory.getBeansOfType(type,
				includeNonSingletons, allowEagerInit);
	}
}

package com.neusoft.aplus.common.cache.api;

import java.util.List;

import com.alibaba.fastjson.TypeReference;

/**
 * 项目中实际应用时调用的缓存接口
 * @author MaHan
 *
 * @date 2015年4月17日
 */
public interface CacheService {
	/**
	 * 获取缓存服务器中的存在的缓存名称列表
	 * 
	 * @return
	 * @author MaHan
	 * @date 2015年4月16日
	 */
	public String[] getAllCacheNames();

	/**
	 * 获取指定cacheName下的所有key值
	 * 
	 * @param cacheName
	 * @return
	 * @author MaHan
	 * @date 2015年4月16日
	 */
	public List<Object> getKeys(String cacheName);

	/**
	 * 判断某键值为key的元素 是否存在指定的缓存中
	 * 
	 * @param cacheName
	 * @param key
	 * @return
	 * @author MaHan
	 * @date 2015年4月16日
	 */
	public boolean isInCache(String cacheName, String key);

	/**
	 * 从某一缓存中移除指定key值的缓存内容
	 * 
	 * @param cacheName
	 * @param key
	 * @author MaHan
	 * @date 2015年4月16日
	 */
	public void remove(String cacheName, String key);
	
	/**
	 * 将某一键值对存入指定缓存
	 * 若使用此方法存入一个非基本类型的JavaBean对象
	 * 该对象需要存在于model工程下，否则将出错
	 * 
	 * @param cacheName
	 * @param key
	 * @param value
	 * @author MaHan
	 * @date 2015年4月16日
	 */
	public void put(String cacheName, String key, Object value);
	/**
	 * 通过指定键值key从某缓存中取对应的缓存值,可能返回null
	 * 若使用此方法获取一个非基本类型的JavaBean对象
	 * 该对象需要存在于model工程下，否则将出错
	 *  
	 * @param cacheName
	 * @param key
	 * @return
	 * @author MaHan
	 * @date 2015年4月16日
	 */
	public Object get(String cacheName, String key);
	/**
	 * 将某一键值对存入指定缓存,
	 * 若存入一个非基本类型的JavaBean对象
	 * 此方法会将该对象转换为json串后再存入
	 * 
	 * @param cacheName
	 * @param key
	 * @param value
	 * @author MaHan
	 * @date 2015年4月16日
	 */
	public void putObject(String cacheName, String key, Object value);
	/**
	 * 通过指定键值key从某缓存中取对应的缓存值,可能返回null
	 * 此方法于putObject方法对应，取出以json串形式存入的值
	 * clazz类  需要有一个无参的构造方法
	 * 
	 * @param cacheName
	 * @param key
	 * @param clazz
	 * @return
	 * @author MaHan
	 * @date 2015年4月16日
	 */
	public <T> T getSimpleObject(String cacheName, String key, Class<T> clazz);
	
	/**
	 * 通过指定键值key从某缓存中取对应的缓存值,可能返回null
	 * 此方法于putObject方法对应，取出以json串形式存入的值
	 * 用于取复杂类型数据 如List<Map<String, String>>
	 * 使用时 参数如：new TypeReference<List<Map<String, String>>>(){}
	 * 
	 * @param cacheName
	 * @param key
	 * @param type
	 * @return
	 * @author MaHan
	 * @date 2015年4月20日
	 */
	public <T> T getComplexObject(String cacheName,String key,TypeReference<T> type);

}

package com.neusoft.aplus.common.netty.message;

import java.util.List;

import com.google.common.base.Objects;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.dbentity.table.AplusCollectTaskEntity;
import com.neusoft.aplus.model.dbentity.table.AplusMetricEntity;

/**
 * 数据采集命令
 * 
 * 由Server端向Client端发送，通过Connection，Device 和Metrics来采集相应的数据
 * 
 * @author Mu Xian Ming
 * @date 2015年2月9日 下午3:28:27
 */
public class DataCollectCommand extends AbstractCommand {
	private static final String COMMAND_KEY = "dataCollectCommand";
	private AplusConnection connection;
	private AplusDevice device;
	private List<String> metrics; // 指标名列表，若为null则采集所有active指标的数据
	private List<AplusMetricEntity> metricEntitys;
	private Boolean isPush; // 是否为推送，是从配置文件读取间隔，否则从plugin脚本读取
	private Boolean isSubSystem = Boolean.FALSE; // 为true时采集端将从metricEntitys读取完整的指标信息
	private Status status;

	public DataCollectCommand() {
	}

	public DataCollectCommand(AplusConnection connection, AplusDevice device,
			Boolean isPush, Boolean isSubSystem, Status status) {
		super();
		this.connection = connection;
		this.device = device;
		this.isPush = isPush;
		this.isSubSystem = isSubSystem;
		this.status = status;
		if (!Objects.equal(null, device)) {
			StringBuffer commandId = new StringBuffer(0);
			commandId.append(device.getFqn()).append("@").append(isPush);
			this.setCommandId(commandId.toString());
		}
	}

	public DataCollectCommand(AplusConnection connection, AplusDevice device,
			List<AplusMetricEntity> metricEntitys, Boolean isPush, Status status) {
		super();
		this.connection = connection;
		this.device = device;
		this.metricEntitys = metricEntitys;
		this.isPush = isPush;
		this.status = status;
		if (!Objects.equal(null, device)) {
			StringBuffer commandId = new StringBuffer(0);
			commandId.append(device.getFqn()).append("@").append(isPush);
			this.setCommandId(commandId.toString());
		}
	}

	public DataCollectCommand(AplusConnection connection, AplusDevice device,
			List<AplusMetricEntity> metricEntitys, Boolean isPush,
			Boolean isSubSystem, Status status) {
		super();
		this.connection = connection;
		this.device = device;
		this.metricEntitys = metricEntitys;
		this.isPush = isPush;
		this.isSubSystem = isSubSystem;
		this.status = status;
		if (!Objects.equal(null, device) && !Objects.equal(null, isPush)) {
			StringBuffer commandId = new StringBuffer(0);
			commandId.append(device.getFqn()).append("@").append(isPush);
			this.setCommandId(commandId.toString());
		}
	}

	public DataCollectCommand(AplusConnection connection, AplusDevice device,
			List<String> metrics, List<AplusMetricEntity> metricEntitys,
			Boolean isPush, Boolean isSubSystem, Status status) {
		super();
		this.connection = connection;
		this.device = device;
		this.metrics = metrics;
		this.metricEntitys = metricEntitys;
		this.isPush = isPush;
		this.isSubSystem = isSubSystem;
		this.status = status;
		if (!Objects.equal(null, device) && !Objects.equal(null, isPush)) {
			StringBuffer commandId = new StringBuffer(0);
			commandId.append(device.getFqn()).append("@").append(isPush);
			this.setCommandId(commandId.toString());
		}
	}

	public AplusConnection getConnection() {
		return connection;
	}

	public void setConnection(AplusConnection conn) {
		this.connection = conn;
	}

	public AplusDevice getDevice() {
		return device;
	}

	public void setDevice(AplusDevice device) {
		this.device = device;
		if (!Objects.equal(null, device) && !Objects.equal(null, isPush)) {
			StringBuffer commandId = new StringBuffer(0);
			commandId.append(device.getFqn()).append("@").append(isPush);
			this.setCommandId(commandId.toString());
		}
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public List<String> getMetrics() {
		return metrics;
	}

	public void setMetrics(List<String> metrics) {
		this.metrics = metrics;
	}

	@Override
	public String getCommandKey() {
		return COMMAND_KEY;
	}

	public List<AplusMetricEntity> getMetricEntitys() {
		return metricEntitys;
	}

	public void setMetricEntitys(List<AplusMetricEntity> metricEntitys) {
		this.metricEntitys = metricEntitys;
	}

	public Boolean getIsSubSystem() {
		return isSubSystem;
	}

	public void setIsSubSystem(Boolean isSubSystem) {
		this.isSubSystem = isSubSystem;
	}

	public Boolean getIsPush() {
		return isPush;
	}

	public void setIsPush(Boolean isPush) {
		this.isPush = isPush;
		if (!Objects.equal(null, device) && !Objects.equal(null, isPush)) {
			StringBuffer commandId = new StringBuffer(0);
			commandId.append(device.getFqn()).append("@").append(isPush);
			this.setCommandId(commandId.toString());
		}
	}

	public AplusCollectTaskEntity toTaskEntity() {
		AplusCollectTaskEntity taskEntity = new AplusCollectTaskEntity();
		taskEntity.setFqn(this.getDevice().getFqn());
		taskEntity.setTaskCmd(JSONUtil.getJsonString(this));
		taskEntity.setTaskId(this.getCommandId());
		taskEntity.setPush(this.getIsPush());
		taskEntity.setSubSystem(this.getIsSubSystem());
		return taskEntity;
	}

	public static enum Status {
		START("开始采集"), UPDATE("采集条件有更新"), STOP("停止采集"), ONCE("采集一次，特指实时数据");

		private String name;

		private Status(String name) {
			this.setName(name);
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public boolean isStart() {
			return this == START;
		}

		public boolean isStop() {
			return this == STOP;
		}

		public boolean isUpdate() {
			return this == UPDATE;
		}

		public boolean isOnce() {
			return this == ONCE;
		}
	}
}

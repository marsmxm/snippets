package com.neusoft.aplus.common.event;

import java.util.List;
import java.util.concurrent.Callable;


/**
 * 事件链接口，自定义事件链需实现此接口
 * @author zh_ch
 * @param <T>
 * @param <T>
 * @date 2014-12-16 下午2:45:17
 */
public abstract class EventChain<T> implements Callable<T> {
	public abstract EventChain<T> addEvent(Event e);
	public abstract EventChain<T> addEvents(Event...es);
	public abstract EventChain<T> addEvents(List<Event> events);
	public abstract void fireEvents(EventChain<T> chain);
	public abstract void fireEvents(Input input, Output output, EventChain<T> chain);
}

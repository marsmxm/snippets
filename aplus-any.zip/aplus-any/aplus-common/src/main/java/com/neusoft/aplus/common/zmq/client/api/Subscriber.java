package com.neusoft.aplus.common.zmq.client.api;

/**
 * 订阅者接口
 */
public interface Subscriber extends Runnable {
}

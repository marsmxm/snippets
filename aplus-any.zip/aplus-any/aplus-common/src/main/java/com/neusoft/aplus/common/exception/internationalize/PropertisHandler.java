package com.neusoft.aplus.common.exception.internationalize;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.neusoft.aplus.common.exception.RestException;

/**
 * 国际化文件的读写
 * 
 * @author guo.tc
 * @date 2014-6-24 下午3:27:29
 */
public class PropertisHandler {
	// 文件夹
	static String filepath = System.getProperty("user.dir")
			+ "/Internationalization";
	static String CNfilepath = filepath + "/aplus-messages_zh_CN.properties";
	static String USfilepath = filepath + "/aplus-messages_en_US.properties";

	private static Properties props_CN = new Properties();
	private static Properties props_US = new Properties();
	private static Logger log = Logger.getLogger(PropertisHandler.class);
	static {
		try {
			Date now = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
			String currenttime = dateFormat.format(now);

			File folder = new File(filepath);
			folder.mkdirs();

			CNfilepath = CNfilepath + "." + currenttime;
			File fileCN = new File(CNfilepath);
			if (!fileCN.exists()) {
				fileCN.createNewFile();
			}
			// else {
			// 读取国际化文件信息
			// props_CN.load(new FileInputStream(CNfilepath));
			// props_CN.store(new FileOutputStream(CNfilepath), "");
			// props_CN.clear();
			// }

			USfilepath = USfilepath + "." + currenttime;
			File fileUS = new File(USfilepath);
			if (!fileUS.exists()) {
				fileUS.createNewFile();
			}
			// else {
			// 读取国际化文件信息
			// props_US.load(new FileInputStream(USfilepath));
			// props_US.store(new FileOutputStream(USfilepath), "");
			// props_US.clear();
			// }

		} catch (FileNotFoundException e) {
			log.error(e.getMessage(), e);
			RestException
					.throwException(
							RestException.CODE_REST_EXCEPTION_FILENOTFOUNDINFO,
							e, null, null);
		} catch (IOException e) {
			log.error(e.getMessage(), e);
			RestException
					.throwException(
							RestException.CODE_REST_EXCEPTION_IOERRORINFO,
							e, null, null);
		}
	}

	/**
	 * 设定中文国际化文件key对应的值
	 * 
	 * @param key
	 * @param value
	 * @author guo.tc
	 * @date 2014-6-24 下午4:29:45
	 */
	public static void setCNValue(String key, String value) {
		if (!value.isEmpty())
			props_CN.setProperty(key, value);
	}

	/**
	 * 设定英文国际化文件key对应的值
	 * 
	 * @param key
	 * @param value
	 * @author guo.tc
	 * @date 2014-6-24 下午4:29:57
	 */
	public static void setUSValue(String key, String value) {
		if (!value.isEmpty())
			props_US.setProperty(key, value);
	}

	/**
	 * 保存数据到文件
	 * 
	 * @author guo.tc
	 * @date 2014-6-24 下午4:30:13
	 */
	public static void propStore() {
		try {
			props_CN.store(new OutputStreamWriter(new FileOutputStream(
					CNfilepath)), "");
			// props_CN.store(new FileOutputStream(CNfilepath), "");
			props_US.store(new FileOutputStream(USfilepath), "");
		} catch (FileNotFoundException e) {
			log.error(e.getMessage(), e);
			RestException
					.throwException(
							RestException.CODE_REST_EXCEPTION_FILENOTFOUNDINFO,
							e, null, null);
		} catch (IOException e) {
			log.error(e.getMessage(), e);
			RestException
					.throwException(
							RestException.CODE_REST_EXCEPTION_IOERRORINFO,
							e, null, null);
		}
	}
}

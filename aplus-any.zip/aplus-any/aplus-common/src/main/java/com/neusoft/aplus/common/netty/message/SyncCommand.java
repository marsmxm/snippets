package com.neusoft.aplus.common.netty.message;

import java.util.List;
import java.util.Map;

/**
 * 同步命令
 * 
 * 当server端更改指标和动作信息时通过此命令将最新指标/动作
 * 推送回采集端
 *
 * @author Mu Xian Ming
 * @date 15-06-03
 */
public class SyncCommand extends AbstractCommand {
	private String deviceType;
	private String version;
	private List<Map<String, Object>> body;

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public List<Map<String, Object>> getBody() {
		return body;
	}

	public void setBody(List<Map<String, Object>> body) {
		this.body = body;
	}
}

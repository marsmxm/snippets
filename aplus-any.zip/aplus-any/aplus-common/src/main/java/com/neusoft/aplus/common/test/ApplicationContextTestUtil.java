package com.neusoft.aplus.common.test;

import java.io.File;

import org.apache.commons.io.FilenameUtils;

import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.common.spring.PathConst;

/**
 * @author zh_ch
 * @date 2015年3月3日 下午4:41:22
 */
public class ApplicationContextTestUtil {

	public static final String FILE_PREFIX = FilenameUtils
			.getFullPath(new File("").getAbsolutePath());
	private static final String[] FILES = { FILE_PREFIX + PathConst.COMMON_PAHT,
			FILE_PREFIX + PathConst.DATASOURCE_PATH,
			FILE_PREFIX + PathConst.PROPERTY_PATH };

	static {
		ApplicationContextFactory.initialize(FILES);
	}

	public static Object getService(String name) {
		return ApplicationContextFactory.getBean(name);
	}
	
	public static <E> E getService(Class<E> klass) {
		return ApplicationContextFactory.getBean(klass);
	}
}

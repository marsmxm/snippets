package com.neusoft.aplus.common.netty.message;

import com.neusoft.aplus.common.exception.AplusException;


/**
 * 执行Command之后的回馈
 * 
 * @author Mu Xian Ming
 * @date 2015年2月2日 下午2:52:44
 */
public class Reply extends Message {
	private boolean success;
	private String commandId;
	private String detail;
	private Class<?> bodyClass;
	private String bodyString;
	private AplusException exception;

	public boolean getSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}
	
	public String getCommandId() {
		return commandId;
	}

	public void setCommandId(String commandId) {
		this.commandId = commandId;
	}
	
	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public Class<?> getBodyClass() {
		return bodyClass;
	}

	public void setBodyClass(Class<?> bodyClass) {
		this.bodyClass = bodyClass;
	}

	public String getBodyString() {
		return bodyString;
	}

	public void setBodyString(String bodyString) {
		this.bodyString = bodyString;
	}

	public AplusException getException() {
		return exception;
	}

	public void setException(AplusException exception) {
		this.exception = exception;
	}
}

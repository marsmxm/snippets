package com.neusoft.aplus.common.test.rules;

import com.neusoft.aplus.common.base.BaseApplication;
import com.neusoft.aplus.common.test.RestConfig;

import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;
import org.restlet.Component;
import org.restlet.data.Protocol;
import org.restlet.resource.ServerResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Rest服务的Junit4 Rule类。配合{@link org.junit.ClassRule}注解使用。<br>
 * 可在单元测试执行前，根据{@link RestConfig}注解配置的参数启动一个小范围的RestServer。
 *
 * @author li.hzh
 * @date 2015-04-22 10:03
 */
public class RestServerRules implements TestRule {

	private static final Logger logger = LoggerFactory.getLogger(RestServerRules.class);
	private Component component;
	private String url;

	@Override
	public Statement apply(Statement base, Description description) {
		return statement(base, description);
	}

	private Statement statement(final Statement base, final Description description) {
		return new Statement() {
			@Override
			public void evaluate() throws Throwable {
				before(description);
				try {
					base.evaluate();
				} finally {
					after(description);
				}
			}
		};
	}

	private void after(Description description) throws Exception {
		if (component != null && component.isStarted()) {
			logger.debug("Stop rest server.");
			component.stop();
		}
	}

	private void before(Description description) throws Exception {
		Class<?> testClass = description.getTestClass();
		RestConfig restConfig = (RestConfig) testClass.getAnnotation(RestConfig.class);
		if (restConfig == null) {
			logger.error("没有配置RestConfig注解。无法启动Rest服务。");
			throw new IllegalArgumentException("没有配置RestConfig注解，无法启动Rest服务。");
		}
		url = restConfig.url();
		startServer(url, restConfig.port(), restConfig.action());
	}

	private void startServer(String url, int port, Class<? extends ServerResource> action) throws Exception {
		logger.debug("Starting rest server.url: [{}], port: [{}], class: [{}]", new Object[]{url, port, action.getName()});
		component = new Component();
		BaseApplication testApplication = new BaseApplication();
		testApplication.attach(url, action);
		component.getServers().add(Protocol.HTTP, port);
		component.getDefaultHost().attach(testApplication);
		component.start();
	}

	public String getUrl() {
		return url;
	}

}

package com.neusoft.aplus.common.zmq.client.factory;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.zeromq.ZMQ;

import com.neusoft.aplus.common.config.ZMQConfig;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.common.zmq.client.api.IDoBusiness;
import com.neusoft.aplus.common.zmq.client.api.Publisher;
import com.neusoft.aplus.common.zmq.client.api.Subscriber;
import com.neusoft.aplus.common.zmq.client.connector.Connector;
import com.neusoft.aplus.common.zmq.client.connector.ConnectorManager;
import com.neusoft.aplus.common.zmq.client.impl.PubClusterClient;
import com.neusoft.aplus.common.zmq.client.impl.SubClusterClient;

/**
 * 用来创建Pub和Sub的类
 */
public class PubSubFactory {
	private static Logger log = LoggerFactory.getLogger(PubSubFactory.class);
	private static PubClusterClient pubClient;

	// 获取当前zmq的使用模式，在配置文件中规定是否为集群，用于与单机切换
	// private static boolean isCluser ;

	private PubSubFactory() {
	}

	/**
	 * 获取Publisher对象
	 * 
	 * @return
	 * @author MaHan
	 * @date 2015年5月27日
	 */
	public static synchronized Publisher createPublisher() {
		if (isClusterConfig()) {
			return createPubClusterClient();
		}
		return null;
	}

	private static PubClusterClient createPubClusterClient() {
		log.info("创建pubclient");
		if (pubClient == null) {
			Connector pubConn = ConnectorManager.create(ZMQ.REQ,
					ZMQConfig.SEVICE_REP, false);
			if (pubConn.getAddress() != null) {
				pubConn.connect(pubConn.getAddress());
			}
			pubClient = PubClusterClient.buider().setReqConn(pubConn);
		}
		return pubClient;
	}

	/**
	 * 获取Subscriber对象,指定接收的主题topic，与接收该主题后对应的处理方法doBusiness
	 * 
	 * @return
	 * @author MaHan
	 * @date 2015年5月27日
	 */
	public static synchronized Subscriber createSubscriber(String topic,
			IDoBusiness doBusiness) {
		if (isClusterConfig()) {
			return createSubCluserClient(topic, doBusiness, null);
		} else {
			// 暂时不支持
		}
		return null;
	}

	// /**
	// * 获取Subscriber对象,指定接收的主题topic，与接收该主题后对应的处理方法doBusiness
	// * defaultBusiness为默认处理方法，在接收到某一主题的消息，并未找到该主题对应的doBusiness处理方法被时调用
	// *
	// * @return
	// * @author MaHan
	// * @date 2015年5月27日
	// */
	// public static synchronized Subscriber createSubscriber(String topic,
	// IDoBusiness doBusiness, IDoBusiness defaultBusiness) {
	// if (isCluser) {
	// return createSubCluserClient(topic, doBusiness, defaultBusiness);
	// } else {
	// //暂不支持
	// }
	// return null;
	// }

	/**
	 * 获取Subscriber对象
	 * 
	 * @param businessMap
	 *            封装了主题及对应的处理方法信息
	 * @return
	 * @author zhangjian
	 * @date 2015年6月5日
	 */
	public static synchronized Subscriber createSubscriber(
			Map<String, IDoBusiness> businessMap) {
		if (isClusterConfig()) {
			return createSubCluserClient(businessMap);
		} else {
			// 暂不支持
		}
		return null;
	}

	private static Subscriber createSubCluserClient(
			Map<String, IDoBusiness> businessMap) {
		return createSubClusterClient().setBusinessMap(businessMap);
	}

	private static Subscriber createSubCluserClient(String topic,
			IDoBusiness doBusiness, IDoBusiness defaultBusiness) {
		Map<String, IDoBusiness> businessMap = new HashMap<String, IDoBusiness>();
		if (topic == null || topic.length() <= 0) {
			businessMap.put("", defaultBusiness);
		} else {
			businessMap.put(topic, doBusiness);
		}
		return createSubClusterClient().setBusinessMap(businessMap);
	}

	private static SubClusterClient createSubClusterClient() {
		log.info("创建subclient");
		Connector subConn = ConnectorManager.create(ZMQ.SUB,
				ZMQConfig.SEVICE_PUB, false);
		if (subConn.getAddress() != null) {
			subConn.connect(subConn.getAddress());
		}
		return SubClusterClient.builder().setSubConn(subConn);
	}

	/**
	 * 判断是否为集群部署
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private static boolean isClusterConfig() {
		Map<String, String> map = (HashMap<String, String>) ApplicationContextFactory
				.getBean("zmqClientConfig");
		String flag = map.get(ZMQConfig.ISCLUSTER);
		if (flag != null && flag.equals("1")) {
			return true;
		}
		return false;

	}
}

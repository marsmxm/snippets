package com.neusoft.aplus.common.test;

import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.restlet.data.Reference;
import org.restlet.resource.ClientResource;

import com.neusoft.aplus.common.test.rules.RestServerRules;

/**
 * Restlet单元测试基类，可单独启动通过注解传入的url和Action参数。
 * 支持加载指定的Spring配置文件
 *
 * @author li.hzh
 * @date 2015-04-21 13:48:58
 */
public class BaseRestTest {

	@ClassRule
	public static RestServerRules rules = new RestServerRules();
	protected ClientResource client;
	private static String BASE_URL = "http://127.0.0.1:8182";

	@BeforeClass
	public static void beforeClass() {
		System.out.println("Before class");
	}

	protected void doGet(String url) {
		Reference reference = new Reference(BASE_URL, url);
		client = new ClientResource(reference);
		client.handle();
	}

}

package com.neusoft.aplus.common.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.google.common.base.Objects;

/**
 * @author zh_ch
 * @date 2015年3月27日 下午3:36:39
 */
public class StreamUtil {
	public static void closeInputStream(InputStream inputStream) {
		if (!Objects.equal(inputStream, null)) {
			try {
				inputStream.close();
			} catch (IOException ex) {
				throw new RuntimeException(ex);
			}
		}
	}

	public static void closeOutputStream(OutputStream outputStream) {
		if (!Objects.equal(outputStream, null)) {
			try {
				outputStream.close();
			} catch (IOException ex) {
				throw new RuntimeException(ex);
			}
		}
	}
}

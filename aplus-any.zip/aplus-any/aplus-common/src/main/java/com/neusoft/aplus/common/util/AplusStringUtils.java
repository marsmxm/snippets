package com.neusoft.aplus.common.util;

import java.util.List;

import org.apache.commons.lang.StringUtils;

/**
 * @author zh_ch
 * @date 2015-1-13 下午1:21:35
 */
public final class AplusStringUtils extends StringUtils {
	/**
	 * 根据seperator解析字符串，根据index获取相应索引的字符串
	 * 
	 * @param msg
	 * @param seperator
	 *            分隔符
	 * @param index
	 *            获取解析后字符串数据中某一字符串的索引
	 * @return
	 * @author zh_ch
	 * @date 2015-1-13 下午1:19:34
	 */
	public static String parseStr(String msg, String seperator, Integer index) {
		String[] result = split(msg, seperator);
		return result[index];
	}

	/**
	 * 根据seperator解析字符串
	 * 
	 * @param msg
	 * @param seperator
	 *            分隔符
	 * @return
	 * @author zh_ch
	 * @date 2015-1-13 下午1:20:22
	 */
	public static String[] parseStr(String msg, String seperator) {
		return split(msg, seperator);
	}

	/**
	 * 根据分隔符将一组对象进行连接，如seperator=@,objects]{1,2,3},则结果为1@2@3
	 * 
	 * @param seperator
	 * @param objects
	 * @return
	 * @author zh_ch
	 * @date 2015-1-29 下午2:39:07
	 */
	public static String appendStr(String seperator, Object... objects) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < objects.length; i++) {
			sb.append(String.valueOf(objects[i])).append(seperator);
		}

		sb = new StringBuffer(sb.substring(0, sb.length() - 1));
		return sb.toString();
	}

	/**
	 * 获取类全限定名的类名，并将类名第一个字母变小写，用于spring获取bean
	 * 
	 * @param clazzName
	 * @return
	 * @author zh_ch
	 * @date 2015-2-6 下午5:09:10
	 */
	public static String getBeanName(String clazzName) {
		String[] strArray = split(clazzName, ".");
		Integer size = strArray.length;
		String strTemp = strArray[size - 1];
		return join(new Object[] { Character.toLowerCase(strTemp.charAt(0)),
				strTemp.substring(1) });
	}

	/**
	 * 字符串首字母变小写
	 * 
	 * @param str
	 * @return
	 * @author zh_ch
	 * @date 2015年3月11日 下午4:06:41
	 */
	public static String firstCharToLower(String str) {
		if (isBlank(str)) {
			throw new NullPointerException("String inputed is null or empty");
		}
		StringBuffer sb = new StringBuffer();
		String firstPart = str.substring(0, 1);
		String secondPart = str.substring(1, str.length());
		return sb.append(firstPart.toLowerCase()).append(secondPart).toString();
	}

	/**
	 * 构建postgresql支持的数组类型字符串
	 * 
	 * @param list
	 * @return
	 * @author zh_ch
	 * @date 2015年3月30日 上午9:31:31
	 */
	public static String getArrayType(List<? extends Object> list) {
		StringBuffer sb = new StringBuffer();
		if (list == null || list.isEmpty()) {
			return sb.append("{").append("}").toString();
		}

		sb = new StringBuffer(JSONUtil.getJsonString(list));
		sb.setCharAt(0, '{');
		sb.setCharAt(sb.length() - 1, '}');

		return sb.toString();
	}
}

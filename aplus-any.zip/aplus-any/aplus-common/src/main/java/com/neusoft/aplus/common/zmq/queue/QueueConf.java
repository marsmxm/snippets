package com.neusoft.aplus.common.zmq.queue;
/**
 * Queue模式配置类
 * @author zh_ch
 * @date 2014-12-27 下午1:12:34
 */
public class QueueConf {
	//push端地址，push端进行bind，pull端进行connect
	//push端必选，pull端必选
	private String pushend; 
	
	//req端地址，push端进行bind，pull端进行connect
	//push端必选，pull端必选
	private String respend; 
	
	//pull端的个数，针对push端，可选（建议指定），pull端不选
	private Integer pullerCnt; 
	private String pusherName; //push端名称，可选
	private String pullerName; //pull端名称，必选（要求每个进程/线程的名字不同）
	
	public QueueConf() {
		
	}

	
	public QueueConf(String pushend, String respend, Integer pullerCnt,
			String pusherName, String pullerName) {
		super();
		this.pushend = pushend;
		this.respend = respend;
		this.pullerCnt = pullerCnt;
		this.pusherName = pusherName;
		this.pullerName = pullerName;
	}

	
	public String getPushend() {
		return pushend;
	}


	public void setPushend(String pushend) {
		this.pushend = pushend;
	}


	public String getRespend() {
		return respend;
	}


	public void setRespend(String respend) {
		this.respend = respend;
	}


	public Integer getPullerCnt() {
		return pullerCnt;
	}
	public void setPullerCnt(Integer pullerCnt) {
		this.pullerCnt = pullerCnt;
	}

	public String getPusherName() {
		return pusherName;
	}

	public void setPusherName(String pusherName) {
		this.pusherName = pusherName;
	}

	public String getPullerName() {
		return pullerName;
	}

	public void setPullerName(String pullerName) {
		this.pullerName = pullerName;
	}
}

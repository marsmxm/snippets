package com.neusoft.aplus.common.cache.api;

import java.util.List;

/**
 * 由dubbo对外提供的分布式缓存接口 
 * (为将分布式缓存 改为本地模式时，暂将此类移植common下)
 * @author MaHan
 * @date 2015年4月10日
 */
public interface DCacheService {

	/**
	 * 获取缓存服务器中的存在的缓存名称列表
	 * @return String[]
	 * @author MaHan
	 * @date 2015年4月10日
	 *
	 */
	public String[] getAllCacheNames();
	
	/**
	 * 判断某键值为key的元素 是否存在指定的缓存中
	 * 若存在返回true
	 * @param cacheName
	 * @param key
	 * @return
	 * @author MaHan
	 * @date 2015年4月10日
	 */
	public boolean isInCache(String cacheName, String key);
	
	/**
	 * 通过指定键值key从某缓存中取对应的缓存值
	 * 可能返回null
	 * @param cacheName
	 * @param key
	 * @return
	 * @author MaHan
	 * @date 2015年4月10日
	 */
	public Object get(String cacheName, String key);
	
	/**
	 * 将某一键值对存入指定缓存
	 * @param cacheName
	 * @param key
	 * @param value
	 * @author MaHan
	 * @date 2015年4月10日
	 */
	public void put(String cacheName, String key, Object value);	
	
	/**
	 * 从某一缓存中移除指定key值的缓存内容
	 * @param cacheName
	 * @param key
	 * @author MaHan
	 * @date 2015年4月10日
	 */
	public void remove(String cacheName, String key);
	
	/**
	 * 获取指定cacheName下的所有key值
	 * @param cacheName
	 * @return List
	 * @author MaHan
	 * @date 2015年4月16日
	 */
	
	public List<Object> getKeys(String cacheName);
}

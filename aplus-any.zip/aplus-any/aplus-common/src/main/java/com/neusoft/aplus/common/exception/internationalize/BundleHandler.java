package com.neusoft.aplus.common.exception.internationalize;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import org.apache.log4j.Logger;
import com.neusoft.aplus.common.config.PropertiesConfig;
import com.neusoft.aplus.common.exception.RestException;

/**
 * 属性文件读取处理类
 * 
 * @author guo.tc
 * @date 2014-6-23 下午2:57:14
 */
public class BundleHandler {
	private static Logger log = Logger.getLogger(BundleHandler.class);

	private static final String prefix = "aplus-exception";

	private static Map<String, ResourceBundle> bundleHandleMap = new HashMap<String, ResourceBundle>();

	/**
	 * 取得处理bundle
	 * 
	 * @param name
	 * @param locale
	 * @return
	 * @author guo.tc
	 * @date 2014-6-24 下午4:33:19
	 */
	public static String getBundleHandleKey(String name, Locale locale) {
		String bundleKey = null;
		try{
			String bundleName = (new StringBuilder(prefix)).append(name).toString();
			String exceptionUrl = PropertiesConfig.getPropertiesExceptionUrl();
			bundleKey = (new StringBuilder(String.valueOf(locale.toString())))
					.append(bundleName).toString();
			ResourceBundle bundle = bundleHandleMap.get(bundleKey);
			if (bundle == null) {
					bundle = ResourceBundle.getBundle(exceptionUrl + "/"
							+ bundleName, locale);
					bundleHandleMap.put(bundleKey, bundle);
			} 
		}catch (Exception e) {
			log.error(e.getMessage(), e);
			RestException
			.throwException(
					RestException.CODE_REST_EXCEPTION_IOERRORINFO,
					e, null, null);
		}

		return bundleKey;
	}

	/**
	 * 取得属性信息
	 * 
	 * @param handleKey
	 * @param key
	 * @return
	 * @author guo.tc
	 * @date 2014-6-24 下午4:33:37
	 */
	public static String getString(String handleKey, String key) {
		ResourceBundle bundle;

		if ((handleKey == null) || !bundleHandleMap.containsKey(handleKey)
				|| (key == null)) {
			bundle = null;
		} else {
			bundle = (ResourceBundle) bundleHandleMap.get(handleKey);
		}

		String s = null;
		if (bundle == null) {
			String[] params = { handleKey };
			RestException
					.throwException(
							RestException.CODE_REST_EXCEPTION_INTERNATIONFILENOTFOUNDINFO,
							null, params, null);
		} else {
			try {
				s = bundle.getString(key);
			} catch (Exception e) {
				log.error(e.getMessage(),e);
				String[] params = { handleKey, key };
				RestException
						.throwException(
								RestException.CODE_REST_EXCEPTION_READFILEERRORINFO,
								e, params, null);
			}
		}
		return s;
	}

}

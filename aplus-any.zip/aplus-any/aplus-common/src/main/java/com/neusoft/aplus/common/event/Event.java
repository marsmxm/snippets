package com.neusoft.aplus.common.event;
/**
 * 事件接口，所有的自定义事件均需要实现此接口
 * @author zh_ch
 * @date 2014-12-16 下午2:41:13
 */
public interface Event {
	public  <T> void fireEvent(Input input, Output output, EventChain<T> chain);
}

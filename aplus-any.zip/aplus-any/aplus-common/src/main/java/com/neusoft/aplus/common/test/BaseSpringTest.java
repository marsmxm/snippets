package com.neusoft.aplus.common.test;

import org.junit.BeforeClass;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

/**
 * 需要用到Spring的单元测试基类
 * 请确保spring文件的路径正确
 * 不能用来测试使用ApplicationContextFactory.getBean获取的bean
 * 
 * @author WanWei
 * @date 2014-7-28 下午4:16:51
 */
@ContextConfiguration(locations = {"classpath*:spring/applicationContext*.xml"})
public class BaseSpringTest extends AbstractJUnit4SpringContextTests {

	@BeforeClass
	public static void init() {
		System.setProperty("basedir", "/");
	}
	
	public <T> T getBean(Class<T> type) {
		return applicationContext.getBean(type);
	}
	
	public Object getBean(String beanName) {
		return applicationContext.getBean(beanName);
	}
	
	protected ApplicationContext getContext() {
		return applicationContext;
	}
}

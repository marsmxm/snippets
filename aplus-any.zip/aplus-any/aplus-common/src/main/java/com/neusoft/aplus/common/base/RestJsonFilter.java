package com.neusoft.aplus.common.base;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.restlet.Request;
import org.restlet.Response;
import org.restlet.Restlet;
import org.restlet.data.CharacterSet;
import org.restlet.data.Language;
import org.restlet.data.MediaType;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.ObjectRepresentation;
import org.restlet.representation.Representation;
import org.restlet.routing.Filter;

import com.neusoft.aplus.common.exception.AplusException;
import com.neusoft.aplus.common.util.JSONUtil;

/**
 * 用来处理REST接口的数据流，将固化的对象数据流转化为JSON数据流
 * 
 * @author WanWei
 * @date 2015-3-19 下午7:24:31
 */
public class RestJsonFilter extends Filter {
	
	private static Logger logger = Logger.getLogger(RestJsonFilter.class);
	
	/**
	 * 构造方法
	 * 直接包装BaseAction
	 * 
	 * @param targetClass
	 * 				具体业务相关的resource类
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public RestJsonFilter(Class targetClass){
		super();
		setNext(targetClass);
	}
	
	/**
	 * 构造方法
	 * 直接包装BaseAction
	 * 
	 * @param targetClass
	 * 				具体业务相关的resource类
	 */
	public RestJsonFilter(Restlet filter){
		super();
		setNext(filter);
	}
	
	/**
	 * 具体的业务处理执行结束后调用的方法
	 */
	@Override
	protected void afterHandle(Request request, Response response) {
		logger.debug("将Response数据转换为JSON");
		Representation returnEntity = response.getEntity();
		//仅当返回值为Object时，做json转换
		if((returnEntity != null) && (MediaType.APPLICATION_JAVA_OBJECT.isCompatible(returnEntity
				.getMediaType())
				|| MediaType.APPLICATION_JAVA_OBJECT_XML
						.isCompatible(returnEntity.getMediaType()))){
			try{
				ObjectRepresentation<?> objRepresentation = new ObjectRepresentation<Serializable>(returnEntity);
				Object obj = objRepresentation.getObject();
				if (obj != null && obj instanceof AplusException) {
					super.afterHandle(request, response);
					return;
				}
				String jsonStr = JSONUtil.getJsonString(obj);
				
				JsonRepresentation jsonRep = null;
				
				if(jsonStr.startsWith("[")){//集合类型
					JSONArray jsonObj = new JSONArray(jsonStr);
					jsonRep = new JsonRepresentation(jsonObj);
				}else{
					JSONObject jsonObj = new JSONObject(jsonStr);
					jsonRep = new JsonRepresentation(jsonObj);
				}
				
				jsonRep.getLanguages().add(Language.ALL);
				jsonRep.setCharacterSet(CharacterSet.UTF_8);
				response.setEntity(jsonRep);
				logger.debug("Object[" + obj.getClass().getName() + "] 转换 JSON 字符串：" + jsonStr);
			}catch(Exception e){
				logger.warn("获取REST接口返回值中的Object出错, JSON filter不生效", e);
				//无须处理
			}
		}
		super.afterHandle(request, response);
	}

	/**
	 * 在执行具体的业务处理之前调用的方法
	 */
	@Override
	protected int beforeHandle(Request request, Response response) {
		//什么都不用做
		return super.beforeHandle(request, response);
	}

}

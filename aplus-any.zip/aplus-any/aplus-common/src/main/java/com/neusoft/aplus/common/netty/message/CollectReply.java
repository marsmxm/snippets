package com.neusoft.aplus.common.netty.message;
/**
 * 采集端通过CollectReply将采集结果返回给Server端
 *
 * @author Mu Xian Ming
 * @date 2015年4月22日 下午3:28:20
 */
public class CollectReply extends Reply {
	private boolean isPush;

	public boolean isPush() {
		return isPush;
	}

	public void setPush(boolean isPush) {
		this.isPush = isPush;
	}
}

package com.neusoft.aplus.common.event;
/**
 * 标记接口，事件链输入需实现此接口
 * @author zh_ch
 * @date 2014-12-16 下午2:41:49
 */
public interface Input {

}

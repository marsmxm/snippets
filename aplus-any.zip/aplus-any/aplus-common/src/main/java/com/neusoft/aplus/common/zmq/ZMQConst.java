package com.neusoft.aplus.common.zmq;
/**
 * 常量类
 * @author zh_ch
 * @date 2014-12-25 下午7:32:51
 */
public class ZMQConst {
	// 用以区分不同进程的Publisher，使用不同的Respond地址，MQ主题
	public static final String PROC_DATABUS = "process_databus";
	public static final String PROC_DBUSSERVER = "process_DBUSServer";
	public static final String PROC_POLICY = "process_policy";
	public static final String PROC_LAUNCH = "process_launch";
	public static final String PROC_DBUSREST = "process_DBUSRest";
	
	//探测消息配置，目前没有使用，可先不关注 by zhangchao
	public static final String TOPIC_READY = "subend_ready";
	public static final String TOPIC_HELLO = "hello_sub";
	public static final String TOPIC_OK = "subend_ready_ok";
	public static final String QUEUE_HELLO = "hello_pull";
	public static final String QUEUE_READY = "pullend_ready";
	public static final String QUEUE_OK = "pullend_ready_ok";
	public static final String SEPERATOR = "@";
	
	// 关于plugin脚本或jar包文件增删改的topic，MQ主题
	public static final String  TOPIC_PLUGIN_SCRIPT = "plugin_script_topic";
	public static final String  TOPIC_PLUGIN_JAR = "plugin_jar_topic";
	public static final String  TOPIC_PLUGIN_EXCEL = "plugin_excel_topic";
	
	// 实体入库主题
	public static final String  TOPIC_NOTIFY_INQUIRER = "notify_inquirer_topic";
	
	// CommandClient的ZMQ Subscriber用以区分不同实体的消息
	public final static String PLUGIN_DB_STORE = "plugin_db_store";
	public final static String DEVICE_DB_STORE = "device_db_store";
	
	//规则相关配置，policy部分
	public static final String TOPIC_NEW_ALERT = "topic_new_alert";
	public static final String TOPIC_FIXED_ALERT = "topic_fixed_alert";
	public static final String TOPIC_PROC_POLICY_OPERATION = "topic_proc_policy_operation";
	public static final String TOPIC_NEW_LINKAGE_RECEPTION = "topic_new_linkage_reception";
	public static final String TOPIC_NEW_LINKAGE_BACKSTAGE = "topic_new_linkage_backstage";
	
	//向前端与告警模块推送监控数据主题
	//实时监控订阅者需要订阅的主题
	public static final String TOPIC_DBUSSERVER_TO_CLIENT = "monitordata_push_client";
	//告警模块需要订阅的主题，通过主题来接受DataBus采集到的指标数据
	public static final String TOPIC_DBUSSERVER_TO_POLICY = "monitordata_push_policy";
	//向DataBus发送的MQ消息的主题
	public static final String TOPIC_TO_DBUSSERVER = "TO_DBUSServer";
	//需要订阅控制结果的MQ主题
	public static final String TOPIC_TO_REST = "controlresult_push_rest";
}

package com.neusoft.aplus.common.db;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.hibernate.CallbackException;
import org.hibernate.JDBCException;
import org.hibernate.NonUniqueObjectException;
import org.hibernate.NonUniqueResultException;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.PersistentObjectException;
import org.hibernate.PropertyAccessException;
import org.hibernate.PropertyValueException;
import org.hibernate.QueryException;
import org.hibernate.StaleObjectStateException;
import org.hibernate.TransactionException;
import org.hibernate.TransientObjectException;
import org.hibernate.UnresolvableObjectException;
import org.hibernate.WrongClassException;
import org.hibernate.cache.CacheException;
import org.hibernate.classic.ValidationFailure;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.exception.GenericJDBCException;
import org.hibernate.exception.LockAcquisitionException;
import org.hibernate.exception.SQLGrammarException;
import org.hibernate.id.IdentifierGenerationException;
import org.hibernate.type.SerializationException;

import com.neusoft.aplus.common.exception.AplusException;
import com.neusoft.aplus.common.exception.annotation.MessageCN;
import com.neusoft.aplus.common.exception.annotation.MessageUS;

/**
 * 封装dao基类中发生的数据库异常
 * 
 * 异常码范围： 1 ~ 100
 * 
 * @author WanWei
 * @date 2014-6-26 下午7:27:32
 */
public class AplusHibernateException extends AplusException {

	private static final long serialVersionUID = -1197030368546036934L;
	//
	//异常码范围：1 ~ 100 
	//
	@MessageCN("持久化层未知异常")
	@MessageUS("Unexpected exception occurs on persistence layer.")
	public static final String HIB_GENERIC_EXCEPTION = createExceptionCode(1);  //持久层未知异常
	
	@MessageCN("无效的SQL（语法错误，无效的对象引用等）")
	@MessageUS("The SQL was invalid (syntax error, invalid object references, etc). ")
	public static final String HIB_JDBC_SQLGRAMMAR_EXCEPTION = createExceptionCode(2); //sql 语法异常
	
	@MessageCN("违反定义的完整性约束")
	@MessageUS("Violate the defined integrity constraint. ")
	public static final String HIB_JDBC_CONSTRAINTVIOLATION_EXCEPTION = createExceptionCode(3);	//违反数据约束
	
	@MessageCN("无法连接到数据库服务器")
	@MessageUS("Can not connect to the database server.")
	public static final String HIB_JDBC_CONNECTION_EXCEPTION = createExceptionCode(4);	//jdbc连接
	
	@MessageCN("资源死锁")
	@MessageUS("Lock acquisition with resources.")
	public static final String HIB_JDBC_LOCKACQUISITION_EXCEPTION = createExceptionCode(5);	//数据死锁异常
	
	@MessageCN("一般性的JDBC异常")
	@MessageUS("Generic, non-specific JDBC exception. ")
	public static final String HIB_JDBC_GENERIC_EXCEPTION = createExceptionCode(6); //jdbc异常

	@MessageCN("Hibernate缓存错误")
	@MessageUS("Something went wrong in the cache.")
	public static final String HIB_CACHE_EXCEPTION = createExceptionCode(7); //缓存异常
	
	@MessageCN("生命周期或者拦截器中的持久化对象回调失败")
	@MessageUS("Persistent objects from Lifecycle or Interceptor callbacks fails.")
	public static final String HIB_CALLBACK_EXCEPTION = createExceptionCode(8); //回调异常
	
	@MessageCN("ID生成失败")
	@MessageUS("ID generation fails.")
	public static final String HIB_IDGENERATION_EXCEPTION = createExceptionCode(9); //主键生成异常
	
	@MessageCN("不能实例化一个实体或组件类")
	@MessageUS("Can not instantiate an entity or component class.")
	public static final String HIB_INSTANTIATION_EXCEPTION = createExceptionCode(10); //实例化对象异常	
	
	@MessageCN("在单个会话范围内，不能将一个JAVA类的两个实例与同一个ID关联")
	@MessageUS("Can not associate two different instances of the same Java class with a particular identifier, in the scope of a single Session. ")
	public static final String HIB_NONUNIQUE_OBJECT_EXCEPTION = createExceptionCode(11); //主键不唯一异常
	
	@MessageCN("该查询返回多个结果")
	@MessageUS("The query returned more than one result.")
	public static final String HIB_NONUNIQUE_RESULT_EXCEPTION = createExceptionCode(12); //结果不唯一异常
	
	@MessageCN("需要一个持久化的实例")
	@MessageUS("Expect a persistent instance.")
	public static final String HIB_PERSISTENT_OBJECT_EXCEPTION = createExceptionCode(13); //持久化对象异常
	
	@MessageCN("通过反射访问持久化实例的属性失败")
	@MessageUS("Access a property of an instance of a persistent class by reflection fails.")
	public static final String HIB_PROPERTY_ACCESS_EXCEPTION = createExceptionCode(14); //属性访问异常
	
	@MessageCN("（非法的）属性值不能被持久化")
	@MessageUS("The (illegal) value of a property can not be persisted.")
	public static final String HIB_PROPERTYVALUE_EXCEPTION = createExceptionCode(15); //属性值异常
	
	@MessageCN("Hibernate查询转换为SQL失败（无效的查询语法等）")
	@MessageUS("Translate a Hibernate query to SQL due to invalid query syntax, etc. ")
	public static final String HIB_QUERY_EXCEPTION = createExceptionCode(16); //查询异常
	
	@MessageCN("属性不能被序列化/反序列化")
	@MessageUS("Property can not be serializaed/deserialized.")
	public static final String HIB_SERIALIZATION_EXCEPTION = createExceptionCode(17); //序列化异常
	
	@MessageCN("版本号或者时间戳校验失败")
	@MessageUS("Version number or timestamp check failed.")
	public static final String HIB_STALEOBJECT_STATE_EXCEPTION = createExceptionCode(18); //对象状态和DB不同步异常
	
	@MessageCN("事务不能被开始、提交或者回滚")
	@MessageUS("Transaction could not be begun, committed or rolled back.")
	public static final String HIB_TRANSACTION_EXCEPTION = createExceptionCode(19); //事务异常
	
	@MessageCN("需要一个瞬态的实例")
	@MessageUS("Expect a transient instance.")
	public static final String HIB_TRANSIENT_OBJECT_EXCEPTION = createExceptionCode(10); //瞬态对象异常
	
	@MessageCN("无法通过ID解析对象")
	@MessageUS("Can not resolve an object by id.")
	public static final String HIB_UNRESOLVABLE_OBJECT_EXCEPTION = createExceptionCode(21); //无法解析对象异常
	
	@MessageCN("违反了不可变性约定")
	@MessageUS("The invariant was violated.")
	public static final String HIB_VALIDATION_FAILURE_EXCEPTION = createExceptionCode(22); //验证异常
	
	@MessageCN("返回的数据行指定的数据子类型与请求的类型不匹配")
	@MessageUS("The row's discriminator value specifies a subclass that is not assignable to the class requested.")
	public static final String HIB_WRONGCLASS_EXCEPTION = createExceptionCode(23);	//错误的类型异常

	@MessageCN("没有找到Hibernate对象")
	@MessageUS("ObjectNotFoundException.")
	public static final String OBJECT_NOT_FOUND_EXCEPTION = createExceptionCode(24); //没有找到Hibernate对象
	
	@MessageCN("未知的Hibernate方言")
	@MessageUS("Unexpected hibernate dialect.")
	public static final String UNKNOWN_DB_DIALECT_EXCEPTION = createExceptionCode(25); //未知的数据库方言
	
	@MessageCN("提取数据库类型信息失败")
	@MessageUS("Get the database type information failure.")
	public static final String PICKUP_DB_INFO_EXCEPTION = createExceptionCode(26); //提取数据库类型信息失败
	

	//仅Hibernate的异常这样处理
	private static final Map<String, String> exceptionMap = new ConcurrentHashMap<String, String>();
	
	//仅Hibernate异常用map来处理, 其他的直接调用throwEx抛
	static {
		//JDBCException
		exceptionMap.put(JDBCException.class.getName(), HIB_JDBC_CONNECTION_EXCEPTION);
		exceptionMap.put(SQLGrammarException.class.getName(), HIB_JDBC_SQLGRAMMAR_EXCEPTION);
		exceptionMap.put(ConstraintViolationException.class.getName(), HIB_JDBC_CONSTRAINTVIOLATION_EXCEPTION);
		exceptionMap.put(GenericJDBCException.class.getName(), HIB_JDBC_GENERIC_EXCEPTION);
		exceptionMap.put(LockAcquisitionException.class.getName(), HIB_JDBC_LOCKACQUISITION_EXCEPTION);
		//CacheException
		exceptionMap.put(CacheException.class.getName(), HIB_CACHE_EXCEPTION);
		//HibernateException
		exceptionMap.put(CallbackException.class.getName(), HIB_CALLBACK_EXCEPTION);
		exceptionMap.put(IdentifierGenerationException.class.getName(), HIB_IDGENERATION_EXCEPTION);
		exceptionMap.put(InstantiationException.class.getName(), HIB_INSTANTIATION_EXCEPTION);
		exceptionMap.put(NonUniqueObjectException.class.getName(), HIB_NONUNIQUE_OBJECT_EXCEPTION);
		exceptionMap.put(NonUniqueResultException.class.getName(), HIB_NONUNIQUE_RESULT_EXCEPTION);
		exceptionMap.put(PersistentObjectException.class.getName(), HIB_PERSISTENT_OBJECT_EXCEPTION);
		exceptionMap.put(PropertyAccessException.class.getName(), HIB_PROPERTY_ACCESS_EXCEPTION);
		exceptionMap.put(PropertyValueException.class.getName(), HIB_PROPERTYVALUE_EXCEPTION);
		exceptionMap.put(QueryException.class.getName(), HIB_QUERY_EXCEPTION);
		exceptionMap.put(SerializationException.class.getName(), HIB_SERIALIZATION_EXCEPTION);
		exceptionMap.put(StaleObjectStateException.class.getName(), HIB_STALEOBJECT_STATE_EXCEPTION);
		exceptionMap.put(TransactionException.class.getName(), HIB_TRANSACTION_EXCEPTION);
		exceptionMap.put(TransientObjectException.class.getName(), HIB_TRANSIENT_OBJECT_EXCEPTION);
		exceptionMap.put(UnresolvableObjectException.class.getName(), HIB_UNRESOLVABLE_OBJECT_EXCEPTION);
		exceptionMap.put(ValidationFailure.class.getName(), HIB_VALIDATION_FAILURE_EXCEPTION);
		exceptionMap.put(WrongClassException.class.getName(), HIB_WRONGCLASS_EXCEPTION);
		/** Updated by gaosong at 2013-9-27 11:49:41 **/
		exceptionMap.put(ObjectNotFoundException.class.getName(), OBJECT_NOT_FOUND_EXCEPTION);
	}
	
	/**
	 * 初始化方法
	 * 
	 * @param code
	 * @param original
	 * @param params
	 * @param keyPoints
	 */
	public AplusHibernateException(String code, Exception original,
			Object[] params, Map<String, Object> keyPoints) {
		super(code, original, params, keyPoints);
	}
	
	/**
	 * 工具方法，负责生成异常码
	 * 
	 * @param code
	 * @return String
	 * @author WanWei
	 * @date 2014-6-26 下午8:10:07
	 */
	private static String createExceptionCode(int code){
		return getFormatedNumber(ID_PLATFORM, code);
	}
	
	/**
	 * 解析Hibernate异常并封装层业务异常抛出
	 * @param e
	 * @author WanWei
	 * @date 2014-6-30 下午4:23:15
	 */
	public static void parseException(Exception e) {
		
		String exceptionCode = exceptionMap.get(e.getClass().getName());
		if((exceptionCode == null) || (exceptionCode.isEmpty())){
			exceptionCode = HIB_GENERIC_EXCEPTION;
		}
		//没有传入参数和关键断言
		AplusHibernateException exception = new AplusHibernateException(exceptionCode, e, null, null);
		exception.throwEx();
	}
	
	/**
	 * 建议子类都实现此static方法，利于代码的整洁
	 * 封装异常创建及抛出
	 * @param code
	 * @param original
	 * @param params
	 * @param keyPoints
	 * @author WanWei
	 * @date 2014-6-30 下午4:46:45
	 */
	public static void throwException(String code,  Exception original,
			Object[] params, Map<String, Object> keyPoints){
		AplusHibernateException exception = new AplusHibernateException(code, original, params, keyPoints);
		exception.throwEx();
	}

}

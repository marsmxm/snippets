package com.neusoft.aplus.common.zmq.topic.factory;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.zeromq.ZMQ;

import com.neusoft.aplus.common.config.NettyServerConf;
import com.neusoft.aplus.common.util.SpringUtil;
import com.neusoft.aplus.common.zmq.topic.PubSubProxy;
import com.neusoft.aplus.common.zmq.topic.Publisher;
import com.neusoft.aplus.common.zmq.topic.Subscriber;
import com.neusoft.aplus.common.zmq.topic.TopicConf;

/**
 * 发布者，订阅者的工厂类
 * 
 * @author Mu Xian Ming
 * @date 2015年1月13日 下午3:54:42
 */
public class PubSubFactory {
	private static ZMQ.Context context = ZMQ.context(1);
	private volatile static Publisher publisher;
	private static final Object LOCK = new Object();

	/**
	 * 根据传入的不同进程名得到一个Publisher 一个进程只有一个Publisher
	 * 
	 * @param procName
	 *            进程名，在ZmqConst中定义
	 * @return Publisher
	 */
	public static Publisher newPublisher(String procName) {
		Publisher result = publisher;
		if (result == null) { // First check (no locking)
			synchronized (LOCK) {
				result = publisher;
				if (result == null) // Second check (with locking)
					result = publisher = new Publisher(context,
							getPubConfig(procName)).waitForSendMsg();
			}
		}
		return result;
	}

	/**
	 * 得到一个Subscriber
	 * 
	 * 通过传入的topic判断，如果该Subscriber被配置为需要启动一个 ZMQ Proxy，将在这里启动
	 * 
	 * @param topic
	 * @return Subscriber
	 */
	public static Subscriber newSubscriber(String topic) {
		TopicConf conf = getSubConfig(topic, context);
		if (conf.getIsProxyStarter()) {
			new Thread(new PubSubProxy(context, conf)).start();
		}

		return new Subscriber(context, conf).waitForReceiveMsg();
	}

	private static TopicConf getPubConfig(String procName) {
		NettyServerConf exConf = SpringUtil.getBean(NettyServerConf.class);
		Map<String, String> confMap = exConf.getZmqTopicConf();
		TopicConf conf = new TopicConf();
		conf.setFrontend(confMap.get(NettyServerConf.ZmqTopicConst.FRONT_END));
		conf.setRespend(confMap.get(procName));
		conf.setSubscriberCnt(Integer.parseInt(confMap
				.get(NettyServerConf.ZmqTopicConst.SUB_CNT)));
		conf.setSendHwm(1000L);
		return conf;
	}

	private static TopicConf getSubConfig(String topic, ZMQ.Context ctx) {
		NettyServerConf exConf = SpringUtil.getBean(NettyServerConf.class);
		Map<String, String> confMap = exConf.getZmqTopicConf();
		TopicConf conf = new TopicConf();
		conf.setFrontend(confMap.get(NettyServerConf.ZmqTopicConst.FRONT_END));
		conf.setBackend(confMap.get(NettyServerConf.ZmqTopicConst.BACK_END));
		conf.setSubscription(topic);
		conf.setIsProxyStarter(StringUtils.equals(topic,
				confMap.get(NettyServerConf.ZmqTopicConst.PROXY_STARTER)));
		return conf;
	}

	/**
	 * 启动代理
	 * 
	 * @author zh_ch
	 * @date 2015年4月16日 下午3:18:44
	 */
	public static void startPubSubProxy() {
		NettyServerConf exConf = SpringUtil.getBean(NettyServerConf.class);
		Map<String, String> confMap = exConf.getZmqTopicConf();
		TopicConf conf = new TopicConf();
		conf.setFrontend(confMap.get(NettyServerConf.ZmqTopicConst.FRONT_END));
		conf.setBackend(confMap.get(NettyServerConf.ZmqTopicConst.BACK_END));
		conf.setProxyResp(confMap.get(NettyServerConf.ZmqTopicConst.PROXY_RESP));
		new PubSubProxy(context, conf).start();
	}
}

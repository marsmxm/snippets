package com.neusoft.aplus.common.test;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.restlet.resource.ServerResource;

/**
 * @author li.hzh
 * @date 2015-04-21 14:09
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface RestConfig {

	String url() default "/";

	Class<? extends ServerResource> action();

	int port() default 8182;
}

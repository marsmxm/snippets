package com.neusoft.aplus.common.exception;

import com.neusoft.aplus.common.exception.annotation.MessageCN;
import com.neusoft.aplus.common.exception.annotation.MessageUS;

import java.util.Map;

/**
 * 框架异常的类
 * <p/>
 * 异常码范围：201 ~ 400
 *
 * @author wuhao
 * @date 2014-7-23 下午2:30:08
 */
public class RestException extends AplusException {

    private static final long serialVersionUID = 1L;
    //
    // 异常码范围：201 ~ 400
    //
    @MessageCN("URL协议、格式或者路径错误 ：协议:{0},Ip:{1},端口:{2}")
    @MessageUS("Unknown protocol,formate or url：Protocol:{0},Ip:{1},Port:{2}")
    public static String CODE_REST_EXCEPTION_URLERRORINFO = createExceptionCode(201);
    @MessageCN("文件未找到")
    @MessageUS("File Not Found")
    public static String CODE_REST_EXCEPTION_FILENOTFOUNDINFO = createExceptionCode(202);
    @MessageCN("文件读写错误")
    @MessageUS("I/O Exception")
    public static String CODE_REST_EXCEPTION_IOERRORINFO = createExceptionCode(203);
    @MessageCN("读写SqlMap文件错误")
    @MessageUS("SqlMap I/O Exception")
    public static String CODE_REST_EXCEPTION_SQLMAPIOERRORINFO = createExceptionCode(204);
    @MessageCN("国际化文件:{0}未找到")
    @MessageUS("File:{0} Not Found")
    public static String CODE_REST_EXCEPTION_INTERNATIONFILENOTFOUNDINFO = createExceptionCode(205);
    @MessageCN("读取国际化文件:{0}中的:{1}错误")
    @MessageUS("Error Read the :{1} of the File:{0}")
    public static String CODE_REST_EXCEPTION_READFILEERRORINFO = createExceptionCode(206);
    @MessageCN("Rest Client克隆Response错误")
    @MessageUS("Rest Client cloning Response error")
    public static String CODE_REST_EXCEPTION_CLIENT_RESPONSE_CLONE_FAIL = createExceptionCode(207);
    @MessageCN("读取BundleMessage文件编码错误:文件:{0},key值:{1}")
    @MessageUS("BundleMessage encoding error:File{0},key:{1}")
    public static String BUNDLEMESSAGE_ENCODING_ERROR = createExceptionCode(208);
    @MessageCN("不支持的HTTP请求类型: {0}。")
    @MessageUS("Unsupported http method type: {0}.")
    public static final String CODE_UNSUPPORT_HTTP_METHOD_TYPE_ERROR = createExceptionCode(209);

    private RestException(String code, Exception original,
                          Object[] params, Map<String, Object> keyPoints) {
        super(code, original, params, keyPoints);
    }

    /**
     * 封装异常抛出
     *
     * @param code
     *         异常码
     * @param params
     *         异常信息中的参数信息
     *
     * @author li.hzh
     * @date 2015-04-17 15:33:49
     */
    public static void throwException(String code, Object[] params) {
        throwException(code, null, params, null);
    }

    /**
     * 封装异常创建及抛出
     *
     * @param code
     * @param original
     * @param params
     * @param keyPoints
     *
     * @author wuhao
     * @date 2014-7-23 下午2:45:48
     */
    public static void throwException(String code, Exception original,
                                      Object[] params, Map<String, Object> keyPoints) {
        RestException exception = new RestException(code,
                original, params, keyPoints);
        exception.throwEx();
    }

    /**
     * 工具方法，负责生成异常码
     *
     * @param code
     *
     * @return String
     * @author wuhao
     * @date 2014-7-23 下午2:45:48
     */
    private static String createExceptionCode(int code) {
        return getFormatedNumber(ID_PLATFORM, code);
    }

}

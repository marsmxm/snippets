package com.neusoft.aplus.common.exception.internationalize;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Locale;

/**
 * 获取指定编码的错误信息
 * 
 * @author guo.tc
 * @date 2014-6-23 下午2:54:46
 */
public class Trace {
	private static String propsName = "-messages";
	
	public static String getMessage(String code, Locale locale) {
		return getMessage(code, ((Object[]) (null)), locale);
	}

	/**
	 * 获取指定编码的错误信息
	 * 
	 * @param code
	 * @param values
	 * @param locale
	 * @return
	 * @author guo.tc
	 * @date 2014-6-24 下午4:27:24
	 */
	public static String getMessage(String code, Object values[], Locale locale) {
		String bundleKey = BundleHandler.getBundleHandleKey(propsName, locale);
		String msg = BundleMessage.getMessage(bundleKey, code, values);
		return msg;
	}

	/**
	 * 获取指定编码的错误堆栈信息
	 * 
	 * @param e
	 * @return
	 * @author guo.tc
	 * @date 2014-6-24 下午4:27:31
	 */
	public static String getStackTrace(Exception e) {
		String rst = "";
		if (null == e)
			return "";
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		PrintWriter pw = new PrintWriter(os, true);
		e.printStackTrace(pw);
		try {
			rst = os.toString("utf-8");
		} catch (UnsupportedEncodingException e1) {
			rst = os.toString();
		}
		return rst;
	}
}

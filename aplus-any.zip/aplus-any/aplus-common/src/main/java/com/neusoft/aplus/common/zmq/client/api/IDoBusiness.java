package com.neusoft.aplus.common.zmq.client.api;

import com.neusoft.aplus.common.zmq.model.ZMQMessage;

/**
 * 订阅者处理接口，每个主题对应一个实现该接口的类的实例，用于subscriber端接收消息后的处理
 *
 * @date 2015年5月27日
 */
public interface IDoBusiness {

	/**
	 * 接收处理，在这里对接收到的消息进行处理
	 * 
	 * @param recvMsg
	 */
	public void handleRecv(ZMQMessage msg);

}

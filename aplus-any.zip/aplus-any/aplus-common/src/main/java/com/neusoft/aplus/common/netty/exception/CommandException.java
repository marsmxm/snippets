package com.neusoft.aplus.common.netty.exception;

import java.util.Map;

import com.neusoft.aplus.common.exception.AplusException;
import com.neusoft.aplus.common.exception.annotation.MessageCN;
import com.neusoft.aplus.common.exception.annotation.MessageUS;

/**
 * Netty相关的异常类
 * 
 * 异常码范围：901 ~ 1000
 * 
 * @author Mu Xian Ming
 * @date 2014-12-27 下午2:30:08
 */
public class CommandException extends AplusException {

	private static final long serialVersionUID = 1L;
	//
	// 异常码范围：901 ~ 1000
	//
	@MessageCN("错误")
	@MessageUS("Error")
	public static String COMMAND_EXCEPTCODE_ERROR = createExceptionCode(901);
	
	public CommandException() {
		this(COMMAND_EXCEPTCODE_ERROR);
	}
	
	public CommandException(String code) {
		this(code, null, null, null);
	}

	public CommandException(String code, Exception original,
			Object[] params, Map<String, Object> keyPoints) {
		super(code, original, params, keyPoints);
	}

	/**
	 * 封装异常创建及抛出
	 * 
	 * @param ecode
	 * @author Mu Xian Ming
	 * @date 2014-7-23 下午2:45:48
	 */
	public static void throwException(String ecode) {
		throwException(ecode, null, null, null);
	}

	/**
	 * 封装异常创建及抛出
	 * 
	 * @param ecode
	 * @param original
	 * @param params
	 * @param keyPoints
	 * @author wuhao
	 * @date 2014-7-23 下午2:45:48
	 */
	public static void throwException(String ecode, Exception original,
			Object[] params, Map<String, Object> keyPoints) {
		CommandException exception = new CommandException(ecode,
				original, params, keyPoints);
		exception.throwEx();
	}


	/**
	 * 工具方法，负责生成异常码
	 * 
	 * @param code
	 * @return String
	 * @author wuhao
	 * @date 2014-7-23 下午2:45:48
	 */
	private static String createExceptionCode(int code) {
		return getFormatedNumber(ID_DATABUS, code);
	}

}

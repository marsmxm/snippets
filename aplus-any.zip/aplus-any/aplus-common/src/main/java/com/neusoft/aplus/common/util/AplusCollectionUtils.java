package com.neusoft.aplus.common.util;

import java.util.Collection;

import org.apache.commons.collections.CollectionUtils;

/**
 * @author zh_ch
 * @date 2015年5月15日 上午9:21:25
 */
public class AplusCollectionUtils extends CollectionUtils {
	public static Boolean isBlank(Collection<?> collection) {
		if (collection == null || collection.isEmpty()) {
			return Boolean.TRUE;
		}
		
		return Boolean.FALSE;
	}
	
	public static Boolean isNotBlank(Collection<?> collection) {
		if (collection == null || collection.isEmpty()) {
			return Boolean.FALSE;
		}
		
		return Boolean.TRUE;
	}
}

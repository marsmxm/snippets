package com.neusoft.aplus.common.netty.message;

import java.util.UUID;

/**
 * Netty中用到的所有命令的基类
 * 
 * 每种命令都有对应的Key，接受命令方通过key来找到
 * 提前配置好的{@link ICommandProcess}对象，进而处理接收到
 * 的命令，命令的处理结果会以{@link Reply}的形式返回给
 * 命令发起方
 * 
 * @author Mu Xian Ming
 *
 */
public abstract class AbstractCommand extends Message {
	private String commandId = UUID.randomUUID().toString();
	private String commandKey;

	
	/**
	 * 获取命令ID
	 * @return String
	 */
	public String getCommandId(){
		return commandId;
	}
	
	public void setCommandId(String commandId) {
		this.commandId = commandId;
	}

	public String getCommandKey() {
		return commandKey;
	}

	public void setCommandKey(String cmdKey) {
		this.commandKey = cmdKey;
	}
}

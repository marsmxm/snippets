package com.neusoft.aplus.common.zmq.client.connector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.zeromq.ZMQ;

/**
 * 封装连接，每个socket对应一个connector
 * 
 * @author MaHan
 *
 * @date 2015年5月27日
 */
public class Connector {
	private static Logger log = LoggerFactory.getLogger(Connector.class);

	private boolean connected = false;
	private ZMQ.Context cxt;
	// socket的类型
	private int socketType;
	// socket的连接地址
	private String address;
	// 从配置信息的map中获取地址的key值，在配置文件中统一规定
	private String addresskey;
	// socket是否为bind()，flase则为connect()
	private boolean isBind;
	// 是否为新出现的主服务对应的未被处理的连接，用于在publisher和subscriber中做判断
	private boolean newMaster = true;

	public Connector(ZMQ.Context cxt) {
		this.cxt = cxt;
	}

	/**
	 * 修改连接状态标志位，关闭socket方法在publisher和subscriber中
	 * 
	 * @author MaHan
	 * @date 2015年5月27日
	 */
	public void disconnect() {
		setConnected(false);
		log.warn(address + " Connector 断开连接   disconnect()");
	}

	/**
	 * 修改连接状态标志位、修改新的连接地址 连接socket方法在publisher和subscriber中
	 * 
	 * @author MaHan
	 * @date 2015年5月27日
	 */
	public void connect(String newAddr) {
		log.info("Connector() 修改连接地址与状态" + newAddr);
		setAddress(newAddr);
		setConnected(true);
	}

	public ZMQ.Socket createSocket() {
		log.info("createSocket方法被调用");
		return cxt.socket(socketType);
	}

	public boolean isConnected() {
		return connected;
	}

	public void setConnected(boolean connected) {
		this.connected = connected;
	}

	public ZMQ.Context getCxt() {
		return cxt;
	}

	public void setCxt(ZMQ.Context cxt) {
		this.cxt = cxt;
	}

	public int getSocketType() {
		return socketType;
	}

	public void setSocketType(int socketType) {
		this.socketType = socketType;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddresskey() {
		return addresskey;
	}

	public void setAddresskey(String addresskey) {
		this.addresskey = addresskey;
	}

	public boolean isBind() {
		return isBind;
	}

	public void setBind(boolean isBind) {
		this.isBind = isBind;
	}

	public boolean isNewMaster() {
		return newMaster;
	}

	public void setNewMaster(boolean newMaster) {
		this.newMaster = newMaster;
	}

}

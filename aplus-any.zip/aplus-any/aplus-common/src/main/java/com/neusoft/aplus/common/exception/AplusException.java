package com.neusoft.aplus.common.exception;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neusoft.aplus.common.exception.biz.service.bo.IMessageService;
import com.neusoft.aplus.common.exception.internationalize.Trace;
import com.neusoft.aplus.common.spring.ApplicationContextFactory;

/**
 * 异常的基类
 * 
 * @author guo.tc
 * @date 2014-6-23 下午1:34:08
 */
public abstract class AplusException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	private final static Logger log = LoggerFactory.getLogger(AplusException.class);

	// Add by WanWei 2014-6-26 19:38 增加一些常量和工具方法
	// 子系统代号
	// 平台代号
	public static final String ID_PLATFORM = "pfm";

	// ITSM前台代号
	public static final String ID_ITSM_WEB = "itsw";

	// ITSM后台代号
	public static final String ID_ITSM_SERVER = "itss";

	// A+E后台代号
	public static final String ID_AE_SERVER = "aes";

	// DataBus代号
	public static final String ID_DATABUS = "databus";
	// TODO 添加其他子系统代号

	// 异常码数字部分的长度,固定为5
	private static final int CODE_NUMBER_LENGTH = 5;

	// 用来格式化数字，左侧补零
	private static NumberFormat nf = NumberFormat.getInstance();

	// 异常队列
	private static BlockingQueue<AplusException> queue = new LinkedBlockingDeque<AplusException>();

	// 异常码
	private String eCode;
	// java原生异常的堆栈信息
	private String stackMsg;
	// java原生异常
	private Exception original;
	// 异常信息需要传递的参数
	private Object[] params;
	// 一些重要的断言信息
	private Map<String, Object> keyPoints;
	// 异常说明信息
	private String errorMsg;

	// 国际化信息
	private Locale locale;

	/**
	 * 初始数字格式化工具 5位数字，左侧补零
	 * 
	 * @author WanWei
	 * @date 2014-6-26 下午7:49:03
	 */
	static {
		nf.setGroupingUsed(false);
		nf.setMaximumIntegerDigits(CODE_NUMBER_LENGTH);
		nf.setMinimumIntegerDigits(CODE_NUMBER_LENGTH);
		SaveMsg.t.start();
	}

	/**
	 * 构造方法，code不允许为空，其余参数可能设定null
	 * 
	 * @param code
	 * @param original
	 * @param params
	 * @param keyPoints
	 */
	public AplusException(String code, Exception original, Object[] params,
			Map<String, Object> keyPoints) {
		this.eCode = code;
		this.original = original;
		this.params = params;
		this.keyPoints = keyPoints;
		this.stackMsg = Trace.getStackTrace(this.original);
		// 国际化信息默认为中文，可通过setLocale()方法进行设定
		locale = new Locale("zh", "CN");
		if(this.original != null){
			//打印原始异常堆栈 Add by WanWei 2015-04-27 14:57:23
			log.error("记录原始异常堆栈", this.original);
		}
	}

	/**
	 * 提供此方法是为了规范异常码的写法,但是这么做会影响程序启动时的效率 启动时间多个几秒影响不是很大，可以忍
	 * 
	 * @param currentSystemId
	 *            子系统代号 如：ID_PLATFORM
	 * @param code
	 * @return String
	 * @author WanWei
	 * @date 2014-6-26 下午7:59:10
	 */
	public static String getFormatedNumber(String currentSystemId, int code) {
		if ((currentSystemId != null) && (!currentSystemId.isEmpty())) {
			return currentSystemId.concat(nf.format(code));
		}

		return nf.format(code);
	}

	/**
	 * 异常模块处理，保存数据到DB等
	 * 
	 * @author guo.tc
	 * @date 2014-6-23 下午5:42:39
	 */
	public final <T extends AplusException> void throwEx()
			throws AplusException {
		queue.add(this);
		throw this;
	}

	/**
	 * 获取带国际化描述信息的异常信息
	 * 
	 * @return
	 * @author WanWei
	 * @date 2014-8-4 上午11:04:44
	 */
	public String getErrorMsg() {
		try{
			if (this.errorMsg == null || this.errorMsg.isEmpty()) {
				if (params == null){
					this.errorMsg = Trace.getMessage(eCode, locale);
				} else {
					this.errorMsg = Trace.getMessage(eCode, params, locale);
				}
			}
		}catch(Exception e){
			log.error("获取国际化后的错误信息失败,请确保国际化配置文件的正确性,将返回null值", e);
		}

		return this.errorMsg;

	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * 取得原生异常堆栈信息
	 * 
	 * @return
	 * @author guo.tc
	 * @date 2014-6-23 下午5:43:36
	 */
	public String getOriginMessage() {
		return stackMsg;
	}

	/**
	 * 取得异常码
	 * 
	 * @return
	 * @author guo.tc
	 * @date 2014-6-23 下午5:44:02
	 */
	public String getEcode() {
		return this.eCode;
	}

	/**
	 * 取得传递的参数
	 * 
	 * @return
	 * @author guo.tc
	 * @date 2014-6-23 下午5:44:23
	 */
	public Object[] getParams() {
		return params;
	}

	/**
	 * 取得要保存的重要信息
	 * 
	 * @return
	 * @author guo.tc
	 * @date 2014-6-23 下午5:45:24
	 */
	public Map<String, Object> getkeyPoints() {
		return keyPoints;
	}

//	@Override
//	public String toString() {
//		String s = getClass().getName();
//		String message = getMessage();
//		return (message != null) ? (s + ": " + message) : s;
//	}

	/**
	 * 设定国际化信息的语言
	 * 
	 * @param locale
	 * @author guo.tc
	 * @date 2014-6-23 下午5:45:50
	 */
	public void setLocale(Locale locale) {
		this.locale = locale;
	}

	/**
	 * 保存信息到DB的子线程 队列中有值时进行数据保存，没有值时挂起
	 * 
	 * @author guo.tc
	 * 
	 */
	static class SaveMsg {
		static Thread t = new Thread(new Runnable() {
			public void run() {
				while (true) {
					AplusException ex = null;
					try {
						ex = queue.take();
					} catch (InterruptedException e) {
						log.error(e.getMessage(), e);//正常来说不会发生异常，即使发生也无须特殊处理
					}
					IMessageService service = ApplicationContextFactory.getBean(IMessageService.class);
					service.saveMsg(ex);
				}
			}
		});
	}

	@Override
	public String toString() {
		return getErrorMsg() + "\n" + super.toString();
	}
}

package com.neusoft.aplus.common.base;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.restlet.Context;
import org.restlet.Response;
import org.restlet.data.ChallengeScheme;
import org.restlet.data.CharacterSet;
import org.restlet.data.Language;
import org.restlet.data.MediaType;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.ext.xml.DomRepresentation;
import org.restlet.representation.ObjectRepresentation;
import org.restlet.representation.Representation;
import org.restlet.representation.StringRepresentation;
import org.restlet.resource.ClientResource;

import com.neusoft.aplus.common.exception.AplusException;
import com.neusoft.aplus.common.exception.RestException;

/**
 * 本类封装发送REST请求的客户端，提供其相关功能
 * 
 * @author WanWei
 * 
 */
public class RestClient {

	private final static Logger log = Logger.getLogger(RestClient.class);

	private Protocol protocol = Protocol.HTTP;// 默认协议为HTTP

	private String userId;

	private String secret;

	private int timeout = 60000;// 超时时间默认为60秒

	public RestClient() {
	}

	public RestClient(Protocol protocol) {
		this.protocol = protocol;
	}

	public void setUser(String userId, String secret) {
		this.userId = userId;
		this.secret = secret;
	}

	/**
	 * 设定请求超时时间
	 * 
	 */
	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	/**
	 * 发送Post请求
	 * 
	 * @param uri
	 * @param data
	 * @return Response
	 * @author WanWei
	 * @date 2014-12-5 下午7:55:26
	 */
	public Response post(Reference uri, Representation data) {
		ClientResource client = createClient(uri);
		try {
			client.post(data);
			return getCloneResponse(client);
		} catch (RuntimeException e) {
			throw e;
		} catch (Error e) {
			throw e;
		} finally {
			if (client != null) {
				client.release();
			}
		}
	}
	
	public Response post(Reference uri, Object data) {
		ClientResource client = createClient(uri);
		try {
			client.post(data);
			return getCloneResponse(client);
		} catch (RuntimeException e) {
			throw e;
		} catch (Error e) {
			throw e;
		} finally {
			if (client != null) {
				client.release();
			}
		}
	}
	
	public <T> Response post(Reference uri, Object data, Class<T> clazz) {
		ClientResource client = createClient(uri);
		try {
			client.post(data);
			return getCloneResponse(client);
		} catch (RuntimeException e) {
			throw e;
		} catch (Error e) {
			throw e;
		} finally {
			if (client != null) {
				client.release();
			}
		}
	}

	/**
	 * 发送Get请求
	 * 
	 * @param uri
	 * @return Response
	 * @author WanWei
	 * @date 2014-12-5 下午7:58:14
	 */
	public Response get(Reference uri) {
		ClientResource client = createClient(uri);
		try {
			client.get();
			return getCloneResponse(client);
		} catch (RuntimeException e) {
			throw e;
		} catch (Error e) {
			throw e;
		} finally {
			if (client != null) {
				client.release();
			}
		}
	}

	/**
	 * 发送Delete请求
	 * 
	 * @param uri
	 * @return Response
	 * @author WanWei
	 * @date 2014-12-5 下午7:59:04
	 */
	public Response delete(Reference uri) {
		ClientResource client = createClient(uri);
		try {
			client.delete();
			return getCloneResponse(client);
		} catch (RuntimeException e) {
			throw e;
		} catch (Error e) {
			throw e;
		} finally {
			if (client != null) {
				client.release();
			}
		}
	}

	/**
	 * 发送Put请求
	 * 
	 * @param uri
	 * @param data
	 * @return Response
	 * @author WanWei
	 * @date 2014-12-5 下午7:59:45
	 */
	public Response put(Reference uri, Representation data) {
		ClientResource client = createClient(uri);
		try {
			client.put(data);
			return getCloneResponse(client);
		} catch (RuntimeException e) {
			throw e;
		} catch (Error e) {
			throw e;
		} finally {
			if (client != null) {
				client.release();
			}
		}
	}

	/**
	 * 创建ClientResource，并设置默认参数
	 * 
	 * @param uri
	 * @return ClientResource
	 * @author WanWei
	 * @date 2014-6-6 下午3:40:28
	 */
	private ClientResource createClient(Reference uri) {
		ClientResource client = new ClientResource(new Context(), uri);

		client.setRetryAttempts(0);
		client.setProtocol(protocol);
		client.getContext().getParameters()
				.add("socketTimeout", String.valueOf(timeout));
		if (userId != null) {
			client.setChallengeResponse(ChallengeScheme.HTTP_BASIC, userId,
					(secret == null ? userId : secret));
		}
		return client;
	}

	/**
	 * 克隆Response
	 * 
	 * @param client
	 * @return Response
	 * @author WanWei
	 * @date 2014-12-5 下午8:00:19
	 */
	private Response getCloneResponse(ClientResource client) {
		Response clone = new Response(client.getRequest());
		Response clientResp = client.getResponse();

		// TODO 以下代码内容需要验证 Add by WanWei 2015-03-18 17:51:45
		Throwable throwable = clientResp.getStatus().getThrowable();
		if (throwable != null && (throwable instanceof AplusException)) {
			throw (AplusException) throwable;
		}
		// end

		clone.setStatus(clientResp.getStatus());
		clone.setDate(clientResp.getDate());

		Representation representation = clientResp.getEntity();

		try {
			if (MediaType.APPLICATION_JAVA_OBJECT.isCompatible(representation
					.getMediaType())
					|| MediaType.APPLICATION_JAVA_OBJECT_XML
							.isCompatible(representation.getMediaType())) {

				ObjectRepresentation<?> obj = new ObjectRepresentation<Serializable>(
						representation);
				Serializable serializable = obj.getObject();
				obj = new ObjectRepresentation<Serializable>(serializable);
				clone.setEntity(obj);
			} else if (MediaType.TEXT_PLAIN.isCompatible(representation
					.getMediaType())) {
				StringRepresentation stringRep = new StringRepresentation(
						representation.getText(),
						representation.getMediaType(), Language.ALL,
						representation.getCharacterSet());
				clone.setEntity(stringRep);
			} else if (MediaType.APPLICATION_XML.isCompatible(representation
					.getMediaType())
					|| MediaType.TEXT_XML.isCompatible(representation
							.getMediaType())) {
				DomRepresentation domRep = new DomRepresentation(representation);
				org.w3c.dom.Document document = domRep.getDocument();
				domRep = new DomRepresentation(representation.getMediaType(),
						document);
				domRep.getLanguages().add(Language.ALL);
				domRep.setCharacterSet(CharacterSet.UTF_8);
				clone.setEntity(domRep);
			} else if (MediaType.APPLICATION_JSON.isCompatible(representation
					.getMediaType())) {
				JsonRepresentation jsonRep = null;
				String jsonText = representation.getText();
				try {
					jsonRep = new JsonRepresentation(jsonText);
					JSONArray obj = jsonRep.getJsonArray();
					jsonRep = new JsonRepresentation(obj);
				} catch (Exception e) {
					log.warn("返回数据为JSONobject");
					jsonRep = new JsonRepresentation(jsonText);
					JSONObject obj = jsonRep.getJsonObject();
					jsonRep = new JsonRepresentation(obj);
				}

				jsonRep.getLanguages().add(Language.ALL);
				jsonRep.setCharacterSet(CharacterSet.UTF_8);
				clone.setEntity(jsonRep);
			}

			clone.setServerInfo(clientResp.getServerInfo());
			clone.setAge(clientResp.getAge());
			clone.setAllowedMethods(clientResp.getAllowedMethods());
			clone.setAttributes(clientResp.getAttributes());
			clone.setAuthenticationInfo(clientResp.getAuthenticationInfo());
			clone.setCacheDirectives(clientResp.getCacheDirectives());
			clone.setCommitted(clientResp.isCommitted());
			clone.setCookieSettings(clientResp.getCookieSettings());
			clone.setDimensions(clientResp.getDimensions());
			clone.setLocationRef(clientResp.getLocationRef());
			clone.setOnSent(clientResp.getOnSent());
			clone.setProxyChallengeRequests(clientResp
					.getProxyChallengeRequests());
			clone.setRecipientsInfo(clientResp.getRecipientsInfo());
			clone.setRequest(clientResp.getRequest());
			clone.setRetryAfter(clientResp.getRetryAfter());
			clone.setWarnings(clientResp.getWarnings());

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			clone.setStatus(clientResp.getStatus(), e);
			RestException
					.throwException(
							RestException.CODE_REST_EXCEPTION_CLIENT_RESPONSE_CLONE_FAIL,
							e, null, null);
		}
		return clone;
	}
}

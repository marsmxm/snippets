package com.neusoft.aplus.common.event;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 触发事件链执行类
 * 
 * @author zh_ch
 * @param <T>
 * @date 2014-12-16 下午3:09:49
 */
public class EChainHandler<T> {
	private static final ExecutorService exec = Executors.newCachedThreadPool();

	private EventChain<T> chain;

	public EChainHandler() {
	}

	public EChainHandler(EventChain<T> evnetChain) {
		this.chain = evnetChain;
	}

	public EventChain<T> getChain() {
		return chain;
	}

	public void setChain(EventChain<T> chain) {
		this.chain = chain;
	}

	/**
	 * 触发事件链开始执行方法
	 * 
	 * @param input
	 *            事件链输入
	 * @param output
	 *            事件链输出
	 * @param isSync
	 *            是否同步执行，Boolean.FALSE为异步执行，Boolean.TRUR为同步执行
	 * @param events
	 *            构成事件链的事件集合
	 * @author zh_ch
	 * @date 2014-12-16 下午5:11:30
	 */
	@SuppressWarnings("unchecked")
	public void addAndFireEvents(Input input, Output output, Boolean isSync,
			Event... events) {
		if (chain == null) {
			chain = (EventChain<T>) new DefaultEventChain(input, output);
		}
		chain.addEvents(events);
		if (isSync.equals(Boolean.TRUE)) {
			chain.fireEvents(chain);
		} else {
			exec.submit((Callable<?>) chain);
		}
	}

	@SuppressWarnings("unchecked")
	public void addAndFireEvents(Input input, Output output, Boolean isSync,
			List<Event> events) {
		if (chain == null) {
			chain = (EventChain<T>) new DefaultEventChain(input, output);
		}
		chain.addEvents(events);
		if (isSync.equals(Boolean.TRUE)) {
			chain.fireEvents(chain);
		} else {
			exec.submit((Callable<?>) chain);
		}
	}

	public void addAndFireEventsSync(Input input, Output output,
			Event... events) {
		addAndFireEvents(input, output, Boolean.TRUE, events);
	}

	public void addAndFireEventsSync(Input input, Output output,
			List<Event> events) {
		addAndFireEvents(input, output, Boolean.TRUE, events);
	}

	public void addAndFireEventsASync(Input input, Output output,
			Event... events) {
		addAndFireEvents(input, output, Boolean.FALSE, events);
	}

	public void addAndFireEventsASync(Input input, Output output,
			List<Event> events) {
		addAndFireEvents(input, output, Boolean.FALSE, events);
	}

	public void addAndFireEventsSync(Input input, Event... events) {
		addAndFireEvents(input, null, Boolean.TRUE, events);
	}

	public void addAndFireEventsSync(Input input, List<Event> events) {
		addAndFireEvents(input, null, Boolean.TRUE, events);
	}

	public void addAndFireEventsASync(Input input, Event... events) {
		addAndFireEvents(input, null, Boolean.FALSE, events);
	}

	public void addAndFireEventsASync(Input input, List<Event> events) {
		addAndFireEvents(input, null, Boolean.FALSE, events);
	}
}

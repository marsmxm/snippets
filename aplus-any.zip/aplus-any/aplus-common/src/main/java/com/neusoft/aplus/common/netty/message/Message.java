package com.neusoft.aplus.common.netty.message;

import com.neusoft.aplus.common.util.JSONUtil;

/**
 * Command, Reply的基类，目的是便于
 * MessageWrapperEncoder对Message衍生类的处理
 * 
 * @author Mu Xian Ming
 * @date 2015年2月3日 下午3:52:56
 */
public abstract class Message {
	@Override
	public String toString() {
		return JSONUtil.getJsonString(this);
	}
}

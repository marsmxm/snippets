package com.neusoft.aplus.common.zmq.topic;

/**
 * 发布订阅模式配置类
 *
 * @author zh_ch
 * @date 2014-12-25 下午2:07:46
 */
public class TopicConf {
	// proxy
	private String frontend; // Pub-Sub代理前端地址
	private String backend; // Pub-Sub代理后端地址

	// 高可用模式下，需要用到的req-rep通信端口
	private String proxyResp;


	// pub
	private String respend; // pub端用来接收req的地址
	private Integer subscriberCnt; // 进程启动时客户端数量
	private Long sendHwm; // pub端缓存

	// sub
	private String subscription; // 订阅主题
	private Boolean isProxyStarter;

	public TopicConf() {
	}

	public TopicConf(String frontend, String backend, String respend,
					 Integer subscriberCnt, String subscription, String proxyResp, Long sendHwm,
					 Boolean isProxyStarter) {
		super();
		this.frontend = frontend;
		this.backend = backend;
		this.proxyResp = proxyResp;
		this.respend = respend;
		this.subscriberCnt = subscriberCnt;
		this.subscription = subscription;
		this.sendHwm = sendHwm;
		this.isProxyStarter = isProxyStarter;
	}

	public String getProxyResp() {
		return proxyResp;
	}

	public void setProxyResp(String proxyResp) {
		this.proxyResp = proxyResp;
	}

	public Integer getSubscriberCnt() {
		return subscriberCnt;
	}

	public void setSubscriberCnt(Integer subscriberCnt) {
		this.subscriberCnt = subscriberCnt;
	}

	public Long getSendHwm() {
		return sendHwm;
	}

	public void setSendHwm(Long sendHwm) {
		this.sendHwm = sendHwm;
	}

	public String getSubscription() {
		return subscription;
	}

	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}

	public String getFrontend() {
		return frontend;
	}

	public void setFrontend(String frontend) {
		this.frontend = frontend;
	}

	public String getBackend() {
		return backend;
	}

	public void setBackend(String backend) {
		this.backend = backend;
	}

	public String getRespend() {
		return respend;
	}

	public void setRespend(String respend) {
		this.respend = respend;
	}

	public Boolean getIsProxyStarter() {
		return isProxyStarter;
	}

	public void setIsProxyStarter(Boolean isProxyStarter) {
		this.isProxyStarter = isProxyStarter;
	}

	@Override
	public String toString() {
		return "TopicConf [frontend=" + frontend + ", backend=" + backend
				+ ", respend=" + respend + ", subscriberCnt=" + subscriberCnt
				+ ", sendHwm=" + sendHwm + ", subscription=" + subscription
				+ ", isProxyStarter=" + isProxyStarter + "]";
	}
}

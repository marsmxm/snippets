package com.neusoft.aplus.common.zmq.client.api;

import com.neusoft.aplus.common.zmq.model.ZMQMessage;

/**
 * 发布者接口
 */
public interface Publisher {
	/**
	 * 发送消息，若topic设置为null或空字符串""，则抛出异常
	 * 
	 * @param topic
	 * @param msg
	 * @return
	 * @author MaHan
	 * @date 2015年5月27日
	 */
	public Boolean send(String topic, String msg);

	/**
	 * 发送消息，若topic设置为null或空字符串""，则抛出异常
	 * 
	 * @param topic
	 * @param msg
	 * @return
	 * @author MaHan
	 * @date 2015年5月27日
	 */
	public Boolean send(String topic, byte[] msg);

	/**
	 * 发送消息，若topic设置为null或空字符串""，则抛出异常，主题以topic为准，若topic与msg中的主题不同，
	 * 则msg中的主题会被设置为topic
	 * 
	 * @param topic
	 * @param msg
	 * @return
	 * @author zhangjian
	 * @data 2015年6月3日 下午4:46:34
	 */
	public Boolean send(String topic, ZMQMessage msg);
}

package com.neusoft.aplus.common.base;

import org.apache.log4j.Logger;
import org.restlet.Response;
import org.restlet.data.Reference;
import org.restlet.data.Status;
import org.restlet.representation.Representation;
import org.restlet.resource.ResourceException;
import com.neusoft.aplus.common.config.ForwardPoint;

/**
 * 请求转发类 
 * 服务接收到不需要自身处理的请求时，转发至Aclome CSS处理
 * 
 * @author WanWei
 * @date 2014-6-6 下午3:33:04
 */
public class ForwardAction extends BaseAction {
	
	private static Logger log = Logger.getLogger(ForwardAction.class);
	
	private Reference url;
	
	
	private RestClient client = new RestClient();
	
	@Override
	public void doInit() {
		url = this.getReference();
		setExisting(true);
	}
	
	public void acceptRepresentation(Representation entity)
			throws ResourceException {
		try{
		
			Reference reUrl = filterReURL(url);
			client.setUser(getUserId(), null);
			Response response = client.post(reUrl,entity);	
			this.getResponse().setEntity(response.getEntity());
		}catch(Exception e){
			log.error("不识别传递的数据类型,请确定是否引入需要录制的服务的相关jar", e);
			this.getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
		}
	}

	public  Representation represent() throws ResourceException {
		Reference reUrl = filterReURL(url);
		client.setUser(getUserId(), null);
		return client.get(reUrl).getEntity();
	}

	public void removeRepresentations() throws ResourceException {
		client.setUser(getUserId(), null);
		Response response = client.delete(url);
		this.getResponse().setEntity(response.getEntity());
	}

	public void storeRepresentation(Representation entity)
			throws ResourceException {
		try{
			Reference reUrl = filterReURL(url);
			client.setUser(getUserId(), null);
			Response response = client.put(reUrl, entity);
			this.getResponse().setEntity(response.getEntity());
		}catch(Exception e){
			log.error("不识别传递的数据类型,请确定是否引入需要录制的服务的相关jar", e);
			this.getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
		}
	}
	
	/**
	 * 得到真正服务器的url
	 * 
	 * @return String
	 */
	private Reference filterReURL(Reference url){
		String reUrl = url.toString();
		String newIpPort = ForwardPoint.getForwardPath();
		if(!newIpPort.isEmpty()){
			reUrl = reUrl.replace("http://", "");
			int subIndex = reUrl.indexOf("/");
			String oldIpPort = reUrl.substring(0,subIndex);
			reUrl = url.toString().replace(oldIpPort, newIpPort);
		}
		log.info("reUrl == "+reUrl);
		return new Reference(reUrl);//"http://10.4.55.21:8182/api/aclome/virtualcenter/control/resource/23.93c6b0d4-ba06-3b99-efcb-b07119a443af/resourcetype/VM/env/XENSERVER/action/FORCE_STOP");
	}
}

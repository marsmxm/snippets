package com.neusoft.aplus.common.zmq.topic;

import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.zeromq.ZMQ;
import org.zeromq.ZMQ.Context;
import org.zeromq.ZMQ.PollItem;
import org.zeromq.ZMQ.Poller;

import com.google.common.base.Objects;
import com.google.common.collect.Sets;
import com.neusoft.aplus.common.util.AplusStringUtils;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.ZMQException;

/**
 * Pub-Sub模式中的pub，提供Proxy初始化，pub初始化，消息发送等
 * 
 * @author zh_ch
 * @date 2014-12-25 下午2:26:13
 */
public final class Publisher {
	private static Logger logger = Logger.getLogger(Publisher.class);
	private ZMQ.Context ctx;
	private ZMQ.Socket pub;
	private ZMQ.Socket rep;
	private TopicConf topicConf;

	public Publisher() {
	}

	public Publisher(Context ctx, TopicConf topicConf) {
		super();
		this.ctx = ctx;
		this.topicConf = topicConf;
	}

	public TopicConf getTopicConf() {
		return topicConf;
	}

	public void setTopicConf(TopicConf topicConf) {
		this.topicConf = topicConf;
	}

	public ZMQ.Context getCtx() {
		return ctx;
	}

	public void setCtx(ZMQ.Context ctx) {
		this.ctx = ctx;
	}

	/**
	 * 初始化proxy,向客户端发送hello请求，等待所有sub端连接成功
	 * 
	 * @return
	 * @author zh_ch
	 * @date 2014-12-25 下午9:14:33
	 */
	public Publisher waitForSendMsg() {
		checkAddrsForPub();
		pub = ctx.socket(ZMQ.PUB);
		pub.connect(topicConf.getFrontend());
		if (checkSendHwn()) {
			pub.setHWM(topicConf.getSendHwm());
		}

		rep = ctx.socket(ZMQ.REP);
		rep.bind(topicConf.getRespend());

		if (!checkSubscriberCnt()) {
			return this;
		}
		waitForSubRegistion();
		return this;
	}

	/**
	 * 发送字符串
	 * 
	 * @param data
	 * @return
	 * @author zh_ch
	 * @date 2014-12-26 上午11:47:18
	 */
	public Boolean send(String data) {
		return pub.send(data);
	}

	/**
	 * 销毁上下文
	 * 
	 * @author zh_ch
	 * @date 2014-12-26 上午11:48:37
	 */
	public void destory() {
		pub.close();
		rep.close();
		ctx.term();
	}

	/**
	 * 等待所有sub端连接到pub/sub proxy上
	 * 
	 * @author zh_ch
	 * @date 2014-12-27 上午11:00:57
	 */
	private void waitForSubRegistion() {
		Set<String> subs = Sets.newConcurrentHashSet();
		PollItem[] items = new PollItem[] { new PollItem(rep, Poller.POLLIN) };
		while (!Thread.currentThread().isInterrupted()) {
			pub.send(ZMQConst.TOPIC_HELLO + ZMQConst.SEPERATOR + topicConf.getRespend());
			handleRegMsgFromSub(items, subs);
			if (subs.size() >= topicConf.getSubscriberCnt().intValue()) {
				break;
			}
		}
	}

	/**
	 * 处理sub端发送过来的注册信息
	 * 
	 * @param items
	 * @param subs
	 * @author zh_ch
	 * @date 2014-12-30 上午11:05:21
	 */
	private void handleRegMsgFromSub(PollItem[] items, Set<String> subs) {
		// 每10mspoll一次，100次(1s)后无法等到所有sub注册，再发一次pub sayhello
		for (int tick = 0; tick < 100; tick++) {
			Integer readableCnt = ZMQ.poll(items, 10);
			if (readableCnt == -1) {
				break;
			}
			if (items[0].isReadable()) {
				String rev = rep.recvStr();
				rep.send(ZMQConst.TOPIC_OK);
				if (rev.startsWith(ZMQConst.TOPIC_READY)) {
					subs.add(AplusStringUtils.parseStr(rev, ZMQConst.SEPERATOR, 1));
				}
			}
		}
	}

	/**
	 * 检查pub端相关地址的合法性
	 * 
	 * @author zh_ch
	 * @date 2014-12-27 上午10:41:05
	 */
	private void checkAddrsForPub() {
		if (StringUtils.isBlank(topicConf.getFrontend())) {
			ZMQException.throwException(ZMQException.FRONTEND_NULL);
		}

		if (StringUtils.isBlank(topicConf.getRespend())) {
			ZMQException.throwException(ZMQException.PUB_RESPEND_NULL);
		}
	}

	/**
	 * 检查是否设置了sun端数量，不同设置采取不同策略
	 * 
	 * @return
	 * @author zh_ch
	 * @date 2014-12-27 上午10:41:44
	 */
	private Boolean checkSubscriberCnt() {
		if (Objects.equal(null, topicConf.getSubscriberCnt())
				|| topicConf.getSubscriberCnt().intValue() <= 0) {
			logger.warn("SubscriberCnt from [Publisher] may be invalid(null or <=0)");
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}

	/**
	 * 检查是否设置了sendHwm，不同设置采取不同策略
	 * 
	 * @return
	 * @author zh_ch
	 * @date 2014-12-27 上午10:42:32
	 */
	private Boolean checkSendHwn() {
		if (Objects.equal(null, topicConf.getSendHwm())
				|| topicConf.getSendHwm().intValue() <= 0) {
			logger.warn("SendHwm from [Publisher] may be invalid(null or <=0)");
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}
}

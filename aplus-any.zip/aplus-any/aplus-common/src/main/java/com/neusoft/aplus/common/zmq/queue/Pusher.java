package com.neusoft.aplus.common.zmq.queue;

import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.zeromq.ZMQ;
import org.zeromq.ZMQ.Context;

import com.google.common.base.Objects;
import com.google.common.collect.Sets;
import com.neusoft.aplus.common.util.AplusStringUtils;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.ZMQException;

/**
 * Queue模式push端，推送消息给pull端
 * 
 * @author zh_ch
 * @date 2014-12-27 下午1:12:03
 */
public final class Pusher {
	private ZMQ.Context ctx;
	private ZMQ.Socket push;
	private ZMQ.Socket rep;
	private QueueConf queueConf;

	public Pusher() {

	}

	public Pusher(Context ctx, QueueConf queueConf) {
		super();
		this.ctx = ctx;
		this.queueConf = queueConf;
	}

	public ZMQ.Context getCtx() {
		return ctx;
	}

	public void setCtx(ZMQ.Context ctx) {
		this.ctx = ctx;
	}

	public ZMQ.Socket getPush() {
		return push;
	}

	public void setPush(ZMQ.Socket push) {
		this.push = push;
	}

	public ZMQ.Socket getRep() {
		return rep;
	}

	public void setRep(ZMQ.Socket rep) {
		this.rep = rep;
	}

	public QueueConf getQueueConf() {
		return queueConf;
	}

	public void setQueueConf(QueueConf queueConf) {
		this.queueConf = queueConf;
	}

	/**
	 * 等待所有pull端连接到push端
	 * 
	 * @return
	 * @author zh_ch
	 * @date 2014-12-27 下午1:41:00
	 */
	public Pusher waitForSendMsg() {
		checkAddrForPush();
		push = ctx.socket(ZMQ.PUSH);
		push.bind(queueConf.getPushend());
		rep = ctx.socket(ZMQ.REP);
		rep.bind(queueConf.getRespend());
		if (!checkPullersCnt()) {
			return this;
		}

		return waitForPullerRegistion();
	}

	/**
	 * push端发送消息
	 * 
	 * @param data
	 * @return Boolean.TRUE 发送成功 Boolean.FALSE 发送失败
	 * @author zh_ch
	 * @date 2014-12-27 下午1:50:48
	 */
	public Boolean send(String data) {
		return push.send(data);
	}

	/**
	 * 等待所有pull端注册到push端的私有方法
	 * 
	 * @return
	 * @author zh_ch
	 * @date 2014-12-27 下午2:46:38
	 */
	private Pusher waitForPullerRegistion() {
		Set<String> pullers = Sets.newConcurrentHashSet();
		while (!Thread.currentThread().isInterrupted()) {
			push.send(ZMQConst.QUEUE_HELLO);
			String recv = rep.recvStr();
			rep.send(ZMQConst.QUEUE_OK);
			if (recv.startsWith(ZMQConst.QUEUE_READY)) {
				String pullName = AplusStringUtils.parseStr(recv, ZMQConst.SEPERATOR, 1);
				pullers.add(pullName);
			}

			if (pullers.size() >= queueConf.getPullerCnt().intValue()) {
				break;
			}
		}
		return this;
	}

	/**
	 * 销毁上下文
	 * 
	 * @author zh_ch
	 * @date 2014-12-27 下午4:57:46
	 */
	public void destory() {
		push.close();
		rep.close();
		ctx.term();
	}

	/**
	 * 检查客户端
	 * 
	 * @author zh_ch
	 * @date 2014-12-27 下午4:32:24
	 */
	private void checkAddrForPush() {
		if (StringUtils.isBlank(queueConf.getPushend())) {
			ZMQException.throwException(ZMQException.PUSHEND_NULL);
		}

		if (StringUtils.isBlank(queueConf.getRespend())) {
			ZMQException.throwException(ZMQException.PUSH_RESPEND_NULL);
		}
	}

	/**
	 * 检查是否设置了puller端的值，根据是否设置采取不同push/pull策略
	 * 
	 * @return
	 * @author zh_ch
	 * @date 2014-12-27 下午4:39:19
	 */
	private Boolean checkPullersCnt() {
		if (Objects.equal(null, queueConf.getPullerCnt())
				|| queueConf.getPullerCnt().intValue() <= 0) {
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}
}

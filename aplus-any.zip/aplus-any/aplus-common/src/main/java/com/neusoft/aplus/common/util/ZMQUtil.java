package com.neusoft.aplus.common.util;

import java.util.UUID;

import com.alibaba.fastjson.JSON;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;
import com.neusoft.aplus.common.zmq.topic.Publisher;

/**
 * @author Mu Xian Ming
 * @date 2015年3月4日 上午9:36:17
 */
public class ZMQUtil {
	private static final String MSG_SEP = ";;";
	
	public static void publish(Publisher pub, ZMQMessage msg) {
		pub.send(msg.getTopic() + MSG_SEP + JSON.toJSONString(msg));
	}
	
	public static ZMQMessage parse(String msg) {
		return JSON.parseObject(msg.split(MSG_SEP)[1], ZMQMessage.class);
	}
	
	/**
	 * 为存入数据库的消息生成id
	 * @return id
	 * @author MaHan
	 * @date 2015年5月6日
	 */
	public static String generateId(){
		return UUID.randomUUID().toString();
	}
}

package com.neusoft.aplus.common.spring;

import java.io.File;

import org.apache.commons.io.FilenameUtils;


/**
 * @author zh_ch
 * @date 2015-2-9 下午3:18:56
 */
public class PathConst {
	public static final String BASE_PATH = "/aplus-launch/src/main/resources/spring/common";
	public static final String COMMON_PAHT =  BASE_PATH + "/applicationContext-common.xml";

	public static final String DATASOURCE_PATH = BASE_PATH+ "/applicationContext-datasource.xml";
	public static final String PROPERTY_PATH = BASE_PATH + "/applicationContext-properties.xml";
	public static final String FILE_PREFIX = FilenameUtils
			.getFullPath(new File("").getAbsolutePath());
	public static final String[] FILES = { FILE_PREFIX + PathConst.COMMON_PAHT,
			FILE_PREFIX + PathConst.DATASOURCE_PATH,
			FILE_PREFIX + PathConst.PROPERTY_PATH };
}

package com.neusoft.aplus.common.config;

import java.util.Map;

/**
 * @author zh_ch
 * @date 2015年6月15日 上午9:20:06
 */
public final class NettyClientConf {
	private Map<String, String> type2Protocol;
	private Map<String, String> cmdProcConf;
	private Map<String, String> nettyConf;
	private Integer dataPushPeriod; // second
	private Integer dataCollectThreads; // 采集任务的线程数量
	private Integer dataPushTaskMaxNum; // 采集推送任务的最大数量
	private String pluginDir;
	private String pluginTemplateDir;
	// 河北钢铁相关
	private Integer TCPPort;
	private Integer UDPPort;
	private String typeUDPSteelDevice;
	private String versionUDPSteelDevice;
	private String typeUDPSteelZone;
	private String versionUDPSteelZone;
	private Integer UDPSteelRetries;

	public Map<String, String> getType2Protocol() {
		return type2Protocol;
	}

	public void setType2Protocol(Map<String, String> type2Protocol) {
		this.type2Protocol = type2Protocol;
	}

	public Map<String, String> getCmdProcConf() {
		return cmdProcConf;
	}

	public void setCmdProcConf(Map<String, String> cmdProcConf) {
		this.cmdProcConf = cmdProcConf;
	}

	public Map<String, String> getNettyConf() {
		return nettyConf;
	}

	public void setNettyConf(Map<String, String> nettyConf) {
		this.nettyConf = nettyConf;
	}

	public Integer getDataPushPeriod() {
		return dataPushPeriod;
	}

	public void setDataPushPeriod(Integer dataPushPeriod) {
		this.dataPushPeriod = dataPushPeriod;
	}

	public Integer getDataCollectThreads() {
		return dataCollectThreads;
	}

	public void setDataCollectThreads(Integer dataCollectThreads) {
		this.dataCollectThreads = dataCollectThreads;
	}

	public Integer getDataPushTaskMaxNum() {
		return dataPushTaskMaxNum;
	}

	public void setDataPushTaskMaxNum(Integer dataPushTaskMaxNum) {
		this.dataPushTaskMaxNum = dataPushTaskMaxNum;
	}

	public String getPluginDir() {
		return pluginDir;
	}

	public void setPluginDir(String pluginDir) {
		this.pluginDir = pluginDir;
	}

	public String getPluginTemplateDir() {
		return pluginTemplateDir;
	}

	public void setPluginTemplateDir(String pluginTemplateDir) {
		this.pluginTemplateDir = pluginTemplateDir;
	}

	public Integer getUDPPort() {
		return UDPPort;
	}

	public void setUDPPort(Integer UDPPort) {
		this.UDPPort = UDPPort;
	}

	public String getTypeUDPSteelDevice() {
		return typeUDPSteelDevice;
	}

	public void setTypeUDPSteelDevice(String typeUDPSteelDevice) {
		this.typeUDPSteelDevice = typeUDPSteelDevice;
	}

	public String getVersionUDPSteelDevice() {
		return versionUDPSteelDevice;
	}

	public void setVersionUDPSteelDevice(String versionUDPSteelDevice) {
		this.versionUDPSteelDevice = versionUDPSteelDevice;
	}

	public String getTypeUDPSteelZone() {
		return typeUDPSteelZone;
	}

	public void setTypeUDPSteelZone(String typeUDPSteelZone) {
		this.typeUDPSteelZone = typeUDPSteelZone;
	}

	public String getVersionUDPSteelZone() {
		return versionUDPSteelZone;
	}

	public void setVersionUDPSteelZone(String versionUDPSteelZone) {
		this.versionUDPSteelZone = versionUDPSteelZone;
	}

	public Integer getUDPSteelRetries() {
		return UDPSteelRetries;
	}

	public void setUDPSteelRetries(Integer UDPSteelRetries) {
		this.UDPSteelRetries = UDPSteelRetries;
	}

	public Integer getTCPPort() {
		return TCPPort;
	}

	public void setTCPPort(Integer TCPPort) {
		this.TCPPort = TCPPort;
	}

	// nettyConfig配置中的key值常量
	public static final class NettyConst {
		// netty服务端的相关配置key
		public static final String NETTY_SERVER_PORT = "hostPort";
		public static final String NETTY_SERVER_IP = "hostIp";
		public static final String NETTY_CLIENT_IP = "clientIp";
		public static final String NETTY_CLIENT_Port = "clientPort";
		public static final String IS_NETTY_SERVER_SSL = "SSL";
	}

	// commandProcessConfig配置中的key值常量
	public static final class CmdProcConst {
		public static final String CMD_KEY_DB_METRIC = "metricEntityCommand";
		public static final String CMD_KEY_DB_CONN = "connEntityCommand";
		public static final String CMD_KEY_DB_DEVICE = "deviceEntityCommand";
		public static final String CMD_KEY_DB_ACTION = "actionEntityCommand";
		public static final String CMD_KEY_DB_DEVICE_ATTR = "deviceAttrEntityCommand";
		public static final String CMD_KEY_DB_DEVICE_PARENT = "deviceParentEntityCommand";
		public static final String CMD_KEY_DB_I18N = "deviceI18NEntityCommand";
		public static final String CMD_KEY_SYNC_METRIC = "metricSyncCommand";
		public static final String CMD_KEY_SYNC_ACTION = "actionSyncCommand";
	}

	// commandProcessConfig配置中的key值常量
	public static final class MetricInfoKey {
		public static final String PASSWORD1 = "password1";
		public static final String PASSWORD2 = "password2";
		public static final String PASSWORD3 = "password3";
		public static final String PASSWORD4 = "password4";
		public static final String PASSWORD5 = "password5";
		public static final String PASSWORD6 = "password6";
		public static final String ARMING = "arming";
		public static final String OUTPUT_CODE = "outputCode";
		public static final String OUTPUT_STATUS = "outputStatus";
		public static final String ACTION_TIME= "actionTime";
		public static final String LAMP_CODE = "lampCode";
		public static final String LAMP_STATUS= "lampsStatus";
		public static final String TOTAL_TIME= "totalTime";
		public static final String RING_TIME = "ringTime";
		public static final String STOP_TIME= "stopTime";
		
	}
}

//package com.neusoft.aplus.common.zmq.biz.bo.impl;
//
//import com.neusoft.aplus.common.util.JSONUtil;
//import com.neusoft.aplus.common.util.ZMQUtil;
//import com.neusoft.aplus.common.zmq.biz.bo.JMSMsgBo;
//import com.neusoft.aplus.common.zmq.biz.dao.JMSMsgDao;
//import com.neusoft.aplus.common.zmq.model.ZMQMessage;
//import com.neusoft.aplus.model.jms.JMSMessageEntity;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
///**
// * 
// * @author MaHan
// *
// * @date 2015年5月6日
// */
//@Service
//@Transactional
//public class JMSMsgBoImpl implements JMSMsgBo {
//	
//	@Autowired
//	private JMSMsgDao jmsMsgDao;
//
//	@Override
//	@Transactional(readOnly=true)
//	public List<ZMQMessage> listAll() {
//		List<JMSMessageEntity> entityList = jmsMsgDao.listAll();
//		if(null == entityList || entityList.size()<=0)
//			return null;
//		
//		List<ZMQMessage> zmqMsgList = new ArrayList<ZMQMessage>();
//		for(JMSMessageEntity entity: entityList){
//			zmqMsgList.add(JSONUtil.getSimpleObject(entity.getContent(), ZMQMessage.class));
//		}
//		return zmqMsgList;
//	}
//
//	@Override
//	@Transactional
//	public String addMsg(ZMQMessage zmqMsg) {
//		String id = ZMQUtil.generateId();
//		zmqMsg.setUuid(id);
//		String msgContent = JSONUtil.getJsonString(zmqMsg);
//
//		JMSMessageEntity jmsMessageEntity = new JMSMessageEntity();
//		jmsMessageEntity.setContent(msgContent);
//		jmsMessageEntity.setId(id);
//		jmsMsgDao.addMsg(jmsMessageEntity);
//		
//		return id;
//	}
//
//	@Override
//	@Transactional
//	public void removeMsg(String id) {
//		jmsMsgDao.removeMsg(id);
//	}
//}

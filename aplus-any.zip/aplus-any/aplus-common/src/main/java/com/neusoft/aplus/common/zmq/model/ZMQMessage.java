package com.neusoft.aplus.common.zmq.model;

import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.model.bizentity.AplusMsgAction;

/**
 * @author Mu Xian Ming
 * @date 2015年3月3日 下午5:26:26
 */
public class ZMQMessage {
	private String topic;
	private String bodyString;
	private Class<?> bodyClass;
	private AplusMsgAction action;
	private boolean result;// control结果
	private String timeStamp;//时间戳
	private String flag;// 同一个topic，不同的动作，想当于subtopic

	public ZMQMessage() {
	}

	public ZMQMessage(String topic, String bodyString) {
		super();
		this.topic = topic;
		this.bodyString = bodyString;
	}

	public ZMQMessage(String topic, String bodyString, AplusMsgAction action) {
		super();
		this.topic = topic;
		this.bodyString = bodyString;
		this.action = action;
	}

	public ZMQMessage(String topic, String bodyString, Class<?> bodyClass) {
		super();
		this.topic = topic;
		this.bodyString = bodyString;
		this.bodyClass = bodyClass;
	}

	public ZMQMessage(String topic, String bodyString, Class<?> bodyClass,
			AplusMsgAction action, String flag) {
		super();
		this.topic = topic;
		this.bodyString = bodyString;
		this.bodyClass = bodyClass;
		this.action = action;
		this.flag = flag;
	}

	public ZMQMessage(String topic, String bodyString, boolean result,String timeStamp) {
		super();
		this.topic = topic;
		this.bodyString = bodyString;
		this.result = result;
		this.timeStamp = timeStamp;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public boolean isResult() {
		return result;
	}

	public void setResult(boolean result) {
		this.result = result;
	}
	
	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getBodyString() {
		return bodyString;
	}

	public void setBodyString(String bodyString) {
		this.bodyString = bodyString;
	}

	public Class<?> getBodyClass() {
		return bodyClass;
	}

	public void setBodyClass(Class<?> bodyClass) {
		this.bodyClass = bodyClass;
	}

	public AplusMsgAction getAction() {
		return action;
	}

	public void setAction(AplusMsgAction action) {
		this.action = action;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	@Override
	public String toString() {
		return JSONUtil.getJsonString(this);
	}
}

package com.neusoft.aplus.common.netty.basehandler;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

import java.net.InetSocketAddress;

/**
 * @author zh_ch
 * @date 2015-2-5 上午9:49:54
 */
public abstract class BaseInboundHandler<T> extends SimpleChannelInboundHandler<T>{

	@Override
	protected abstract void channelRead0(ChannelHandlerContext ctx, T msg);
	
	/**
	 * 提取远端连接本地的远端IP和端口作为channel的key
	 * @param channel
	 * @return
	 * @author zh_ch
	 * @date 2015-2-5 上午9:54:01
	 */
	protected String getChannelKey(Channel channel){
		InetSocketAddress insAdd = (InetSocketAddress)channel.remoteAddress();
		String remoteIp = insAdd.getAddress().getHostAddress();
		String port = String.valueOf(insAdd.getPort());
		String key = remoteIp.concat(":").concat(port);
		return key;
	}
}

//package com.neusoft.aplus.common.test.zmq;
//
//
//import java.util.List;
//
//import org.junit.Assert;
//import org.junit.Test;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.neusoft.aplus.common.test.BaseSpringTest;
//import com.neusoft.aplus.common.zmq.biz.bo.JMSMsgBo;
//import com.neusoft.aplus.common.zmq.model.ZMQMessage;
//
///**
// * @author MaHan
// *
// * @date 2015年5月6日
// */
//public class JMSMsgBoTest extends BaseSpringTest{
//	
//	@Test
//	@Transactional
//	public void testAdd(){
//		JMSMsgBo jmsMsgBo = getBean(JMSMsgBo.class);
//		ZMQMessage zmqMessage = new ZMQMessage();
//		zmqMessage.setTopic("topic");
//		zmqMessage.setFlag("flag");
//		zmqMessage.setBodyClass(Integer.class);
//		
//		String id = jmsMsgBo.addMsg(zmqMessage);
//		System.out.println(id);
//		Assert.assertNotNull(id);
//	}
//	
//	@Test
//	public void testList(){
//		JMSMsgBo jmsMsgBo = getBean(JMSMsgBo.class);
//		List<ZMQMessage> listAll = jmsMsgBo.listAll();
//		String id = "";
//		for(ZMQMessage zmqMsg : listAll){
//			id = zmqMsg.getUuid();
//			System.out.println(id);
//			Assert.assertNotNull(id);
//		}
//	}
//	
//	@Test
//	public void testRemove(){
//		JMSMsgBo jmsMsgBo = getBean(JMSMsgBo.class);
//		List<ZMQMessage> listAll = jmsMsgBo.listAll();
//		
//		jmsMsgBo.removeMsg(listAll.get(0).getUuid());
//		
//		List<ZMQMessage> listAll2 = jmsMsgBo.listAll();
//		Assert.assertTrue(listAll2 == null || (listAll2.size()+1)==listAll.size());
//	}
//
//}

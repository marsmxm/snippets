package com.neusoft.aplus.common.test.zmqguide.topic;

import org.junit.Test;
import org.zeromq.ZMQ;

import com.neusoft.aplus.common.util.ZMQUtil;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;
import com.neusoft.aplus.common.zmq.topic.Subscriber;
import com.neusoft.aplus.common.zmq.topic.TopicConf;

/**
 * sub端使用样例1
 * @author zh_ch
 * @date 2014-12-25 下午8:24:04
 */
@Deprecated
public class Sub1 {
	@Test
	public void test() {
		ZMQ.Context ctx = ZMQ.context(1);
		Subscriber sub = new Subscriber(ctx, buildConfig()).waitForReceiveMsg();
		System.out.println("HI, I am here(Sub1)");
		while (!Thread.currentThread().isInterrupted()) {
			String rev = sub.recvStr();
			ZMQMessage msg = ZMQUtil.parse(rev);
			System.out.println("Rev == " + msg);
		}
		
		sub.destroy();
	}
	
	public static TopicConf buildConfig() {
		/**
		 * 对于sub端，与其相关的属性为frontend、backend、subscription、subName
		 * 对于第一个启动的sub，frontend、backend为必选，这两个属性为启动
		 * pub/sun之间proxy的必选属性，对于非第一个启动的sub，backend为必选属性
		 * 
		 * subscription为可选，如果为空则默认订阅所有消息
		 * 
		 * sunName必选属性，并且每个sub端的subName不相同
		 */
		TopicConf conf = new TopicConf();
		conf.setFrontend("tcp://10.0.65.186:5000");
		conf.setBackend("tcp://10.0.65.186:5001");
		conf.setSubscription("monitordata_push_policy");
		
		return conf;
	}
}

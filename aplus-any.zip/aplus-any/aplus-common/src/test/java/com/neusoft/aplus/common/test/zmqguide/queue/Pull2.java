package com.neusoft.aplus.common.test.zmqguide.queue;

import org.junit.Test;
import org.zeromq.ZMQ;

import com.neusoft.aplus.common.zmq.queue.Puller;
import com.neusoft.aplus.common.zmq.queue.QueueConf;

/**
 * pull使用样例
 * @author zh_ch
 * @date 2014-12-27 下午5:16:34
 */
public class Pull2 {

	@Test
	public void test() {
		ZMQ.Context ctx = ZMQ.context(1);
		Puller pull = new Puller(ctx, buildConfig()).waitForReceiveMsg();
		while (!Thread.currentThread().isInterrupted()) {
			String recv = pull.recvStr();
			System.out.println("{Pull_2} is recving: " + recv);
		}

		pull.destroy();
	}

	public static QueueConf buildConfig() {
		QueueConf conf = new QueueConf();
		conf.setPullerName("Pull2");
		conf.setPushend("tcp://localhost:5000");
		conf.setRespend("tcp://localhost:5001");
		return conf;
	}

}

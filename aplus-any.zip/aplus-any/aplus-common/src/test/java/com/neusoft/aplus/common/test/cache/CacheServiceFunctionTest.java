package com.neusoft.aplus.common.test.cache;


import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.alibaba.fastjson.TypeReference;
import com.neusoft.aplus.common.cache.api.CacheService;
import com.neusoft.aplus.common.cache.api.DCacheService;
import com.neusoft.aplus.common.cache.impl.CacheServiceImpl;

/**
 * 缓存组件功能测试
 * @author MaHan
 *
 * @date 2015年4月21日
 */
public class CacheServiceFunctionTest {
	private static DCacheService dcs;
	private String myCache = "myCache";
	private String testCache = "testCache";
//	private CacheServiceTestUtil cu ;
	private static CacheService cs;

	@BeforeClass
	public static void init() {
		String configLocation = "spring/applicationContext-cachetest.xml";
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(configLocation);
		dcs = (DCacheService) context.getBean("dCacheService");
		CacheServiceImpl csi = new CacheServiceImpl();
		csi.setDcs(dcs);
		cs = csi;
		context.close();
	}
	@Before
	public void initUtil() {
//		cu = new CacheServiceTestUtil();
	}

	/**
	 * 测试两个cache中放相同KEY值是否有影响
	 * @throws InterruptedException
	 * @author MaHan
	 * @date 2015年4月20日
	 */
	@Test
	public void test1() throws InterruptedException {
		String key = "test1()";
		String s1  = myCache+" test1";
		String s2 = testCache+" test1";
		cs.put(myCache, key, s1);
		cs.put(testCache, key, s2);
		
		Thread.sleep(2000);
		
		Assert.assertEquals(s1, cs.get(myCache, key));
		Assert.assertEquals(s2, cs.get(testCache, key));
	}
	/**
	 * 测试指定key的缓存值更新
	 * @throws InterruptedException
	 * @author MaHan
	 * @date 2015年4月20日
	 */
	@Test
	public void test2() throws InterruptedException{
		String key="test2()";
		String v1 = myCache+key;
		String v2 = "new"+key;
		
		cs.put(myCache, key, v1);
		Thread.sleep(1000);
		cs.put(myCache, key, v2);
		Thread.sleep(1000);
		Assert.assertEquals(v2, cs.get(myCache, key));
	}
	/**
	 * 测试删除 和 判断是否存在功能
	 * @throws InterruptedException
	 * @author MaHan
	 * @date 2015年4月20日
	 */
	@Test
	public void test3() throws InterruptedException{
		String key ="test3()";
		String v1 = myCache+key;
		
		cs.put(myCache, key, v1);
		Thread.sleep(1000);
		Assert.assertEquals(v1, cs.get(myCache, key));
		Thread.sleep(1000);
		cs.remove(myCache, key);
		Thread.sleep(1000);
		Assert.assertNull(cs.get(myCache, key));
		Assert.assertFalse(cs.isInCache(myCache, key));
		
	}
	/**
	 * 测试存取JAVA Bean对象
	 * @throws InterruptedException
	 * @author MaHan
	 * @date 2015年4月20日
	 */
	@Test
	public void test4() throws InterruptedException{
		String key = "test4()";
		CacheUser u1 = new CacheUser(1, "a1", 20, null);
//		cu.timeStart();
		cs.putObject(myCache, key, u1);
//		cu.timeEnd();
		Thread.sleep(1000);
		Assert.assertTrue(u1.equal(cs.getSimpleObject(myCache, key,CacheUser.class)));
	}
	
	/**
	 * 测试存取List<Bean>对象
	 * @throws InterruptedException
	 * @author MaHan
	 * @date 2015年4月21日
	 */
	@Test
	public void test5() throws InterruptedException{
		String key = "test5()";
		CacheUser u1 = new CacheUser(1, "a1", 20, null);
		CacheUser u2 = new CacheUser(2, "a2", 22, u1);
		CacheUser u3 = new CacheUser(3, "a3", 33, null);
		List<CacheUser> list = new ArrayList<CacheUser>();
		list.add(u1);
		list.add(u2);
		list.add(u3);
//		cu.timeStart();
		cs.putObject(myCache, key, list);
//		cu.timeEnd();
		Thread.sleep(1000);
		List<CacheUser> rList = cs.getComplexObject(myCache, key, new TypeReference<List<CacheUser>>(){});
		Assert.assertTrue(rList!=null);
		Assert.assertTrue(rList.size()>0);
		Assert.assertTrue(rList.get(0).equal(u1));
		Assert.assertTrue(rList.get(1).equal(u2));
		Assert.assertTrue(rList.get(2).equal(u3));
	}
	
	
	@Test
	public void test(){
//		String[] cacheNames = dcs.getAllCacheNames();
//		for(String name:cacheNames)
//			System.out.println(name);
		List<Object> keys = cs.getKeys(myCache);
		for(Object obj:keys){
//			cs.remove(myCache, obj.toString());
			System.out.println(obj);
		}
			
	}

}

package com.neusoft.aplus.common.test.zmqguide.topic;

import org.junit.Test;
import org.zeromq.ZMQ;

import com.neusoft.aplus.common.zmq.topic.Subscriber;
import com.neusoft.aplus.common.zmq.topic.TopicConf;

/**
 * @author zh_ch
 * @date 2014-12-26 下午5:27:12
 */
@Deprecated
public class Sub3 {
	@Test
	public void test() {
		ZMQ.Context ctx = ZMQ.context(1);
		Subscriber sub = new Subscriber(ctx, buildConfig()).waitForReceiveMsg();
		System.out.println("HI, I am here(Sub3)");
		while (!Thread.currentThread().isInterrupted()) {
			System.out.println("Sub_3 is waiting...");
			String rev = sub.recvStr();
			System.out.println("Rev == " + rev);
		}

		sub.destroy();
	}
	
	public static TopicConf buildConfig() {
		TopicConf conf = new TopicConf();
		conf.setBackend("tcp://localhost:5001");
		conf.setSubscription("1");
		return conf;
	}
}

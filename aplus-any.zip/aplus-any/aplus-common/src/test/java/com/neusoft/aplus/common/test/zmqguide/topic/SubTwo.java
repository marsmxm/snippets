package com.neusoft.aplus.common.test.zmqguide.topic;

import org.junit.Test;
import org.zeromq.ZMQ;

/**
 * @author zh_ch
 * @date 2015年6月30日 下午4:40:12
 */
public class SubTwo {

	@Test
	public void sub() {
		ZMQ.Context ctx = ZMQ.context(1);
		ZMQ.Socket sub = ctx.socket(ZMQ.SUB);
		sub.subscribe("2eko2".getBytes());
		sub.connect("tcp://localhost:5000");
		System.out.println("HI, I am here(Subtwo)");
		while (!Thread.currentThread().isInterrupted()) {
			String rev = sub.recvStr();
			System.out.println("Rev == " + rev);
		}
		
		sub.disconnect("tcp://localhost:5000");
		ctx.term();
	}

}

package com.neusoft.aplus.common.test.zmqguide.topic;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.zeromq.ZMQ;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.common.util.ZMQUtil;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;
import com.neusoft.aplus.common.zmq.topic.Publisher;
import com.neusoft.aplus.common.zmq.topic.TopicConf;
import com.neusoft.aplus.model.bizentity.AplusControlData;
import com.neusoft.aplus.model.bizentity.AplusMsgAction;

/**
 * pub端使用样例1
 * 
 * @author zh_ch
 * @date 2014-12-25 下午8:06:08
 */
@Deprecated
public class Pub1 {
	@Test
	public void test() throws InterruptedException {
		//AtomicLong cnt = new AtomicLong(); // 用来进行发送消息的计数
		ZMQ.Context ctx = ZMQ.context(1);
		Publisher pub = new Publisher(ctx, buildConfig()).waitForSendMsg();
//		while (cnt.get() < Long.MAX_VALUE) {
////			Thread.sleep(5000); // 为了便于调试观察，实际开发不需要
////			pub.send("1eko[" + cnt.getAndIncrement() + "](Pub1)");
//		}

		ZMQUtil.publish(pub, getMessage());
		System.out.println("Pub1 is dying...");
		pub.destory();
	}

	public static TopicConf buildConfig() {
		/**
		 * 对于pub端，与其相关的参数为frontend、respend、subscriberCnt、sendHwm
		 * 其中frontend、respend为必选，subscriberCnt、sendHwm为可选，如果进行pub 与sub的同步则必选
		 * 
		 * frontend、respend地址格式为{procotol}://{ip}:{port}，例如tcp://10.1.5.133
		 * 
		 * 在pub端启动前要保证所有sub端已经启动，如果无法保证启动顺序，则可将subscriberCnt置为null
		 */
		TopicConf conf = new TopicConf();
		conf.setFrontend("tcp://10.1.5.161:5000");
		conf.setRespend("tcp://localhost:5009");
		conf.setSubscriberCnt(-1);

		return conf;
	}

	private static ZMQMessage getMessage() {
		Map<String, List<AplusControlData>> map = Maps.newHashMap();
		List<AplusControlData> list = Lists.newArrayList();
		
		AplusControlData data = new AplusControlData();
		data.setActionName("Bucket Brigade.Boolean");
		List<Object> valueList = Lists.newArrayList();
		valueList.add("true");
		data.setActionValues(valueList);
		
		list.add(data);
		
		map.put("ybtest12", list);
		
		String text = JSONUtil.getJsonString(map);
		System.out.println("text == " + text);
		ZMQMessage message = new ZMQMessage(ZMQConst.TOPIC_TO_DBUSSERVER, text,
				AplusMsgAction.POLICY_CONTROL);
		return message;
	}
}

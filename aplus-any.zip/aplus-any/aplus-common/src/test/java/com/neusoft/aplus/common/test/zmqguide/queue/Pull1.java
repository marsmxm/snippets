package com.neusoft.aplus.common.test.zmqguide.queue;

import org.junit.Test;
import org.zeromq.ZMQ;

import com.neusoft.aplus.common.zmq.queue.Puller;
import com.neusoft.aplus.common.zmq.queue.QueueConf;

/**
 * pull使用样例
 * 
 * @author zh_ch
 * @date 2014-12-27 下午5:02:43
 */
public class Pull1 {
	@Test
	public void test() {
		ZMQ.Context ctx = ZMQ.context(1);
		Puller pull = new Puller(ctx, buildConfig()).waitForReceiveMsg();

		while (!Thread.currentThread().isInterrupted()) {
			String recv = pull.recvStr();
			System.out.println("{Pull_1} is recving: " + recv);
		}

		pull.destroy();
	}

	public static QueueConf buildConfig() {
		/**
		 * 对于pull端来说，pullerName、pushend、respend三个属性与其相关，全为必选属性
		 * 
		 * 对于不同的pull端，pullerName必须不同，此属性用来push端和多个pull端的同步
		 * 
		 * pushend为push端bind地址，用于发送数据，pull端需要connect到pushend进行消息接收
		 * respend为push端bind地址，用于push和pull同步数据接收，pull端需要connect到respend与push进行同步
		 * pushend和respend属性的格式为{protocol}://{ip}:{port},例如tcp://10.1.5.110:9903
		 */
		QueueConf conf = new QueueConf();
		conf.setPullerName("Pull1");
		conf.setPushend("tcp://localhost:5000");
		conf.setRespend("tcp://localhost:5001");
		return conf;
	}
}

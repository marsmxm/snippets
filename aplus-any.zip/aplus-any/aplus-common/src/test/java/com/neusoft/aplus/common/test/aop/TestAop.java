//package com.neusoft.aplus.aop;
//
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.neusoft.aplus.common.test.BaseSpringTest;
//
///**
// * @author wanw
// * @date 2014-7-28 下午3:09:14
// */
//public class TestAop extends BaseSpringTest {
//	
//	@Autowired
//	Business business;
//		
//	@Test
//	public void testDelete(){
//		business.delete("猫");
//		StaticUtil.delete("猫");
//	}
//	
//}

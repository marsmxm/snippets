package com.neusoft.aplus.common.test.zmqguide.topic;

import java.util.concurrent.atomic.AtomicLong;

import org.junit.Test;
import org.zeromq.ZMQ;

import com.neusoft.aplus.common.zmq.topic.Publisher;
import com.neusoft.aplus.common.zmq.topic.TopicConf;

/**
 * pub端使用样例2
 * @author zh_ch
 * @date 2014-12-25 下午9:23:27
 */
@Deprecated
public class Pub2 {
	@Test
	public void test() throws InterruptedException {
		AtomicLong cnt = new AtomicLong();
		ZMQ.Context ctx = ZMQ.context(1);
		Publisher pub = new Publisher(ctx, buildConfig()).waitForSendMsg();
		while (cnt.get() < Long.MAX_VALUE) {
			Thread.sleep(3000);
			pub.send("2eko[" + cnt.getAndIncrement() + "](Pub2)");
		}
		System.out.println("Pub2 is dying...");
		pub.destory();
	}

	public static TopicConf buildConfig() {
		TopicConf conf = new TopicConf();
		conf.setFrontend("tcp://localhost:5000");
		conf.setRespend("tcp://localhost:5003");
		conf.setSubscriberCnt(2);
		return conf;
	}
}

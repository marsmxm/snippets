package com.neusoft.aplus.common.test.zmqguide.topic;

import org.junit.Test;

import com.neusoft.aplus.common.spring.AppCtxLoader;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.topic.Subscriber;
import com.neusoft.aplus.common.zmq.topic.factory.PubSubFactory;

/**
 * @author zh_ch
 * @date 2015年3月18日 上午9:24:05
 */
public class SubString {
	static {
		AppCtxLoader.loadSpringCtx();
	}
	
	@Test
	public void test() {
		Subscriber sub = PubSubFactory.newSubscriber(ZMQConst.TOPIC_TO_DBUSSERVER);
		while (true) {
			String str = sub.recvStr();
			System.out.println(str);
		}
	}
}

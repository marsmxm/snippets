package com.neusoft.aplus.common.test.zmq.cluster;

import java.util.HashMap;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.common.util.FileUtil;
import com.neusoft.aplus.common.zmq.client.api.IDoBusiness;
import com.neusoft.aplus.common.zmq.client.api.Publisher;
import com.neusoft.aplus.common.zmq.client.factory.PubSubFactory;
import com.neusoft.aplus.common.zmq.client.launch.ClientLaunchHandler;
import com.neusoft.aplus.common.zmq.client.launch.ZkClient;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;

public class ZMQPubSubTest {

	@BeforeClass
	public static void init() {
		String path = FileUtil
				.getTestRepoPath("spring\\applicationContext-zmqtest.xml");
		String[] files = { path };
		ApplicationContextFactory.initialize(files);
	}

	public static void main(String[] args) {
		String path = FileUtil
				.getTestRepoPath("spring\\applicationContext-zmqtest.xml");
		String[] files = { path };
		ApplicationContextFactory.initialize(files);

		new Thread(new ZkClient(new ClientLaunchHandler())).start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// new Thread(PubSubFactory.createSubscriber("1", new MyBusiness()))
		// .start();
		Map<String, IDoBusiness> map = new HashMap<String, IDoBusiness>();
		map.put("1", new MyBusiness());
		map.put("a", new DefaultBusiness());
		new Thread(PubSubFactory.createSubscriber(map)).start();

		Publisher publisher = PubSubFactory.createPublisher();
		for (int i = 0; i < 10; i++) {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ZMQMessage msg = new ZMQMessage("11", "msg" + i);
			publisher.send("11", msg);
		}
	}

	@Test
	public void testZMQ() throws Exception {
		new Thread(new ZkClient(new ClientLaunchHandler())).start();
		Thread.sleep(1000);

		new Thread(PubSubFactory.createSubscriber("1", new MyBusiness()))
				.start();

		Publisher publisher = PubSubFactory.createPublisher();
		for (int i = 0; i < 10; i++) {
			Thread.sleep(3000);
			ZMQMessage msg = new ZMQMessage(null, "msg" + i);
			publisher.send(null, msg);
		}
	}
}

class MyBusiness implements IDoBusiness {
	@Override
	public void handleRecv(ZMQMessage msg) {
		System.out.println("MyBusiness handle->" + msg.getBodyString());
	}
}

class DefaultBusiness implements IDoBusiness {

	@Override
	public void handleRecv(ZMQMessage msg) {
		System.out.println("DefaultBusiness handle->" + msg.getBodyString());
	}
}

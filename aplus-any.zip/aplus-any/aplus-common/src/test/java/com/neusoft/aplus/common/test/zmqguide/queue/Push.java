package com.neusoft.aplus.common.test.zmqguide.queue;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.atomic.AtomicLong;

import org.junit.Test;
import org.zeromq.ZMQ;

import com.neusoft.aplus.common.zmq.queue.Pusher;
import com.neusoft.aplus.common.zmq.queue.QueueConf;

/**
 * push使用样例
 * @author zh_ch
 * @date 2014-12-27 下午4:50:15
 */
public class Push {
	@Test
	public void tetst() {
		AtomicLong cnt = new AtomicLong(); //用来进行测试时计数
		ZMQ.Context ctx = ZMQ.context(1);
		Pusher push = new Pusher(ctx, buildConfig()).waitForSendMsg();
		while (cnt.get() < 100) {
			push.send("eko[" + cnt.getAndIncrement() + "](Push1)");
		}
		push.destory();
		assertEquals(100, cnt.get());
	}
	
	public static QueueConf buildConfig() {
		/**
		 * 对于push端，与其相关的参数pushend、respend、pusherName、pullerCnt
		 * pushend、respend为必选，pusherName为可选。如果需要做push和pull的同步，pullerCnt
		 * 为必选，如果不需要做push和pull端的同步，则可不选
		 * 
		 * pushend为push端bind地址，用于发送数据，pull端需要connect到pushend进行消息接收
		 * respend为push端bind地址，用于push和pull同步数据接收，pull端需要connect到respend
		 * 与push进行同步，pushend和respend属性的格式为{protocol}://{ip}:{port},
		 * 例如tcp://10.1.5.110:9903
		 * 
		 * 实际部署时要求先启动pull端，然后启动push端。如果无法保证pull先于push端启动，则可将
		 * pullerCnt设置为null
		 */
		QueueConf conf = new QueueConf();
		conf.setPullerCnt(2);
		conf.setPushend("tcp://localhost:5000");
		conf.setRespend("tcp://localhost:5001");
		return conf;
	}
}

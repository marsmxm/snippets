package com.neusoft.aplus.common.test.cache;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.neusoft.aplus.common.cache.api.DCacheService;
/**
 * 缓存组件性能测试
 * @author MaHan
 *
 * @date 2015年4月21日
 */
public class CacheServicePerformanceTest {

	private static DCacheService dcs;
	private String myCache = "myCache";
	private CacheServiceTestUtil cacheUtil;
	
	@BeforeClass
	public static void init(){
		String configLocation = "spring/applicationContext-cachetest.xml";
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(configLocation);
		dcs = (DCacheService)context.getBean("dCacheService");
		context.close();
	}
	
	@Before
	public void initUtil(){
		cacheUtil = new CacheServiceTestUtil();
	}
	//测试是否存在方法性能
	@Test
	public void isInCacheTest(){
		cacheUtil.timeStart();
		boolean b = dcs.isInCache(myCache, "a1");
		cacheUtil.timeEnd();
		System.out.println(b);
	}
	//测试存入性能
	@Test
	public void putTest(){
		cacheUtil.timeStart();
		dcs.put(myCache, "a2", "a1a1");
		cacheUtil.timeEnd();
	}
	//测试获取性能
	@Test
	public void getTest(){
		cacheUtil.timeStart();
		Object obj = dcs.get(myCache, "a1");
		cacheUtil.timeEnd();
		System.out.println(obj);
	}
	
	@Test
	public void testRemove(){
		cacheUtil.timeStart();
		dcs.remove(myCache, "a1");
		cacheUtil.timeEnd();
	}
	//连续存入
	@Test
	public void putListTest(){
		int n = 50;
		List<Long> list = new ArrayList<Long>(n);
		for(int i=0; i<n; i++){
			cacheUtil.timeStart();
			dcs.put(myCache, "kk"+i, ""+i);
			list.add(cacheUtil.timeEnd());
		}
		cacheUtil.sortTimeList(list);
	}
	//连续读取
	@Test
	public void getListTest(){
		long start = 0;
		long end = 0;
		int n = 50;
		Object obj;
		List<Long> list = new ArrayList<Long>(n);
		List<Object> objList = new ArrayList<Object>(n);
		
		for(int i=0; i<n; i++){
			start =System.nanoTime();
			obj = dcs.get(myCache, "p"+i);
			end = System.nanoTime();
			list.add(end-start);
			objList.add(obj);
		}
		cacheUtil.sortTimeList(list);
		cacheUtil.searchNull(objList);
	}
	//手动模拟程序运行存入
	@Test
	public void manulPut(){
		Scanner sc = new Scanner(System.in);
		String input ="";
		while(true){
			input = sc.nextLine();
			if(input.equals("quit")){
				sc.close();
				break;
			}
			cacheUtil.timeStart();
			dcs.put(myCache, input, input+input);
			cacheUtil.timeEnd();
		}
	}
	//手动模拟程序运行获取
	@Test
	public void manulGet(){
		Scanner sc = new Scanner(System.in);
		String input ="";
		while(true){
			input = sc.nextLine();
			if(input.equals("quit")){
				sc.close();
				break;
			}
			cacheUtil.timeStart();
			Object obj = dcs.get(myCache, input);
			System.out.println(obj);
			cacheUtil.timeEnd();
		}
	}
	//手动模拟程序运行删除
	@Test
	public void manulRemove(){
		Scanner sc = new Scanner(System.in);
		String input ="";
		while(true){
			input = sc.nextLine();
			if(input.equals("quit")){
				sc.close();
				break;
			}
			cacheUtil.timeStart();
			dcs.remove(myCache, input);
			cacheUtil.timeEnd();
		}
	}
}

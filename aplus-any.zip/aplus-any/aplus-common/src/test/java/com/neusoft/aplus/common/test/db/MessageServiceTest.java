package com.neusoft.aplus.common.test.db;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.neusoft.aplus.common.exception.biz.service.bo.IMessageService;
import com.neusoft.aplus.common.test.BaseSpringTest;

public class MessageServiceTest extends BaseSpringTest {
	
	@Autowired
	private IMessageService messageService;
    
    @Test
    public void saveMsgTest(){
    	messageService.saveMsg(new MockException(MockException.CODE_AES_EXCEPTION_ADDDEVICE,new NullPointerException(),null,null));
    }

}

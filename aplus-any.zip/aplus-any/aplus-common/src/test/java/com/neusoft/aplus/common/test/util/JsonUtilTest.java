package com.neusoft.aplus.common.test.util;

import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.model.bizentity.AplusMetricData;

/**
 * @author zh_ch
 * @date 2015-2-12 下午1:12:31
 */
public class JsonUtilTest {
	@Test
	public void test1() {
		String msg = "[{\"metricDatas\":[{\"name\":\"deviceInfo\", "
				+ "\"recordTime\":0,\"value\":\"Windows PC 6.1.7600  Professional x86 Family 6 Model 58 Stepping 9\"},"
				+ "{\"name\":\"deviceName\",\"recordTime\":0,\"value\":\"PC\"}]}]";
		JSONArray array = JSONArray.parseArray(msg);
		JSONObject obj = (JSONObject) array.get(0);
		String message = obj.getString("metricDatas");
		System.out.println("message:" + message);
		List<AplusMetricData> list = JSONUtil.getObjectList(message,
				AplusMetricData.class);
		System.out.println("list:" + list);
	}

	@Test
	public void testPair() {
		Map<String, String> map = Maps.newHashMap();
		map.put("dt", "pc");
		map.put("dv", "v1");
		List<Map<String, String>> list = Lists.newArrayList();
		list.add(map);
		String jsonString = JSONUtil.getJsonString(list);
		System.out.println(jsonString + "@");
		List<Map<String, String>> result = JSONUtil.getComplexObject(
				jsonString, new TypeReference<List<Map<String, String>>>() {
				});
		System.out.println(result + "@@");
		System.out.println(result.get(0).get("dt"));
		System.out.println(result.get(0).get("dv"));
	}
}

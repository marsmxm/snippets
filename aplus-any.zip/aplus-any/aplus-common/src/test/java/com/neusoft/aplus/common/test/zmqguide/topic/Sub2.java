package com.neusoft.aplus.common.test.zmqguide.topic;

import org.junit.Test;
import org.zeromq.ZMQ;

import com.neusoft.aplus.common.zmq.topic.Subscriber;
import com.neusoft.aplus.common.zmq.topic.TopicConf;

/**
 * sub端使用样例2
 * @author zh_ch
 * @date 2014-12-25 下午8:24:13
 */
@Deprecated
public class Sub2 {
	@Test
	public void test() {
		ZMQ.Context ctx = ZMQ.context(1);
		Subscriber sub = new Subscriber(ctx, buildConfig()).waitForReceiveMsg();
		System.out.println("HI, I am here(Sub2)");
		while (!Thread.currentThread().isInterrupted()) {
			System.out.println("Sub_2 is waiting...");
			String rev = sub.recvStr();
			System.out.println("Rev == " + rev);
		}

		sub.destroy();
	}
	
	public static TopicConf buildConfig() {
		TopicConf conf = new TopicConf();
		conf.setBackend("tcp://localhost:5001");
		conf.setSubscription("2");
		return conf;
	}
}

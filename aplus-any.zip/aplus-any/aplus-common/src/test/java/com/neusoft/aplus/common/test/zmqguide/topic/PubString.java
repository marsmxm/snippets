package com.neusoft.aplus.common.test.zmqguide.topic;

import java.util.concurrent.atomic.AtomicLong;

import org.junit.Test;

import com.neusoft.aplus.common.spring.AppCtxLoader;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.topic.Publisher;
import com.neusoft.aplus.common.zmq.topic.factory.PubSubFactory;

/**
 * @author zh_ch
 * @date 2015年3月18日 上午9:21:47
 */
public class PubString {
	static {
		AppCtxLoader.loadSpringCtx();
	}
	@Test
	public void test() throws InterruptedException {
		AtomicLong cnt = new AtomicLong();
		Publisher pub = PubSubFactory.newPublisher(ZMQConst.PROC_DATABUS);
		
		String str = "{alertid:'告警id',fqn:'fqn',extend_property: '告警内容',createtime:'2015-03-05 12:00:00',alarmlevel:'1'}";
		Thread.sleep(2000);;
		while (cnt.getAndIncrement() < 100) {
			pub.send(ZMQConst.TOPIC_TO_DBUSSERVER + str + cnt.get());
		}
		
	}
}

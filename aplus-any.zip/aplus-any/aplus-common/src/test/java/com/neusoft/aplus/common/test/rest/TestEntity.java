package com.neusoft.aplus.common.test.rest;

import java.io.Serializable;
import java.util.List;

/**
 * @author li.hzh
 * @date 2015-05-06 16:17
 */
public class TestEntity implements Serializable{

	private static final long serialVersionUID = 1667256542921644837L;
	private String name;
	private List<String> ids;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getIds() {
		return ids;
	}

	public void setIds(List<String> ids) {
		this.ids = ids;
	}
}

package com.neusoft.aplus.common.test.zmqguide.topic;

import java.util.concurrent.atomic.AtomicLong;

import org.junit.Test;
import org.zeromq.ZMQ;

/**
 * @author zh_ch
 * @date 2015年6月30日 下午4:37:20
 */
public class PubOne {
	@Test
	public void test() throws InterruptedException {
		AtomicLong cnt = new AtomicLong();
		ZMQ.Context ctx = ZMQ.context(1);
		ZMQ.Socket publisher = ctx.socket(ZMQ.PUB);
		publisher.bind("tcp://localhost:5000");
		while (cnt.get() < Long.MAX_VALUE) {
			Thread.sleep(3000);
			publisher.send("2eko[" + cnt.getAndIncrement() + "](Pub2)");
		}
		System.out.println("Pub2 is dying...");
		publisher.unbind("tcp://localhost:5000");
	}
}

package com.neusoft.aplus.common.test.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.aplus.common.util.ClassUtil;

/**
 * 
 * @author Mu Xian Ming
 * @date 2015-01-09
 */
public class ClassUtilTest {
	@SuppressWarnings("unused")
	private class Dummy {
		public static final String TOPIC_READY = "subend_ready";
		public static final String TOPIC_HELLO = "hello_sub";
		public static final String TOPIC_OK = "subend_ready_ok";
		public static final String QUEUE_HELLO = "hello_pull";
		public static final String QUEUE_READY = "pullend_ready";
		public static final String QUEUE_OK = "pullend_ready_ok";
		public static final String SEPERATOR = "@";
	}
	
	@Before
	public void setUp() throws Exception {

	}
	
	@Test
	public void testGetAllConstValues() {
		Object[] values = ClassUtil.getAllConstValues(Dummy.class);
		assertEquals(7, values.length);
	}
	
	@Test
	public void testHasConstValueTrue() {
		assertTrue(ClassUtil.hasConstValue(Dummy.class, "@"));
	}
	
	@Test
	public void testHasConstValueFalse() {
		assertFalse(ClassUtil.hasConstValue(Dummy.class, "Hello World!"));
	}
}

package com.neusoft.aplus.common.test.zmqguide.topic;

import org.junit.Test;
import org.zeromq.ZMQ;

/**
 * @author zh_ch
 * @date 2015年6月30日 下午4:37:43
 */
public class SubOne {
	@Test
	public void sub() {
		ZMQ.Context ctx = ZMQ.context(1);
		ZMQ.Socket sub = ctx.socket(ZMQ.SUB);
		sub.subscribe("2".getBytes());
		sub.connect("tcp://localhost:5000");
		System.out.println("HI, I am here(Sub1)");
		while (!Thread.currentThread().isInterrupted()) {
			String rev = sub.recvStr();
			System.out.println("Rev == " + rev);
		}
		
		sub.disconnect("tcp://localhost:5000");
	}
}

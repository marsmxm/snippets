package com.neusoft.aplus.common.test.rest;

import com.neusoft.aplus.common.test.BaseRestTest;
import com.neusoft.aplus.common.test.RestConfig;
import org.junit.Test;

/**
 * RestConfig注解测试类
 *
 * @author li.hzh
 * @date 2015-04-21 16:05
 */
@RestConfig(url = "/test1", action = TestAction.class)
public class BaseRestTestTest extends BaseRestTest {

	@Test
	public void doTest() {
		doGet("/");
	}


}

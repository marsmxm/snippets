//package com.neusoft.aplus.aop;
//
//import org.springframework.stereotype.Component;
//
///**
// * @author wanw
// * @date 2014-7-28 下午3:54:43
// */
//@Component
//public class StaticUtil {
//
//	public static String delete(String obj) {
//		System.out.println("==========调用切入点：" + obj + "说：你敢删除我！===========\n");
//		return obj + "：瞄～";
//	}
//}

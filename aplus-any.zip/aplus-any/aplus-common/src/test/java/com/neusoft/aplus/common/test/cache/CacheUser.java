package com.neusoft.aplus.common.test.cache;

public class CacheUser {
	private Integer id;
	private String name;
	private int age;
	private CacheUser peer;

	public CacheUser(){}
	
	public CacheUser(Integer id, String name, int age, CacheUser peer) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.peer = peer;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public CacheUser getPeer() {
		return peer;
	}

	public void setPeer(CacheUser peer) {
		this.peer = peer;
	}

	public String toString() {
		String s = "id=" + id + "|name=" + name + "|age=" + age + "|peer=("
				+ (peer == null ? "null" : peer.toString()) + ")";
		return s;
	}

	public boolean equal(CacheUser cu) {
		if(this.id==cu.getId() && this.name.equals(cu.getName()) && this.age==cu.getAge())
				return true;
		return false;
	}
}

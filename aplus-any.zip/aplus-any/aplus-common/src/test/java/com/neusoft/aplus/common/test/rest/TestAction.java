package com.neusoft.aplus.common.test.rest;

import com.neusoft.aplus.common.base.BaseAction;
import org.restlet.representation.ObjectRepresentation;
import org.restlet.representation.Representation;

import java.io.IOException;

/**
 * @author li.hzh
 * @date 2015-04-21 16:07
 */
public class TestAction extends BaseAction {


	@Override
	public void acceptRepresentation(Representation entity) {

	}

	@Override
	public Representation represent() {
		System.out.println("doGet");
		return null;
	}

	@Override
	 public void removeRepresentations() {
		ObjectRepresentation<?> obR = (ObjectRepresentation<?>) getRequest().getEntity();
		try {
			obR.getObject();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("doDelete");
	}

	@Override
	public void storeRepresentation(Representation entity) {

	}
}

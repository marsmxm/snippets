package com.neusoft.aplus.common.test.jmx;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.neusoft.aplus.common.test.BaseSpringTest;


/**
 * @author wanw
 * @date 2014-7-28 下午4:39:21
 */
public class JmxTest extends BaseSpringTest{
	
	@Autowired
	private MockHello mockHello;
	
	@Test
	public void jmxTest(){
		mockHello.getName();
		try{
			//等待5分钟，使得JMX服务可以通过jconsole查看
			Thread.sleep(300000);
		}catch(Exception e){
			Assert.fail();
		}
	}

}

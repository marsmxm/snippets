package com.neusoft.aplus.common.test.jmx;

/**
 * JMX接口定义，这个接口是必须的
 * 且必须以*MBean为后缀
 * 
 * @author WanWei
 * @date 2014-7-28 下午4:35:43
 */
public interface MockHelloMBean {

	public String getName();

	public void setName(String name);

	public void printHello();

	public void printHello(String whoName);
}

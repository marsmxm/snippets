package com.neusoft.aplus.common.test.jmx;

import org.springframework.stereotype.Component;

import com.neusoft.aplus.common.jmx.AbstractMBean;

/**
 * MBean接口的实现类
 * @author WanWei
 * @date 2014-7-28 下午4:37:20
 */
@Component
public class MockHello extends AbstractMBean implements MockHelloMBean {
	
    private String name;
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void printHello() {
        System.out.println("Hello World, " + name);
    }
    public void printHello(String whoName) {
        System.out.println("Hello , " + whoName);
    }
	@Override
	public Object getCurrentMBean() {
		return this;
	}
	@Override
	public String getMBeanName() {
		return null;
	}
}
package com.neusoft.aplus.common.test.util;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.neusoft.aplus.common.util.AplusCollectionUtils;
import com.neusoft.aplus.common.util.AplusStringUtils;
import com.neusoft.aplus.common.util.JSONUtil;

/**
 * @author zh_ch
 * @date 2015年3月30日 上午11:05:52
 */
public class AplusStringUtilsTest {
	@Test
	public void test1() {
		Map<String, Object> map1 = Maps.newHashMap();
		map1.put("ip", "10.10.12.13");
		map1.put("port", 8080);
		map1.put("active", Boolean.TRUE);
		Map<String, Object> map2 = Maps.newHashMap();
		map2.put("ip", "20.10.12.13");
		map2.put("port", 9090);
		map2.put("active", Boolean.FALSE);
		List<Map<String, Object>> list = Lists.newArrayList();
		list.add(map1);
		list.add(map2);
		String result = AplusStringUtils.getArrayType(list);
		System.out.println(result);
	}

	@Test
	public void test2() {
		List<String> list = Lists.newArrayList();
		list.add("eko");
		list.add("kobe");
		String jsonString = JSONUtil.getJsonString(list);
		System.out.println(jsonString);
		List<String> resultList = JSONUtil.getObjectList(jsonString, String.class);
		System.out.println(resultList);
	}
	
	@Test
	public void testCollectionUtil() {
		Set<String> list = Sets.newHashSet();
		Assert.assertTrue((AplusCollectionUtils.isBlank(list)));
	}
}

package com.neusoft.aplus.common.test.cache;

import java.util.ArrayList;
import java.util.List;

public class CacheServiceTestUtil {
	
	private  long startTime;
	private  long endTime;
	
	
	public  void timeStart(){
		startTime = System.nanoTime();
	}
	
	public  long timeEnd(){
		endTime = System.nanoTime();
		long time = endTime-startTime;
		System.out.printf("%.3f 毫秒 \n",(endTime-startTime)/1000000.0);
		return time;
	}
	public  long timeEnd(int i){
		endTime = System.nanoTime();
		long time = endTime-startTime;
		return time;
	}
	
	// 筛选最长最短时间
	public  void sortTimeList(List<Long> list) {
		Long max = 0L;
		int maxIndex = 0;
		Long min = Long.MAX_VALUE;
		int minIndex = 0;
		long total = 0L;
		for (int i = 0; i < list.size(); i++) {
			Long t = list.get(i);
			total += t;
			if (t > max) {
				max = t;
				maxIndex = i;
			} else if (t < min) {
				min = t;
				minIndex = i;
			}
		}
		System.out.println(list);
		System.out.println(list.size());
		System.out.println("总时间" + total);
		System.out.println("平均时间=" + total / list.size());
		System.out.println("最大值=" + max + " | 序号=" + maxIndex);
		System.out.println("最小值=" + min + " | 序号=" + minIndex);
	}

	// 判断get到的值是否有空
	public  void searchNull(List<Object> list) {
		if (null == list || list.size() <= 0) {
			System.out.println("列表中无值");
		}
		List<Integer> indexList = new ArrayList<Integer>();
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i) == null)
				indexList.add(i);
		}
		System.out.println("共 " + indexList.size() + " 个为空");
		System.out.println(indexList);
	}

}

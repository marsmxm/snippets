package com.neusoft.aplus.common.test.rest;

import com.neusoft.aplus.common.test.BaseRestTest;
import com.neusoft.aplus.common.test.RestConfig;
import org.junit.Before;
import org.junit.Test;
import org.restlet.Client;
import org.restlet.Request;
import org.restlet.data.Method;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.representation.ObjectRepresentation;

/**
 * @author li.hzh
 * @date 2015-05-06 15:58
 */
@RestConfig(url = "/test/baseaction", action = TestAction.class)
public class BaseActionTest extends BaseRestTest {

	private TestEntity testEntity;

	@Before
	public void before() {
		testEntity = mockEntity();
	}

	private TestEntity mockEntity() {
		TestEntity entity = new TestEntity();
		entity.setName("EntityName");
		return entity;
	}

	@Test
	public void testDeleteMethod() {
		Client client = new Client(Protocol.HTTP);
		Reference reference = new Reference("http://127.0.0.1:8182/test/baseaction");
		Request request = new Request(Method.DELETE, reference);
		request.setEntity(new ObjectRepresentation<TestEntity>(testEntity));
		client.handle(request);
	}


}

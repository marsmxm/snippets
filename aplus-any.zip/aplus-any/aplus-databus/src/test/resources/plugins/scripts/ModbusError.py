import os.path
from java.util.concurrent import TimeUnit
from com.neusoft.aplus.databus.biz.plugin.interfaces import DBUSPlugin
from com.neusoft.aplus.databus.util import DBUSPluginUtil
from com.neusoft.aplus.model.bizentity import AplusConnection
from com.neusoft.aplus.model.bizentity import AplusDevice
from com.neusoft.aplus.model.bizentity import AplusDeviceMonitorData
from com.neusoft.aplus.model.bizentity import AplusMetricValueType
from com.neusoft.aplus.databus.biz.constants import DBUSMetricConstants
from com.neusoft.aplus.databus.biz.protocol.modbus import DBUSModbusConnection
from com.neusoft.aplus.databus.biz.protocol.modbus import DBUSModbus
from com.neusoft.aplus.databus.biz.protocol.modbus import DBUSModbusConnectionTool


class Plugin(DBUSPlugin):
    def __init__(self):
        self.locale_dict = self._get_locale_dict()
        self.enum_dict = self._get_enum_dict()
        
    def getDeviceTypeId(self):
        return DBUSPluginUtil.getDeviceTypeId(self)

    def getProtocol(self):
        return DBUSModbus.getProtocol()
    
    def getProtocolMode(self):
        return "v1"
    
    def getDeviceType(self):
        return "Modbus-simulate"
    
    def getVersion(self):
        return "1"
    
    def getCategory(self):
        return "SIMULATE"
    
    def getMetricDef(self):
        metrics = [
             {DBUSMetricConstants.NAME: "TestName1", DBUSMetricConstants.CODE: "3.0.10", 
             DBUSMetricConstants.START:0, DBUSMetricConstants.END:5,
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1, 
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES,DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},

             {DBUSMetricConstants.NAME: "TestName2", DBUSMetricConstants.CODE: "3.0.10", 
             DBUSMetricConstants.START:6, DBUSMetricConstants.END:11,
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1, 
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES,DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"}
        ]
        return metrics
    
    def monitor(self, conn, *params):
        device = AplusDevice()
        device.setDeviceType(self.getDeviceType())
        device.setCategory(self.getCategory())
        device.setVersion(self.getVersion())
        tool = DBUSModbusConnectionTool.getInstance()
        return tool.collectAllMetricsOfDevice(conn, device)
    
    def getConnectionDef(self):
        conn = DBUSModbusConnection()
        conn.setComValue("COM6")
        conn.setParity(0)
        conn.setDataBits(8)
        conn.setBaudRate(19200)
        conn.setRetry(0)
        conn.setStopBits(1)
        conn.setConnectiontype("COM")
        conn.setCommunicatetyp("RTU")
        conn.setSlave("1")
        return conn
    
    def connect(self):
        pass
       
    def getDeviceDef(self):
        pass
    
    def findParent(self):
        pass
    
    def getParentTypeInfo(self):
        pass
    
    def getDeviceFqn(self):
        pass
    
    def discover(self, connection, *params):
        pass
    
    def getActionDef(self):
        pass
    
    def control(self, connection, action, *params):
        pass
    
    def checkControl(self, connection, check_id, *params):
        pass
    
    def getExtJarPaths(self):
        return []
    
    def internationalization(self, defkey, locale):
        return self.locale_dict["defkey"]["locale"]
    
    def getAbsFilename(self):
        curdir = os.path.abspath(os.path.curdir)
        filename = __file__
        if "$" in filename:
            filename = filename.split("$")[0] + ".py"
        return os.path.join(curdir, filename)
    
    def getMetricEnum(self, key):
        if key not in self.enum_dict:
            return None
        else:
            return self.enum_dict[key]

    def _get_enum_dict(self):
        return {"name1": {0: ("H", "defkey_0"),
                          1: ("M", "defkey_1")},
        }

    def _get_locale_dict(self):
        return {
            "": {
                "": "",
            },
        }

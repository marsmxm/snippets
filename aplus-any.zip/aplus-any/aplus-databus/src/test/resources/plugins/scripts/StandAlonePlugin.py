import sys
sys.path.append(r'D:\plugins\snmp4j-2.2.2.jar')
# from com.neusoft.aplus.databus.biz.plugin.interfaces import DBUSPlugin
from org.snmp4j import CommunityTarget
from org.snmp4j import PDU
from org.snmp4j import Snmp
from org.snmp4j import TransportMapping
from org.snmp4j.event import ResponseEvent
from org.snmp4j.mp import SnmpConstants
from org.snmp4j.smi import Address
from org.snmp4j.smi import GenericAddress
from org.snmp4j.smi import OID
from org.snmp4j.smi import OctetString
from org.snmp4j.smi import VariableBinding
from org.snmp4j.transport import DefaultUdpTransportMapping
from java.util import Vector
from java.util.concurrent import TimeUnit
import os.path


class Plugin():
    def __init__(self):
        self.locale_dict = self._get_locale_dict
        self.transport = DefaultUdpTransportMapping()
        self.snmp = Snmp(self.transport)
        self.transport.listen()
        
    def getDeviceTypeId(self):
        return "XiaoBaWang-PC:1"
    
    def getProtocol(self):
        return "Unknown"
    
    def getProtocolMode(self):
        return "v1"
    
    def getDeviceType(self):
        return "XiaoBaWang-PC"
    
    def getVersion(self):
        return "1"
    
    def getCategory(self):
        return "PC"
    
    def getMetricDef(self):
        metrics = [
            {DBUSMetricConstants.NAME: "deviceName", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "deviceInfo", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"}
        ]
        return metrics
    
    def getConnectionDef(self):
        conn = DBUSSnmpConnection()
        conn.setIpAddress("10.1.5.149")
        conn.setPort("161")
        conn.setCommunity("public")
        conn.setRetry(3)
        conn.setTimeOut(1500)
        conn.setVersion(1)
        return conn
    
    def connect(self):
        pass
    
    def monitor(self, conn, *args):
        pdu = PDU()
        pdu.add(VariableBinding(OID("1.3.6.1.2.1.1.5.0")))
        pdu.setType(PDU.GET)
        self.readResponse(self.sendPDU(pdu))

    def getDeviceDef(self):
        pass
    
    def findParent(self):
        pass
    
    def getParentTypeInfo(self):
        pass
    
    def getDeviceFqn(self):
        pass
    
    def discover(self, connection, *params):
        pass
    
    def getActionDef(self):
        pass
    
    def control(self, connection, action, *params):
        pass
    
    def checkControl(self, connection, check_id, *params):
        pass
    
    def getExtJarPaths(self):
        return []
    
    def internationalization(self, defkey, locale):
        return self.locale_dict["defkey"]["locale"]
    
    def getAbsFilename(self):
        curdir = os.path.abspath(os.path.curdir)
        filename = __file__
        # if the compiled class of this plugin script is interpreted
        # the filename would be "*$*.class" format
        # so it should be changed back to "*.py" format
        if "$" in filename:
            filename = filename.split("$")[0] + ".py"
        return os.path.join(curdir, filename)
    
    def getMetricEnum(self, key):
        d = {"some_metric_name": {0: ("H", "defkey_0"),
                                  1: ("M", "defkey_1")},
             }
        return d[key]

    def _get_locale_dict(self):
        return {
            "": {
                "": "",
            },
        }

    def sendPDU(self, pdu):
        target = CommunityTarget()
        targetAddress = GenericAddress.parse("udp:10.1.5.149/161")
        target.setCommunity(OctetString("public"))
        target.setAddress(targetAddress)
        target.setRetries(2)
        
        target.setTimeout(1500)
        target.setVersion(SnmpConstants.version1)

        res = self.snmp.send(pdu, target)
        print res.getResponse()
        return res;

    def readResponse(self, respEvnt):
        if respEvnt != None and respEvnt.getResponse() != None:
            recVBs = respEvnt.getResponse().getVariableBindings()
            for i in range(0, recVBs.size()):
                recVB = recVBs.elementAt(i)
                print(str(recVB.getOid()) + " ||| " + str(recVB.getVariable()))

if __name__ == "__main__":
    plugin = Plugin()
    plugin.monitor(None)

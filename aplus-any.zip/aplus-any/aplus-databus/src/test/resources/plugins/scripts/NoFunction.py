from com.neusoft.aplus.databus.biz.plugin.interfaces import DBUSPlugin


class Plugin(DBUSPlugin):
    pass

import os.path
from java.util.concurrent import TimeUnit
from com.neusoft.aplus.databus.biz.plugin.interfaces import DBUSPlugin
from com.neusoft.aplus.databus.util import DBUSPluginUtil
from com.neusoft.aplus.model.bizentity import AplusConnection
from com.neusoft.aplus.model.bizentity import AplusDevice
from com.neusoft.aplus.model.bizentity import AplusDeviceMonitorData
from com.neusoft.aplus.model.bizentity import AplusMetricValueType
from com.neusoft.aplus.databus.biz.protocol.snmp import DBUSSnmpConnection
from com.neusoft.aplus.databus.biz.constants import DBUSMetricConstants
from com.neusoft.aplus.databus.biz.protocol.snmp import DBUSSnmpConnectionTool
from com.neusoft.aplus.databus.biz.protocol.snmp import DBUSSnmp

class Plugin(DBUSPlugin):
    
    def __init__(self):
        self.locale_dict = self._get_locale_dict
        
    def getDeviceTypeId(self):
        return DBUSPluginUtil.getDeviceTypeId(self)
    
    def getProtocol(self):
        return DBUSSnmp.getProtocol()
    
    def getProtocolMode(self):
        return DBUSSnmp.VERSION1
    
    def getDeviceType(self):
        return "HP-PC"
    
    def getVersion(self):
        return "1"
    
    def getCategory(self):
        return "PC"
    
    def getMetricDef(self):
        metrics = [
            {DBUSMetricConstants.NAME: "metric1", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric2", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric3", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric4", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric5", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric6", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric7", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric8", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric9", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric10", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric11", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric12", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric13", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric14", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric15", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric16", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric17", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric18", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric19", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric20", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric21", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric22", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric23", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric24", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric25", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric26", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric27", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric28", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric29", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric30", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric31", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric32", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric33", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric34", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric35", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric36", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric37", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric38", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric39", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric40", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric41", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric42", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric43", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric44", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric45", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric46", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric47", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric48", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric49", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric50", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric51", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric52", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric53", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric54", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric55", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric56", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric57", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric58", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric59", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric60", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric61", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric62", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric63", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric64", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric65", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric66", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric67", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric68", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric69", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric70", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric71", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric72", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric73", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric74", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric75", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric76", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric77", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric78", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric79", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric80", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric81", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric82", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric83", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric84", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric85", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric86", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric87", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric88", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric89", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric90", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric91", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric92", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric93", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric94", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric95", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric96", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric97", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric98", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric99", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric100", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric101", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric102", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric103", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric104", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric105", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric106", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric107", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric108", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric109", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric110", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric111", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric112", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric113", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric114", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric115", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric116", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric117", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric118", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric119", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric120", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric121", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric122", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric123", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric124", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric125", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric126", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric127", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric128", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric129", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric130", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric131", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric132", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric133", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric134", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric135", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric136", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric137", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric138", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric139", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric140", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric141", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric142", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric143", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric144", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric145", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric146", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric147", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric148", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric149", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric150", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric151", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric152", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric153", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric154", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric155", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric156", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric157", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric158", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric159", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric160", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric161", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric162", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric163", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric164", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric165", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric166", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric167", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric168", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric169", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric170", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric171", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric172", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric173", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric174", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric175", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric176", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric177", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric178", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric179", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric180", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric181", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric182", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric183", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric184", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric185", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric186", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric187", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric188", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric189", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric190", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric191", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric192", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric193", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric194", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric195", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric196", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric197", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
            
            {DBUSMetricConstants.NAME: "metric198", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.5.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceName_i18n_key"},
                   
            {DBUSMetricConstants.NAME: "metric199", DBUSMetricConstants.CODE: "1.3.6.1.2.1.1.1.0",
             DBUSMetricConstants.UNIT: "", DBUSMetricConstants.INTERVAL: 1,
             DBUSMetricConstants.TIMEUNIT: TimeUnit.MINUTES, DBUSMetricConstants.ACTIVE: True,
             DBUSMetricConstants.TYPE: AplusMetricValueType.TYPE_STRING,
             DBUSMetricConstants.DEFKEY: "deviceInfo_i18n_key"},
                   
        ]
        curdir = os.path.dirname(os.path.abspath(__file__))
        import imp
        ManyMetricsSub = imp.load_source("ManyMetricsSub", os.path.join(curdir, "ManyMetricsSub"))
        plugin = ManyMetricsSub.Plugin()
        return metrics + plugin.getMetricDef()
    
    def getConnectionDef(self):
        return []
    
    def connect(self):
        pass
    
    def monitor(self, conn, *params):
        device = AplusDevice()
        device.setDeviceType(self.getDeviceType())
        device.setCategory(self.getCategory())
        device.setVersion(self.getVersion())
        tool = DBUSSnmpConnectionTool.getInstance()
        return tool.collectAllMetricsOfDevice(conn, device)

    def getDeviceDef(self):
        pass
    
    def findParent(self):
        pass
    
    def getParentTypeInfo(self):
        pass
    
    def getDeviceFqn(self):
        pass
    
    def discover(self, connection, *params):
        pass
    
    def getActionDef(self):
        pass
    
    def control(self, connection, action, *params):
        pass
    
    def checkControl(self, connection, check_id, *params):
        pass
    
    def getExtJarPaths(self):
        return []
    
    def internationalization(self, defkey, locale):
        return self.locale_dict["defkey"]["locale"]
    
    def getAbsFilename(self):
        curdir = os.path.dirname(os.path.abspath(__file__))
        filename = os.path.basename(__file__)
        if "$" in filename:
            filename = filename.split("$")[0] + ".py"
        return os.path.join(curdir, filename)
    
    def getMetricEnum(self, key):
        d = {"some_metric_name": {0: ("H", "defkey_0"),
                                  1: ("M", "defkey_1")},
             }
        return d[key]

    def _get_locale_dict(self):
        return {
            "": {
                "": "",
            },
        }
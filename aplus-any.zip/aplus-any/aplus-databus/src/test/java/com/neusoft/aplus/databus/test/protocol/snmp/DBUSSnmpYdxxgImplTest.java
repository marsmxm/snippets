package com.neusoft.aplus.databus.test.protocol.snmp;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.neusoft.aplus.databus.biz.protocol.snmp.DBUSSnmpConnection;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.dbentity.table.AplusMetricEntity;

/**
 * snmp移动信息港接口测试类
 * @author wuhao
 * @date 2015-2-2 下午2:47:52
 */
public class DBUSSnmpYdxxgImplTest{

	AplusDevice device  = new AplusDevice();
	DBUSSnmpConnection connection  = new DBUSSnmpConnection();
	List<AplusMetricEntity> metricList = new ArrayList<AplusMetricEntity>();
    List<AplusDeviceMonitorData> data=null;
    Random rand = new Random(100);
	
	
	

}

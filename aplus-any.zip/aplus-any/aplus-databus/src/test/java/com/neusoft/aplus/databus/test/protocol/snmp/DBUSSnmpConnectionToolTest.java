package com.neusoft.aplus.databus.test.protocol.snmp;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.junit.Before;
import org.junit.Test;

import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.databus.DataBusInit;
import com.neusoft.aplus.databus.biz.protocol.snmp.DBUSSnmpConnection;
import com.neusoft.aplus.databus.biz.service.bo.DBUSMonitorService;
import com.neusoft.aplus.databus.biz.service.bo.impl.DBUSMonitorServiceImpl;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.bizentity.AplusMetricData;

/**
 * @author Mu Xian Ming
 * @date 2014年12月26日
 */
public class DBUSSnmpConnectionToolTest {

	@Before
	public void setUp() throws Exception {

	}

	@Test
	public void testDummy() {
	}

	public static void main(String[] args) {
		String basedir = FilenameUtils.getFullPath(new File("")
				.getAbsolutePath());
		ApplicationContextFactory
				.initialize(new String[] {
						basedir
								+ "aplus-probe-inquirer\\src\\main\\resources\\spring\\applicationContext-properties.xml",
						basedir
								+ "aplus-probe-inquirer\\src\\main\\resources\\spring\\applicationContext-common.xml",
						basedir
								+ "aplus-probe-inquirer\\src\\main\\resources\\spring\\applicationContext-dataSource.xml" });

		try {
			DataBusInit.init(new String[0]);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		DBUSSnmpConnection conn = new DBUSSnmpConnection();
		
		conn.setIpAddress("10.1.5.154");
		conn.setPort("161");
		conn.setCommunity("public");
		conn.setRetry("3");
		conn.setTimeOut("1500");
		conn.setVersion("1");
		
		
		AplusDevice device = new AplusDevice();
		device.setDeviceType("HP-PC");
		device.setDeviceVersion("v1.0");
		DBUSMonitorService dbusService = ApplicationContextFactory
				.getBean(DBUSMonitorServiceImpl.class);
		
		List<AplusDeviceMonitorData> data = dbusService.collectAllMetricsOfDevice(conn, device);
		

		AplusDeviceMonitorData monitorData = data.get(0);
		Map<String, AplusMetricData> metricDatas = monitorData.getMetricDatas();
		Set<String> keySet = metricDatas.keySet();
		Iterator<String> iter = keySet.iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			System.out.println(metricDatas.get(key).getValue());
		}	

	}

}

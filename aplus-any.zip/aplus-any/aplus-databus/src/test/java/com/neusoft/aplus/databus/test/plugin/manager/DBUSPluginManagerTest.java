package com.neusoft.aplus.databus.test.plugin.manager;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.databus.biz.cache.DBUSLocalCache;
import com.neusoft.aplus.databus.biz.constants.DBUSPluginConstants;
import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;
import com.neusoft.aplus.databus.biz.plugin.manager.DBUSPluginManager;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;

/**
 * @author Mu Xian Ming
 * @date 2014年12月26日
 */
public class DBUSPluginManagerTest {
	private static DBUSPluginManager manager;
	
	@BeforeClass
	public static void initialize() {
		String basedir = FilenameUtils.getFullPath(new File("").getAbsolutePath());
		ApplicationContextFactory.initialize(
				new String[] { basedir + "aplus-probe-inquirer\\src\\main\\resources\\spring\\applicationContext-properties.xml" });
		manager = DBUSPluginManager.getInstance();
	}
	
	@Before
	public void setUp() throws Exception {
		DBUSLocalCache.getPluginCache().removeAll();
	}
	
	@Test
	public void testAddAndGet() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("PCPlugin.py");
		DBUSPlugin plugin = manager.add(filename).get();
		String id = DBUSDatabusUtil.getDeviceTypeId(plugin);
		assertSame("should get same plugin", plugin, manager.getById(id).get());

	}
	
	@Test
	public void testGetByFilename() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("PCPlugin.py");
		DBUSPlugin plugin = manager.add(filename).get();
		assertSame("should get same plugin", plugin, manager.getByFilename(filename).get());
	}
	
	
	@Test
	public void testRemoveExist() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("PCPlugin.py");
		manager.add(filename);
		DBUSPlugin plugin = manager.remove(filename).get();
		String pluginId = DBUSDatabusUtil.getDeviceTypeId(plugin);
		assertTrue("the plugin should've been removed", !manager.getById(pluginId).isPresent());
	}
	
	@Test
	public void testRemoveNonExist() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("PCPlugin.py");
		assertTrue(!manager.remove(filename).isPresent());
	}
	
	@Test
	public void testUpdate() {
		System.out.println("testUpdate:");
		String oldFilename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat(File.separator).concat("plugin_update_test")
				.concat(File.separator).concat("Original.py");
		String newFilename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat(File.separator).concat("plugin_update_test")
				.concat(File.separator).concat("CategoryChanged.py");
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("UpdatePlugin.py");
		try {
			FileUtils.copyFile(new File(oldFilename), new File(filename));
		} catch (Exception e) {
			e.printStackTrace();
		}
		DBUSPlugin plugin = manager.add(filename).get();
		String oldCategory = plugin.getCategory();
		System.out.println("Old category: " + oldCategory);
		try {
			FileUtils.copyFile(new File(newFilename), new File(filename));
		} catch (Exception e) {
			e.printStackTrace();
		}
		plugin = manager.update(filename).get();
		String newCategory = plugin.getCategory();
		System.out.println("New category: " + newCategory);
		FileUtils.deleteQuietly(new File(filename));
		assertFalse(newCategory.equals(oldCategory));
	}
	
	@Test
	public void testUpdateDeviceTypeId() {
		System.out.println("testUpdateDeviceTypeId:");
		String oldFilename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat(File.separator).concat("plugin_update_test")
				.concat(File.separator).concat("Original.py");
		String newFilename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat(File.separator).concat("plugin_update_test")
				.concat(File.separator).concat("VersionChanged.py");
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("UpdatePlugin.py");
		try {
			FileUtils.copyFile(new File(oldFilename), new File(filename));
		} catch (Exception e) {
			e.printStackTrace();
		}
		DBUSPlugin plugin = manager.add(filename).get();
		String oldID = DBUSDatabusUtil.getDeviceTypeId(plugin);
		System.out.println("Old ID: " + oldID);
		try {
			FileUtils.copyFile(new File(newFilename), new File(filename));
		} catch (Exception e) {
			e.printStackTrace();
		}
		plugin = manager.update(filename).get();
		String newID = DBUSDatabusUtil.getDeviceTypeId(plugin);
		System.out.println("New ID: " + newID);
		FileUtils.deleteQuietly(new File(filename));
		assertTrue(!manager.getById(oldID).isPresent());
		assertTrue(manager.getById(newID).isPresent());
	}
	
	@Test
	public void testUpdateWithError() {
		String oldFilename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat(File.separator).concat("plugin_update_test")
				.concat(File.separator).concat("Original.py");
		String newFilename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat(File.separator).concat("plugin_update_test")
				.concat(File.separator).concat("ChangedWithError.py");
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("UpdatePlugin.py");
		try {
			FileUtils.copyFile(new File(oldFilename), new File(filename));
		} catch (Exception e) {
			e.printStackTrace();
		}
		DBUSPlugin plugin = manager.add(filename).get();
		String oldID = DBUSDatabusUtil.getDeviceTypeId(plugin);
		try {
			FileUtils.copyFile(new File(newFilename), new File(filename));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertTrue(!manager.update(filename).isPresent());
		FileUtils.deleteQuietly(new File(filename));
		assertTrue(manager.getById(oldID).isPresent());
	}
	
}

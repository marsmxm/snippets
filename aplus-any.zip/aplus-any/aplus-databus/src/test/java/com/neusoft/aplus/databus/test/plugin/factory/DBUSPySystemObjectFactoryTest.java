package com.neusoft.aplus.databus.test.plugin.factory;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FilenameUtils;
import org.junit.BeforeClass;
import org.junit.Test;

import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.databus.biz.constants.DBUSPluginConstants;
import com.neusoft.aplus.databus.biz.plugin.factory.DBUSPySystemObjectFactory;
import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;
import com.neusoft.aplus.databus.biz.protocol.snmp.DBUSSnmp;


/**
 * @author Mu Xian Ming
 * @date 2014年12月23日
 */
public class DBUSPySystemObjectFactoryTest {
	private static DBUSPlugin plugin;
	private static String filename;
	
	
	@BeforeClass
	public static void setUp() throws Exception {
		String basedir = FilenameUtils.getFullPath(new File("").getAbsolutePath());
		ApplicationContextFactory.initialize(
				new String[] { basedir + "aplus-probe-inquirer\\src\\main\\resources\\spring\\applicationContext-properties.xml" });
		
		filename = DBUSPluginConstants.SCRIPT_PATH_TEST.concat("PCPlugin.py");
		DBUSPySystemObjectFactory factory = new DBUSPySystemObjectFactory(
						DBUSPlugin.class, filename, DBUSPluginConstants.PLUGIN_CLASS_NAME);
		plugin = (DBUSPlugin) factory.createObject();
		
	}
	
	@Test
	public void testCreateObject() {
		assertNotNull("script should've been created", plugin);
	}
	
	@Test
	public void testGetMetricDef() {
		List<Map<String, Object>> list = plugin.getMetricDef();
		for (Map<String, Object> map: list) {
			if (map.get("name") == "deviceName") {
				assertEquals("device name 1.3.6.1.2.1.1.5.0", "1.3.6.1.2.1.1.5.0", 
						map.get("code"));
				assertEquals("time unit is AplusTimeUnit.MINUTE", TimeUnit.MINUTES,
						map.get("timeUnit"));
			}
			if (map.get("name") == "deviceInfo") {
				assertEquals("device info 1.3.6.1.2.1.1.1.0", "1.3.6.1.2.1.1.1.0", 
						map.get("code"));
			}
		}
		
	}
	
	@Test
	public void testGetProtocol() {
		assertEquals("protocol is ProtocolConstants.SNMP", DBUSSnmp.getProtocol(),
				plugin.getProtocol());
	}
	
	@Test
	public void testGetAbsFilename() {
		assertEquals("name should equal", filename, plugin.getAbsFilename());
	}
	
	@Test
	public void testManyMetrics() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST.concat("ManyMetrics.py");
		DBUSPySystemObjectFactory factory = new DBUSPySystemObjectFactory(
						DBUSPlugin.class, filename, DBUSPluginConstants.PLUGIN_CLASS_NAME);
		DBUSPlugin plugin = (DBUSPlugin) factory.createObject();
		System.out.println(plugin.getMetricDef());
		System.out.println(plugin.getMetricDef().size());
	}
}

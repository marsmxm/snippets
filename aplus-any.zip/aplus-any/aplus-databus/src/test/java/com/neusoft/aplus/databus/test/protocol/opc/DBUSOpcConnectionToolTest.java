package com.neusoft.aplus.databus.test.protocol.opc;

import org.junit.Before;
import org.junit.Test;

import com.neusoft.aplus.databus.DataBusInit;
import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;
import com.neusoft.aplus.databus.biz.plugin.manager.DBUSPluginManager;
import com.neusoft.aplus.databus.biz.protocol.opc.DBUSOpcConnection;
import com.neusoft.aplus.databus.biz.protocol.opc.DBUSOpcConnectionTool;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;

/**
 * @author Mu Xian Ming
 * @date 2014年12月26日
 */
public class DBUSOpcConnectionToolTest {
	private AplusDeviceMonitorData data;
	
	@Before
	public void setUp() throws Exception {
		DataBusInit.init(new String[0]);
		DBUSOpcConnectionTool tool = DBUSOpcConnectionTool.getInstance();
		String deviceId = DBUSDatabusUtil.getDeviceTypeId("OPCTester", "1");
		DBUSPlugin plugin = DBUSPluginManager.getInstance().getById(deviceId).get();
		DBUSOpcConnection conn = (DBUSOpcConnection) plugin.getConnectionDef().get(0);
		AplusDevice device = new AplusDevice();
		device.setDeviceType(plugin.getDeviceType());
		device.setDeviceVersion(plugin.getVersion());
		data = tool.collectAllMetricsOfDevice(conn, device).get(0);
		for (String key: data.getMetricDatas().keySet()) {
			System.out.println("name:" + data.getMetricDatas().get(key).getName());
			System.out.println("value:" + data.getMetricDatas().get(key).getValue());
			System.out.println("Time:" + data.getMetricDatas().get(key).getRecordTime());
			System.out.println("@@@@@@@@@@");
		}
	}
	
	@Test
	public void testDummy() {
	}
	
//	@Test
//	public void testValidate() {
//		DBUSPluginManager manager = new DBUSPluginManager(
//				"C:\\Users\\neusoft\\workspace\\aplus-any\\aplus-databus\\src\\test\\resources\\plugins\\scripts\\NoClass.py");
//		assertFalse("No class", manager.validate());
//		manager = new DBUSPluginManager(
//				"C:\\Users\\neusoft\\workspace\\aplus-any\\aplus-databus\\src\\test\\resources\\plugins\\scripts\\NoFunction.py");
//		assertFalse("No function", manager.validate());
//		manager = new DBUSPluginManager(
//				"C:\\Users\\neusoft\\workspace\\aplus-any\\aplus-databus\\src\\test\\resources\\plugins\\scripts\\PCPlugin.py");
//		assertTrue("OK", manager.validate());
//	}
	
	
	
	
}

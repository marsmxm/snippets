package com.neusoft.aplus.databus.test.plugin.manager;

import static org.junit.Assert.assertEquals;

import java.io.File;

import org.apache.commons.io.FilenameUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.databus.biz.cache.DBUSLocalCache;
import com.neusoft.aplus.databus.biz.constants.DBUSPluginConstants;
import com.neusoft.aplus.databus.biz.plugin.manager.DBUSPluginManager;
import com.neusoft.aplus.databus.exception.DBUSPluginException;

/**
 * @author Mu Xian Ming
 * @date 2015年1月22日 上午10:31:47
 */
public class DBUSPluginValidatorTest {
	private static DBUSPluginManager manager;
	
	@BeforeClass
	public static void initialize() {
		String basedir = FilenameUtils.getFullPath(new File("").getAbsolutePath());
		ApplicationContextFactory.initialize(
				new String[] { basedir + "aplus-launch\\src\\main\\resources\\spring\\common\\applicationContext-properties.xml" });
		manager =  DBUSPluginManager.getInstance();
	}
	
	@Before
	public void setUp() throws Exception {
		DBUSLocalCache.getPluginCache().removeAll();
	}
	//脚本中没有类
	@Test(expected=DBUSPluginException.class)
	public void testAddNoClass() {
		
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("NoClass.py");
		System.out.println("=====filename===="+filename);
		try{
			manager.add(filename);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_NOCLASS, e.getEcode());
			e.throwEx();
		}
	}
	//脚本间设备类型重复
	@Test(expected=DBUSPluginException.class)
	public void testAddDuplicatePlugin() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("PCPlugin.py");
		String filename1 = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("DuplicatePlugin.py");
		manager.add(filename);
		try{
			manager.add(filename1);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_DUPLICATE, e.getEcode());
			e.throwEx();
		}
	}
	//未定义指标
	@Test(expected=DBUSPluginException.class)
	public void testAddNoMetric() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("NoMetric.py");
		try{
			manager.add(filename);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY, e.getEcode());
			for (DBUSPluginException sube : e.getSubExceptions()) {
				assertEquals(DBUSPluginException.PLUGIN_EXCEPTCODE_NO_METRIC,
						sube.getEcode());
			}
			e.throwEx();
		}
	}
	//校验每个指标Map的key是否为DBUSMetricConstants中已定义的常量值
	@Test(expected=DBUSPluginException.class)
	public void testAddWrongMetricKey() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("WrongMetricKey.py");
		try{
			manager.add(filename);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY, e.getEcode());
			assertEquals(2, e.getSubExceptions().size());
			for (DBUSPluginException sube : e.getSubExceptions()) {
				assertEquals(DBUSPluginException.PLUGIN_EXCEPTCODE_ILLEGAL_METRIC_KEY,
						sube.getEcode());
			}
			e.throwEx();
		}
	}
	//有重复的指标名
	@Test(expected=DBUSPluginException.class)
	public void testAddMetricNameDuplicate() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("MetricNameDuplicate.py");
		try{
			manager.add(filename);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY, e.getEcode());
			for (DBUSPluginException sube : e.getSubExceptions()) {
				assertEquals(DBUSPluginException.PLUGIN_EXCEPTCODE_METRIC_NAME_DUPLICATE,
						sube.getEcode());
			}
			e.throwEx();
		}
	}
	//如果指标是枚举型，那么枚举的方法必须有这个name的值
	@Test(expected=DBUSPluginException.class)
	public void testAddNoEnum() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("NoEnum.py");
		try{
			manager.add(filename);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY, e.getEcode());
			for (DBUSPluginException sube : e.getSubExceptions()) {
				assertEquals(DBUSPluginException.PLUGIN_EXCEPTCODE_NO_ENUM,
						sube.getEcode());
			}
			e.throwEx();
		}
	}
	//校验脚本中是否有路径的方法getAbsFilename
	@Test(expected=DBUSPluginException.class)
	public void testAddNoAbsFilename() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("NoAbsFilename.py");
		try{
			manager.add(filename);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY, e.getEcode());
			assertEquals(e.getSubExceptions().getFirst().getEcode(), 
					DBUSPluginException.PLUGIN_EXCEPTCODE_NO_ABS_FILENAME);
			e.throwEx();
		}
	}
	//校验设备和版本号不为空
	@Test(expected=DBUSPluginException.class)
	public void testAddNoDeviceTypeAndVersion() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("NoDeviceTypeNoVersion.py");
		try{
			manager.add(filename);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY, e.getEcode());
			e.throwEx();
		}
	}
	//校验脚本没有方法定义
	@Test(expected=DBUSPluginException.class)
	public void testAddNoFunction() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("NoFunction.py");
		try{
			manager.add(filename);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY, e.getEcode());
			e.throwEx();
		}
	}
	//校验指标范围
	@Test(expected=DBUSPluginException.class)
	public void testAddModbusError() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("ModbusError.py");
		try{
			manager.add(filename);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY, e.getEcode());
			for (DBUSPluginException sube : e.getSubExceptions()) {
				assertEquals(DBUSPluginException.PLUGIN_EXCEPTCODE_MODBUS_OUT_RANGE,
						sube.getEcode());
			}
			e.throwEx();
		}
	}
	//校验指标范围
	@Test(expected=DBUSPluginException.class)
	public void testAddModbusStartGreaterThanEnd() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("ModbusStartGreaterThanEnd.py");
		try{
			manager.add(filename);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY, e.getEcode());
			for (DBUSPluginException sube : e.getSubExceptions()) {
				assertEquals(DBUSPluginException.PLUGIN_EXCEPTCODE_START_GREATER_THAN_END,
						sube.getEcode());
			}
			e.throwEx();
		}
	}
	//getProtocolMode函数返回空的SNMP版本号
	@Test(expected=DBUSPluginException.class)
	public void testAddNoSNMPVersion() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("NoSNMPVersion.py");
		try{
			manager.add(filename);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY, e.getEcode());
			for (DBUSPluginException sube : e.getSubExceptions()) {
				assertEquals(DBUSPluginException.PLUGIN_EXCEPTCODE_NO_SNMP_VERSION,
						sube.getEcode());
			}
			e.throwEx();
		}
	}
	//getProtocolMode函数返回的SNMP版本号v1不合法
	@Test(expected=DBUSPluginException.class)
	public void testAddIllegalSNMPVersion() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("WrongSNMPVersion.py");
		try{
			manager.add(filename);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY, e.getEcode());
			for (DBUSPluginException sube : e.getSubExceptions()) {
				assertEquals(DBUSPluginException.PLUGIN_EXCEPTCODE_SNMP_VERSION_ILLEGAL,
						sube.getEcode());
			}
			e.throwEx();
		}
	}
	
	
	//有重复的defkey
	@Test(expected=DBUSPluginException.class)
	public void testAddMetricDefKeyDuplicate() {
		String filename = DBUSPluginConstants.SCRIPT_PATH_TEST
				.concat("MetricDefKeyDuplicate.py");
		try{
			manager.add(filename);
		} catch (DBUSPluginException e) {
			assertEquals(
					DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY, e.getEcode());
			e.throwEx();
		}
	}
	
}

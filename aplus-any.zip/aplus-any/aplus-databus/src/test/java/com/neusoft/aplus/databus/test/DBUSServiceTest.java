package com.neusoft.aplus.databus.test;

import com.neusoft.aplus.common.test.BaseSpringTest;
import org.junit.Test;

import java.util.Date;

/**
 * @author wuhao
 * @date 2015-1-16 下午2:13:47
 */
public class DBUSServiceTest extends BaseSpringTest {

	@Test
	public void testDummy() {
		while (true) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
			} 
			System.out.println(new Date());
		}
	}

	public static void main(String[] args) {
		System.out.printf("%02x", 2);
	}
}

package com.neusoft.aplus.databus.test;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FilenameUtils;

import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.databus.DataBusInit;
import com.neusoft.aplus.databus.biz.protocol.modbus.DBUSModbus;
import com.neusoft.aplus.databus.biz.protocol.modbus.DBUSModbusConnection;
import com.neusoft.aplus.databus.biz.protocol.opc.DBUSOpcConnection;
import com.neusoft.aplus.databus.biz.protocol.snmp.DBUSSnmpConnection;
import com.neusoft.aplus.databus.biz.service.bo.DBUSMonitorService;
import com.neusoft.aplus.databus.biz.service.bo.impl.DBUSMonitorServiceImpl;
import com.neusoft.aplus.model.bizentity.AplusDevice;

/**
 * @author zhangjian
 * @data 2015年4月24日 下午1:40:43
 */
public class DBUSControlServiceTest {

	public static void main(String[] args) {
		String basedir = FilenameUtils.getFullPath(new File("")
				.getAbsolutePath());
		ApplicationContextFactory
				.initialize(new String[] {
						basedir
								+ "aplus-common\\src\\main\\resources\\spring\\applicationContext-properties.xml",
						basedir
								+ "aplus-common\\src\\main\\resources\\spring\\applicationContext-common.xml",
						basedir
								+ "aplus-common\\src\\main\\resources\\spring\\applicationContext-dataSource.xml" });

		try {
			DataBusInit.init(new String[0]);
		} catch (IOException e) {
			e.printStackTrace();
		}
		DBUSControlServiceTest test = new DBUSControlServiceTest();
		test.testOpc();
	}

	public void testOpc() {
		DBUSOpcConnection conn = new DBUSOpcConnection();
		conn.setHost("10.1.5.191");
		conn.setDomain("WORKGROUP");
		conn.setUser("neusoft");
		conn.setPassword("zhj19890206");
		conn.setClsId("F8582CF2-88FB-11D0-B850-00C0F0104305");
		conn.setProgId("");

		DBUSMonitorService dbusService = new DBUSMonitorServiceImpl();
		AplusDevice device = new AplusDevice();
		device.setDeviceType("OPCTester");
		device.setDeviceVersion("v1.0");

		boolean result = dbusService.control(conn, device, "Action2", 1);
		System.out.println(result);
	}

	public void testSnmp() {
		DBUSSnmpConnection conn = new DBUSSnmpConnection();

		conn.setIpAddress("10.1.5.191");
		conn.setPort("161");
		conn.setCommunity("public");
		conn.setRetry("3");
		conn.setTimeOut("1500");
		conn.setVersion("1");

		AplusDevice device = new AplusDevice();
		device.setDeviceType("HP-PC");
		device.setDeviceVersion("v1.0");
		DBUSMonitorService dbusService = new DBUSMonitorServiceImpl();
		boolean result = dbusService.control(conn, device, "Action2", "bbb-pc");
		System.out.println(result);
	}

	public void testModbusTCP() {
		DBUSModbusConnection conn = new DBUSModbusConnection();
		conn.setIpAddress("10.1.5.191");
		conn.setPort(502);
		conn.setConnectiontype(DBUSModbus.TCP);
		conn.setCommunicatetyp(DBUSModbus.TCP);
		conn.setSlave("1");

		AplusDevice device = new AplusDevice();
		device.setDeviceType("Modbus-simulate");
		device.setDeviceVersion("1");
		DBUSMonitorService dbusService = new DBUSMonitorServiceImpl();
		boolean result = dbusService.control(conn, device, "Action2", "2");
		System.out.println(result);
	}

	public void testModbusRTU() {
		DBUSModbusConnection conn = new DBUSModbusConnection();
		conn.setConnectiontype(DBUSModbus.COM);
		conn.setCommunicatetyp(DBUSModbus.RTU);
		conn.setComValue("COM2");
		conn.setParity(0);
		conn.setDataBits(8);
		conn.setBaudRate(19200);
		conn.setRetry(0);
		conn.setStopBits(1);
		conn.setSlave("1");

		AplusDevice device = new AplusDevice();
		device.setDeviceType("Modbus-simulate");
		device.setDeviceVersion("1");
		DBUSMonitorService dbusService = new DBUSMonitorServiceImpl();
		boolean result = dbusService.control(conn, device, "Action2", 3);
		System.out.println(result);
	}
}

package com.neusoft.aplus.databus.test.protocol.opc;

import java.net.UnknownHostException;
import java.util.concurrent.Executors;

import org.jinterop.dcom.common.JIException;
import org.junit.Test;
import org.openscada.opc.lib.common.AlreadyConnectedException;
import org.openscada.opc.lib.common.ConnectionInformation;
import org.openscada.opc.lib.common.NotConnectedException;
import org.openscada.opc.lib.da.AccessBase;
import org.openscada.opc.lib.da.AddFailedException;
import org.openscada.opc.lib.da.DataCallback;
import org.openscada.opc.lib.da.DuplicateGroupException;
import org.openscada.opc.lib.da.Item;
import org.openscada.opc.lib.da.ItemState;
import org.openscada.opc.lib.da.Server;
import org.openscada.opc.lib.da.SyncAccess;

/**
 * @author zh_ch
 * @date 2015年4月23日 下午4:05:07
 */
public class OPCTest {
	@Test
	public void testOpc() {

		ConnectionInformation connection = new ConnectionInformation();
		connection.setHost("10.1.5.149");
		//udpConnection.setDomain("WORKGROUP");
		connection.setUser("wuhao");
		connection.setPassword("Eminem123");
		//udpConnection.setProgId("Matrikon.OPC.Simulation.1");
		connection.setClsid("F8582CF2-88FB-11D0-B850-00C0F0104305");

		Server server = new Server(connection,
				Executors.newSingleThreadScheduledExecutor());
		AccessBase accessBase = null;
		try {
			server.connect();
				accessBase = new SyncAccess(server, 1000);
				accessBase.addItem("Random.Int4", new DataCallback() {
					@Override
					public void changed(Item paramItem, ItemState paramItemState) {
						String text = null;
						try {
							text = paramItemState.getValue().getObject().toString();
						} catch (JIException e) {
							e.printStackTrace();
						}
						
						System.out.println("text == " + Long.valueOf(text));
					}

				});

				accessBase.bind();
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (JIException e) {
			e.printStackTrace();
		} catch (AlreadyConnectedException e) {
			e.printStackTrace();
		} catch (NotConnectedException e) {
			e.printStackTrace();
		} catch (DuplicateGroupException e) {
			e.printStackTrace();
		} catch (AddFailedException e) {
			e.printStackTrace();
		} finally {
			try {
				if (accessBase != null) {
					accessBase.unbind();
				}
			} catch (JIException e) {
				e.printStackTrace();
			}
		}
	}
}

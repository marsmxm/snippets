package com.neusoft.aplus.databus.test.protocol.modbus;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.junit.Before;
import org.junit.Test;

import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.databus.DataBusInit;
import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;
import com.neusoft.aplus.databus.biz.plugin.manager.DBUSPluginManager;
import com.neusoft.aplus.databus.biz.protocol.modbus.DBUSModbus;
import com.neusoft.aplus.databus.biz.protocol.modbus.DBUSModbusConnection;
import com.neusoft.aplus.databus.biz.service.bo.DBUSMonitorService;
import com.neusoft.aplus.databus.biz.service.bo.impl.DBUSMonitorServiceImpl;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.bizentity.AplusMetricData;

/**
 * @author wuhao
 * @date 2015-1-8 上午9:20:25
 */
public class DBUSModbusConnectionToolTest {

	@Before
	public void setUp() throws Exception {
		String basedir = FilenameUtils.getFullPath(new File("").getAbsolutePath());
		ApplicationContextFactory.initialize(
				new String[] { basedir + "aplus-probe-inquirer\\src\\main\\resources\\spring\\applicationContext-properties.xml",
						 basedir + "aplus-probe-inquirer\\src\\main\\resources\\spring\\applicationContext-common.xml",
						 basedir + "aplus-probe-inquirer\\src\\main\\resources\\spring\\applicationContext-dataSource.xml"});
		
		
		DataBusInit.init(new String[0]);
		
		String deviceId = DBUSDatabusUtil.getDeviceTypeId("Modbus-simulate", "v1");
		DBUSPlugin plugin = DBUSPluginManager.getInstance().getById(deviceId).get();
		DBUSModbusConnection conn = new DBUSModbusConnection();
		
//		conn.setComValue("COM1");
//		conn.setParity(0);
//		conn.setDataBits(8);
//		conn.setBaudRate(19200);
//		conn.setRetry(0);
//		conn.setStopBits(1);
//		conn.setConnectiontype(DBUSModbus.COM);
//		conn.setCommunicatetyp(DBUSModbus.RTU);
		
		conn.setIpAddress("10.1.5.149");
		conn.setPort(502);
		conn.setConnectiontype(DBUSModbus.TCP);
		conn.setSlave("1");
		
		AplusDevice device = new AplusDevice();
		device.setDeviceType(plugin.getDeviceType());
		device.setDeviceVersion(plugin.getVersion());
		
		DBUSMonitorService dbusService = ApplicationContextFactory
				.getBean(DBUSMonitorServiceImpl.class);
		
		List<AplusDeviceMonitorData> data = dbusService.collectAllMetricsOfDevice(conn, device);
		
		AplusDeviceMonitorData monitorData  = data.get(0);
		Map<String, AplusMetricData> metricDatas = monitorData.getMetricDatas();
		Set<String> keySet = metricDatas.keySet();
		Iterator<String> iter = keySet.iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			System.out.println(metricDatas.get(key));
		}	
	}
	
	@Test
	public void testDummy() {
	}
}

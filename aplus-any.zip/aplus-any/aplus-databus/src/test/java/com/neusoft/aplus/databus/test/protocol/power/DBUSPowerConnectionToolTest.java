/**
 * 
 */
package com.neusoft.aplus.databus.test.protocol.power;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.junit.Before;
import org.junit.Test;

import com.neusoft.aplus.common.spring.ApplicationContextFactory;
import com.neusoft.aplus.databus.DataBusInit;
import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;
import com.neusoft.aplus.databus.biz.plugin.manager.DBUSPluginManager;
import com.neusoft.aplus.databus.biz.protocol.DBUSConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.power.DBUSPowerConnection;
import com.neusoft.aplus.databus.biz.protocol.power.DBUSPowerConnectionTool;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.bizentity.AplusMetricData;

/**
 * @author yaobo
 *
 */
public class DBUSPowerConnectionToolTest {
	@Before
	public void setUp() throws Exception {
		String basedir = FilenameUtils.getFullPath(new File("")
				.getAbsolutePath());
		ApplicationContextFactory
				.initialize(new String[] {
						basedir
								+ "aplus-probe-inquirer\\src\\main\\resources\\spring\\applicationContext-properties.xml",
						basedir
								+ "aplus-probe-inquirer\\src\\main\\resources\\spring\\applicationContext-common.xml",
						basedir
								+ "aplus-probe-inquirer\\src\\main\\resources\\spring\\applicationContext-dataSource.xml" });
		DataBusInit.init(null);

	}

	@Test
	public void Test() {
		DBUSConnectionTool tool = DBUSPowerConnectionTool.getInstance();

		String deviceId = DBUSDatabusUtil
				.getDeviceTypeId("Power-simulate", "v1");
		DBUSPlugin plugin = DBUSPluginManager.getInstance().getById(deviceId)
				.get();
		DBUSPowerConnection conn = new DBUSPowerConnection();

		// conn.setComValue("COM1");
		// conn.setParity(0);
		// conn.setDataBits(8);
		// conn.setBaudRate(19200);
		// conn.setRetry(0);
		// conn.setStopBits(1);
		// conn.setConnectiontype(DBUSModbus.COM);
		// conn.setCommunicatetyp(DBUSModbus.RTU);

		/*
		 * conn.setIpAddress("10.1.5.149"); conn.setPort(502);
		 * conn.setConnectiontype(DBUSModbus.TCP); conn.setSlave("1");
		 */
		conn.setHost("10.1.5.191");
		conn.setPort("702");

		AplusDevice device = new AplusDevice();
		device.setFqn("powerFQN");
		device.setDeviceType(plugin.getDeviceType());
		device.setDeviceVersion(plugin.getVersion());
		List<AplusDeviceMonitorData> data = tool.collectAllMetricsOfDevice(
				conn, device);
		for(int i=0;i<data.size();i++){
			AplusDeviceMonitorData monitorData = data.get(i);
			Map<String, AplusMetricData> metricDatas = monitorData.getMetricDatas();
			Set<String> keySet = metricDatas.keySet();
			Iterator<String> iter = keySet.iterator();
			while (iter.hasNext()) {
				String key = iter.next();
				AplusMetricData ad = metricDatas.get(key);
				System.out.println(ad.getName()+":"+ad.getValue());
				System.out.println("==============================================");
			}
		}

	

	}
}

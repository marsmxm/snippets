package com.neusoft.aplus.databus.test.plugin.monitor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import org.junit.Test;

import static org.mockito.Mockito.*;

import com.neusoft.aplus.common.test.BaseSpringTest;
import com.neusoft.aplus.databus.biz.plugin.monitor.DBUSFileListener;
import com.neusoft.aplus.databus.biz.plugin.monitor.DBUSFileMonitor;

/**
 * @author wangcd
 * @date 2014年8月1日 下午1:50:51
 */
public class DBUSFileMonitorTest extends BaseSpringTest {
	
	@Test
	public void directoryMonitor() throws Exception {
		DBUSFileListener listener = mock(DBUSFileListener.class);
		
		String monitorDir = new File("").getAbsolutePath() + File.separator + "src"
				+ File.separator + "test" + File.separator + "resources"
				+ File.separator;
		
		//启动文件监控
		DBUSFileMonitor.addMonitorPath(monitorDir, listener);
		DBUSFileMonitor.start();
		
		String createFilePath = monitorDir + "FileTest.txt";
		File testFile = new File(createFilePath);
		
		//新文件操作及验证
		testFile.createNewFile();
		Thread.sleep(1000);
		verify(listener, times(1)).onFileCreate(new File(createFilePath));
		
		//修改文件操作及验证
		BufferedWriter bw = new BufferedWriter(new FileWriter(testFile));
		bw.write("change file");
		bw.close();
		Thread.sleep(11000);
		verify(listener, times(1)).onFileChange(new File(createFilePath));
		
		//删除文件操作及验证
		testFile.delete();
		Thread.sleep(11000);
		verify(listener, times(1)).onFileDelete(new File(createFilePath));
	}
	
	public static void main(String[] args){
		System.out.println(System.getProperty("basedir"));
	}
	
}

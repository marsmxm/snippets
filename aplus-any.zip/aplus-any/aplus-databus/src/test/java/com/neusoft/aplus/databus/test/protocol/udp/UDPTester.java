package com.neusoft.aplus.databus.test.protocol.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Arrays;

/**
 * @author mxm
 * @date 15-7-9
 */
public class UDPTester {
    public static void main(String[] args) throws IOException {
        DatagramSocket client = new DatagramSocket();



//      InetAddress addr = InetAddress.getByName("127.0.0.1");
        InetAddress addr = InetAddress.getByName("10.1.5.154");

        int port = 8098;
        byte[] sendBuf = getStatusCmd();
        DatagramPacket sendPacket = new DatagramPacket(sendBuf, sendBuf.length,
                addr, port);

        client.send(sendPacket);

        byte[] recvBuf = new byte[8];

        DatagramPacket recvPacket = new DatagramPacket(recvBuf, recvBuf.length);

        client.receive(recvPacket);

        System.out.println("收到:" + Arrays.toString(recvBuf));
        client.close();
    }

    public static byte[] getStatusCmd() {
        byte[] sendBuf = new byte[11];
        sendBuf[0] = 11;
        sendBuf[1] = 5;
        sendBuf[2] = 2;
        sendBuf[3] = 0;
        sendBuf[4] = 1;
        sendBuf[5] = 0;
        sendBuf[6] = 2;
        sendBuf[7] = 3;
        sendBuf[8] = 85;
        sendBuf[9] = 1;
        sendBuf[10] = 110;
        return sendBuf;
    }
}

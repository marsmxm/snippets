package com.neusoft.aplus.databus.biz.protocol.modbus;
/**
 * modbus协议连接类型，用来设定起始位和长度
 * @author wuhao
 * @date 2015-1-22 上午10:21:55
 */
public enum DBUSModbusConnectionType {

	MODBUSRTU(2*2, 6), DIANZONG(10*2, 24),MODBUSTCP(2*8,18),OTHERPORTAL(4,7);

	private int startPosition;

	private int length;

	DBUSModbusConnectionType(int startPosition, int length) {
		this.startPosition = startPosition;
		this.length = length;
	}

	public int getStartPosition() {
		return startPosition;
	}

	public void setStartPosition(int startPosition) {
		this.startPosition = startPosition;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

}

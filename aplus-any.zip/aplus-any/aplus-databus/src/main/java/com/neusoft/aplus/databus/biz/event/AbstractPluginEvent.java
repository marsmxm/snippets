package com.neusoft.aplus.databus.biz.event;

import com.neusoft.aplus.common.util.JSONUtil;

/**
 * 通过EventBus传输的Event类
 *
 * @author mxm
 * @date 15-5-28
 */
public abstract class AbstractPluginEvent {
	public boolean isCaseOf(Class<? extends AbstractPluginEvent> eventClass) {
		return eventClass.isInstance(this);
	}

    @Override
	public String toString() {
		return JSONUtil.getJsonString(this);
	}
}

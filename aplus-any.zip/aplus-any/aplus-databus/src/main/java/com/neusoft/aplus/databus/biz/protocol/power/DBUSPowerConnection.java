/**
 * 
 */
package com.neusoft.aplus.databus.biz.protocol.power;

import org.apache.commons.lang.StringUtils;

import com.neusoft.aplus.databus.exception.DBUSProtocolException;
import com.neusoft.aplus.model.bizentity.AplusConnection;

/**
 * @author yaobo
 *
 */
public class DBUSPowerConnection extends AplusConnection {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	// 主机名
	public static final String HOST = "host";
	
	//端口
	public static final String PORT = "port";

	public String getHost() {
		return String.valueOf(get(HOST));
	}

	public void setHost(String host) {
		put(HOST, host);
	}


	public  String getPort() {
		return String.valueOf(get(PORT));
	}
	public void setPort(String port) {
		put(PORT, port);
	}
	
	
	public static DBUSPowerConnection of(AplusConnection conn) {
		String host = String.valueOf(conn.get(HOST));
		String port = String.valueOf(conn.get(PORT));
		
		if (StringUtils.isBlank(host) || StringUtils.isBlank(port)) {
			DBUSProtocolException
					.throwException(DBUSProtocolException.OPC_PARA_ERROR);
		}

		DBUSPowerConnection newConn = new DBUSPowerConnection();

		newConn.setHost(host);
		newConn.setPort(port);
		return newConn;
	}

	
	
	
	
	

}

package com.neusoft.aplus.databus.biz.service.bo.impl;

import java.lang.reflect.Constructor;
import java.util.List;
import java.util.Map;

import com.neusoft.aplus.databus.biz.protocol.udp.steel.DBUSUDPSteel;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.DBUSUDPSteelConnectionTool;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neusoft.aplus.common.config.NettyClientConf;
import com.neusoft.aplus.common.util.SpringUtil;
import com.neusoft.aplus.databus.biz.constants.DBUSMetricConstants;
import com.neusoft.aplus.databus.biz.model.DBUSMetric;
import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;
import com.neusoft.aplus.databus.biz.plugin.manager.DBUSPluginManager;
import com.neusoft.aplus.databus.biz.protocol.DBUSConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.modbus.DBUSModbus;
import com.neusoft.aplus.databus.biz.protocol.modbus.DBUSModbusConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.opc.DBUSOpc;
import com.neusoft.aplus.databus.biz.protocol.opc.DBUSOpcConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.power.DBUSPower;
import com.neusoft.aplus.databus.biz.protocol.power.DBUSPowerConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.snmp.DBUSSnmp;
import com.neusoft.aplus.databus.biz.protocol.snmp.DBUSSnmpConnectionTool;
import com.neusoft.aplus.databus.biz.service.bo.DBUSMonitorService;
import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusControlData;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.dbentity.table.AplusMetricEntity;

/**
 * 监控数据采集的实现类
 * 
 * @author WanWei
 * @date 2014-12-24 下午12:22:41
 */
@Service
public class DBUSMonitorServiceImpl implements DBUSMonitorService {
	private static Logger log = LoggerFactory
			.getLogger(DBUSMonitorServiceImpl.class);

	@Override
	public List<AplusDeviceMonitorData> collectAllMetricsOfDevice(
			AplusConnection connection, AplusDevice device)
			throws DBUSPluginException {
		return collectSomeMetricsOfDevice(connection, device, null);
	}

	@Override
	public List<AplusDeviceMonitorData> collectSomeMetricsOfDevice(
			AplusConnection connection, AplusDevice device, List<String> metrics)
			throws DBUSPluginException {
		List<AplusDeviceMonitorData> monitorDataList = Lists.newArrayList();

		String deviceId = DBUSDatabusUtil.getDeviceTypeId(
				device.getDeviceType(), device.getDeviceVersion());

		Optional<DBUSPlugin> pluginOption = DBUSPluginManager.getInstance()
				.getById(deviceId);
		if (pluginOption.isPresent()) {
			DBUSPlugin plugin = pluginOption.get();
			// 根据deviceId，找到配置文件中的处理类
			DBUSConnectionTool connectiontool = initConnectionTool(deviceId,
					plugin.getProtocol());
			if (connectiontool != null) {
				// 采集
				monitorDataList = connectiontool.collectSomeMetricsOfDevice(
						connection, device, metrics);
				monitorDataList = plugin.monitor(null,
						Lists.newArrayList(monitorDataList));
			} else {
				monitorDataList = plugin.monitor(connection, null);
			}
		} else {
			Object[] params = { deviceId };
			DBUSPluginException e = new DBUSPluginException(
					DBUSPluginException.EXCEPTCODE_NO_PLUGIN, null, params,
					null);
			log.error("采集时异常: {}", e.getErrorMsg());
			e.throwEx();
		}

		return monitorDataList;
	}

	@Override
	public List<AplusDeviceMonitorData> collectDeviceByMetricEntity(
			AplusConnection connection, AplusDevice device,
			List<AplusMetricEntity> metricList) throws DBUSPluginException {
		List<AplusDeviceMonitorData> monitorDataList = Lists.newArrayList();
		DBUSMetric metricsMap = constructDBUSMetric(metricList);
		String deviceId = DBUSDatabusUtil.getDeviceTypeId(
				device.getDeviceType(), device.getDeviceVersion());
		Optional<DBUSPlugin> pluginOption = DBUSPluginManager.getInstance()
				.getById(deviceId);
		if (pluginOption.isPresent()) {
			DBUSPlugin plugin = pluginOption.get();
			// 根据deviceId，找到配置文件中的处理类
			DBUSConnectionTool connTool = initConnToolFromScript(plugin.getProtocol());
			if (connTool != null) {
				monitorDataList = connTool.collectDeviceByMetricEntity(
						connection, device, metricsMap);
				monitorDataList = plugin.monitor(null,
						Lists.newArrayList(monitorDataList));
			} else {
				// 非常规支持的协议走plugin脚本
				monitorDataList = plugin.monitor(connection, null);
			}
		} else {
			// 获取配置
			NettyClientConf config = SpringUtil.getBean(NettyClientConf.class);
			String className = config.getType2Protocol().get(deviceId);
			if (StringUtils.isBlank(className)) {
				Object[] params = { deviceId };
				DBUSPluginException e = new DBUSPluginException(
						DBUSPluginException.EXCEPTCODE_NO_PLUGIN, null, params,
						null);
				log.error("采集时异常: {}", e.getErrorMsg());
				e.throwEx();
			} else {
				DBUSConnectionTool connTool = initConnToolFromConf(className);
				monitorDataList = connTool.collectDeviceByMetricEntity(
						connection, device, metricsMap);
			}
		}

		return monitorDataList;
	}

	/**
	 * 修改指标的数据
	 * 
	 * @param connection 链接信息
	 * @param device 资源信息
	 * @param actionName 脚本中对应的actionName
	 * @param value 指标的值
	 * @return 控制是否成功
	 * @author zhangjian
	 * @date 2015年4月21日 上午10:50:46
	 * */
	@Override
	public boolean control(AplusConnection connection, AplusDevice device,
			String actionName, Object... value) {

		String deviceId = DBUSDatabusUtil.getDeviceTypeId(
				device.getDeviceType(), device.getDeviceVersion());
		Optional<DBUSPlugin> pluginOption = DBUSPluginManager.getInstance()
				.getById(deviceId);
		if (pluginOption.isPresent()) {
			DBUSPlugin plugin = pluginOption.get();
			// 根据deviceId，找到配置文件中的处理类
			DBUSConnectionTool connectiontool = initConnectionTool(deviceId,
					plugin.getProtocol());
			if (connectiontool != null) {
				return connectiontool.control(connection, connectiontool,
						device, actionName, value);
			} else {
				return plugin.control(connection, actionName, value);
			}
		} else {
			Object[] params = { deviceId };
			DBUSPluginException e = new DBUSPluginException(
					DBUSPluginException.EXCEPTCODE_NO_PLUGIN, null, params,
					null);
			log.error("控制时异常: {}", e.getErrorMsg());
			e.throwEx();
			return false;
		}
	}

	private DBUSConnectionTool initConnectionTool(String deviceId,
			String protocol) {
		DBUSConnectionTool connectiontool = null;

		NettyClientConf config = SpringUtil.getBean(NettyClientConf.class);
		String className = config.getType2Protocol().get(deviceId);
		if (StringUtils.isBlank(className) || className.equals("null")) {
			// 若配置文件内未配置对应ID的采集类则根据协议匹配
			if (protocol.equals(DBUSSnmp.getProtocol())) {
				connectiontool = DBUSSnmpConnectionTool.getInstance();
			} else if (protocol.equals(DBUSModbus.getProtocol())) {
				connectiontool = DBUSModbusConnectionTool.getInstance();
			} else if (protocol.equals(DBUSOpc.getProtocol())) {
				connectiontool = DBUSOpcConnectionTool.getInstance();
			} else if (protocol.equals(DBUSPower.getProtocol())) {
				connectiontool = DBUSPowerConnectionTool.getInstance();
			}
		} else {
			try {
				// 根据找到deviceId对应的处理类，生成对应的实体类
				Class<?> klass = Class.forName(className);
				Constructor<?> con = klass.getDeclaredConstructor();
				con.setAccessible(true);
				connectiontool = (DBUSConnectionTool) con.newInstance();
			} catch (Exception e) {
				Object[] params = { className };
				DBUSPluginException ex = new DBUSPluginException(
						DBUSPluginException.PLUGIN_EXCEPTCODE_INIT_CON_TOOL_FAIL,
						null, params, null);
				ex.throwEx();
			}
		}
		return connectiontool;
	}

	private DBUSMetric constructDBUSMetric(List<AplusMetricEntity> metricList) {
		DBUSMetric metricsMap = new DBUSMetric();
		for (AplusMetricEntity entity : metricList) {
			Map<String, Object> valueMap = Maps.newHashMap();
			valueMap.put(DBUSMetricConstants.NAME, entity.getMetricName());
			valueMap.put(DBUSMetricConstants.CODE, entity.getMetricCode());
			valueMap.put(DBUSMetricConstants.TYPE, entity.getMetricType());
			valueMap.put(DBUSMetricConstants.ACTIVE, entity.getMetricActive());
			metricsMap.put(entity.getMetricName(), valueMap);
		}

		return metricsMap;
	}

	private DBUSConnectionTool initConnToolFromConf(String className) {
		DBUSConnectionTool connecionTool = null;
		try {
			// 根据找到deviceId对应的处理类，生成对应的实体类
			Class<?> klass = Class.forName(className);
			Constructor<?> con = klass.getDeclaredConstructor();
			con.setAccessible(true);
			connecionTool = (DBUSConnectionTool) con.newInstance();
		} catch (Exception e) {
			Object[] params = { className };
			DBUSPluginException ex = new DBUSPluginException(
					DBUSPluginException.PLUGIN_EXCEPTCODE_INIT_CON_TOOL_FAIL,
					null, params, null);
			ex.throwEx();
		}

		return connecionTool;
	}

	private DBUSConnectionTool initConnToolFromScript(String protocol) {
		DBUSConnectionTool connecionTool = null;
		if (protocol.equals(DBUSSnmp.getProtocol())) {
			connecionTool = DBUSSnmpConnectionTool.getInstance();
		} else if (protocol.equals(DBUSModbus.getProtocol())) {
			connecionTool = DBUSModbusConnectionTool.getInstance();
		} else if (protocol.equals(DBUSOpc.getProtocol())) {
			connecionTool = DBUSOpcConnectionTool.getInstance();
		} else if (protocol.equals(DBUSPower.getProtocol())) {
			connecionTool = DBUSPowerConnectionTool.getInstance();
		} else if (protocol.equals(DBUSUDPSteel.getProtocol())) {
			connecionTool = DBUSUDPSteelConnectionTool.getInstance();
		}

		return connecionTool;
	}

	@Override
	public List<String> controlByActionEntity(AplusConnection connection,
			AplusDevice device, List<AplusControlData> controlDataList)
			throws DBUSPluginException {

		DBUSConnectionTool connTool = null;
		String deviceId = DBUSDatabusUtil.getDeviceTypeId(
				device.getDeviceType(), device.getDeviceVersion());
		Optional<DBUSPlugin> pluginOption = DBUSPluginManager.getInstance()
				.getById(deviceId);

		boolean processByPy = false;
		DBUSPlugin plugin = null;
		if (pluginOption.isPresent()) {
			plugin = pluginOption.get();
			// 根据deviceId，找到配置文件中的处理类
			connTool = initConnToolFromScript(plugin.getProtocol());
			// 如果没找到，走python脚本的处理方法
			if (connTool == null) {
				processByPy = true;
			}
		} else {
			// 获取配置
			NettyClientConf config = SpringUtil.getBean(NettyClientConf.class);
			String className = config.getType2Protocol().get(deviceId);
			if (StringUtils.isBlank(className)) {
				Object[] params = { deviceId };
				DBUSPluginException e = new DBUSPluginException(
						DBUSPluginException.EXCEPTCODE_NO_PLUGIN, null, params,
						null);
				log.error("操作时异常: {}", e.getErrorMsg());
				e.throwEx();
			} else {
				connTool = initConnToolFromConf(className);
			}
		}
		
		// 操作失败的ActionName存在此处。
		List<String> falseList = Lists.newArrayList();
		// 循环调用Action
		for (AplusControlData controlData : controlDataList) {
			boolean result;

			if (processByPy) {
				// 通过python脚本调用
				result = plugin.control(connection,
						controlData.getActionName(),
						controlData.getActionValues());
			} else {
				assert connTool != null;
				result = connTool.controlByActionEntity(connection,
						device, controlData);
			}
			if (!result) {
				falseList.add(controlData.getActionName());
			}
		}

		return falseList;
	}
}

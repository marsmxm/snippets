package com.neusoft.aplus.databus.biz.plugin.factory;

import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.log4j.Logger;
import com.neusoft.aplus.databus.biz.plugin.loader.DBUSPluginClassLoader;

/**
 * 为了应对可能的jar包冲突问题，定义工厂类可创建自定义ClassLoader
 * @author WanWei
 * @date 2014-12-27 下午1:36:28
 */
public class DBUSPluginClassLoaderFactory {
	
	private static Logger log = Logger.getLogger(DBUSPluginClassLoaderFactory.class);
	
	/**
	 * 传入需要额外加载的jar路径，创建自定义ClassLoader
	 * 
	 * @param external
	 * 			需要在自定义ClassLoader加载的jar包路径
	 * @return
	 * @author WanWei
	 * @date 2014-12-27 下午2:08:26
	 */
	public static DBUSPluginClassLoader createPluginClassLoader(List<URL> external){
		//获取系统的ClassLoader
		URLClassLoader sysClassLoader = (URLClassLoader)Thread.currentThread().getContextClassLoader();
		//获取系统默认的CLASSPATH
		URL[] sysUrls = sysClassLoader.getURLs();
		DBUSPluginClassLoader pluginClassLoader;
		
		if((external == null) || external.isEmpty()){
			log.warn("没有需要引入的外部jar包, 创建的DBUSPluginClassLoader跟系统ClassLoader一样, 无特殊作用！");
			pluginClassLoader = new DBUSPluginClassLoader(sysUrls);
			return pluginClassLoader;
		}
		
		ArrayList<URL> urlList = new ArrayList<URL>(Arrays.asList(sysUrls));
		//系统路径+外部路径=自定义ClassLoader的路径
		urlList.addAll(external);
		
		URL[] pluginUrls = new URL[0];
		pluginUrls = urlList.toArray(pluginUrls);
		
		pluginClassLoader = new DBUSPluginClassLoader(pluginUrls);
		return pluginClassLoader;
	}
		
}

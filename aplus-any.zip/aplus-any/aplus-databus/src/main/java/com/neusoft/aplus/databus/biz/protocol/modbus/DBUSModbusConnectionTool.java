package com.neusoft.aplus.databus.biz.protocol.modbus;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.python.google.common.collect.Lists;

import com.google.common.base.Optional;
import com.neusoft.aplus.databus.biz.constants.DBUSMetricConstants;
import com.neusoft.aplus.databus.biz.model.DBUSMetric;
import com.neusoft.aplus.databus.biz.protocol.DBUSAbstractConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.DBUSActionManager;
import com.neusoft.aplus.databus.biz.protocol.DBUSConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.DBUSConnectionWrapper;
import com.neusoft.aplus.databus.biz.protocol.DBUSMetricManager;
import com.neusoft.aplus.databus.biz.protocol.DBUSProtocolConstants;
import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusControlData;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.bizentity.AplusMetricData;
import com.serotonin.io.serial.SerialParameters;
import com.serotonin.modbus4j.ModbusFactory;
import com.serotonin.modbus4j.ModbusMaster;
import com.serotonin.modbus4j.code.ExceptionCode;
import com.serotonin.modbus4j.exception.ModbusInitException;
import com.serotonin.modbus4j.exception.ModbusTransportException;
import com.serotonin.modbus4j.ip.IpParameters;
import com.serotonin.modbus4j.msg.ModbusRequest;
import com.serotonin.modbus4j.msg.ReadHoldingRegistersRequest;
import com.serotonin.modbus4j.msg.ReadResponse;
import com.serotonin.modbus4j.msg.WriteRegistersRequest;
import com.serotonin.modbus4j.msg.WriteRegistersResponse;

/**
 * Modbus 连接工具类
 * 
 * @author wuhao
 * @date 2014-12-31 上午11:13:44
 */
public class DBUSModbusConnectionTool extends DBUSAbstractConnectionTool {

	private static DBUSModbusConnectionTool instance = new DBUSModbusConnectionTool();
	public static final String MASTER = "master";
	public static final String SLAVE = "slave";
	public static final String SOCKET = "socket";
	public static final String TYPE = "type";

	private DBUSModbusConnectionTool() {
	}

	/***
	 * 返回modbus工具类实例
	 * 
	 * @return
	 * @author wuhao
	 * @date 2014-12-30 下午1:42:06
	 */
	public static DBUSModbusConnectionTool getInstance() {
		return instance;
	}

	/***
	 * 采集指定资源某些指标的监控数据
	 * 
	 * @param wrapper
	 * @param device
	 * @param metrics
	 * @return AplusDeviceMonitorData
	 * @author wuhao
	 * @date 2015-1-6 上午10:19:51
	 */
	@Override
	public List<AplusDeviceMonitorData> collectSomeMetricsOfDevice(
			DBUSConnectionWrapper wrapper,
			AplusDevice device, List<String> metrics) {

		String deviceId = DBUSDatabusUtil.getDeviceTypeId(
				device.getDeviceType(), device.getDeviceVersion());
		// 根据设备类型和设备版本，获取设备的指标信息
		Optional<DBUSMetric> metricsMapOption = DBUSMetricManager.getInstance()
				.getMetricMap(deviceId);
		if (!metricsMapOption.isPresent()) {
			Object[] params = { deviceId };
			DBUSPluginException.throwException(
					DBUSPluginException.EXCEPTCODE_NO_METRIC, null, params,
					null);
		}
		DBUSMetric metricsMap = metricsMapOption.get();
		// 如果没有
		List<String> codes = Lists.newArrayList();
		if (metrics == null) {
			codes = metricsMap.getAllCodeList();
		} else {
			codes = metricsMap.getCodeList(metrics);
		}
		List<AplusDeviceMonitorData> monitoerDataList = getResponseEvent(
				wrapper, codes, metricsMap, device);
		return monitoerDataList;
	}

	/**
	 * 
	 * @param wrapper
	 * @param metrics
	 * @return
	 * @author wuhao
	 * @date 2015-1-6 下午8:51:43
	 */
	@SuppressWarnings("unchecked")
	private List<AplusDeviceMonitorData> getResponseEvent(
			DBUSConnectionWrapper wrapper, List<String> metrics, DBUSMetric metricsMap,
			AplusDevice aplusDevice) {

		Map<String, Object> connectionTable = 
				(ConcurrentHashMap<String, Object>) wrapper.getConnection();
		HashMap<String, String> resultMap = new HashMap<String, String>();
		AplusDeviceMonitorData monitorData = new AplusDeviceMonitorData();
		if (connectionTable.containsKey(SOCKET)) {

			for (String code : metrics) {
				String result = null;
				Socket socket = (Socket) connectionTable.get(SOCKET);
				DBUSModbusConnectionType connectionType = (DBUSModbusConnectionType) connectionTable
						.get(TYPE);
				OutputStream os = null;
				byte[] buf = null;
				try {
					os = socket.getOutputStream();
					os.write(code.getBytes());
					InputStream is = socket.getInputStream();
					buf = new byte[DBUSModbus.DEFAULT_COMMAND_SIZE];
					is.read(buf);
					String origStr = DBUSCRC16Util.bytesToHexString(buf);
					if (DBUSModbusConnectionType.MODBUSRTU == connectionType
							|| DBUSModbusConnectionType.MODBUSTCP == connectionType) {
						int length = Integer.parseInt(origStr.substring(
								connectionType.getStartPosition(),
								connectionType.getLength()), 16);
						// +4为四位CRC校验位
						String realStr = origStr.substring(0,
								connectionType.getLength() + length * 2 + 4);
						String checkStr = realStr.substring(0,
								realStr.length() - 4);

						int[] checkStrArray = DBUSCRC16Util
								.hexStrToIntArray(checkStr);
						int[] datas = DBUSCRC16Util.crc(checkStrArray);

						byte[] da = new byte[datas.length];

						for (int i = 0; i < datas.length; i++) {
							da[i] = (byte) datas[i];
						}

						String backStr = DBUSCRC16Util.bytesToHexString(da);
						if (!realStr.equalsIgnoreCase(backStr)) {
							return null;
						}
						result = handleResponseByProtocol(origStr,
								connectionType);
						resultMap.put(code, result);
					}
				} catch (IOException e) {

				}
			}
		} else {
			ModbusMaster master = null;

			Object masterInfo = connectionTable.get(MASTER);
			master = (ModbusMaster) masterInfo;

			int slave = Integer.valueOf(connectionTable.get(SLAVE).toString());
			String code = metrics.get(0);
			byte[] value = null;
			try {
				// 开始采集
				ModbusRequest request = createModbusRequest(slave, code);
				ReadResponse response = (ReadResponse) master.send(request);
				if (response.isException()) {
					String exceptionCode = null;
					// 根据exceptioncode抛出对应的DBUSProtocolException
					switch (response.getExceptionCode()) {
					case ExceptionCode.ILLEGAL_FUNCTION:
						exceptionCode = DBUSPluginException.ILLEGAL_FUNCTION;
						break;
					case ExceptionCode.ILLEGAL_DATA_ADDRESS:
						exceptionCode = DBUSPluginException.ILLEGAL_DATA_ADDRESS;
						break;
					case ExceptionCode.SLAVE_DEVICE_FAILURE:
						exceptionCode = DBUSPluginException.DEVICE_CONNECTION_FAILURE;
						break;
					}
					if (exceptionCode != null)
						DBUSPluginException.throwException(exceptionCode);
				}
				value = response.getData();

			} catch (ModbusTransportException e) {
				e.printStackTrace();
				DBUSPluginException
						.throwException(DBUSPluginException.MODBUS_TRANSPORT_EXCEPTION);
			}

			// TODO 需要等串口服务器采集测试时，增加调用失败后再次调用。（调用总次数通过配置文件获取）
			// TODO 增加通过串口服务器采集的方式。需要等串口服务器采集测试时统一修改下面的注释部分。

			for (String name : metricsMap.keySet()) {

				Map<String, Object> metricEntity = metricsMap.get(name);

				AplusMetricData metricData = new AplusMetricData();

				int start = Integer.parseInt(metricEntity.get(
						DBUSMetricConstants.START).toString());
				int end = Integer.parseInt(metricEntity.get(
						DBUSMetricConstants.END).toString());

				metricData.setName(name);
				if (metricEntity.containsKey(DBUSMetricConstants.BIT_INDEX)) {
					int bitIndex = (Integer) metricEntity.get(DBUSMetricConstants.BIT_INDEX);
					int byteIndex = bitIndex / 8;
					byte[] byteArr = Arrays.copyOfRange(value, (start - 1) * 2, end * 2);
					byte byteVal = byteArr[byteIndex];
					int bitVal = DBUSDatabusUtil.getBit(byteVal, bitIndex % 8);
					metricData.setValue(bitVal);
				} else {
					metricData.setValue(Arrays.copyOfRange(value, (start - 1) * 2, end * 2));
				}
				metricData.setRecordTime(System.currentTimeMillis());

				monitorData.setAplusDevice(aplusDevice);
				monitorData.getMetricDatas().put(name, metricData);
			}
		}
		List<AplusDeviceMonitorData> monitorDatas = Lists.newArrayList();
		monitorDatas.add(monitorData);
		return monitorDatas;
	}
	
	/***
	 * 根据功能码返回对应的 ModbusRequest
	 * 
	 * @return
	 * @author wuhao
	 * @date 2015-1-6 下午5:12:30
	 */
	private ModbusRequest createModbusRequest(int slave, String code) {
		// String[] codes = code.split("\\.");
		String[] codes = code.split("\\" + DBUSProtocolConstants.POINT);
		// int slaveId = Integer.parseInt(codes[0]);
		int functioncode = Integer.parseInt(codes[0]);
		int startOffset = Integer.parseInt(codes[1]);
		int numberOfRegisters = Integer.parseInt(codes[2]);
		ModbusRequest request = null;

		try {
			switch (functioncode) {
			case DBUSModbus.READ_HOLDING_REGISTERS:
				request = new ReadHoldingRegistersRequest(slave, startOffset,
						numberOfRegisters);
				break;
			default:
				break;
			}
		} catch (ModbusTransportException e) {
			DBUSPluginException
					.throwException(DBUSPluginException.MODBUS_TRANSPORT_EXCEPTION);
		}
		return request;
	}

	/**
	 * 根据Connection创建链接
	 * 
	 * @param connection
	 * @return
	 * @author wuhao
	 * @date 2014-12-26 下午5:28:22
	 */
	public DBUSConnectionWrapper createConnection(AplusConnection connection) {
		DBUSModbusConnection modbusConnection;
		if (connection instanceof DBUSModbusConnection) {
			modbusConnection = (DBUSModbusConnection) connection;
		} else {
			modbusConnection = DBUSModbusConnection.of(connection);
		}
		Map<String, Object> returnTable = new ConcurrentHashMap<String, Object>();

		// 判断连接方式
		// 如果是串口服务器的连接形式，则返回一个socket
		if (modbusConnection.getConnectiontype().equals(DBUSModbus.SERVER)) {
			Socket socket = new Socket();
			try {
				socket.setSoTimeout(modbusConnection.getSoTimeOut());
				socket.setKeepAlive(true);
				socket.connect(
						new InetSocketAddress(modbusConnection.getIpAddress(),
								modbusConnection.getPort()), modbusConnection
								.getSoTimeOut());
			} catch (SocketException e) {
				DBUSPluginException
						.throwException(DBUSPluginException.MODBUS_CONNECTION_INIT_EXCEPTION);
			} catch (IOException e) {
				DBUSPluginException
						.throwException(DBUSPluginException.MODBUS_CONNECTION_INIT_EXCEPTION);
			}
			DBUSModbusConnectionType connectionType = null;
			if (modbusConnection.getCommunicatetype().equals(DBUSModbus.RTU)) {
				connectionType = DBUSModbusConnectionType.MODBUSRTU;
			} else if (modbusConnection.getCommunicatetype().equals(
					DBUSModbus.TCP)) {
				connectionType = DBUSModbusConnectionType.MODBUSTCP;
			} else if (modbusConnection.getCommunicatetype().equals(
					DBUSModbus.OTHER)) {
				connectionType = DBUSModbusConnectionType.OTHERPORTAL;
			} else {
				connectionType = DBUSModbusConnectionType.DIANZONG;
			}

			returnTable.put(SOCKET, socket);
			returnTable.put(TYPE, connectionType);
		} else {
			// 否则，通过modbus4j调用，返回一个master
			ModbusFactory factory = new ModbusFactory();
			ModbusMaster master = null;
			if (modbusConnection.getConnectiontype().equals(DBUSModbus.COM)) {

				SerialParameters params = new SerialParameters();
				params.setCommPortId(modbusConnection.getComValue());// com
				params.setParity(modbusConnection.getParity());// 奇偶校验
				params.setDataBits(modbusConnection.getDataBits());// 数据位
				params.setStopBits(modbusConnection.getStopBits());// 停止位
				params.setBaudRate(modbusConnection.getBaudRate());// 波特率

				// 判断传输方式
				if (modbusConnection.getCommunicatetype()
						.equals(DBUSModbus.RTU)) {
					master = factory.createRtuMaster(params);
				} else {
					master = factory.createAsciiMaster(params);
				}
				master.setRetries(modbusConnection.getRetry());// 重试次数

			} else {
				IpParameters params = new IpParameters();
				params.setHost(modbusConnection.getIpAddress());
				params.setPort(modbusConnection.getPort());
				master = factory.createTcpMaster(params, true);
			}
			try {
				master.init();
			} catch (ModbusInitException e) {
				DBUSPluginException
						.throwException(DBUSPluginException.MODBUS_CONNECTION_INIT_EXCEPTION);
			}

			returnTable.put(MASTER, master);
			returnTable.put(SLAVE, modbusConnection.getSlave());
		}
		return new DBUSModbusConnectionWrapper(connection, returnTable);
	}

	private static String handleResponseByProtocol(final String result,
			final DBUSModbusConnectionType connectionType) {
		String resultstr = null;
		int length = 0;
		if (DBUSModbusConnectionType.MODBUSRTU == connectionType
				|| DBUSModbusConnectionType.MODBUSTCP == connectionType) {
			length = Integer.parseInt(result.substring(
					connectionType.getStartPosition(),
					connectionType.getLength()), 16);
			resultstr = result.substring(connectionType.getLength(),
					connectionType.getLength() + length * 2);
		} else if (DBUSModbusConnectionType.DIANZONG == connectionType) {
			resultstr = DBUSCRC16Util.convertHexToString(result);
			length = Integer.parseInt(resultstr.substring(
					connectionType.getStartPosition(),
					connectionType.getLength()));
			resultstr = result.substring(connectionType.getLength(),
					connectionType.getLength() + length * 2);
		} else if (DBUSModbusConnectionType.OTHERPORTAL == connectionType) {
			String result1 = DBUSCRC16Util.convertHexToString(result);
			length = Integer.parseInt(result1.substring(
					connectionType.getStartPosition(),
					connectionType.getLength()));
			resultstr = result1.substring(connectionType.getLength(),
					connectionType.getLength() + length);
		} else {
			return null;
		}
		return resultstr;
	}

	/**
	 * 
	 * @param connection
	 * @param device
	 * @param metricsMap
	 * @return
	 * @author wuhao
	 * @date 2015-2-1 上午10:00:25
	 */

	@Override
	public List<AplusDeviceMonitorData> collectDeviceByMetricEntity(
			AplusConnection connection, AplusDevice device,
			DBUSMetric metricsMap) {
		// TODO Auto-generated method stub
		return null;
	}
	
	/**
	 * 修改指标的值
	 * 
	 * @param connectiontool
	 * @param device
	 * @param actionName
	 * @param value
	 * @return 成功true，反之false
	 * @author zhangjian
	 * @data 2015年4月24日 上午11:15:09
	 */
	@Override
	public boolean control(AplusConnection connection,
			DBUSConnectionTool connectiontool, AplusDevice device,
			String actionName, Object... value) {
		final String MASTER = "master";
		final String SLAVE = "slave";
		ModbusRequest request;
		@SuppressWarnings("unchecked")
		Map<String, Object> connectionTable = (Map<String, Object>) connectiontool
				.createConnection(connection);
		ModbusMaster master = (ModbusMaster) connectionTable.get(MASTER);
		String slave = (String) connectionTable.get(SLAVE);
		String deviceId = DBUSDatabusUtil.getDeviceTypeId(
				device.getDeviceType(), device.getDeviceVersion());
		// 根据设备类型和设备版本，获取action信息
		Optional<DBUSMetric> actionMapOption = DBUSActionManager.getInstance()
				.getMetricMap(deviceId);
		if (!actionMapOption.isPresent()) {
			Object[] params = { deviceId };
			DBUSPluginException.throwException(
					DBUSPluginException.EXCEPTCODE_NO_ACTION, null, params,
					null);
		}
		DBUSMetric actionMap = actionMapOption.get();
		// code 第一位操作码 4为写入 第二位起始地址 第三位长度
		String code = actionMap.get(actionName).get(DBUSMetricConstants.CODE).toString();
		short[] sdata = new short[Integer.parseInt(code.split("\\.")[2])];
		for (int i = 0; i < sdata.length; i++) {
			sdata[i] = Short.valueOf((value[0]).toString());
		}
		try {
			// 参数：从机号、起始地址、数据集合
			request = new WriteRegistersRequest(Integer.parseInt(slave),
					Integer.parseInt(code.split("\\.")[1]), sdata);
			WriteRegistersResponse response = (WriteRegistersResponse) master
					.send(request);
			if (null != response) {
				return true;
			}
		} catch (ModbusTransportException e) {
			DBUSPluginException
					.throwException(DBUSPluginException.MODBUS_TRANSPORT_EXCEPTION);
		}
		return false;
	}

	@Override
	public boolean controlByActionEntity(AplusConnection connection, AplusDevice device,
			AplusControlData controlData) {
		// TODO Auto-generated method stub
		return false;
	}

}

package com.neusoft.aplus.databus.biz.protocol.modbus;

import com.neusoft.aplus.common.util.ObjectUtil;
import com.neusoft.aplus.model.bizentity.AplusConnection;

/**
 * Modbus协议的连接信息
 * 
 * @author wuhao
 * @date 2014-12-31 下午2:32:23
 */
public class DBUSModbusConnection extends AplusConnection {

	private static final long serialVersionUID = 1L;
	// udpConnection info
	// 串口
	public static final String COMVALUE = "ComValue";
	// 奇偶校验
	public static final String PARITY = "Parity";
	// 数据位
	public static final String DATABITS = "DataBits";
	// 停止位
	public static final String STOPBITS = "StopBits";
	// 串行口上的波特率
	public static final String BAUDRATE = "Baudrate";
	// 重试次数
	public static final String RETRY = "retry";
	// ip地址
	public static final String IPADDRESS = "ipAddress";
	// 端口
	public static final String PORT = "port";
	// 连接方式
	public static final String CONNECTIONTYPE = "connectiontype";
	// 编码类型
	public static final String COMMUNICATETYPE = "communicatetype";
	// slave
	public static final String SLAVE = "slave";
	// sotimeout
	public static final String SOTIMEOUT = "sotimeout";

	public static DBUSModbusConnection of(AplusConnection conn) {
		DBUSModbusConnection modbusConn = new DBUSModbusConnection();
		try {
			modbusConn.setIpAddress((String) conn.get(IPADDRESS));
			modbusConn.setPort(Integer.parseInt((String) conn.get(PORT)));
			modbusConn.setSlave((String) conn.get(SLAVE));
			modbusConn.setConnectiontype((String) conn.get(CONNECTIONTYPE));
			modbusConn.setComValue((String) conn.get(COMVALUE));
			modbusConn.setParity(Integer.parseInt((String) conn.get(PARITY)));
			modbusConn.setDataBits(Integer.parseInt((String) conn.get(DATABITS)));
			modbusConn.setStopBits(Integer.parseInt((String) conn.get(STOPBITS)));
			modbusConn.setBaudRate(Integer.parseInt((String) conn.get(BAUDRATE)));
			modbusConn.setRetry(Integer.parseInt((String) conn.get(RETRY)));
			modbusConn.setCommunicatetyp((String) conn.get(COMMUNICATETYPE));
			modbusConn.setSoTimeOut(Integer.parseInt((String) conn.get(SOTIMEOUT)));
		} catch (NullPointerException e) {
			// ignore
		}
		
		return modbusConn;
	}
	
	public String getSlave() {
		return get(SLAVE).toString();
	}

	public void setSlave(String slave) {
		put(SLAVE, slave);
	}

	public String getConnectiontype() {
		return get(CONNECTIONTYPE).toString();
	}

	public void setConnectiontype(String connectiontype) {
		put(CONNECTIONTYPE, connectiontype);
	}

	public String getCommunicatetype() {
		return get(COMMUNICATETYPE).toString();
	}

	public void setCommunicatetyp(String communicatetype) {
		put(COMMUNICATETYPE, communicatetype);
	}

	public int getBaudRate() {
		return getIntValue(BAUDRATE);
	}

	public void setBaudRate(int baudRate) {
		putIntValue(BAUDRATE, baudRate);
	}

	public int getParity() {
		return getIntValue(PARITY);
	}

	public void setParity(int parity) {
		putIntValue(PARITY, parity);
	}

	public String getComValue() {
		return get(COMVALUE).toString();
	}

	public void setComValue(String comValue) {
		put(COMVALUE, comValue);
	}

	public int getRetry() {
		return getIntValue(RETRY);
	}

	public void setRetry(int retry) {
		putIntValue(RETRY, retry);
	}

	public int getStopBits() {
		return getIntValue(STOPBITS);
	}

	public void setStopBits(int stopBits) {
		putIntValue(STOPBITS, stopBits);
	}

	public int getDataBits() {
		return getIntValue(DATABITS);
	}

	public void setDataBits(int dataBits) {
		putIntValue(DATABITS, dataBits);
	}

	public String getIpAddress() {
		return get(IPADDRESS).toString();
	}

	public void setIpAddress(String ipAddress) {
		put(IPADDRESS, ipAddress);
	}

	public int getPort() {
		return getIntValue(PORT);
	}

	public void setPort(int port) {
		putIntValue(PORT, port);
	}

	public int getSoTimeOut() {
		return getIntValue(SOTIMEOUT);
	}

	public void setSoTimeOut(int sotimeout) {
		putIntValue(SOTIMEOUT, sotimeout);
	}

	/**
	 * 返回int型value
	 *
	 */
	public int getIntValue(String key) {
		final int defaultInt = 0;
		Object object = get(key);

		if (object != null && ObjectUtil.isNumeric(object.toString())) {
			return (Integer) object;
		} else {
			return defaultInt;
		}
	}

	/**
	 * 将int型的key放入连接信息中
	 *
	 */
	public void putIntValue(String key, int value) {
		put(key, value);
	}
}

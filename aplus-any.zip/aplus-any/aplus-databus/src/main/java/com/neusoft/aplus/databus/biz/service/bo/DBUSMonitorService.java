package com.neusoft.aplus.databus.biz.service.bo;

import java.util.List;

import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusControlData;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.dbentity.table.AplusMetricEntity;

/**
 * 监控接口，封装了指标采集的接口
 * 
 * @author WanWei
 * @date 2014-12-24 上午9:43:12
 */
public interface DBUSMonitorService {

	/**
	 * 采集指定资源所有指标的监控数据
	 * 
	 * @param connection
	 *            连接信息
	 * @param device
	 *            资源信息
	 * @author WanWei
	 * @date 2014-12-24 上午11:54:30
	 */
	List<AplusDeviceMonitorData> collectAllMetricsOfDevice(
			AplusConnection connection, AplusDevice device)
			throws DBUSPluginException;

	/**
	 * 采集指定资源某些指标的监控数据
	 * 
	 * @param connection 连接信息
	 * @param device 资源信息
	 * @param metrics 指定指标集合
	 * @author WanWei
	 * @date 2014-12-24 下午12:15:40
	 */
	List<AplusDeviceMonitorData> collectSomeMetricsOfDevice(
			AplusConnection connection, AplusDevice device, List<String> metrics)
			throws DBUSPluginException;

	/**
	 * 采集指定资源某些指标的监控数据()
	 *
	 * @author wuhao
	 * @date 2015-2-5 下午3:15:45
	 */
	List<AplusDeviceMonitorData> collectDeviceByMetricEntity(
			AplusConnection connection, AplusDevice device,
			List<AplusMetricEntity> metricList) throws DBUSPluginException;

	/**
	 * 修改指标的数据
	 * 
	 * @param connection
	 *            链接信息
	 * @param device
	 *            资源信息
	 * @param actionName
	 *            脚本中对应的actionName
	 * @param value
	 *            指标的值
	 * @author zhangjian
	 * @date 2015年4月21日 上午10:50:46
	 * */
	boolean control(AplusConnection connection, AplusDevice device,
					String actionName, Object... value) throws DBUSPluginException;

	/**
	 * 修改指定资源某些指标的值
	 * @author wuhao
	 * @date 2015-6-23 下午5:41:09
	 */
	List<String> controlByActionEntity(AplusConnection connection, AplusDevice device,
									   List<AplusControlData> controlDataList)
			throws DBUSPluginException;

}

package com.neusoft.aplus.databus.biz.protocol;

import java.util.List;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

import com.neusoft.aplus.databus.biz.cache.DBUSLocalCache;
import com.neusoft.aplus.databus.biz.model.DBUSMetric;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;

/**
 * 协议连接工具类，提供一些公用的方法
 * 
 * @author wuhao
 * @date 2014-12-31 上午11:23:14
 */
public abstract class DBUSAbstractConnectionTool implements
		DBUSConnectionTool {

	/***
	 * 根据Connection和协议类型返回此Connection连接池中的链接信息
	 *
	 * @author wuhao
	 * @date 2015-1-6 下午1:23:06
	 */
	@Override
	public DBUSConnectionWrapper getConnection(AplusConnection connection) {
		Cache connectionPoolCache = DBUSLocalCache.getConnectionPoolCache();
		DBUSConnectionPool pool;
		// 如果沒有创建过此设备资源的连接池
		if (connectionPoolCache.get(connection.getUniqueKey()) == null) {
			// 新建连接池
			pool = new DBUSConnectionPool(connection, this);
			DBUSLocalCache.putIntoCache(connectionPoolCache,
					connection.getUniqueKey(), pool);
		} else {
			Element element = connectionPoolCache
					.get(connection.getUniqueKey());
			pool = (DBUSConnectionPool) element
					.getObjectValue();
		}
		return pool.getConnection();
	}

	/***
	 * 清空连接池
	 *
	 * @author wuhao
	 * @date 2015-1-22 下午3:52:47
	 */
	public void clearConnectionPool(AplusConnection connection) {
		Cache connectionPoolCache = DBUSLocalCache.getConnectionPoolCache();
		connectionPoolCache.remove(connection.getUniqueKey());
	}

	@Override
	public void pushConnectionBack(DBUSConnectionWrapper wrapper) {
		Cache connectionPoolCache = DBUSLocalCache.getConnectionPoolCache();
		Element element = connectionPoolCache.get(wrapper.getConnectionInfo().getUniqueKey());
		DBUSConnectionPool pool = (DBUSConnectionPool) element.getObjectValue();
		pool.pushBack(wrapper);
	}

	// /***
	// * 返回枚举类型的数据
	// * @param deviceId
	// * @param name
	// * @param value
	// * @return
	// * @author wuhao
	// * @date 2015-1-16 下午5:00:35
	// */
	// public static String getEnumInfo(String deviceId,String name,Integer
	// value){
	// DBUSPluginManager manager = DBUSPluginManager.getInstance();
	// DBUSPlugin entity = manager.getById(deviceId);
	// Map<Integer, List<String>> enumMap = entity.getMetricEnum(name);
	// List<String> valueList = enumMap.get(value);
	// return entity.internationalization(valueList.get(1),"CN");
	// }

	/***
	 * 返回设备的所有指标数据
	 *
	 * @author wuhao
	 * @date 2015-1-4 上午9:41:44
	 */
	@Override
	public List<AplusDeviceMonitorData> collectAllMetricsOfDevice(
			AplusConnection connection, AplusDevice device) {
		return collectSomeMetricsOfDevice(connection, device, null);
	}

	@Override
	public List<AplusDeviceMonitorData> collectAllMetricsOfDevice(
			DBUSConnectionWrapper wrapper, AplusDevice device) {
		return collectSomeMetricsOfDevice(wrapper, device, null);
	}

	@Override
	public List<AplusDeviceMonitorData> collectSomeMetricsOfDevice(
			AplusConnection connection, AplusDevice device, List<String> metrics) {

		DBUSConnectionWrapper wrapper = getConnection(connection);
		List<AplusDeviceMonitorData> dataList = collectSomeMetricsOfDevice(
				wrapper, device, metrics);
		pushConnectionBack(wrapper);
		return dataList;

	}

	public abstract List<AplusDeviceMonitorData> collectDeviceByMetricEntity(
			AplusConnection connection, AplusDevice device,
			DBUSMetric metricsMap);



	
}

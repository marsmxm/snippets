package com.neusoft.aplus.databus.biz.protocol;

import io.netty.channel.socket.DatagramPacket;
import io.reactivex.netty.RxNetty;
import io.reactivex.netty.channel.ConnectionHandler;
import io.reactivex.netty.client.RxClient;
import io.reactivex.netty.pipeline.PipelineConfigurators;
import io.reactivex.netty.protocol.udp.server.UdpServer;
import io.reactivex.netty.server.RxServer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neusoft.aplus.common.config.NettyClientConf;
import com.neusoft.aplus.common.util.SpringUtil;


/**
 * TCP和UDP的客户端以及服务端的工厂类
 *
 * @author mxm
 * @date 15-6-30
 */
public final class DBUSTcpUdpFactory {
    private static Logger log = LoggerFactory.getLogger(DBUSTcpUdpFactory.class);
    private static final int UDP_SERVER_PORT;
    private static final int TCP_SERVER_PORT;

    static {
        NettyClientConf exConf = SpringUtil.getBean(NettyClientConf.class);
        TCP_SERVER_PORT = exConf.getTCPPort();
        UDP_SERVER_PORT = exConf.getUDPPort();
    }

    private DBUSTcpUdpFactory() {}

    public static UdpServer<DatagramPacket, DatagramPacket> createUDPServer(
            ConnectionHandler<DatagramPacket, DatagramPacket> handler) {
        UdpServer<DatagramPacket, DatagramPacket> server =
                RxNetty.createUdpServer(UDP_SERVER_PORT, handler);
        log.debug("UDP server started.");
        return server;
    }

    public static RxClient<DatagramPacket, DatagramPacket> createUDPClient(String host, int port) {
        return RxNetty.<DatagramPacket, DatagramPacket>newUdpClientBuilder(host, port).build();
    }

    public RxServer<byte[], byte[]> createTCPServer(ConnectionHandler<byte[], byte[]> handler) {
        RxServer<byte[], byte[]> server = RxNetty.createTcpServer(
                TCP_SERVER_PORT, PipelineConfigurators.byteArrayConfigurator(), handler);
        log.debug("TCP  server started.");
        return server;
    }

    public RxClient<byte[], byte[]> createTCPClient(String host, int port) {
        return RxNetty.createTcpClient(host, port, PipelineConfigurators.byteArrayConfigurator());
    }
}

package com.neusoft.aplus.databus.biz.event;

import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;

/**
 * @author mxm
 * @date 15-5-28
 */
public class PluginAddEvent extends AbstractPluginEvent {
    private final DBUSPlugin plugin;

    public PluginAddEvent(DBUSPlugin plugin) {
        this.plugin = plugin;
    }

    public DBUSPlugin getPlugin() {
        return plugin;
    }
}

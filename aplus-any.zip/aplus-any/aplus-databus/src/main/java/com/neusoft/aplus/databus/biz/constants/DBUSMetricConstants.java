package com.neusoft.aplus.databus.biz.constants;

/**
 * 指标key值常量类
 *
 * 由于指标类在采集端是由Map实现的，
 * 所以需要定义Map的常量键名，便于维护
 *
 * @author wuhao
 * @date 2015-1-8 下午8:19:26
 */
public class DBUSMetricConstants {

	public static final String CODE = "code";
	public static final String NAME = "name";
	public static final String UNIT = "unit";
	public static final String INTERVAL = "interval";
	public static final String TIMEUNIT = "timeUnit";
	public static final String ACTIVE = "active";
	public static final String TYPE = "type";
	public static final String DEFKEY = "defkey";
	public static final String START = "start";
	public static final String END = "end";
	public static final String BIT_INDEX = "bitIndex";
	public static final String BYTE_INDEX = "byteIndex";

}

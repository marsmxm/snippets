package com.neusoft.aplus.databus.biz.plugin.monitor;

import java.io.File;
import java.io.FileFilter;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.monitor.FileAlterationListenerAdaptor;
import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.apache.log4j.Logger;

import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;

/**
 * @author wangcd
 * @date 2014年8月4日 上午10:39:18
 */
public class DBUSFileMonitor {
	private static Logger logger = Logger.getLogger(DBUSFileMonitor.class);
	private static FileAlterationMonitor monitor;
	static {
		monitor = new FileAlterationMonitor(5000); // 5000ms 时间间隔
	}

	/**
	 * 添加文件监控路径（可以是文件目录名，也可以是文件名）
	 * 
	 * @param path
	 * @param listener
	 * @throws Exception
	 * @author wangcd
	 * @date 2014年8月4日 上午11:55:11
	 */
	public static void addMonitorPath(String path,
			FileAlterationListenerAdaptor listener) throws Exception {
		String directory;
		FileFilter filter = null;
		final File file = new File(path);
		if (file.isFile()) {
			directory = FilenameUtils.getFullPath(file.getAbsolutePath());
			filter = new FileFilter() {
				public boolean accept(File pathname) {
					return file.equals(pathname);
				}
			};
		} else {
			directory = file.getAbsolutePath();
		}

		FileAlterationObserver observer = new FileAlterationObserver(new File(
				directory), filter);
		monitor.addObserver(observer);
		observer.addListener(listener);
	}

	/**
	 * 启动监控线程
	 * 
	 * @throws Exception
	 * @author wangcd
	 * @date 2014年8月4日 上午11:54:32
	 */
	public static void start() throws Exception {
		monitor.start();
		StringBuilder sb = new StringBuilder("开始监听目录: ");
		for (FileAlterationObserver ob : monitor.getObservers()) {
			sb.append(ob.getDirectory().getAbsoluteFile() + ", ");
		}
		logger.info(sb.toString());
	}

	/**
	 * 停止监控线程
	 * 
	 * @throws Exception
	 * @author wangcd
	 * @date 2014年8月4日 上午11:54:54
	 */
	public static void stop() throws Exception {
		monitor.stop();
	}

	/**
	 * 将脚本文件目录和jar目录加入监控，并启动监控线程
	 * 
	 * @author wangcd
	 * @date 2014年8月4日 上午11:53:34
	 */
	public static void startMonitor() {
		try {
			addMonitorPath(DBUSDatabusUtil.getPluginDir(),
					new DBUSFileListener(ZMQConst.TOPIC_PLUGIN_SCRIPT));
			start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

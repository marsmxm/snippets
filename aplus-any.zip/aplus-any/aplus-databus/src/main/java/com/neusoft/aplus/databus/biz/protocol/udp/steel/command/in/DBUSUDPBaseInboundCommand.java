package com.neusoft.aplus.databus.biz.protocol.udp.steel.command.in;

import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.neusoft.aplus.databus.biz.model.DBUSMetric;
import com.neusoft.aplus.databus.biz.protocol.DBUSMetricManager;
import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.hbgt.DBUSUDPSteelDataWrapper;

import java.util.List;
import java.util.Map;

/**
 * @author mxm
 * @date 15-6-30
 */
public abstract class DBUSUDPBaseInboundCommand {
    private final byte[] bytes;
    private final byte frameLength;  // 帧长度
    private final byte alarmHost;    // 通讯机地址
    private final byte equipAddr;    // 设备地址
    private final byte groupHigh;    // 用户组编号高字节
    private final byte groupLow;     // 用户组编号低字节
    private final byte ext;          // 扩展备用
    private final byte cmdID;        // 命令字
    private final int checksum;      // 校验和

    public DBUSUDPBaseInboundCommand(byte[] bytes) {
        this.bytes = bytes;
        frameLength = bytes[0];
        alarmHost = bytes[1];
        equipAddr = bytes[2];
        groupHigh = bytes[3];
        groupLow = bytes[4];
        ext = bytes[5];
        cmdID = bytes[6];
        checksum = bytes[frameLength - 1];
    }

    public byte[] getBytes() {
        return bytes;
    }

    public byte getFrameLength() {
        return frameLength;
    }

    public byte getAlarmHost() {
        return alarmHost;
    }

    public byte getEquipAddr() {
        return equipAddr;
    }

    public byte getGroupHigh() {
        return groupHigh;
    }

    public byte getGroupLow() {
        return groupLow;
    }
    
    public int getGroup() {
    	return (groupHigh << 8) + groupLow;
    }

    public byte getExt() {
        return ext;
    }

    public byte getCmdID() {
        return cmdID;
    }

    public int getChecksum() {
        return checksum;
    }

    protected static List<Map<String, Object>> getMetrics(String deviceTypeID, int cmdID) {
        Optional<DBUSMetric> optional =
                DBUSMetricManager.getInstance().getMetricMap(deviceTypeID);
        if (optional.isPresent()) {
            return optional.get().getMetricMaps("0x" + String.format("%02x", cmdID));
        } else {
            Object[] params = {deviceTypeID};
            DBUSPluginException.throwException(
                    DBUSPluginException.EXCEPTCODE_NO_METRIC, null, params, null);
            return Lists.newArrayList();
        }
    }

    public boolean validate() {
        return DBUSDatabusUtil.makeChecksum(getBytes()) == getChecksum();
    }

    public abstract byte[] getReply();

    protected byte[] partialReply(byte[] reply) {
        assert reply.length > 7;
        reply[1] = getAlarmHost();
        reply[2] = getEquipAddr();
        reply[3] = getGroupHigh();
        reply[4] = getGroupLow();
        reply[5] = getExt();
        reply[6] = (byte) (getCmdID() + 0x80);
        return reply;
    }

    public abstract boolean hasUDPData();
    public abstract List<DBUSUDPSteelDataWrapper> getUDPData();
}

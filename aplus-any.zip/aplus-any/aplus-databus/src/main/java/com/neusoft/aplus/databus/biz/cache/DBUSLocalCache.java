package com.neusoft.aplus.databus.biz.cache;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;


/**
 * 本地缓存，存储了插件相关的一些信息和采集工具类用到的一些数据
 * 
 * @author WanWei
 * @date 2014-12-24 下午6:02:49
 */
public class DBUSLocalCache {
	
	//连接池缓存名称
	private final static String CONNECTION_POOL_CACHE = "connection_pool";
	private final static String PLUGIN_CACHE = "plugin_cache";
	private final static String METRICS_CACHE = "metrics_cache";
	private final static String ACTION_CACHE = "action_cache";
	
	//缓存连接信息及其所对应的连接池信息
	private static Cache connectionPoolCache;
	private static Cache pluginCache;
	private static Cache metricsCache;
	private static Cache actionCache;
	
	//使用EHCACHE做缓存管理
	private static CacheManager cacheManager;
	
	static{
		cacheManager = CacheManager.create();
		// 元素个数设置为10000，意味着支持10000个连接 存储,第3个参数设置为true，
		// 意味着缓存超过内存限制时会将内容写至磁盘
		connectionPoolCache = new Cache(CONNECTION_POOL_CACHE, 10000, false,
				false, 0, 0);
		pluginCache = new Cache(PLUGIN_CACHE, 5000, false,
				false, 0, 0);
		metricsCache = new Cache(METRICS_CACHE, 5000, false,
				false, 0, 0);
		actionCache = new Cache(ACTION_CACHE, 5000, false,
				false, 0, 0);
		cacheManager.addCache(connectionPoolCache);
		cacheManager.addCache(pluginCache);
		cacheManager.addCache(metricsCache);
		cacheManager.addCache(actionCache);
	}
	
	
	/**
	 * 取得存放连接信息及其对应的连接池的缓存
	 *
	 */
	public static Cache getConnectionPoolCache(){
		return connectionPoolCache;
	}

	
	/**
	 * 取得plugin缓存
	 *
	 */
	public static Cache getPluginCache(){
		return pluginCache;
	}
	/**
	 * 取得metrics缓存
	 *
	 */
	public static Cache getMetricsCache(){
		return metricsCache;
	}

	public static Cache getActionCache(){
		return actionCache;
	}

	/***
	 * 将资源设备的连接放入连接池缓存中
	 *
	 */
	public static void putIntoCache(Cache cache, Object uniqueKey, Object object){
		Element element = new Element(uniqueKey,object);
		cache.put(element);
	}

}

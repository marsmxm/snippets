package com.neusoft.aplus.databus.biz.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.python.google.common.base.Objects;
import org.python.google.common.collect.Lists;

import com.neusoft.aplus.databus.biz.constants.DBUSMetricConstants;

/**
 * 指标集合类, 其中key为指标名称(name),value为map map<key = name, code, unit, active...>
 * 
 * @author wuhao
 * @date 2015-1-7 下午4:26:12
 */
public class DBUSMetric extends HashMap<String, Map<String, Object>> {

	private static final long serialVersionUID = 1L;

	/**
	 * 将map中的code值封装成List<String>
	 * 
	 * @return
	 * @author wuhao
	 * @date 2015-1-8 上午10:02:34
	 */
	public List<String> getAllCodeList() {
		List<String> metrics = new ArrayList<String>();
		for (String name : this.keySet()) {
			metrics.add(this.get(name).get(DBUSMetricConstants.CODE).toString());
		}
		return metrics;
	}
	
	public List<String> getCodeList(List<String> metricNames) {
		if (metricNames == null || metricNames.size() == 0) {
			return getAllCodeList();
		}
		List<String> metrics = new ArrayList<String>();
		for (String name : this.keySet()) {
			if (metricNames.contains(name)) {
				metrics.add(this.get(name).get(DBUSMetricConstants.CODE).toString());
			}
		}
		return metrics;
	}
	
	/***
	 * 根据指标的name，返回对应的code
	 * @param name
	 * @return
	 */
	public String getCode(String name) {

		return this.get(name).get(DBUSMetricConstants.CODE).toString();

	}

	/***
	 * 根据code返回对应的namelist，仅适用于code不重复的指标信息
	 * 
	 * @param code
	 * @return
	 * @author wuhao
	 * @date 2015-1-16 下午4:31:17
	 */
	public String getName(String code) {
		for (String name : this.keySet()) {
			if (this.get(name).get(DBUSMetricConstants.CODE).toString()
					.equals(code)) {
				return name;
			}
		}
		return null;
	}

	/***
	 * 根据code返回对应的指标哈希表，仅适用于code不重复的指标信息
	 * 
	 * @param code
	 * @return
	 * @author wuhao
	 * @date 2015-1-16 下午4:34:36
	 */
	public Map<String, Object> getMetricMap(String code) {
		for (String name : this.keySet()) {
			Map<String, Object> metricMap = this.get(name);
			if (metricMap.get(DBUSMetricConstants.CODE).toString().equals(code)) {
				return metricMap;
			}
		}
		return null;
	}

	/***
	 * 根据code返回对应的namelist
	 * 
	 * @param code
	 * @return
	 * @author wuhao
	 * @date 2015-1-16 下午4:32:41
	 */
	public List<String> getNames(Object code) {
		List<String> names = new ArrayList<String>();
		for (String name : this.keySet()) {
			if (this.get(name).get(DBUSMetricConstants.CODE)
					.equals(code)) {
				names.add(name);
			}
		}
		return names;
	}

	/***
	 * 根据code返回对应的指标哈希表
	 * 
	 * @param code
	 * @return
	 * @author wuhao
	 * @date 2015-1-16 下午4:34:36
	 */
	public List<Map<String, Object>> getMetricMaps(Object code) {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>(0);
		for (String name : this.keySet()) {
			Map<String, Object> metricMap = this.get(name);
			if (metricMap.get(DBUSMetricConstants.CODE).equals(code)) {
				list.add(metricMap);
			}
		}
		return list;
	}

	/**
	 * 返回active为true的code列表
	 * 
	 * @return
	 * @author zh_ch
	 * @date 2015-1-21 上午10:36:59
	 */
	public List<String> getActiveCodeList() {
		List<String> codes = Lists.newArrayList();

		for (String name : this.keySet()) {
			String code = String.valueOf(this.get(name).get(
					DBUSMetricConstants.CODE));
			String active = String.valueOf(this.get(name).get(
					DBUSMetricConstants.ACTIVE));
			if (Objects.equal(Boolean.FALSE, Boolean.valueOf(active))) {
				continue;
			}
			codes.add(code);
		}

		return codes;
	}
}

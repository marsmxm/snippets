package com.neusoft.aplus.databus.biz.protocol.opc;
/**
 * OPC协议涉及到的常量
 * @author wuhao
 * @date 2015-1-17 上午11:39:45
 */
public final class DBUSOpc {

	public static String getProtocol() {
		return DBUSOpc.OPCSTR;
	}
	
	public static final String OPCSTR = "opc";
}

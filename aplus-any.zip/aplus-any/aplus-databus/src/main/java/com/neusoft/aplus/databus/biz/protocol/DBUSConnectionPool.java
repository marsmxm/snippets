package com.neusoft.aplus.databus.biz.protocol;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neusoft.aplus.model.bizentity.AplusConnection;

/**
 * 协议连接池
 * 
 * @author wuhao
 * @date 2014-12-25 下午5:43:29
 */
public class DBUSConnectionPool {
	public static final int DEFAULT_SIZE = 1;
	
	private AplusConnection connection;
	private DBUSConnectionTool connectionTool;
	private final BlockingQueue<DBUSConnectionWrapper> connQ;
	private static Logger log = LoggerFactory.getLogger(DBUSConnectionPool.class);

	public DBUSConnectionPool(AplusConnection connection, 
			DBUSConnectionTool connectionTool) {
		this(connection, connectionTool, DEFAULT_SIZE);
	}
	
	public DBUSConnectionPool(AplusConnection connection, 
			DBUSConnectionTool connectionTool, int maxSize) {
		this.connection = connection;
		this.connectionTool = connectionTool;
		this.connQ = new LinkedBlockingQueue<DBUSConnectionWrapper>(maxSize);
	}

	/***
	 * 从连接池里取得一个链接信息
	 * 
	 */
	public DBUSConnectionWrapper getConnection() {
		DBUSConnectionWrapper wrapper = connQ.poll();
		return wrapper == null ? create() : wrapper;
	}

	/***
	 * 将连接信息放回连接池
	 * 
	 */
	public void pushBack(DBUSConnectionWrapper wrapper) {
		if (!connQ.offer(wrapper)) {
			wrapper.close();
		}
	}

	private DBUSConnectionWrapper create() {
		log.debug("创建新的连接: {}", connection);
		return connectionTool.createConnection(connection);
	}
}

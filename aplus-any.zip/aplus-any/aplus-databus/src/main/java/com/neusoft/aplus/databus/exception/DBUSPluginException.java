package com.neusoft.aplus.databus.exception;

import java.util.LinkedList;
import java.util.Map;

import com.neusoft.aplus.common.exception.AplusException;
import com.neusoft.aplus.common.exception.annotation.MessageCN;
import com.neusoft.aplus.common.exception.annotation.MessageUS;

/**
 * Plugin异常的类
 * 
 * 异常码范围：401 ~ 600
 * 
 * @author Mu Xian Ming
 * @date 2014-12-27 下午2:30:08
 */
public class DBUSPluginException extends AplusException {

	private static final long serialVersionUID = 1L;
	//
	// 异常码范围：401 ~ 550
	//
	@MessageCN("{0}: 脚本中没有需要的类 ({1})")
	@MessageUS("{0}: Can't find the neccessary class ({1})")
	public static String PLUGIN_EXCEPTCODE_NOCLASS = createExceptionCode(401);
	@MessageCN("{0}: 与现有脚本({1})的设备类型冲突")
	@MessageUS("{0}: The plugin script for this device type is already existing ({1})")
	public static String PLUGIN_EXCEPTCODE_DUPLICATE = createExceptionCode(402);

	// plugin的校验过程中如果发现错误会抛出这个"总"的Exception
	// 它会包含指示各种错误的子Exception
	@MessageCN("脚本{0}中发现错误:")
	@MessageUS("Found errors in {0}:")
	public static String PLUGIN_EXCEPTCODE_VERIFY = createExceptionCode(500);

	@MessageCN("  未定义函数{1}")
	@MessageUS("  Function {1} is not defined")
	public static String PLUGIN_EXCEPTCODE_NO_ABS_FILENAME = createExceptionCode(499);
	@MessageCN("  {1}函数中含有不合法的key值: ({2})")
	@MessageUS("  Illegal dictionary key ({2}) found in function {1}")
	public static String PLUGIN_EXCEPTCODE_ILLEGAL_METRIC_KEY = createExceptionCode(498);
	@MessageCN("  {1}函数中的{2}指标是枚举型但不能从{3}函数得到该指标的枚举值")
	@MessageUS("  The metric {2} from function {1} is enum type, but can't get its enum value from function {3}")
	public static String PLUGIN_EXCEPTCODE_NO_ENUM = createExceptionCode(497);
	@MessageCN("  {1}函数中未定义指标")
	@MessageUS("  No metric defined in function {1}")
	public static String PLUGIN_EXCEPTCODE_NO_METRIC = createExceptionCode(496);
	@MessageCN("  {1}函数中定义了重复的指标名{2}")
	@MessageUS("  Duplicate metric name {2} in function {1}")
	public static String PLUGIN_EXCEPTCODE_METRIC_NAME_DUPLICATE = createExceptionCode(495);
	@MessageCN("  {1}函数返回空的设备类型")
	@MessageUS("  Blank device type from function {1}")
	public static String PLUGIN_EXCEPTCODE_NO_DEVICE_TYPE = createExceptionCode(494);
	@MessageCN("  {1}函数返回空的设备版本号")
	@MessageUS("  Blank device version from function {1}")
	public static String PLUGIN_EXCEPTCODE_NO_VERSION = createExceptionCode(493);
	@MessageCN("  {1}函数中的指标{2}的{3}({4})超出范围{5}")
	@MessageUS("  {3}({4}) in metric {2} from function {1} is out of range {5}")
	public static String PLUGIN_EXCEPTCODE_MODBUS_OUT_RANGE = createExceptionCode(492);
	@MessageCN("  {1}函数中的指标{2}的{3}({4})大于{5}({6})")
	@MessageUS("  {3}({4}) in metric {2} from function {1} is greater then {5}({6})")
	public static String PLUGIN_EXCEPTCODE_START_GREATER_THAN_END = createExceptionCode(491);
	@MessageCN("  {1}函数返回的SNMP版本号{2}不合法，请使用{3}中定义的常量")
	@MessageUS("  Illegal SNMP version {2} from function {1}, please use constants defined in {3}")
	public static String PLUGIN_EXCEPTCODE_SNMP_VERSION_ILLEGAL = createExceptionCode(490);
	@MessageCN("  {1}函数返回空的SNMP版本号")
	@MessageUS("  Blank SNMP version from function {1}")
	public static String PLUGIN_EXCEPTCODE_NO_SNMP_VERSION = createExceptionCode(489);
	@MessageCN("  {0}函数中定义了重复的defkey{1}")
	@MessageUS("  Duplicate defkey {1} in function {0}")
	public static String PLUGIN_EXCEPTCODE_METRIC_DEFKEY_DUPLICATE = createExceptionCode(488);
	@MessageCN("  脚本 {0}中的国际化defkey{1}不存在于指标信息中")
	@MessageUS("  The internation defkey {0} is not in the metric in {1}")
	public static String PLUGIN_EXCEPTCODE_CHECK_I18N = createExceptionCode(487);
	@MessageCN("  {0}函数中定义了重复的name{1}")
	@MessageUS("  Duplicate name {1} in function {0}")
	public static String PLUGIN_EXCEPTCODE_ACTION_NAME_DUPLICATE = createExceptionCode(486);
	@MessageCN("  {1}函数中未定义Action")
	@MessageUS("  No action defined in function {1}")
	public static String PLUGIN_EXCEPTCODE_NO_ACTION = createExceptionCode(485);
	@MessageCN("  {1}函数中有未定义NAME的指标")
	@MessageUS("  Some metrics don't contain names in function {1}")
	public static String PLUGIN_EXCEPTCODE_NO_METRIC_NAME = createExceptionCode(484);
	@MessageCN("  {1}函数中有未定义CODE的指标")
	@MessageUS("  Some metrics don't contain codes in function {1}")
	public static String PLUGIN_EXCEPTCODE_NO_METRIC_CODE = createExceptionCode(483);
	
	
	@MessageCN("非法的功能代码")
	@MessageUS("illegal function")
	public static String ILLEGAL_FUNCTION = createExceptionCode(501);
	@MessageCN("非法的地址信息")
	@MessageUS("illegal data address")
	public static String ILLEGAL_DATA_ADDRESS = createExceptionCode(502);
	@MessageCN("连接目标设备失败")
	@MessageUS("device_connect_failure")
	public static String DEVICE_CONNECTION_FAILURE = createExceptionCode(503);
	@MessageCN("Modbus传输异常")
	@MessageUS("modbus_transport_exception")
	public static String MODBUS_TRANSPORT_EXCEPTION = createExceptionCode(504);
	@MessageCN("Modbus连接初始化异常")
	@MessageUS("modbus_connection_init_exception")
	public static String MODBUS_CONNECTION_INIT_EXCEPTION = createExceptionCode(505);
	@MessageCN("Modbus串口服务器连接异常")
	@MessageUS("modbus_serials_server_exception")
	public static String MODBUS_SERIALS_SERVER_EXCEPTION = createExceptionCode(506);
	@MessageCN("创建协议工具类异常 {1}")
	@MessageUS("connection_tool_create_exception {1}")
	public static String CONNECTION_TOOL_CREATE_EXCEPTION = createExceptionCode(507);
	@MessageCN("缓存中没有{0}设备类型的指标")
	@MessageUS("No metric data for device type {0} in metric cache")
	public static String EXCEPTCODE_NO_METRIC = createExceptionCode(508);
	@MessageCN("缓存中没有{0}设备类型对应的Plugin")
	@MessageUS("No plugin for device type {0} in cache")
	public static String EXCEPTCODE_NO_PLUGIN = createExceptionCode(509);
	@MessageCN("缓存中没有{0}设备类型的action")
	@MessageUS("No action data for device type {0} in cache")
	public static String EXCEPTCODE_NO_ACTION = createExceptionCode(510);
	@MessageCN("传入的值非法")
	@MessageUS("Illegal value")
	public static String EXCEPTCODE_ILLEGAL_VALUE = createExceptionCode(511);
	@MessageCN("ConnectionTool初始化失败: {0}")
	@MessageUS("ConnectionTool initialization failed: {0}")
	public static String PLUGIN_EXCEPTCODE_INIT_CON_TOOL_FAIL = createExceptionCode(512);

	private LinkedList<DBUSPluginException> subExceptions;

	public DBUSPluginException(String code) {
		this(code, null, null, null);
	}

	public DBUSPluginException(String code, Exception original,
			Object[] params, Map<String, Object> keyPoints) {
		super(code, original, params, keyPoints);
		if (code.equals(PLUGIN_EXCEPTCODE_VERIFY)) {
			subExceptions = new LinkedList<DBUSPluginException>();
		}
	}

	/**
	 * 封装异常创建及抛出
	 * 
	 * @param ecode
	 * @author Mu Xian Ming
	 * @date 2014-7-23 下午2:45:48
	 */
	public static void throwException(String ecode) {
		throwException(ecode, null, null, null);
	}

	/**
	 * 封装异常创建及抛出
	 * 
	 * @param ecode
	 * @param original
	 * @param params
	 * @param keyPoints
	 * @author wuhao
	 * @date 2014-7-23 下午2:45:48
	 */
	public static void throwException(String ecode, Exception original,
			Object[] params, Map<String, Object> keyPoints) {
		DBUSPluginException exception = new DBUSPluginException(ecode,
				original, params, keyPoints);
		exception.throwEx();
	}

	public LinkedList<DBUSPluginException> getSubExceptions() {
		return subExceptions;
	}

	public void addSubException(DBUSPluginException e) {
		if (getEcode().equals(PLUGIN_EXCEPTCODE_VERIFY)) {
			subExceptions.add(e);
		}
	}

	/**
	 * 工具方法，负责生成异常码
	 * 
	 * @param code
	 * @return String
	 * @author wuhao
	 * @date 2014-7-23 下午2:45:48
	 */
	private static String createExceptionCode(int code) {
		return getFormatedNumber(ID_DATABUS, code);
	}

}

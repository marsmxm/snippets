package com.neusoft.aplus.databus.biz.constants;

import java.io.File;

import org.apache.commons.io.FilenameUtils;

/**
 * 包含Plugin相关常量的类
 * 
 * @author Mu Xian Ming
 * @date 2014年12月25日 下午5:25:50
 */
public class DBUSPluginConstants {
	// 插件Python脚本及插件Jar包的路径
	private static String basedir = FilenameUtils.getFullPath(new File("").getAbsolutePath());
	
	public final static String SCRIPT_PATH_TEST = basedir + "aplus-databus" + File.separator + "src"
			+ File.separator + "test" + File.separator + "resources"
			+ File.separator + "plugins" + File.separator + "scripts" + File.separator;
	
	// Python插件脚本中的类名，用来实现{@link DBUSPlugin}接口
	public final static String PLUGIN_CLASS_NAME = "Plugin";
	
	// ZMQ传输的JSONObject的key值
	public final static String JSONOBJ_KEY_DEVICE_TYPE = "deviceType";
	public final static String JSONOBJ_KEY_DEVICE_VERSION = "deviceTypeVersion";
	public final static String JSONOBJ_KEY_FQN = "FQN";
	public final static String JSONOBJ_KEY_CONN_INFO = "connInfo";
}

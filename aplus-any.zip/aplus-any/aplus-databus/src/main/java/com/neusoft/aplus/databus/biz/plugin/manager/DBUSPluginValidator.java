package com.neusoft.aplus.databus.biz.plugin.manager;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import org.apache.commons.lang.StringUtils;
import org.python.core.PyException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neusoft.aplus.common.util.ClassUtil;
import com.neusoft.aplus.databus.biz.constants.DBUSMetricConstants;
import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;
import com.neusoft.aplus.databus.biz.protocol.modbus.DBUSModbus;
import com.neusoft.aplus.databus.biz.protocol.opc.DBUSOpc;
import com.neusoft.aplus.databus.biz.protocol.snmp.DBUSSnmp;
import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.model.bizentity.AplusMetricValueType;

/**
 * plugin验证器
 *
 * {@link DBUSPluginManager}增加脚本时会调用该类的verify方法
 * 
 * @author Mu Xian Ming
 * @date 2015年1月10日 下午2:40:07
 */
public class DBUSPluginValidator {
	private static Logger logger = LoggerFactory
			.getLogger(DBUSPluginValidator.class);
	private static DBUSPluginValidator instance = new DBUSPluginValidator();

	private DBUSPluginValidator() {
	}

	public static DBUSPluginValidator getInstance() {
		return instance;
	}

	/**
	 * 验证plugin脚本的合法性
	 * 
	 * 由脚本的各项分步验证组成，每步校验出的错误会以DBUSPluginException
	 * 的形式存到一个队列中，最后会显示出队列中所有DBUSPluginException的
	 * 错误信息，然后抛出一个包含所有DBUSPluginException的code为
	 * DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY的总异常。
	 * 
	 * @param plugin
	 *            要校验的plugin实例
	 * @throws DBUSPluginException
	 */
	public void verify(DBUSPlugin plugin, String currentFilename) throws DBUSPluginException {
		logger.debug("Validating " + currentFilename + "...");
		Queue<DBUSPluginException> eq = new LinkedList<DBUSPluginException>();

		checkAbsFilename(currentFilename, plugin, eq);
		checkDeviceType(plugin, eq);
		checkVersion(plugin, eq);
		checkMetricDef(plugin, eq);
		checkActionDef(plugin, eq);

		if (useSupportedProtocal(plugin)) {
			checkProtocalRelated(plugin, eq);
		}

		if (!eq.isEmpty()) {
			Object[] params = { currentFilename };
			DBUSPluginException verifyException = new DBUSPluginException(
					DBUSPluginException.PLUGIN_EXCEPTCODE_VERIFY, null, params,
					null);
			logger.error(verifyException.getErrorMsg());
			for (DBUSPluginException e : eq) {
				logger.error(e.getErrorMsg());
				verifyException.addSubException(e);
			}
			verifyException.throwEx();
		}
		logger.debug("Validation finished without error.");
	}

	/**
	 * 校验脚本是否能通过getAbsFilename函数得到绝对路径
	 *
	 * @param eq
	 *            DBUSPluginException队列，用来保存此步校验产生的异常
	 */
	private void checkAbsFilename(String currentFilename, DBUSPlugin plugin,
			Queue<DBUSPluginException> eq) {
		logger.debug("Checking absolute filename...");
		String filename = plugin.getAbsFilename();
		if (StringUtils.isBlank(filename) || filename.equals("null")) {
			Object[] params = { currentFilename, "getAbsFilename" };
			DBUSPluginException e = new DBUSPluginException(
					DBUSPluginException.PLUGIN_EXCEPTCODE_NO_ABS_FILENAME,
					null, params, null);
			eq.offer(e);
		}
	}

	/**
	 * 校验脚本getDeviceType返回设备类型的合法性
	 *
	 * @param eq
	 *            DBUSPluginException队列，用来保存此步校验产生的异常
	 */
	private void checkDeviceType(DBUSPlugin plugin,
			Queue<DBUSPluginException> eq) {
		logger.debug("Checking DeviceType...");
		String deviceType = plugin.getDeviceType();
		if (StringUtils.isBlank(deviceType) || deviceType.equals("null")) {
			Object[] params = { plugin.getAbsFilename(), "getDeviceType" };
			DBUSPluginException e = new DBUSPluginException(
					DBUSPluginException.PLUGIN_EXCEPTCODE_NO_DEVICE_TYPE, null,
					params, null);
			eq.offer(e);
		}
	}

	/**
	 * 校验脚本getVersion返回的版本的合法性
	 *
	 * @param eq
	 *            DBUSPluginException队列，用来保存此步校验产生的异常
	 */
	private void checkVersion(DBUSPlugin plugin, Queue<DBUSPluginException> eq) {
		logger.debug("Checking Version...");
		String version = plugin.getVersion();
		if (StringUtils.isBlank(version) || version.equals("null")) {
			Object[] params = { plugin.getAbsFilename(), "getVersion" };
			DBUSPluginException e = new DBUSPluginException(
					DBUSPluginException.PLUGIN_EXCEPTCODE_NO_VERSION, null,
					params, null);
			eq.offer(e);
		}
	}

	/**
	 * 校验脚本getMetricDef函数返回的指标的合法性
	 * 
	 * 1. 指标不为空 
	 * 2. 每个指标须定义NAME和CODE
	 * 3. 每个指标的指标名不重复 
	 * 4. 使用已知协议时每个指标Map的key是已定义的常量值 
	 * 5. 使用已知协议时枚举类型的指标必须能通过getMetricEnum得到枚举值map
	 *
	 * @param eq
	 *            DBUSPluginException队列，用来保存此步校验产生的异常
	 */
	private void checkMetricDef(DBUSPlugin plugin, Queue<DBUSPluginException> eq) {
		logger.debug("Checking Metrics...");
		String funcName = "getMetricDef";
		List<Map<String, Object>> metrics = plugin.getMetricDef();
		boolean support = useSupportedProtocal(plugin);
		// 校验是否定义了指标
		if (metrics == null || metrics.size() == 0) {
			Object[] params = { plugin.getAbsFilename(), funcName };
			DBUSPluginException e = new DBUSPluginException(
					DBUSPluginException.PLUGIN_EXCEPTCODE_NO_METRIC, null,
					params, null);
			eq.offer(e);
			return;
		}
		Map<String, Integer> nameCounter = new HashMap<String, Integer>();
//		Map<String, Integer> defKeyCounter = new HashMap<String, Integer>();
		for (Map<String, Object> m : metrics) {
			if (!m.containsKey(DBUSMetricConstants.NAME)) {
				Object[] params = { plugin.getAbsFilename(), funcName };
				DBUSPluginException e = new DBUSPluginException(
						DBUSPluginException.PLUGIN_EXCEPTCODE_NO_METRIC_NAME, null,
						params, null);
				eq.offer(e);
				continue;
			}
			if (!m.containsKey(DBUSMetricConstants.CODE)) {
				Object[] params = { plugin.getAbsFilename(), funcName };
				DBUSPluginException e = new DBUSPluginException(
						DBUSPluginException.PLUGIN_EXCEPTCODE_NO_METRIC_CODE, null,
						params, null);
				eq.offer(e);
			}
			String metricName = (String) m.get(DBUSMetricConstants.NAME);
			// 用作校验指标名是否重复(value大于1)
			if (nameCounter.containsKey(metricName)) {
				nameCounter.put(metricName, nameCounter.get(metricName) + 1);
			} else {
				nameCounter.put(metricName, 1);
			}

//			String defkey = (String) m.get(DBUSMetricConstants.DEFKEY);
//			// 用作校验defkey是否重复(value大于1)
//			if (defKeyCounter.containsKey(defkey)) {
//				defKeyCounter.put(defkey, defKeyCounter.get(defkey) + 1);
//			} else {
//				defKeyCounter.put(defkey, 1);
//			}

			if (support) { // 使用已知协议
				// 校验每个指标Map的key是否为DBUSMetricConstants中已定义的常量值
				for (String k : m.keySet()) {
					if (!ClassUtil.hasConstValue(DBUSMetricConstants.class, k)) {
						Object[] params = { plugin.getAbsFilename(), funcName,
								k };
						DBUSPluginException e = new DBUSPluginException(
								DBUSPluginException.PLUGIN_EXCEPTCODE_ILLEGAL_METRIC_KEY,
								null, params, null);
						eq.offer(e);
					}
				}
				// 枚举类型的指标必须能通过getMetricEnum得到枚举值map
				if (m.get(DBUSMetricConstants.TYPE)
						.equals(AplusMetricValueType.TYPE_ENUM)) {

					if (plugin.getMetricEnum(metricName) == null) {
						Object[] params = { plugin.getAbsFilename(), funcName,
								metricName, "getMetricEnum()" };
						DBUSPluginException e = new DBUSPluginException(
								DBUSPluginException.PLUGIN_EXCEPTCODE_NO_ENUM,
								null, params, null);
						eq.offer(e);
					}
				}
			}
		}
		// 校验是否有重复的指标名
		for (String k : nameCounter.keySet()) {
			if (nameCounter.get(k) > 1) {
				Object[] params = { plugin.getAbsFilename(), funcName, k };
				DBUSPluginException e = new DBUSPluginException(
						DBUSPluginException.PLUGIN_EXCEPTCODE_METRIC_NAME_DUPLICATE,
						null, params, null);
				eq.offer(e);
			}
		}

//		// 校验是否有重复的defkey
//		for (String k : defKeyCounter.keySet()) {
//			if (defKeyCounter.get(k) > 1) {
//				Object[] params = { funcName, k };
//				DBUSPluginException e = new DBUSPluginException(
//						DBUSPluginException.PLUGIN_EXCEPTCODE_METRIC_DEFKEY_DUPLICATE,
//						null, params, null);
//				eq.offer(e);
//			}
//		}
	}

	/**
	 * 协议相关的校验
	 *
	 * @param eq
	 *            DBUSPluginException队列，用来保存此步校验产生的异常
	 */
	private void checkProtocalRelated(DBUSPlugin plugin,
			Queue<DBUSPluginException> eq) {
		String protocal = plugin.getProtocol();

		if (protocal.equals(DBUSSnmp.getProtocol())) {
			// 校验SNMP版本是否合法
			String funcName = "getProtocolMode";
			String protocalMode;
			try {
				protocalMode = plugin.getProtocolMode();
			} catch (PyException e) {
				Object[] params = { plugin.getAbsFilename(), funcName, "",
						"DBUSSnmp.class" };
				DBUSPluginException plugine = new DBUSPluginException(
						DBUSPluginException.PLUGIN_EXCEPTCODE_SNMP_VERSION_ILLEGAL,
						null, params, null);
				eq.offer(plugine);
				return;
			}
			if (StringUtils.isBlank(protocalMode)
					|| protocalMode.equals("null")) {
				Object[] params = { plugin.getAbsFilename(), funcName };
				DBUSPluginException e = new DBUSPluginException(
						DBUSPluginException.PLUGIN_EXCEPTCODE_NO_SNMP_VERSION,
						null, params, null);
				eq.offer(e);
			} else if (!(protocalMode.equals(DBUSSnmp.VERSION1)
					|| protocalMode.equals(DBUSSnmp.VERSION2) || protocalMode
						.equals(DBUSSnmp.VERSION3))) {
				Object[] params = { plugin.getAbsFilename(), funcName,
						protocalMode, "DBUSSnmp.class" };
				DBUSPluginException e = new DBUSPluginException(
						DBUSPluginException.PLUGIN_EXCEPTCODE_SNMP_VERSION_ILLEGAL,
						null, params, null);
				eq.offer(e);

			}

		} // SNMP validation

		if (protocal.equals(DBUSModbus.getProtocol())) {
			List<Map<String, Object>> metrics = plugin.getMetricDef();
			// 校验modbus指标中的start和end必须在长度范围内
			for (Map<String, Object> m : metrics) {
				String name = (String) m.get(DBUSMetricConstants.NAME);
				String code = (String) m.get(DBUSMetricConstants.CODE);
				// code第三位是长度范围
				int length = Integer.parseInt(code.split("\\.")[2]);
				int start = (Integer) m.get(DBUSMetricConstants.START);
				int end = (Integer) m.get(DBUSMetricConstants.END);
				if (start > end) {
					Object[] params = { plugin.getAbsFilename(),
							"getMetricDef", name, DBUSMetricConstants.START,
							start, DBUSMetricConstants.END, end };
					DBUSPluginException e = new DBUSPluginException(
							DBUSPluginException.PLUGIN_EXCEPTCODE_START_GREATER_THAN_END,
							null, params, null);
					eq.offer(e);
				}
				if (start < 1) {
					Object[] params = { plugin.getAbsFilename(),
							"getMetricDef", name, DBUSMetricConstants.START,
							start, code };
					DBUSPluginException e = new DBUSPluginException(
							DBUSPluginException.PLUGIN_EXCEPTCODE_MODBUS_OUT_RANGE,
							null, params, null);
					eq.offer(e);
				}
				if (end > length) {
					Object[] params = { plugin.getAbsFilename(),
							"getMetricDef", name, DBUSMetricConstants.END, end,
							code };
					DBUSPluginException e = new DBUSPluginException(
							DBUSPluginException.PLUGIN_EXCEPTCODE_MODBUS_OUT_RANGE,
							null, params, null);
					eq.offer(e);
				}
			}
		} // modbus validation
	}

	private boolean useSupportedProtocal(DBUSPlugin plugin) {
		String protocal = plugin.getProtocol();
		return StringUtils.isNotBlank(protocal)
				&& (protocal.equals(DBUSSnmp.getProtocol())
						|| protocal.equals(DBUSModbus.getProtocol()) || protocal
							.equals(DBUSOpc.getProtocol()));
	}

	/**
	 * 校验脚本getActionDef函数返回的指标的合法性 1. name不能重复 2. defey不能重复，且与metric的defkey相同
	 *
	 */
	private void checkActionDef(DBUSPlugin plugin, Queue<DBUSPluginException> eq) {
		logger.debug("Checking Action...");
		String funcName = "getActionDef";
		List<Map<String, Object>> action = plugin.getActionDef();
		if (action != null && action.size() > 0) {
			Map<String, Integer> nameCounter = new HashMap<String, Integer>();
//			Map<String, Integer> defKeyCounter = new HashMap<String, Integer>();
			for (Map<String, Object> m : action) {
				String actionName = (String) m.get(DBUSMetricConstants.NAME);
				// 用作校验指标名是否重复(value大于1)
				if (nameCounter.containsKey(actionName)) {
					nameCounter
							.put(actionName, nameCounter.get(actionName) + 1);
				} else {
					nameCounter.put(actionName, 1);
				}

//				String defkey = (String) m.get(DBUSMetricConstants.DEFKEY);
//				// 用作校验defkey是否重复(value大于1)
//				if (defKeyCounter.containsKey(defkey)) {
//					defKeyCounter.put(defkey, defKeyCounter.get(defkey) + 1);
//				} else {
//					defKeyCounter.put(defkey, 1);
//				}

			}
			// 校验action中是否有重复的name
			for (String k : nameCounter.keySet()) {
				if (nameCounter.get(k) > 1) {
					Object[] params = { funcName, k };
					DBUSPluginException e = new DBUSPluginException(
							DBUSPluginException.PLUGIN_EXCEPTCODE_ACTION_NAME_DUPLICATE,
							null, params, null);
					eq.offer(e);
				}
			}

//			// 校验是否有重复的defkey
//			for (String k : defKeyCounter.keySet()) {
//				if (defKeyCounter.get(k) > 1) {
//					Object[] params = { funcName, k };
//					DBUSPluginException e = new DBUSPluginException(
//							DBUSPluginException.PLUGIN_EXCEPTCODE_METRIC_DEFKEY_DUPLICATE,
//							null, params, null);
//					eq.offer(e);
//				}
//			}
		}

	}
}

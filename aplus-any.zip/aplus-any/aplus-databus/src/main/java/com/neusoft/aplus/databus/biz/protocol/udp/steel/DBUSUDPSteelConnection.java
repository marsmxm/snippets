package com.neusoft.aplus.databus.biz.protocol.udp.steel;

import com.neusoft.aplus.model.bizentity.AplusConnection;

/**
 * 河北钢铁UDP的连接信息实体类
 *
 * @author mxm
 * @date 2015-6-30
 */
public class DBUSUDPSteelConnection extends AplusConnection {

    private static final long serialVersionUID = 1L;

    // udpConnection info
    // ip地址
    public static final String IP_ADDRESS = "ip_addr";
    // 端口
    public static final String PORT = "port";
    // 通讯机（告警主机）地址
    public static final String ALARM_HOST = "alarm_host";
    // 设备地址
    public static final String EQU_ADDRESS = "equipment_addr";
    // 用户组编号
    public static final String GROUP_ID = "group_id";
    // 防区号
    public static final String ZONE = "zone";

    public DBUSUDPSteelConnection(AplusConnection conn) {
        setIpAddress((String) conn.get(IP_ADDRESS));
        setPort((String) conn.get(PORT));
        setAlarmHost((Integer) conn.get(ALARM_HOST));
        setEquipAddress((Integer) conn.get(EQU_ADDRESS));
        setGroupID((Integer) conn.get(GROUP_ID));
        Object zone = conn.get(ZONE);
        if (zone == null) {
            setZone(0);
        } else {
            setZone((Integer) zone);
        }
    }


    public String getIpAddress() {
        return get(IP_ADDRESS).toString();
    }

    public void setIpAddress(String ipAddress) {
        put(IP_ADDRESS, ipAddress);
    }

    public String getPort() {
        return get(PORT).toString();
    }

    public void setPort(String port) {
        put(PORT, port);
    }

    public int getAlarmHost() {
        return (Integer) get(ALARM_HOST);
    }

    public void setAlarmHost(int alarmHost) {
        put(ALARM_HOST, alarmHost);
    }

    public int getEquipAddress() {
        return (Integer) get(EQU_ADDRESS);
    }

    public void setEquipAddress(int addr) {
        put(EQU_ADDRESS, addr);
    }

    public int getGroupID() {
        return (Integer) get(GROUP_ID);
    }

    public void setGroupID(int id) {
        put(GROUP_ID, id);
    }

    public int getZone() {
        return (Integer) get(ZONE);
    }

    public void setZone(int zone) {
        put(ZONE, zone);
    }

}

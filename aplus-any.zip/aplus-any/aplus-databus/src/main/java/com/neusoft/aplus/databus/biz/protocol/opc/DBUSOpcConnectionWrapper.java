package com.neusoft.aplus.databus.biz.protocol.opc;

import org.openscada.opc.lib.common.ConnectionInformation;

import com.neusoft.aplus.databus.biz.protocol.DBUSAbstractConnectionWrapper;
import com.neusoft.aplus.model.bizentity.AplusConnection;

/**
 * OPC采集connection的包装类
 * @author Mu Xian Ming
 * @date 2015年6月23日 下午2:46:27
 */
public class DBUSOpcConnectionWrapper extends DBUSAbstractConnectionWrapper {
	private ConnectionInformation conInfo;

	public DBUSOpcConnectionWrapper(
			AplusConnection connInfo, ConnectionInformation conn) {
		super(connInfo, conn);
		this.conInfo = conn;
	}
	
	@Override
	public ConnectionInformation getConnection() {
		return conInfo;
	}

	@Override
	public void close() {
		// Nothing to do
	}

}

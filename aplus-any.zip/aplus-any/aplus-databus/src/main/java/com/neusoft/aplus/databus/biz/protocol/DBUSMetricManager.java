package com.neusoft.aplus.databus.biz.protocol;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

import org.apache.commons.lang.StringUtils;
import org.python.google.common.base.Preconditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;
import com.neusoft.aplus.databus.biz.cache.DBUSLocalCache;
import com.neusoft.aplus.databus.biz.constants.DBUSMetricConstants;
import com.neusoft.aplus.databus.biz.model.DBUSMetric;
import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;
import com.neusoft.aplus.databus.biz.plugin.manager.DBUSPluginManager;
import com.neusoft.aplus.databus.exception.DBUSPluginException;

/**
 * 负责从Plugin得到的指标的存取和修改
 * 
 * @author Mu Xian Ming
 * @date 2015年1月16日 下午3:24:20
 */
public class DBUSMetricManager {
	private static Logger logger = LoggerFactory
			.getLogger(DBUSMetricManager.class);
	private static DBUSMetricManager instance = new DBUSMetricManager();
	private Cache metricCache = DBUSLocalCache.getMetricsCache();
	
	private DBUSMetricManager() {
	}
	
	public static DBUSMetricManager getInstance() {
		return instance;
	}
	
	/**
	 * 将deviceTypeId代表的plugin的所有指标存入缓存
	 * 
	 * @param deviceTypeId 指标所属的设备类型ID
	 * @return DBUSMetric
	 */
	public Optional<DBUSMetric> add(String deviceTypeId) {
		logger.debug("Adding metrics of " + deviceTypeId + "...");
		Optional<DBUSMetric> metricOption = getMetricMap(deviceTypeId);
		if (metricOption.isPresent()) {
			return add(deviceTypeId, metricOption.get());
		} else {
			return Optional.absent();
		}
	}
	
	private Optional<DBUSMetric> add(String deviceTypeId, DBUSMetric map) {
		Element element = new Element(deviceTypeId, map);
		metricCache.put(element);
		return Optional.of(map);
	}
	
	public boolean remove(String deviceTypeId) {
		return metricCache.remove(deviceTypeId);
	}
	
	public void update(String deviceTypeId, DBUSMetric map) {
		add(deviceTypeId, map);
	}
	
	public void update(String deviceTypeID,
			List<Map<String, Object>> deltaBody) throws DBUSPluginException {
		Preconditions.checkArgument(StringUtils.isNotBlank(deviceTypeID));
		Preconditions.checkNotNull(deltaBody);
		Preconditions.checkArgument(deltaBody.size() > 0);
		Optional<DBUSMetric> mapOption = getMetricMap(deviceTypeID);
		if (mapOption.isPresent()) {
			DBUSMetric map = mapOption.get();
			for (Map<String, Object> metric : deltaBody) {
				String metricName = 
						(String) metric.get(DBUSMetricConstants.NAME);
				map.put(metricName, metric);
			}
			update(deviceTypeID, map);
		} else {
			Object[] params = { deviceTypeID };
			DBUSPluginException e = new DBUSPluginException(
					DBUSPluginException.EXCEPTCODE_NO_METRIC, null, params,
					null);
			logger.error(e.getErrorMsg());
			e.throwEx();
		}
	}
	
	/**
	 * @param deviceTypeId 指标所属的设备类型ID
	 * @return DBUSMetricMap实例
	 * @author wuhao
	 * @date 2014-12-26 下午5:39:29
	 */
	public Optional<DBUSMetric> getMetricMap(String deviceTypeId) {
		if (!exists(deviceTypeId)) {
			DBUSMetric metricMap = listToMetricMap(getMetricsFromPlugin(deviceTypeId));
			if (metricMap != null && metricMap.size() != 0) {
				return add(deviceTypeId, metricMap);
			} else {
				return Optional.absent();
			}
		}
		return Optional.of((DBUSMetric) metricCache.get(deviceTypeId).getObjectValue());
	}
	
	
	/***
	 * 根据设备Id，获取指定设备的指标信息
	 * 
	 * @param deviceTypeId 设备类型ID
	 * @return 包含deviceTypeId对应的plugin的所有指标Map的List
	 * @author wuhao
	 * @date 2014-12-25 下午8:47:42
	 */
	private List<Map<String, Object>> getMetricsFromPlugin(String deviceTypeId) {
		DBUSPluginManager pluginManager = DBUSPluginManager.getInstance();
		Optional<DBUSPlugin> pluginOption = pluginManager.getById(deviceTypeId);
		if (pluginOption.isPresent()) {
			return pluginOption.get().getMetricDef();
		} else {
			return null;
		}
		
	}
	
	/***
	 * 将指标类型信息封装成存入指标缓存中的Map结构
	 * 
	 * @param list 代表指标的List<Map>
	 * @return 指标类DBUSMetric
	 * @author wuhao
	 * @date 2014-12-26 下午5:29:24
	 */
	public static DBUSMetric listToMetricMap(List<Map<String, Object>> list) {
		if (list != null && list.size() != 0) {
			DBUSMetric metricMap = new DBUSMetric();
			for (Map<String, Object> map : list) {
				if (map.containsKey(DBUSMetricConstants.NAME)) {
					metricMap.put(map.get(DBUSMetricConstants.NAME).toString(), map);
				}
			}
			return metricMap;
		} else {
			return null;
		}
	}
	
	public static List<Map<String, Object>> metricMapToList(DBUSMetric map) {
		Preconditions.checkNotNull(map, "传入的DBUSMetric为null");
		return new ArrayList<Map<String, Object>>(map.values());
	}
	
	private boolean exists(String deviceTypeId) {
		return metricCache.get(deviceTypeId) != null;
	}
}

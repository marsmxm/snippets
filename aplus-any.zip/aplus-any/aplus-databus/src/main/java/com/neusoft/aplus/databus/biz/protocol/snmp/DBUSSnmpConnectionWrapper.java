package com.neusoft.aplus.databus.biz.protocol.snmp;

import java.io.IOException;
import java.util.Map;

import org.snmp4j.Snmp;

import com.neusoft.aplus.databus.biz.protocol.DBUSAbstractConnectionWrapper;
import com.neusoft.aplus.model.bizentity.AplusConnection;

/**
 * @author Mu Xian Ming
 * @date 2015年6月23日 下午2:46:27
 */
public class DBUSSnmpConnectionWrapper extends DBUSAbstractConnectionWrapper {

	public DBUSSnmpConnectionWrapper(
			AplusConnection connInfo, Object conn) {
		super(connInfo, conn);
	}

	@Override
	public void close() {
		@SuppressWarnings("unchecked")
		Map<String, Object> connectionTable = 
				(Map<String, Object>) getConnection();
		Snmp snmp = (Snmp) connectionTable.get(DBUSSnmpConnectionTool.SNMP);
		try {
			snmp.close();
		} catch (IOException ignored) {
		}
	}

}

package com.neusoft.aplus.databus.biz.protocol.modbus;

/**
 * modbus常量类
 * 
 * @author wuhao
 * @date 2014-12-31 下午2:57:26
 */
public class DBUSModbus {

	public static String getProtocol() {
		return "modbus";
	}

	// Modbus连接类型和传输类型
	public static final String COM = "COM";
	public static final String RTU = "RTU";
	public static final String TCP = "TCP";
	public static final String SERVER = "SERVER";// 串口服务器连接方式
	public static final String DIANZONG = "DIANZONG";
	public static final String OTHER = "OTHER";// 其他

	// Modbus功能代码
	public static final int READ_COILS = 1;
	public static final int READ_DISCRETE_INPUTS = 2;
	public static final int READ_HOLDING_REGISTERS = 3;
	public static final int READ_INPUT_REGISTERS = 4;
	public static final int WRITE_COIL = 5;
	public static final int WRITE_REGISTER = 6;
	public static final int READ_EXCEPTION_STATUS = 7;
	public static final int WRITE_COILS = 15;
	public static final int WRITE_REGISTERS = 16;
	public static final int REPORT_SLAVE_ID = 17;
	public static final int WRITE_MASK_REGISTER = 22;

	public static int DEFAULT_COMMAND_SIZE = 200;
}

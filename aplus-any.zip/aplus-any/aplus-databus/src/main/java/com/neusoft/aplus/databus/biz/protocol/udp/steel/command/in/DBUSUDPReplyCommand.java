package com.neusoft.aplus.databus.biz.protocol.udp.steel.command.in;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neusoft.aplus.databus.biz.constants.DBUSMetricConstants;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.DBUSUDPSteel;
import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.bizentity.AplusMetricData;
import com.neusoft.aplus.model.bizentity.hbgt.DBUSUDPSteelDataWrapper;

/**
 * 河北钢铁UDP设备上报操作命令
 *
 * @author limn
 * @date 2015-7-7 上午10:49:14
 */
public class DBUSUDPReplyCommand extends DBUSUDPBaseInboundCommand {

    public static final int REPLY_FRAME_LENGTH = 10;//帧长度；设备应答（中心应答）9~16
    public static final int USER_OPERATION_TYPE_BYTE_INDEX = 7;
    public static final int USER_OPERATION_CODE_BYTE_INDEX = 8;


    private final byte userOperationTypeByte; // 用户操作类型
    private final byte userOperationCodeByte; // 操作号字节

    public DBUSUDPReplyCommand(byte[] bytes) {
        super(bytes);
        userOperationTypeByte = bytes[USER_OPERATION_TYPE_BYTE_INDEX];
        userOperationCodeByte = bytes[USER_OPERATION_CODE_BYTE_INDEX];

    }

    @Override
    public byte[] getReply() {
        byte[] reply = new byte[REPLY_FRAME_LENGTH];
        reply[0] = REPLY_FRAME_LENGTH;
        partialReply(reply);
        reply[REPLY_FRAME_LENGTH - 3] = DBUSDatabusUtil.makeChecksum(reply);
        return reply;
    }

    @Override
    public boolean hasUDPData() {
        return true;
    }

    @Override
    public List<DBUSUDPSteelDataWrapper> getUDPData() {
        List<DBUSUDPSteelDataWrapper> result = Lists.newArrayList();

        // 获取deviceType deviceVersion
        String typeIDDevice = DBUSDatabusUtil.getDeviceTypeId(
                DBUSUDPSteel.TYPE_DEVICE, DBUSUDPSteel.VERSION_DEVICE);
        // 根据type+version，获取脚本中的指标信息
        List<Map<String, Object>> deviceMetrics = getMetrics(typeIDDevice, DBUSDatabusUtil.unsigned(getCmdID()));

        AplusMetricData deviceMetricData = new AplusMetricData();
        Map<String, AplusMetricData> deviceMetricDataMap = Maps.newHashMap();

        String userOperationTypeMetricName = null;
        String userOperationCodeMetricName = null;
        for (Map<String, Object> metric : deviceMetrics) {
            if (USER_OPERATION_TYPE_BYTE_INDEX == (Integer) metric.get(DBUSMetricConstants.BYTE_INDEX)) {
                userOperationTypeMetricName = (String) metric.get(DBUSMetricConstants.NAME);
                deviceMetricData.setName(userOperationTypeMetricName);
                deviceMetricData.setRecordTime(System.currentTimeMillis());
                deviceMetricData.setValue(userOperationTypeByte);
                deviceMetricDataMap.put(deviceMetricData.getName(),
                        deviceMetricData);
            }
            if (USER_OPERATION_CODE_BYTE_INDEX == (Integer) metric.get(DBUSMetricConstants.BYTE_INDEX)) {
                userOperationCodeMetricName = (String) metric.get(DBUSMetricConstants.NAME);
                deviceMetricData.setName(userOperationCodeMetricName);
                deviceMetricData.setRecordTime(System.currentTimeMillis());
                deviceMetricData.setValue(userOperationCodeByte);
                deviceMetricDataMap.put(deviceMetricData.getName(),
                        deviceMetricData);
            }
        }
        if (userOperationTypeMetricName == null || userOperationCodeMetricName == null) {
            Object[] params = {typeIDDevice};
            DBUSPluginException.throwException(
                    DBUSPluginException.EXCEPTCODE_NO_METRIC, null, params, null);
        }


        // build device data
        AplusDeviceMonitorData deviceData = new AplusDeviceMonitorData();
        deviceData.setDeviceType(DBUSUDPSteel.TYPE_DEVICE);
        deviceData.setDeviceVersion(DBUSUDPSteel.VERSION_DEVICE);

        deviceData.setMetricDatas(deviceMetricDataMap);
        DBUSUDPSteelDataWrapper deviceWrapper = new DBUSUDPSteelDataWrapper(
                DBUSDatabusUtil.unsigned(getEquipAddr()), 0, deviceData, getGroup());
        result.add(deviceWrapper);

        return result;
    }
}

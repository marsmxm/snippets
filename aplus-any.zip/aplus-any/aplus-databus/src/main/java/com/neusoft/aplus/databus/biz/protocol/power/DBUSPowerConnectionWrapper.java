package com.neusoft.aplus.databus.biz.protocol.power;

import com.neusoft.aplus.databus.biz.protocol.DBUSAbstractConnectionWrapper;
import com.neusoft.aplus.model.bizentity.AplusConnection;

/**
 * @author Mu Xian Ming
 * @date 2015年6月23日 下午2:46:27
 */
public class DBUSPowerConnectionWrapper extends DBUSAbstractConnectionWrapper {

	public DBUSPowerConnectionWrapper(
			AplusConnection connInfo, Object conn) {
		super(connInfo, conn);
	}

	@Override
	public void close() {
		// Nothing to do
	}

}

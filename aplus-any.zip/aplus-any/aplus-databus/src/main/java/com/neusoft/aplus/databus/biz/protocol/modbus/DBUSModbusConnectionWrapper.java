package com.neusoft.aplus.databus.biz.protocol.modbus;

import java.util.Map;

import com.neusoft.aplus.databus.biz.protocol.DBUSAbstractConnectionWrapper;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.serotonin.modbus4j.ModbusMaster;

/**
 * @author Mu Xian Ming
 * @date 2015年6月23日 下午2:46:27
 */
public class DBUSModbusConnectionWrapper extends DBUSAbstractConnectionWrapper {

	public DBUSModbusConnectionWrapper(
			AplusConnection connInfo, Object conn) {
		super(connInfo, conn);
		
	}

	@Override
	public void close() {
		@SuppressWarnings("unchecked")
		Map<String, Object> connectionTable = 
				(Map<String, Object>) getConnection();
		ModbusMaster master = (ModbusMaster) connectionTable.get(
				DBUSModbusConnectionTool.MASTER);
		master.destroy();
	}

}

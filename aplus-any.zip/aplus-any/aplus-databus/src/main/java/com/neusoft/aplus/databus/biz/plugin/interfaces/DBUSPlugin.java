package com.neusoft.aplus.databus.biz.plugin.interfaces;

import java.util.List;
import java.util.Map;

import com.neusoft.aplus.databus.biz.plugin.factory.DBUSPySystemObjectFactory;
import com.neusoft.aplus.databus.biz.plugin.manager.DBUSPluginManager;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.dbentity.table.AplusDeviceEntity;

/**
 * Java代码中调用Python脚本的接口
 * 
 * Python实现的plugin脚本里是该接口所有方法的具体实现
 * 
 * {@link DBUSPySystemObjectFactory}将Python脚本中的对象实例化后，
 * 转换成该接口类型的对象，返回给Java里的调用方
 * 
 * @see DBUSPluginManager
 * 
 * @author Mu Xian Ming
 * @date 2014-12-17
 */
public interface DBUSPlugin {
	
	/** 
	 * 得到该设备类型建立连接所需的参数
	 * 
	 * 返回AplusConnection实例，需要针对不同的协议
	 * 做类型转换
	 * 
	 * @return AplusConnection实例
	 * @author Mu Xian Ming
	 */
	List<AplusConnection> getConnectionDef();
	
	/** 
	 * 可通过脚本进行资源探测及监控收集
	 * @return connection列表
	 */
	List<AplusConnection> connect();
	
	/**
	 * 
	 * @return 该设备类型需要采集的指标List:
	 * [{'name':? , 'code':?, 'unit':?, 'inerval':? ,'timeUnit':? , 
	 * 'active':?, 'type':MetricType, 'defkey':?}]
	 */
	List<Map<String, Object>> getMetricDef();
	
	/**
	 * 得到指标所有的枚举值
	 * 
	 * 当采集的是TYPE_ENUM类型数据时，需要调用该方法返回指标对应的所有枚举值。
	 * 类似如下格式 {0:["H", "i18n_defkey_0"], 1:["M", "i18n_defkey_1"]}
	 * 
	 * @param enumKey 该参数可由getMetricDef返回的监控指标中得到
	 * @return {0:["H", "i18n_defkey_0"], 1:["M", "i18n_defkey_1"]}
	 * @author Mu Xian Ming
	 * @date 2015年1月9日 上午10:34:47
	 */
	Map<Integer, List<String>> getMetricEnum(String enumKey);
	
	/**
	 * @return 用来定义DataBus所支持协议的字符串
	 */
	String getProtocol();
	
	/**
	 * 
	 * @return 协议版本号
	 */
	String getProtocolMode();
	
	/**
	 * 
	 * @return 用来对设备大类别(如动环,中间件等)的java对象
	 */
	String getCategory();
	
	/**
	 * 
	 * @return 字符串,用于描述设备类型
	 */
	String getDeviceType();
	
	/**
	 * 
	 * @return 字符串,用于区分相同设备类型的不同版本
	 */
	String getVersion();
	
	/**
	 *
	 * @return java对象 List<AplusDevice>
	 */
	List<AplusDevice> discover(AplusConnection connection, Object... params);
	
	/**
	 * 通过connection建立连接，采集数据
	 * 
	 * @param connection 连接参数
	 * @param params 和采集指标相关的参数
	 * @return 采集到的数据List
	 */
	List<AplusDeviceMonitorData> monitor(AplusConnection connection, List<?> params);
	
	/**
	 * 
	 * @param connection 连接信息
	 * @param actionName 动作名
	 * @param params 动作参数
	 * @return 执行成功与否 true 或 false 异步情况下返回可check的id
	 */
	boolean control(AplusConnection connection, String actionName, Object... params);
	
	/**
	 *
	 * @return 执行成功与否 true 或 false或分钟级的超时时间
	 */
	int checkControl(AplusConnection connection, int checkId, Object... params);
	
	/**
	 * 
	 * @return 当前资源的父资源信息[{'resourceType':?, 'version':?}]]
	 */
	Map<String, String> getParentTypeInfo();
	
	/**
	 * 
	 * @return [{'name':? ,'notNull':?,'defkey':?}]
	 */
	List<Map<String, Object>> getDeviceDef();
	
	/**
	 * 
	 * @return [resource的单个属性或属性组合]
	 */
	String getDeviceFqn(AplusDeviceEntity device);
	
	/**
	 * 
	 * @return [{'parent':[type,version], 'pField':?, 'curField':?}]
	 */
	List<Map<String, Object>> getParent();
	
	/**
	 * 
	 * @return [{'name':? ,  params'：[java.class],defkey':?}]
	 */
	List<Map<String, Object>> getActionDef();
	
	/**
	 * 
	 * @param defkey 国际化key
	 * @return 所需语言的文本
	 */
	Map<String, String> internationalization(String defkey);
	
	/**
	 * 国际化脚本入库
	 * @author YAOP
	 * @date 2015年5月6日 上午11:05:57
	 * @return 国际化字典
	 */
	Map<String, Map<String, String>> getLocaleDict();
	/**
	 * 
	 * @return 脚本需要的外部Jar包的相对路径列表, ["lib\*.jar",...]
	 */
	List<String> getExtJarPaths();
	
	/**
	 * 
	 * @return 该plugin实例所属脚本文件的绝对路径
	 * @author Mu Xian Ming
	 * @date 2015年1月8日 下午1:23:58
	 */
	String getAbsFilename();
}

package com.neusoft.aplus.databus.biz.protocol.udp.steel;

import com.neusoft.aplus.common.eventbus.EventBusFactory;
import com.neusoft.aplus.databus.biz.event.UDPSteelDataEvent;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.command.in.DBUSUDPBaseInboundCommand;
import io.netty.buffer.ByteBuf;
import io.netty.channel.socket.DatagramPacket;
import io.reactivex.netty.channel.ConnectionHandler;
import io.reactivex.netty.channel.ObservableConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;
import rx.functions.Func1;

import java.net.InetSocketAddress;
import java.util.Arrays;

/**
 * 接受告警主机实时推送的UDP Server的handler
 *
 * @author mxm
 * @date 15-7-15
 */
public class DBUSUDPServerConnectionHandler implements ConnectionHandler<DatagramPacket, DatagramPacket> {
    private static Logger log = LoggerFactory.getLogger(DBUSUDPServerConnectionHandler.class);

    @Override
    public Observable<Void> handle(
            final ObservableConnection<DatagramPacket, DatagramPacket> newConnection) {
        return newConnection.getInput().flatMap(new Func1<DatagramPacket, Observable<Void>>() {
            @Override
            public Observable<Void> call(DatagramPacket received) {
                InetSocketAddress sender = received.sender();
                ByteBuf cmdBuf = received.content();
                byte[] cmdBytes = new byte[cmdBuf.readableBytes()];
                cmdBuf.readBytes(cmdBytes);
                log.debug("Received command datagram. Sender: " + sender + ", command: "
                        + Arrays.toString(cmdBytes));
                DBUSUDPBaseInboundCommand command = DBUSUDPParser.parse(cmdBytes);
                if (command.validate()) {
                    byte[] reply = command.getReply();
                    ByteBuf replyBuf = newConnection.getChannel().alloc().buffer(reply[0]);
                    replyBuf.writeBytes(reply);
                    newConnection.writeAndFlush(new DatagramPacket(replyBuf, sender));
                    if (command.hasUDPData()) {
                        EventBusFactory.getEventBus().post(
                                new UDPSteelDataEvent(command.getUDPData()));
                    }
                } else {
                    log.warn("Validating checksum failed: Sender: {}, command: {}.",
                            sender, cmdBuf);
                }
                return Observable.empty();
            }
        });
    }
}

package com.neusoft.aplus.databus.biz.protocol.udp.steel;

import java.util.Arrays;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;
import com.neusoft.aplus.databus.biz.constants.DBUSMetricConstants;
import com.neusoft.aplus.databus.biz.model.DBUSMetric;
import com.neusoft.aplus.databus.biz.protocol.DBUSActionManager;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.command.in.DBUSUDPBaseInboundCommand;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.command.in.DBUSUDPOnlineCommand;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.command.in.DBUSUDPReplyCommand;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.command.in.DBUSUDPStatusCommand;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.command.in.DBUSUDProblemCommand;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.command.out.DBUSUDPArmingCommand;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.command.out.DBUSUDPBaseOutboundCommand;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.command.out.DBUSUDPSingleLampCommand;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.command.out.DBUSUDPSingleOutputCommand;
import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusControlData;
import com.neusoft.aplus.model.bizentity.AplusDevice;

/**
 * 字节数组和命令类的双向解析
 *
 * @author mxm
 * @date 15-6-30
 */
public final class DBUSUDPParser {
    private static Logger log = LoggerFactory.getLogger(DBUSUDPParser.class);

    private DBUSUDPParser() {
    }

    public static DBUSUDPBaseInboundCommand parse(byte[] bytes) {
        int cmdID = DBUSDatabusUtil.unsigned(bytes[6]);
        log.debug("Parsing Inbound command: {}", Arrays.toString(bytes));
        // 通过命令字匹配命令对象
        switch (cmdID) {
            case 0x01:
                return new DBUSUDPOnlineCommand(bytes);
            case 0x02:
                return new DBUSUDPStatusCommand(bytes);
            case 0x03:
            case 0x04:
                return new DBUSUDProblemCommand(bytes);
            case 0x0F:
                return new DBUSUDPReplyCommand(bytes); 
            default:
                throw new IllegalArgumentException("非法的UDP数据命令");
        }
    }

    public static byte[] encode(AplusConnection connection,
                                AplusDevice device,
                                AplusControlData controlData) {
        String typeID = DBUSDatabusUtil.getDeviceTypeId(device);
        String actionName = controlData.getActionName();
        Map<String, Object> actionMap = getAction(typeID, actionName);
        int code = Integer.decode((String) actionMap.get(DBUSMetricConstants.CODE));
        DBUSUDPBaseOutboundCommand controlCmd;
        switch (code) {
            case 0x05:
                controlCmd = new DBUSUDPArmingCommand(
                        code, connection, device, controlData);
                break;
            case 0x06:
                controlCmd = new DBUSUDPSingleOutputCommand(
                        code, connection, device, controlData);
               break;
            case 0x07:
                controlCmd = new DBUSUDPSingleLampCommand(
                        code, connection, device, controlData);
               break;
            default:
                throw new IllegalArgumentException("非法的UDP控制命令");
        }
        log.debug("{} -> {}",
                code, controlCmd.getClass().getSimpleName());
        return controlCmd.getBytes();
    }

    private static Map<String, Object> getAction(String deviceTypeID, String actionName) {
        Optional<DBUSMetric> optional =
                DBUSActionManager.getInstance().getMetricMap(deviceTypeID);
        if (optional.isPresent()) {
            Map<String, Object> result = optional.get().get(actionName);
            if (result != null) {
                return result;
            } else {
                Object[] params = {deviceTypeID};
                throw new DBUSPluginException(
                        DBUSPluginException.EXCEPTCODE_NO_METRIC, null, params, null);
            }
        } else {
            Object[] params = {deviceTypeID};
            throw new DBUSPluginException(
                    DBUSPluginException.EXCEPTCODE_NO_METRIC, null, params, null);
        }
    }

}

package com.neusoft.aplus.databus.util;

import java.util.HashMap;

/**
 * 带有默认值的MAP包装类
 * @author zh_ch
 * @date 2015年4月28日 下午5:42:34
 */
public class MapWithDefaultValue extends HashMap<String, Object> {
	
	private static final long serialVersionUID = 1L;

	@Override
	public Object get(Object key) {
		Object value = super.get(key);
		return value == null ? "" : value;
	}	
}

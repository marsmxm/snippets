package com.neusoft.aplus.databus.biz.plugin.monitor;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.monitor.FileAlterationListenerAdaptor;
import org.apache.log4j.Logger;
import org.python.core.PyException;

import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;
import com.neusoft.aplus.databus.biz.plugin.manager.DBUSPluginManager;
import com.neusoft.aplus.databus.biz.protocol.DBUSMetricManager;
import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;

/**
 * 监听脚本文件的增删改
 *
 * @author wangcd & mxm
 * @date 2014年8月4日 上午10:57:23
 */
public class DBUSFileListener extends FileAlterationListenerAdaptor {
	private static Logger logger = Logger.getLogger(DBUSFileListener.class);
	private String validExt;
	private DBUSPluginManager pluginManager = DBUSPluginManager.getInstance();
	private DBUSMetricManager metricManager = DBUSMetricManager.getInstance();
	
	public DBUSFileListener(String topic) {
		if (topic.equals(ZMQConst.TOPIC_PLUGIN_SCRIPT)) {
			validExt = "py";
		} else if (topic.equals(ZMQConst.TOPIC_PLUGIN_JAR)) {
			validExt = "jar";
		}
	}
	
	@Override
	public void onFileCreate(File file) {
		String absFileName = file.getAbsolutePath();
		if (FilenameUtils.getExtension(absFileName).equals(validExt)) {
			try {
				DBUSPlugin plugin = pluginManager.add(absFileName).get();
				logger.info("脚本已添加进缓存: " + absFileName + ", "
						+ DBUSDatabusUtil.getDeviceTypeId(plugin));
			} catch (DBUSPluginException e) {
				logger.error("添加脚本" + absFileName + "失败");
			} catch (PyException e) {
				logger.error("添加脚本失败，" + absFileName + "中的代码有错误", e);
			} catch (ClassCastException e) {
				logger.error("添加脚本失败，" + absFileName + "中的代码有错误", e);
			}
		}
	}

	@Override
	public void onFileChange(File file) {
		String absFileName = file.getAbsolutePath();
		if (FilenameUtils.getExtension(absFileName).equals(validExt)) {
			Optional<DBUSPlugin> oldPluginOption = pluginManager.getByFilename(absFileName);
			Preconditions.checkArgument(
					oldPluginOption.isPresent(),"脚本更新出错，缓存中没有该脚本文件对应的Plugin");
			DBUSPlugin oldPlugin = oldPluginOption.get();
			Optional<DBUSPlugin> newPluginOption = pluginManager.update(absFileName);
			if (newPluginOption.isPresent()) { // 如果更新成功
				logger.info("缓存中的脚本已更新: " + absFileName);
				DBUSPlugin newPlugin = newPluginOption.get();
				// 相应的更新指标缓存
				if (metricManager.remove(DBUSDatabusUtil.getDeviceTypeId(oldPlugin))) {
					// metricManager.remove为true代表指标缓存有该设备的指标，
					// 此时才需要更新
					metricManager.add(DBUSDatabusUtil.getDeviceTypeId(newPlugin));
				}
			}
		}
	}

	@Override
	public void onFileDelete(File file) {
		String absFileName = file.getAbsolutePath();
		if (FilenameUtils.getExtension(absFileName).equals(validExt)) {
			Optional<DBUSPlugin> removedPluginOption = pluginManager.remove(absFileName);
			if (removedPluginOption.isPresent()) { // 如果删除成功
				logger.info("脚本已从缓存中删除: " + absFileName);
				DBUSPlugin removedPlugin = removedPluginOption.get();
				// 若指标缓存有该plugin的指标则删除
				metricManager.remove(DBUSDatabusUtil.getDeviceTypeId(removedPlugin));
			}
			// 删除python脚本对应的class文件
			String filename = new File(absFileName).getName();
			String dirname = FilenameUtils.getFullPath(absFileName);
			String newname = filename.replace(".", "$") + ".class";
			FileUtils.deleteQuietly(new File(dirname.concat(newname)));
		}
	}

}

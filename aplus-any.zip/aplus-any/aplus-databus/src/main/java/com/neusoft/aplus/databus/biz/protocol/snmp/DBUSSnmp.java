package com.neusoft.aplus.databus.biz.protocol.snmp;


/**
 * SNMP协议涉及到的常量
 * 
 * @author wuhao
 * @date 2014-12-22 下午2:21:12
 */
public final class DBUSSnmp {

	public static String getProtocol() {
		return "snmp";
	}

	// version constants
	public static final String VERSION1 = "0";
	public static final String VERSION2 = "1";
	public static final String VERSION3 = "3";

	// protocol
	public static String UDP = "udp";

}

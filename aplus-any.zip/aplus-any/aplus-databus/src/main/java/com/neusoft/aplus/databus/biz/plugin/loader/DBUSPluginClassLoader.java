package com.neusoft.aplus.databus.biz.plugin.loader;

import java.net.URL;
import java.net.URLClassLoader;

/**
 * 自定义ClassLoader，应对可能出现的jar包冲突问题
 * 
 * @author WanWei
 * @date 2014-12-27 下午1:44:59
 */
public class DBUSPluginClassLoader extends URLClassLoader {

	public DBUSPluginClassLoader() {
		this(new URL[] {});
	}

	/**
	 * URL 以'/'结尾的为目录 
     *     否则为jar包 
     *     其父类加载器为系统类加载器 
     *     
	 * @param urls
	 */
	public DBUSPluginClassLoader(URL[] urls) {
		super(urls);
	}
	
	/**
	 * 添加路径至ClassLoader的CLASSPATH
	 * 
	 * @param url
	 */
    protected void addURL(URL url) {  
        super.addURL(url);  
    }
    
   
    /**
     * 获取ClassLoader的CLASSPATH
     * 
     * @return
     */
    public URL[] getURLs() {  
        return super.getURLs();  
    }  
    
    /** 
     * 查找类对象 
     *   从以上的URLS中查找加载当前类对象[会打开所有的jars去查找指定的类] 
     *   (可以通过调用findClass来得到以上URL加载包中的类) 
     *   
     * @param name
     * @return
     */  
    public Class<?> findClass(String name) throws ClassNotFoundException {  
        return super.findClass(name);  
    }  

}

package com.neusoft.aplus.databus.biz.event;

import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;

/**
 * @author Mu Xian Ming
 * @date 15-5-28
 */
public class PluginChangeEvent extends AbstractPluginEvent {
    private final DBUSPlugin oldPlugin;
    private final DBUSPlugin newPlugin;

    public PluginChangeEvent(DBUSPlugin oldPlugin, DBUSPlugin newPlugin) {
        this.oldPlugin = oldPlugin;
        this.newPlugin = newPlugin;
    }

    public DBUSPlugin getOldPlugin() {
        return oldPlugin;
    }

    public DBUSPlugin getNewPlugin() {
		return newPlugin;
	}
}

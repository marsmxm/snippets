package com.neusoft.aplus.databus.biz.protocol;

import com.neusoft.aplus.model.bizentity.AplusConnection;

/**
 * @author Mu Xian Ming
 * @date 2015年6月23日 下午2:20:17
 */
public interface DBUSConnectionWrapper {
	AplusConnection getConnectionInfo();
	Object getConnection();
	void close();
}

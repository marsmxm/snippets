package com.neusoft.aplus.databus.biz.protocol;


/**
 * 协议中涉及到的标点常量类
 * @author wuhao
 * @date 2014-12-22 下午5:40:36
 */
public class DBUSProtocolConstants {
      
		//标点
		public static final String COMMA = ","; //逗号
		public static final String COLON=":";//冒号
		public static final String LEFTBIAS ="/";//左斜线
		public static final String LEFTBRACKET ="[";//左括号
		public static final String RIGHTBRACKET ="]";//右括号
		public static final String EMPTY="";//空
		public static final String POINT=".";//点
}

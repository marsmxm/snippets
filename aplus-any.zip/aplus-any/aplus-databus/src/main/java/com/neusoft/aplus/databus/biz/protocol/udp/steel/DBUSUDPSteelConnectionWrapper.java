package com.neusoft.aplus.databus.biz.protocol.udp.steel;

import io.netty.channel.socket.DatagramPacket;
import io.reactivex.netty.client.RxClient;

import com.neusoft.aplus.databus.biz.protocol.DBUSAbstractConnectionWrapper;
import com.neusoft.aplus.model.bizentity.AplusConnection;

/**
 * @author Mu Xian Ming
 * @date 2015年6月23日 下午2:46:27
 */
public class DBUSUDPSteelConnectionWrapper extends DBUSAbstractConnectionWrapper {
	private RxClient<DatagramPacket, DatagramPacket> client;

	public DBUSUDPSteelConnectionWrapper(
			AplusConnection connInfo, RxClient<DatagramPacket, DatagramPacket> client) {
		super(connInfo, client);
		this.client = client;
	}

	public RxClient<DatagramPacket, DatagramPacket> getClient() {
		return client;
	}

	@Override
	public void close() {
		// Nothing to do
	}

}

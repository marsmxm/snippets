package com.neusoft.aplus.databus.biz.event;

import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;

/**
 * @author mxm
 * @date 15-5-28
 */
public class PluginRemoveEvent extends AbstractPluginEvent {
    private final DBUSPlugin plugin;

    public PluginRemoveEvent(DBUSPlugin plugin) {
        this.plugin = plugin;
    }

    public DBUSPlugin getPlugin() {
        return plugin;
    }
}

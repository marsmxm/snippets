package com.neusoft.aplus.databus.biz.protocol.udp.steel.command.in;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neusoft.aplus.databus.biz.constants.DBUSMetricConstants;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.DBUSUDPSteel;
import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.bizentity.AplusMetricData;
import com.neusoft.aplus.model.bizentity.hbgt.DBUSUDPSteelDataWrapper;

import java.util.List;
import java.util.Map;

/**
 * 设备状态命令及应答
 *
 * @author mxm
 * @date 15-7-1
 */
public class DBUSUDPStatusCommand extends DBUSUDPBaseInboundCommand {
    public static final int REPLY_FRAME_LENGTH = 8;
    public static final int ALARM_ZONE_BYTE_INDEX = 7;
    public static final int EQUIP_STATUS_BYTE_INDEX = 8;
    public static final int DISARM_ZONE_BYTE_INDEX = 9;

    private final byte alarmZoneByte; // 防区报警 从0~7位表示1~8号防区 0正常1报警
    private final byte equipStatusByte; // 设备状态 0位布防/撤防，2位正常/被撬，4位ac有/无，6位正常/欠压，其他位保留
    private final byte disarmZoneByte; // 防区撤布防 从0~7位表示1~8号防区 0布防1撤防

    public DBUSUDPStatusCommand(byte[] bytes) {
        super(bytes);
        alarmZoneByte = bytes[ALARM_ZONE_BYTE_INDEX];
        equipStatusByte = bytes[EQUIP_STATUS_BYTE_INDEX];
        disarmZoneByte = bytes[DISARM_ZONE_BYTE_INDEX];
    }

    @Override
    public byte[] getReply() {
        byte[] reply = new byte[REPLY_FRAME_LENGTH];
        reply[0] = REPLY_FRAME_LENGTH;
        partialReply(reply);
        reply[REPLY_FRAME_LENGTH - 1] = DBUSDatabusUtil.makeChecksum(reply);
        return reply;
    }

    @Override
    public boolean hasUDPData() {
        return true;
    }

    @Override
    public List<DBUSUDPSteelDataWrapper> getUDPData() {
        List<DBUSUDPSteelDataWrapper> result = Lists.newArrayList();

        String typeIDDevice = DBUSDatabusUtil.getDeviceTypeId(
                DBUSUDPSteel.TYPE_DEVICE, DBUSUDPSteel.VERSION_DEVICE);
        List<Map<String, Object>> deviceMetrics = getMetrics(typeIDDevice,  DBUSDatabusUtil.unsigned(getCmdID()));

        Map<Integer, String> deviceMetricNames = Maps.newHashMap();
        for (Map<String, Object> metric : deviceMetrics) {
            if (EQUIP_STATUS_BYTE_INDEX == ((Integer) metric.get(DBUSMetricConstants.BYTE_INDEX))) {
                if (0 == ((Integer) metric.get(DBUSMetricConstants.BIT_INDEX))) {
                    deviceMetricNames.put(0,(String) metric.get(DBUSMetricConstants.NAME));
                } else if (2 == ((Integer) metric.get(DBUSMetricConstants.BIT_INDEX))) {
                    deviceMetricNames.put(2,(String) metric.get(DBUSMetricConstants.NAME));
                } else if (4 == ((Integer) metric.get(DBUSMetricConstants.BIT_INDEX))) {
                    deviceMetricNames.put(4,(String) metric.get(DBUSMetricConstants.NAME));
                } else if (6 == ((Integer) metric.get(DBUSMetricConstants.BIT_INDEX))) {
                    deviceMetricNames.put(6,(String) metric.get(DBUSMetricConstants.NAME));
                }
            }
        }
        if (deviceMetricNames.size() < 4) {
            Object[] params = {typeIDDevice};
            DBUSPluginException.throwException(
                    DBUSPluginException.EXCEPTCODE_NO_METRIC, null, params, null);
        }

        String typeIDZone = DBUSDatabusUtil.getDeviceTypeId(
                DBUSUDPSteel.TYPE_ZONE, DBUSUDPSteel.VERSION_ZONE);
        List<Map<String, Object>> zoneMetrics = getMetrics(typeIDZone,  DBUSDatabusUtil.unsigned(getCmdID()));
        String alarmZoneMetricName = null;
        String disarmZoneMetricName = null;
        for (Map<String, Object> metric : zoneMetrics) {
            if (ALARM_ZONE_BYTE_INDEX == (Integer) metric.get(DBUSMetricConstants.BYTE_INDEX)) {
                alarmZoneMetricName = (String) metric.get(DBUSMetricConstants.NAME);
            }
            if (DISARM_ZONE_BYTE_INDEX == (Integer) metric.get(DBUSMetricConstants.BYTE_INDEX)) {
                disarmZoneMetricName = (String) metric.get(DBUSMetricConstants.NAME);
            }
        }
        if (alarmZoneMetricName == null || disarmZoneMetricName == null) {
            Object[] params = {typeIDZone};
            DBUSPluginException.throwException(
                    DBUSPluginException.EXCEPTCODE_NO_METRIC, null, params, null);
        }

        // build zone data
        for (int bit = 0; bit < 8; bit++) {
            AplusDeviceMonitorData zoneData = new AplusDeviceMonitorData();
            zoneData.setDeviceType(DBUSUDPSteel.TYPE_ZONE);
            zoneData.setDeviceVersion(DBUSUDPSteel.VERSION_ZONE);

            Map<String, AplusMetricData> zoneMetricDataMap = Maps.newHashMap();
            AplusMetricData alarmZoneMetricData = new AplusMetricData();
            alarmZoneMetricData.setName(alarmZoneMetricName);
            alarmZoneMetricData.setValue(DBUSDatabusUtil.getBit(alarmZoneByte, bit));
            alarmZoneMetricData.setRecordTime(System.currentTimeMillis());
            zoneMetricDataMap.put(alarmZoneMetricName, alarmZoneMetricData);

            AplusMetricData disarmZoneMetricData = new AplusMetricData();
            disarmZoneMetricData.setName(disarmZoneMetricName);
            disarmZoneMetricData.setValue(DBUSDatabusUtil.getBit(disarmZoneByte, bit));
            disarmZoneMetricData.setRecordTime(System.currentTimeMillis());
            zoneMetricDataMap.put(disarmZoneMetricName, disarmZoneMetricData);

            zoneData.setMetricDatas(zoneMetricDataMap);
            DBUSUDPSteelDataWrapper zoneWrapper = new DBUSUDPSteelDataWrapper(
                    DBUSDatabusUtil.unsigned(getEquipAddr()), bit + 1, zoneData, getGroup());
            result.add(zoneWrapper);
        }

        // build device data
        AplusDeviceMonitorData deviceData = new AplusDeviceMonitorData();
        deviceData.setDeviceType(DBUSUDPSteel.TYPE_DEVICE);
        deviceData.setDeviceVersion(DBUSUDPSteel.VERSION_DEVICE);
        Map<String, AplusMetricData> deviceMetricDataMap = Maps.newHashMap();
        for (int bit = 0; bit < 8; bit += 2) {
            AplusMetricData deviceMetricData = new AplusMetricData();
            deviceMetricData.setName(deviceMetricNames.get(bit));
            deviceMetricData.setValue(DBUSDatabusUtil.getBit(equipStatusByte, bit));
            deviceMetricData.setRecordTime(System.currentTimeMillis());
            deviceMetricDataMap.put(deviceMetricNames.get(bit), deviceMetricData);
        }
        deviceData.setMetricDatas(deviceMetricDataMap);
        DBUSUDPSteelDataWrapper deviceWrapper = new DBUSUDPSteelDataWrapper(
                DBUSDatabusUtil.unsigned(getEquipAddr()), 0, deviceData, getGroup());
        result.add(deviceWrapper);

        return result;
    }
}

/**
 * 
 */
package com.neusoft.aplus.databus.biz.protocol.power;


/**
 * @author yaobo
 *
 */
public class DBUSPower {
	public static String getProtocol() {
		return DBUSPower.POWER;
	}
	
	public static final String POWER = "power";
}

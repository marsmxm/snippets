package com.neusoft.aplus.databus.biz.protocol.snmp;

import com.neusoft.aplus.model.bizentity.AplusConnection;

/**
 * SNMP协议的连接信息实体类
 * @author wuhao
 * @date 2014-12-25 上午11:38:11
 */
public class DBUSSnmpConnection extends AplusConnection {

	private static final long serialVersionUID = 1L;
//	private static String defaultInt =0;
	// udpConnection info
	// ip地址
	public static final  String IPADDRESS = "ipAddress";
	// 端口
	public static final  String PORT ="port";
	// 区域
	public static final  String COMMUNITY ="community";
	// 重试次数
	public static final  String RETRY ="retry";
	// 超时时长
	public static final  String TIMEOUT="timeOut";
	// 版本
	public static final  String VERSION="version";
	// 查看密码
	public static final  String AUTHPASS ="authPass";
	// 修改密码
	public static final  String PRIVPASS ="privPass";
	// 用户名
	public static final  String USER="user";
	// 安全级别
	public static final  String LEVEL = "level";
	
	public DBUSSnmpConnection() {
	}
	
	public DBUSSnmpConnection(AplusConnection conn){
		 setIpAddress((String) conn.get(IPADDRESS));
		 setPort((String) conn.get(PORT));
		 setCommunity((String) conn.get(COMMUNITY));
		 setRetry((String) conn.get(RETRY));
		 setTimeOut((String) conn.get(TIMEOUT));
		 setVersion((String) conn.get(VERSION));
	}
	
	public String getLevel() {
		return get(LEVEL).toString();
	}

	public void setLevel(String level) {
		put(LEVEL, level);
	}
	
	public String getUser() {
		return get(USER).toString();
	}

	public void setUser(String user) {
		put(USER, user);
	}
	
	public String getAuthPass() {
		return get(AUTHPASS).toString();
	}

	public void setAuthPass(String authPass) {
		put(AUTHPASS, authPass);
	}

	public String getPrivPass() {
		return get(PRIVPASS).toString();
	}

	public void setPrivPass(String privPass) {
		put(PRIVPASS, privPass);
	}

	public String getIpAddress() {
		return get(IPADDRESS).toString();
	}

	public void setIpAddress(String ipAddress) {
		put(IPADDRESS, ipAddress);
	}
	
	public String getPort() {
		return get(PORT).toString();
	}

	public void setPort(String port) {
		put(PORT, port);
	}

	public String getCommunity() {
		return get(COMMUNITY).toString();
	}

	public void setCommunity(String community) {
		put(COMMUNITY, community);
	}

	public String getRetry() {
		return get(RETRY).toString();
	}

	public void setRetry(String retry) {
		put(RETRY, retry);
	}

	public String getTimeOut() {
		return get(TIMEOUT).toString();
	}

	public void setTimeOut(String timeOut) {
		put(TIMEOUT, timeOut);
	}

	public String getVersion() {
		return get(VERSION).toString();
	}

	public void setVersion(String version) {
		put(VERSION, version);
	}
	
}

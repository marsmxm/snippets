package com.neusoft.aplus.databus.biz.model;

import java.util.List;
import java.util.Map;

/**
 * 代表指标或Action的同步增量
 *
 * 当server端更改指标和动作信息时会将同步增量发回到采集端
 * 
 * @author Mu Xian Ming
 * @date 2015年6月12日 下午2:05:55
 */
public class DBUSSyncDelta {
	private String deviceTypeID;
	private Map<Type, List<Map<String, Object>>> body;
	
	public enum Type {
		METRIC, ACTION
	}

	public String getDeviceTypeID() {
		return deviceTypeID;
	}

	public void setDeviceTypeID(String deviceTypeID) {
		this.deviceTypeID = deviceTypeID;
	}

	public Map<Type, List<Map<String, Object>>> getBody() {
		return body;
	}

	public void setBody(Map<Type, List<Map<String, Object>>> body) {
		this.body = body;
	}
}

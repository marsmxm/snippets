package com.neusoft.aplus.databus.biz.plugin.factory;

import java.io.File;

import com.neusoft.aplus.databus.biz.plugin.manager.DBUSPluginManager;
import org.apache.log4j.Logger;
import org.python.core.Py;
import org.python.core.PyException;
import org.python.core.PyObject;
import org.python.core.PySystemState;

/**
 * 将Python对象转换成Java对象的工厂类
 *
 * 因为创建PythonInterpreter会消耗较多资源，对性能有一定的影响。所以该工厂类使用
 * PySystemState得到一个importer再导入Python的module，得到module里的类的实例，
 * 最后转换成Java对象。
 *
 * @see DBUSPluginManager
 * @author Mu Xian Ming
 * @date 2014-12-22
 */
public class DBUSPySystemObjectFactory {
	private static Logger logger = Logger.getLogger(DBUSPySystemObjectFactory.class);
    private final Class<?> interfaceType;
    private final PyObject klass;

    public DBUSPySystemObjectFactory(PySystemState state, Class<?> interfaceType,
    		String moduleName, String className) {
        this.interfaceType = interfaceType;
        String modName = moduleName;
        // 若moduleName中包含绝对路径，先将绝对路径加入jython的sys.path中，
        // 再import需要的jython类
		if (moduleName.contains(File.separator)) {
			int sepIndex = moduleName.lastIndexOf(File.separator);
			String dir = moduleName.substring(0, sepIndex);
			Py.getSystemState().path.append(Py.newString(dir));
			modName = moduleName.substring(sepIndex + 1);
			if (modName.contains(".")) {
				modName = modName.split("\\.")[0];
			}
		}
		// 从sys.modules中移除旧的module
		// 解决脚本文件更新后，PySysState内存中的module不随着更新的问题
		removeModule(modName);
        PyObject importer = state.getBuiltins().__getitem__(Py.newString("__import__"));
        PyObject module = importer.__call__(Py.newString(modName));
        klass = module.__findattr__(className);
        logger.debug("import Python module=" + module + ", class=" + klass);
    }

    /**
     * 
     * @param interfaceType Python脚本中的类实现的接口的类型
     * @param moduleName Python脚本的文件名，如果是相对路径须保证该脚本在classpath下
     * @param className Python脚本中的类名
     */
    public DBUSPySystemObjectFactory(Class<?> interfaceType, 
    		String moduleName, String className) {
        this(new PySystemState(), interfaceType, moduleName, className);
    }

    public Object createObject() {
    	return klass.__call__().__tojava__(interfaceType);
    }

    public Object createObject(Object arg1) {
    	return klass.__call__(Py.java2py(arg1)).__tojava__(interfaceType);
    }

    public Object createObject(Object arg1, Object arg2) {
        return klass.__call__(Py.java2py(arg1), Py.java2py(arg2))
        		.__tojava__(interfaceType);
    }

    public Object createObject(Object arg1, Object arg2, Object arg3) {
    	return klass.__call__(Py.java2py(arg1), Py.java2py(arg2), Py.java2py(arg3))
    			.__tojava__(interfaceType);
    }

    public Object createObject(Object args[], String keywords[]) {
	    PyObject convertedArgs[] = new PyObject[args.length];
	    for (int i = 0; i < args.length; i++) {
	        convertedArgs[i] = Py.java2py(args[i]);
	    }
	    return klass.__call__(convertedArgs, keywords).__tojava__(interfaceType);
    }

    public Object createObject(Object... args) {
    	return createObject(args, Py.NoKeywords);
    }
    
    public PyObject getKlass() {
    	return klass;
    }
    
    private void removeModule(String name) {
        name = name.intern();
        PyObject modules = Py.getSystemState().modules;
        if (modules.__finditem__(name) != null) {
            try {
                modules.__delitem__(name);
            } catch (PyException pye) {
                // another thread may have deleted it
                if (!pye.match(Py.KeyError)) {
                    throw pye;
                }
            }
        }
    }
}
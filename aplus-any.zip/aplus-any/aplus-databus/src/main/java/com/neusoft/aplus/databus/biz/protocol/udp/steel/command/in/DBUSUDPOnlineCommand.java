package com.neusoft.aplus.databus.biz.protocol.udp.steel.command.in;

import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.hbgt.DBUSUDPSteelDataWrapper;

import java.util.List;

/**
 * 在线命令及应答
 *
 * @author mxm
 * @date 15-6-30
 */
public class DBUSUDPOnlineCommand extends DBUSUDPBaseInboundCommand {
    public static final int REPLY_FRAME_LENGTH = 8;


    public DBUSUDPOnlineCommand(byte[] bytes) {
        super(bytes);
    }

    @Override
    public byte[] getReply() {
        byte[] reply = new byte[REPLY_FRAME_LENGTH];
        reply[0] = REPLY_FRAME_LENGTH;
        partialReply(reply);
        reply[7] = DBUSDatabusUtil.makeChecksum(reply);
        return reply;
    }

    @Override
    public boolean hasUDPData() {
        return false;
    }

    @Override
    public List<DBUSUDPSteelDataWrapper> getUDPData() {
        throw new UnsupportedOperationException();
    }
}

package com.neusoft.aplus.databus.util;

import com.neusoft.aplus.common.config.NettyClientConf;
import com.neusoft.aplus.common.util.SpringUtil;
import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;
import com.neusoft.aplus.model.bizentity.AplusDevice;

/**
 * 和Plugin相关的工具类
 * 
 * @author Mu Xian Ming
 * @date 2014年12月25日 下午7:52:54
 */
public class DBUSDatabusUtil {
	private static final String DEVICE_TYPE_SEP = ":";
	private static String pluginDir;
	private static String templateDir;
	
	static {
		NettyClientConf exConf = SpringUtil.getBean(NettyClientConf.class);
		pluginDir = exConf.getPluginDir();
		templateDir = exConf.getPluginTemplateDir();
	}
	
	private DBUSDatabusUtil() {}
	
	public static String getDeviceTypeId(DBUSPlugin plugin) {
		return getDeviceTypeId(plugin.getDeviceType(), plugin.getVersion());
	}
	
	public static String getDeviceTypeId(AplusDevice device) {
		return getDeviceTypeId(device.getDeviceType(), device.getDeviceVersion());
	}
	
	public static String getDeviceTypeId(String deviceType, String version) {
		return deviceType + DEVICE_TYPE_SEP + version;
	}

	public static String getPluginDir() {
		return pluginDir;
	}

	public static void setPluginDir(String pluginDir) {
		DBUSDatabusUtil.pluginDir = pluginDir;
	}

	public static String getTemplateDir() {
		return templateDir;
	}

	public static void setTemplateDir(String templateDir) {
		DBUSDatabusUtil.templateDir = templateDir;
	}

	public static int getBit(byte value, int position) {
		return (value >> position) & 1;
	}

	public static int unsigned(byte b) {
		return b & 0xFF;
	}

	public static byte getByte(int value, int position) {
		return (byte) ((value >> (position * 8)) & 0xFF);
	}

	public static byte makeChecksum(byte[] bytes) {
		return makeChecksum(bytes, bytes.length - 1);
	}

	public static byte makeChecksum(byte[] bytes, int length) {
		int sum = 0;
		for (int i = 0; i < length; i++) {
			sum += bytes[i];
		}
		return (byte) (sum % 256);
	}

}

/**
 * 
 */
package com.neusoft.aplus.databus.biz.protocol.power;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.python.google.common.collect.Lists;
import org.python.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;
import com.neusoft.aplus.databus.biz.constants.DBUSMetricConstants;
import com.neusoft.aplus.databus.biz.model.DBUSMetric;
import com.neusoft.aplus.databus.biz.protocol.DBUSAbstractConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.DBUSConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.DBUSConnectionWrapper;
import com.neusoft.aplus.databus.biz.protocol.DBUSMetricManager;
import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusControlData;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.bizentity.AplusMetricData;

/**
 * @author yaobo
 *
 */
public class DBUSPowerConnectionTool extends DBUSAbstractConnectionTool {

	private static DBUSPowerConnectionTool instance = new DBUSPowerConnectionTool();

	private static final Logger log = LoggerFactory
			.getLogger(DBUSPowerConnectionTool.class);

	Map<String, String> cache = Maps.newHashMap();

	private DBUSPowerConnectionTool() {

	}

	/**
	 * 获取缓存中的返回的命令
	 * 
	 * @param key
	 * @return
	 */
	public String getCache(String key) {
		return cache.get(key);
	}

	/**
	 * 判断缓存数据是否存在
	 * 
	 * @param key
	 * @return
	 */
	public boolean exsitCache(String key) {
		return cache.containsKey(key);
	}

	/**
	 * 数据加入缓存中
	 * 
	 * @param key
	 * @param value
	 */
	public void putCache(String key, String value) {
		cache.put(key, value);
	}

	public static DBUSPowerConnectionTool getInstance() {

		return instance;
	}

	@Override
	public List<AplusDeviceMonitorData> collectSomeMetricsOfDevice(
			DBUSConnectionWrapper wrapper,
			AplusDevice device, List<String> metrics) {

		DBUSPowerConnection con = DBUSPowerConnection.of(wrapper.getConnectionInfo());

		String deviceId = DBUSDatabusUtil.getDeviceTypeId(
				device.getDeviceType(), device.getDeviceVersion());
		// 根据设备类型和设备版本，获取设备的指标信息
		Optional<DBUSMetric> metricsMapOption = DBUSMetricManager.getInstance()
				.getMetricMap(deviceId);
		if (!metricsMapOption.isPresent()) {
			Object[] params = { deviceId };
			DBUSPluginException.throwException(
					DBUSPluginException.EXCEPTCODE_NO_METRIC, null, params,
					null);
		}
		DBUSMetric metricsMap = metricsMapOption.get();
		if (metrics == null || metrics.size() == 0) {
			metrics = new ArrayList<String>(metricsMap.keySet());
		}
		List<AplusDeviceMonitorData> monitoerDataList = Lists.newArrayList();
		AplusDevice aplusDevice = new AplusDevice();
		aplusDevice.setFqn(aplusDevice.getFqn());
		aplusDevice.setName(device.getName());
		aplusDevice.setDeviceVersion(device.getDeviceVersion());

		String command;
		Integer start;
		Integer end;
		String bit_index;
		String resultValue;
		Object metricsValue;
		AplusDeviceMonitorData aplusDeviceMonitorData = null;

		for (String name : metrics) {
			command = (String) metricsMap.get(name).get(
					DBUSMetricConstants.CODE);
			start = Integer.valueOf(metricsMap.get(name)
					.get(DBUSMetricConstants.START).toString());
			end = Integer.valueOf(metricsMap.get(name)
					.get(DBUSMetricConstants.END).toString());
			if (metricsMap.get(name).get(DBUSMetricConstants.BIT_INDEX) != null) {
				bit_index = metricsMap.get(name)
						.get(DBUSMetricConstants.BIT_INDEX).toString();
			} else {
				bit_index = "";
			}
			resultValue = fireCommand(command, con);
			aplusDeviceMonitorData = new AplusDeviceMonitorData();
			aplusDeviceMonitorData.setAplusDevice(aplusDevice);
			metricsValue = getMetricValue(resultValue, start, end, bit_index);
			AplusMetricData aplusMetricData = new AplusMetricData();
			aplusMetricData.setName(name);
			aplusMetricData.setValue(metricsValue);
			aplusMetricData.setRecordTime(System.currentTimeMillis());
			aplusDeviceMonitorData.getMetricDatas().put(name, aplusMetricData);
			monitoerDataList.add(aplusDeviceMonitorData);
		}

		return monitoerDataList;
	}

	private int getBit(int value, int position) {
		return (value >> position) & 1;
	}

	private Object getMetricValue(String resultValue, Integer start,
			Integer end, String bit_index) {
		if (!"".equals(resultValue)) {
			if ("".equals(bit_index)) {
				return Integer.parseInt(
						resultValue.substring(start / 2, end / 2), 16);
			} else {
				if (bit_index.startsWith("[") && bit_index.endsWith("]")) {
					return "";
				} else {
					Integer value = Integer.parseInt(
							resultValue.substring(start / 2, end / 2), 16);
					return getBit(value, Integer.valueOf(bit_index));
				}
			}

		}
		return "";
	}

	private String fireCommand(String command, DBUSPowerConnection con) {
		String ip = con.getHost();
		String port = con.getPort();

		if (!exsitCache(command)) {
			Socket s = null;
			InputStream is = null;
			OutputStream os = null;
			try {
				s = new Socket(ip, Integer.parseInt(port));
				String send = command;
				byte[] data = new byte[send.length() / 2];
				for (int i = 0; i < send.length(); i += 2) {
					String ss = send.substring(i, i + 2);
					data[i / 2] = (byte) Integer.parseInt(ss, 16);
				}
				os = s.getOutputStream();
				log.info("发送的命令为：{}", Arrays.toString(data));
				os.write(data);
				os.flush();
				String sendLength = send.substring(send.length() - 4,
						send.length());
				is = s.getInputStream();
				byte[] b = new byte[Integer.parseInt(sendLength, 16) * 2 + 9];
				is.read(b);
				log.info("返回的命令为：{}", bytesToHexString(b).toUpperCase());

				putCache(command, convertHexToString(bytesToHexString(b)
						.toUpperCase()));

				log.info("加入缓存：{}", getCache(command));
				return convertHexToString(bytesToHexString(b).toUpperCase());

			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					is.close();
					s.close();
					os.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} else {
			return getCache(command);
		}
		return "";
	}

	// 16进制转ASCII代表字符
	public static String convertHexToString(String hex) {
		StringBuilder sb = new StringBuilder();
		StringBuilder temp = new StringBuilder();
		for (int i = 0; i < hex.length() - 1; i += 2) {
			String output = hex.substring(i, (i + 2));
			int decimal = Integer.parseInt(output, 16);
			sb.append((char) decimal);
			temp.append(decimal);
		}
		log.info("16进制转ASCII码：{}", sb.toString());
		return sb.toString();
	}

	public static String bytesToHexString(byte[] src) {
		if (src == null || src.length <= 0) {
			return null;
		}
		StringBuilder stringBuilder = new StringBuilder("");
		for (int i = 0; i < src.length; i++) {
			int v = src[i] & 0xFF;
			String hv = Integer.toHexString(v);
			if (hv.length() < 2) {
				stringBuilder.append(0);
			}
			stringBuilder.append(hv);
		}

		return stringBuilder.toString();
	}

	@Override
	public DBUSConnectionWrapper createConnection(AplusConnection connection) {
		DBUSPowerConnection con = DBUSPowerConnection.of(connection);

		return new DBUSPowerConnectionWrapper(con, null);
	}

	@Override
	public boolean control(AplusConnection connection,
			DBUSConnectionTool connectiontool, AplusDevice device,
			String actionName, Object... value) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<AplusDeviceMonitorData> collectDeviceByMetricEntity(
			AplusConnection connection, AplusDevice device,
			DBUSMetric metricsMap) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean controlByActionEntity(AplusConnection connection,
			AplusDevice device,
			AplusControlData controlData) {
		// TODO Auto-generated method stub
		return false;
	}

}

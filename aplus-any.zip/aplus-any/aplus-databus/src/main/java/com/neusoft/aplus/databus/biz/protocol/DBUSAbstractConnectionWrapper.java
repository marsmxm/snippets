package com.neusoft.aplus.databus.biz.protocol;

import com.neusoft.aplus.model.bizentity.AplusConnection;

/**
 * @author Mu Xian Ming
 * @date 2015年6月23日 下午2:46:27
 */
public abstract class DBUSAbstractConnectionWrapper implements DBUSConnectionWrapper {
	private final AplusConnection connInfo;
	private final Object conn;
	
	public DBUSAbstractConnectionWrapper(AplusConnection connInfo,
			Object conn) {
		this.connInfo = connInfo;
		this.conn = conn;
	}
	
	@Override
	public AplusConnection getConnectionInfo() {
		return connInfo;
	}

	@Override
	public Object getConnection() {
		return conn;
	}

	@Override
	public void close() {
		throw new UnsupportedOperationException("Should be implement in concret classes");
	}

}

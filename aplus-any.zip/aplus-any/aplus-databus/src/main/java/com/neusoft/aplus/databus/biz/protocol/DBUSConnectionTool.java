package com.neusoft.aplus.databus.biz.protocol;

import java.util.List;

import com.neusoft.aplus.databus.biz.model.DBUSMetric;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusControlData;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;

/**
 * 协议连接接口类
 *
 * @author wuhao
 * @date 2015-1-6 上午9:56:42
 */
public interface DBUSConnectionTool {

    /***
     * 采集指定资源所有指标的监控数据
     *
     * @param connection 连接信息
     * @param device 采集设备
     */
    List<AplusDeviceMonitorData> collectAllMetricsOfDevice(
            AplusConnection connection, AplusDevice device);

    /***
     * 采集指定资源某些指标的监控数据
     *
     * @param connection 连接信息
     * @param device 采集设备
     * @param metrics 指标名列表
     */
    List<AplusDeviceMonitorData> collectSomeMetricsOfDevice(
            AplusConnection connection, AplusDevice device, List<String> metrics);

    /***
     * 采集指定资源所有指标的监控数据
     *
     * @param wrapper 连接wrapper
     * @param device 采集设备
     * @return AplusDeviceMonitorData
     */
    List<AplusDeviceMonitorData> collectAllMetricsOfDevice(
            DBUSConnectionWrapper wrapper, AplusDevice device);

    /***
     * 采集指定资源某些指标的监控数据
     */
    List<AplusDeviceMonitorData> collectSomeMetricsOfDevice(
            DBUSConnectionWrapper wrapper, AplusDevice device,
            List<String> metrics);

    /**
     * 根据Connection创建链接
     *
     */
    DBUSConnectionWrapper createConnection(AplusConnection connection);

    /***
     * 在连接池中返回一个连接句柄
     *
     */
    DBUSConnectionWrapper getConnection(AplusConnection connection);

    /***
     * 将连接放回连接池
     *
     */
    void pushConnectionBack(DBUSConnectionWrapper wrapper);

    /***
     * 清空连接池
     *
     */
    void clearConnectionPool(AplusConnection connection);

    /**
     * 采集指定资源某些指标的监控数据
     *
     */
    List<AplusDeviceMonitorData> collectDeviceByMetricEntity(
            AplusConnection connection, AplusDevice device,
            DBUSMetric metricsMap);

    /**
     * 修改指标的值
     *
     * @param value          参数非法时抛出DBUSPluginException异常
     */
    boolean control(AplusConnection connection,
                    DBUSConnectionTool connectiontool, AplusDevice device,
                    String actionName, Object... value);

    /**
     * 修改指定指标的值
     *
     */
    boolean controlByActionEntity(AplusConnection connection,
                                  AplusDevice device, AplusControlData controlData);
}

package com.neusoft.aplus.databus.biz.protocol.udp.steel;

import com.neusoft.aplus.common.config.NettyClientConf;
import com.neusoft.aplus.common.util.SpringUtil;
import com.neusoft.aplus.databus.biz.model.DBUSMetric;
import com.neusoft.aplus.databus.biz.protocol.DBUSAbstractConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.DBUSConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.DBUSConnectionWrapper;
import com.neusoft.aplus.databus.biz.protocol.DBUSTcpUdpFactory;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusControlData;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import io.netty.channel.socket.DatagramPacket;
import io.reactivex.netty.channel.ObservableConnection;
import io.reactivex.netty.client.RxClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;
import rx.functions.Func1;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * 河北钢铁UDP协议采集工具
 * 
 * @author mxm
 * @date 2015-7-6
 */
public final class DBUSUDPSteelConnectionTool extends DBUSAbstractConnectionTool {
	private static final Logger logger = LoggerFactory
			.getLogger(DBUSUDPSteelConnectionTool.class);
	private static DBUSUDPSteelConnectionTool instance = new DBUSUDPSteelConnectionTool();

	private DBUSUDPSteelConnectionTool() {
	}

	public static DBUSUDPSteelConnectionTool getInstance() {
		return instance;
	}

	@Override
	public DBUSConnectionWrapper createConnection(AplusConnection connection) {
		DBUSUDPSteelConnection con = new DBUSUDPSteelConnection(connection);
		RxClient<DatagramPacket, DatagramPacket> client =
				DBUSTcpUdpFactory.createUDPClient(con.getIpAddress(),
						Integer.valueOf(con.getPort()));

		return new DBUSUDPSteelConnectionWrapper(con, client);
	}

	@Override
	public List<AplusDeviceMonitorData> collectSomeMetricsOfDevice(
			DBUSConnectionWrapper wrapper, AplusDevice device,
			List<String> metrics) {
		throw new UnsupportedOperationException();
	}

	@Override
	public List<AplusDeviceMonitorData> collectDeviceByMetricEntity(
			AplusConnection connection, AplusDevice device,
			DBUSMetric metricsMap) {
		throw new UnsupportedOperationException();
	}


	/**
	 * 修改指定资源某些指标的值
	 */
	@Override
	public boolean controlByActionEntity(AplusConnection connection,
			AplusDevice device, AplusControlData controlData) {
		NettyClientConf exConf = SpringUtil.getBean(NettyClientConf.class);
		final int retries = exConf.getUDPSteelRetries();

		RxClient<DatagramPacket, DatagramPacket> client =
				((DBUSUDPSteelConnectionWrapper) getConnection(connection)).getClient();
		final byte[] bytes = DBUSUDPParser.encode(connection, device, controlData);

		DatagramPacket reply = client.connect()
				.flatMap(new Func1<ObservableConnection<DatagramPacket, DatagramPacket>,
						Observable<DatagramPacket>>() {
					@Override
					public Observable<DatagramPacket> call(
							ObservableConnection<DatagramPacket, DatagramPacket> connection) { // 向通信主机发送代表命令的字节数组
						logger.debug("Send command: {}", Arrays.toString(bytes));
						connection.writeBytes(bytes);
						connection.flush();
						return connection.getInput();
					}
				})
				.timeout(1, TimeUnit.SECONDS) // 超时1秒
				.retry(retries) // 重试若干次
				.onErrorReturn(new Func1<Throwable, DatagramPacket>() {
					@Override
					public DatagramPacket call(Throwable throwable) { // 仍然出错则返回null
						logger.error("{}", throwable);
						return null;
					}
				})
				.take(1)
				.toBlocking()
				.first();


		return reply != null;
	}

	@Override
	public boolean control(AplusConnection connection,
			DBUSConnectionTool connectiontool, AplusDevice device,
			String actionName, Object... value) {

		throw new UnsupportedOperationException();
	}

}

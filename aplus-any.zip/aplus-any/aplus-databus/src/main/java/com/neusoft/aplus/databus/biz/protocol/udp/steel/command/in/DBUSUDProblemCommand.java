package com.neusoft.aplus.databus.biz.protocol.udp.steel.command.in;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neusoft.aplus.databus.biz.constants.DBUSMetricConstants;
import com.neusoft.aplus.databus.biz.protocol.udp.steel.DBUSUDPSteel;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.bizentity.AplusMetricData;
import com.neusoft.aplus.model.bizentity.hbgt.DBUSUDPSteelDataWrapper;

/**
 * 设备故障命令
 * 
 * @author wuhao
 * @date 2015-7-6 下午1:58:07
 */
public class DBUSUDProblemCommand extends DBUSUDPBaseInboundCommand {
	public static final int REPLY_FRAME_LENGTH = 8;
	public static final int EQUIP_PROBLEM_BYTE_INDEX = 7;
	private final byte equipProblemByte; // 设备故障类型 00：设备掉线 01：终端设备收不到应答（主动上报设备）
											// 02:故障解除

	public DBUSUDProblemCommand(byte[] bytes) {
		super(bytes);
		if (bytes.length == 9) {
			equipProblemByte = bytes[EQUIP_PROBLEM_BYTE_INDEX];
		} else {
			equipProblemByte = 2;
		}

	}

	@Override
	public byte[] getReply() {
		byte[] reply = new byte[REPLY_FRAME_LENGTH];
		reply[0] = REPLY_FRAME_LENGTH;
		partialReply(reply);
		reply[7] = DBUSDatabusUtil.makeChecksum(reply);
		return reply;
	}

	@Override
	public boolean hasUDPData() {
		return true;
	}

	@Override
	public List<DBUSUDPSteelDataWrapper> getUDPData() {
		List<DBUSUDPSteelDataWrapper> result = Lists.newArrayList();

		// 获取devicetype deviceversion
		String typeIDDevice = DBUSDatabusUtil.getDeviceTypeId(
				DBUSUDPSteel.TYPE_DEVICE, DBUSUDPSteel.VERSION_DEVICE);
		// 根据type+versin，获取脚本中的指标信息
		List<Map<String, Object>> deviceMetrics = getMetrics(typeIDDevice, 0x03);

		AplusMetricData deviceMetricData = new AplusMetricData();
		Map<String, AplusMetricData> deviceMetricDataMap = Maps.newHashMap();

		for (Map<String, Object> metric : deviceMetrics) {
			if (EQUIP_PROBLEM_BYTE_INDEX == ((Integer) metric
					.get(DBUSMetricConstants.BYTE_INDEX))) {

				deviceMetricData.setName((String) metric
						.get(DBUSMetricConstants.NAME));
				deviceMetricData.setRecordTime(System.currentTimeMillis());
				deviceMetricData.setValue(equipProblemByte);
				deviceMetricDataMap.put(deviceMetricData.getName(),
						deviceMetricData);
			}
		}

		AplusDeviceMonitorData deviceData = new AplusDeviceMonitorData();
		deviceData.setDeviceType(DBUSUDPSteel.TYPE_DEVICE);
		deviceData.setDeviceVersion(DBUSUDPSteel.VERSION_DEVICE);

		deviceData.setMetricDatas(deviceMetricDataMap);
		DBUSUDPSteelDataWrapper deviceWrapper = new DBUSUDPSteelDataWrapper(
				DBUSDatabusUtil.unsigned(getEquipAddr()), 0, deviceData, getGroup());
		result.add(deviceWrapper);

		return result;
	}

}

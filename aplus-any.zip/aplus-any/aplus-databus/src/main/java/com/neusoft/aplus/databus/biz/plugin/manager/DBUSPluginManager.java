package com.neusoft.aplus.databus.biz.plugin.manager;

import java.util.List;

import com.neusoft.aplus.databus.biz.protocol.DBUSMetricManager;
import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

import org.python.core.PyException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;
import com.google.common.eventbus.EventBus;
import com.neusoft.aplus.common.eventbus.EventBusFactory;
import com.neusoft.aplus.databus.biz.cache.DBUSLocalCache;
import com.neusoft.aplus.databus.biz.constants.DBUSPluginConstants;
import com.neusoft.aplus.databus.biz.event.PluginAddEvent;
import com.neusoft.aplus.databus.biz.event.PluginChangeEvent;
import com.neusoft.aplus.databus.biz.event.PluginRemoveEvent;
import com.neusoft.aplus.databus.biz.plugin.factory.DBUSPySystemObjectFactory;
import com.neusoft.aplus.databus.biz.plugin.interfaces.DBUSPlugin;
import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;

/**
 * 负责Plugin脚本的存取，修改和校验
 *
 * 采集端所有对脚本类的操作都通过该类实现，
 * 和指标相关的操作请参见{@link DBUSMetricManager}
 *
 * 当针对Plugin的（增删改）操作成功后会触发相应的EventBus事件，
 * 事件的处理类请参见com.neusoft.aplus.probe.inquirer.biz.Agent
 *
 * @see DBUSMetricManager
 * @author Mu Xian Ming
 * @date 2015年1月6日 上午9:24:20
 */
public class DBUSPluginManager {
	private static final boolean POST_EVENT = true;
	private static final boolean NO_EVENT = false;
	
	private static Logger logger = 
			LoggerFactory.getLogger(DBUSPluginManager.class);
	private Cache pluginCache = DBUSLocalCache.getPluginCache();
	private DBUSPluginValidator validator = DBUSPluginValidator.getInstance();
	private EventBus eventBus = EventBusFactory.getEventBus();
	private static DBUSPluginManager instance = new DBUSPluginManager();
	
	private DBUSPluginManager() {
	}
	
	public static DBUSPluginManager getInstance() {
		return instance;
	}

	/**
	 * 通过脚本绝对路径得到Optional<DBUSPlugin>实例，校验后存入Cache，
	 * 并返回这个plugin实例
	 *
	 * @param scriptFileName plugin脚本文件的绝对路径
	 * @return 新增的Optional<DBUSPlugin>实例，通过get方法得到实际的Plugin实例，不存在时返回Optional.absent()
	 * @throws DBUSPluginException 如果校验不通过抛出异常
	 */
	public synchronized Optional<DBUSPlugin> add(String scriptFileName)
			throws DBUSPluginException {
		return add(scriptFileName, POST_EVENT);
	}

	private synchronized Optional<DBUSPlugin> add(String scriptFileName, boolean postEvent)
			throws DBUSPluginException {
		logger.debug("Adding " + scriptFileName + " ...");
		DBUSPlugin plugin = createPlugin(scriptFileName);
		return add(scriptFileName, plugin, postEvent);
	}
	
	private synchronized Optional<DBUSPlugin> add(String scriptFileName, 
			DBUSPlugin plugin, boolean postEvent)
			throws DBUSPluginException {
		assert plugin != null;
		validator.verify(plugin, scriptFileName);
		String pluginId = DBUSDatabusUtil.getDeviceTypeId(plugin);
		logger.debug("Adding DeviceType ID: " + pluginId);
		if (idExists(DBUSDatabusUtil.getDeviceTypeId(plugin))) {
			DBUSPlugin existPlugin = getById(DBUSDatabusUtil.getDeviceTypeId(plugin)).get();
			Object[] params = {plugin.getAbsFilename(), existPlugin.getAbsFilename()};
			DBUSPluginException e = new DBUSPluginException(
					DBUSPluginException.PLUGIN_EXCEPTCODE_DUPLICATE,
					null, params, null);
			logger.error(e.getErrorMsg());
			e.throwEx();
		}
		Element element = new Element(pluginId, plugin);
		pluginCache.put(element);
		
		if (postEvent) {
			PluginAddEvent event = new PluginAddEvent(plugin);
			eventBus.post(event);
			logger.debug("Adding-event posted: {}", event);
		}
		
		return Optional.of(plugin);
	}
	
	private DBUSPlugin createPlugin(String scriptFileName)
			throws DBUSPluginException {
		DBUSPySystemObjectFactory factory = new DBUSPySystemObjectFactory(
				DBUSPlugin.class, scriptFileName, DBUSPluginConstants.PLUGIN_CLASS_NAME);
		// 如果plugin脚本里缺少所需的类{@link DBUSPluginConstants.PLUGIN_CLASS_NAME}
		// 则抛出Exception
		if (factory.getKlass() == null) {
			Object[] params = {scriptFileName, DBUSPluginConstants.PLUGIN_CLASS_NAME};
			DBUSPluginException e = new DBUSPluginException(
					DBUSPluginException.PLUGIN_EXCEPTCODE_NOCLASS,
					null, params, null);
			logger.error(e.getErrorMsg());
			e.throwEx();
		}
		
		return (DBUSPlugin) factory.createObject();
	}
	
	/**
	 * 通过DeviceTypeID得到一个Optional<DBUSPlugin>实例
	 * 
	 * @param pluginId 通过DBUSPluginUtil.getDeviceTypeId得到的ID
	 * @return Optional<DBUSPlugin>实例，通过get方法得到实际的Plugin实例，不存在时返回Optional.absent()
	 */
	public Optional<DBUSPlugin> getById(String pluginId) {
		if (!idExists(pluginId)) {
			return Optional.absent();
		}
		DBUSPlugin plugin = 
				(DBUSPlugin) pluginCache.get(pluginId).getObjectValue();
		return Optional.of(plugin);
	}
	
	/**
	 * 通过脚本文件名得到一个Optional<DBUSPlugin>实例
	 * 
	 * 遍历plugin缓存，找到脚本文件名和参数文件名相等的plugin
	 * 
	 * @param scriptFileName 脚本文件的绝对路径
	 * @return Optional<DBUSPlugin>实例，通过get方法得到实际的Plugin实例，不存在时返回Optional.absent()
	 */
	public Optional<DBUSPlugin> getByFilename(String scriptFileName) {
		DBUSPlugin plugin = null;
		List<?> keys = pluginCache.getKeys();
		for (Object k : keys) {
			plugin = (DBUSPlugin) pluginCache.get(k).getObjectValue();
			String name = plugin.getAbsFilename();
			if (name.equals(scriptFileName)) {
				break;
			} else {
				plugin = null;
			}
		}
		return Optional.fromNullable(plugin);
	}
	
	/**
	 * 将plugin脚本文件的修改内容同步到缓存中的plugin实例
	 * 
	 * 须考虑同时更新该脚本在指标缓存中的指标
	 * 
	 * @param scriptFileName plugin脚本文件的绝对路径
	 * @return 修改后的Optional<DBUSPlugin>实例，通过get方法得到实际的Plugin实例，不存在时返回Optional.absent()
	 */
	public synchronized Optional<DBUSPlugin> update(String scriptFileName) {
		logger.debug("Updating " + scriptFileName + " ...");
		Optional<DBUSPlugin> oldPluginOption = remove(scriptFileName, NO_EVENT);
		Optional<DBUSPlugin> newPluginOption = Optional.absent(); 
		try {
			newPluginOption = add(scriptFileName, NO_EVENT);
		} catch (DBUSPluginException e) {
			logger.error("更新脚本" + scriptFileName + "失败");
		} catch (PyException e) {
			logger.error("更新脚本失败，" + scriptFileName + "中的代码有错误", e);
		} catch (ClassCastException e) {
			logger.error("更新脚本失败，" + scriptFileName + "中的代码有错误", e);
		} finally {
			if (!fileExists(scriptFileName) && oldPluginOption.isPresent()) {
				add(scriptFileName, oldPluginOption.get(), NO_EVENT);
			}
		}
		
		if (newPluginOption.isPresent()) {
			PluginChangeEvent event = new PluginChangeEvent(
					oldPluginOption.get(), newPluginOption.get());
			eventBus.post(event);
			logger.debug("Changing-event posted: {}", event);
		}
		return newPluginOption;
	}
	
	public Optional<DBUSPlugin> remove(String scriptFileName) {
		return remove(scriptFileName, POST_EVENT);
	}
	
	/**
	 * 将脚本文件对应的plugin实例从缓存中移除
	 * 
	 * 须考虑同时删除该脚本在指标缓存中的指标
	 * 
	 * @param scriptFileName 脚本文件的绝对路径
	 * @return 从缓存中删除的Optional<DBUSPlugin>实例，通过get方法得到实际的Plugin实例，不存在时返回Optional.absent()
	 */
	private synchronized Optional<DBUSPlugin> remove(String scriptFileName, boolean postEvent) {
		logger.debug("Removing " + scriptFileName + " ...");
		Optional<DBUSPlugin> removedPluginOption = getByFilename(scriptFileName);
		if (removedPluginOption.isPresent()) {
			String pluginId = 
					DBUSDatabusUtil.getDeviceTypeId(removedPluginOption.get());
			pluginCache.remove(pluginId);
			
			if (postEvent) {
				PluginRemoveEvent event = new PluginRemoveEvent(removedPluginOption.get());
				eventBus.post(event);
				logger.debug("Removing-event posted: {}", event);
			}
		}
		return removedPluginOption;
	}

	private boolean idExists(String pluginId) {
		return pluginCache.get(pluginId) != null;
	}
	
	private boolean fileExists(String filename) {
		return getByFilename(filename).isPresent();
	}
	
}

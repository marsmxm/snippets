package com.neusoft.aplus.databus.exception;

import java.util.Map;

import com.neusoft.aplus.common.exception.AplusException;
import com.neusoft.aplus.common.exception.annotation.MessageCN;
import com.neusoft.aplus.common.exception.annotation.MessageUS;

/**
 * @author zh_ch
 * @date 2015年4月29日 上午11:33:05
 */
public class DBUSProtocolException extends AplusException {
	
	private static final long serialVersionUID = 1L;

	//异常码范围 550 ~ 600
	@MessageCN("host, user, pwd, clsid有为空的参数")
	@MessageUS("Some of host, user, pwd, clsid parameters are empty")
	public static String OPC_PARA_ERROR = createExceptionCode(550);
	
	public DBUSProtocolException(String code) {
		this(code, null, null, null);
	}
	
	public DBUSProtocolException(String code, Exception original,
			Object[] params, Map<String, Object> keyPoints) {
		super(code, original, params, keyPoints);
	}

	public static void throwException(String ecode, Exception original,
			Object[] params, Map<String, Object> keyPoints) {
		DBUSPluginException exception = new DBUSPluginException(ecode,
				original, params, keyPoints);
		exception.throwEx();
	}
	
	public static void throwException(String ecode) {
		throwException(ecode, null, null, null);
	}
	
	private static String createExceptionCode(int code) {
		return getFormatedNumber(ID_DATABUS, code);
	}
}

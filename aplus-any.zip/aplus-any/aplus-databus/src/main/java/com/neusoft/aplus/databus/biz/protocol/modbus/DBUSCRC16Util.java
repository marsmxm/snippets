package com.neusoft.aplus.databus.biz.protocol.modbus;

/**
 * Modbus crc校验工具类
 * @author wuhao
 * @date 2015-1-4 上午9:45:24
 */
public class DBUSCRC16Util {

	public static String bytesToHexString(byte[] src){  
	    if (src == null || src.length <= 0) {  
	        return null;  
	    }  
	    StringBuilder stringBuilder = new StringBuilder(""); 
	    for (int i = 0; i < src.length; i++) {  
	        int v = src[i] & 0xFF;  
	        String hv = Integer.toHexString(v);  
	        if (hv.length() < 2) {  
	            stringBuilder.append(0);  
	        }  
	        stringBuilder.append(hv);  
	    }  
	   
	    return  stringBuilder.toString();
	}  
	
	public static int[] hexStrToIntArray(String str){
		int strLen = str.length();
		int len = strLen%2 == 0 ? (strLen/2):(strLen/2+1);
		int[] intArray = new int[len];
		for(int i=0 ; i < len ; i++){
			if(i < len-1){
				intArray[i]=Integer.parseInt(str.substring(i*2, i*2+2), 16);
			} else {
				intArray[i]=Integer.parseInt(str.substring(i*2, strLen), 16);
			}
		}
		return intArray;
	}
	
	public static int[] crc(int[] data) {
		int[] temdata = new int[data.length + 2];
		// unsigned char alen = *aStr – 2; //CRC16只计算前两部分
		int xda, xdapoly;
		int i, j, xdabit;
		xda = 0xFFFF;
		xdapoly = 0xA001; // (X**16 + X**15 + X**2 + 1)
		for (i = 0; i < data.length; i++) {
			xda ^= data[i];
			for (j = 0; j < 8; j++) {
				xdabit = (int) (xda & 0x01);
				xda >>= 1;
				if (xdabit == 1)
					xda ^= xdapoly;
			}
		}
		System.arraycopy(data, 0, temdata, 0, data.length);
		temdata[temdata.length - 2] = (int) (xda & 0xFF);
		temdata[temdata.length - 1] = (int) (xda >> 8);
		return temdata;
	}
	
	
	/***
	 * 16进制转ASCII码  
	 * @param hex
	 * @return
	 * @author wuhao
	 * @date 2015-1-22 上午10:38:21
	 */
    public static String convertHexToString(String hex){

  	  StringBuilder sb = new StringBuilder();
  	  StringBuilder temp = new StringBuilder();
  	  for( int i=0; i<hex.length()-1; i+=2 ){
  	      String output = hex.substring(i, (i + 2));
  	      int decimal = Integer.parseInt(output, 16);
  	      sb.append((char)decimal);
  	      temp.append(decimal);
  	  }
  	  return sb.toString();
  	  }

}

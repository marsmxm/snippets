package com.neusoft.aplus.databus.biz.protocol.snmp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

import org.snmp4j.CommunityTarget;
import org.snmp4j.PDU;
import org.snmp4j.Snmp;
import org.snmp4j.TransportMapping;
import org.snmp4j.UserTarget;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.mp.MPv3;
import org.snmp4j.security.AuthMD5;
import org.snmp4j.security.PrivDES;
import org.snmp4j.security.SecurityModels;
import org.snmp4j.security.SecurityProtocols;
import org.snmp4j.security.USM;
import org.snmp4j.security.UsmUser;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.GenericAddress;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;

import com.google.common.base.Optional;
import com.neusoft.aplus.databus.biz.constants.DBUSMetricConstants;
import com.neusoft.aplus.databus.biz.model.DBUSMetric;
import com.neusoft.aplus.databus.biz.protocol.DBUSActionManager;
import com.neusoft.aplus.databus.biz.protocol.DBUSConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.DBUSConnectionWrapper;
import com.neusoft.aplus.databus.biz.protocol.DBUSMetricManager;
import com.neusoft.aplus.databus.biz.protocol.DBUSAbstractConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.DBUSProtocolConstants;
import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusControlData;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.bizentity.AplusMetricData;
import com.neusoft.aplus.model.bizentity.AplusMetricValueType;

/**
 * snmp协议连接工具类
 * 
 * @author wuhao
 * @date 2014-12-22 下午5:46:11
 */
public class DBUSSnmpConnectionTool extends DBUSAbstractConnectionTool {

	private static DBUSSnmpConnectionTool instance = new DBUSSnmpConnectionTool();
	public static final String SNMP = "SNMP";
	public static final String TARGET = "Target";
	
	private DBUSSnmpConnectionTool() {
	}

	/***
	 * 返回snmp工具类实例
	 * 
	 * @return
	 * @author wuhao
	 * @date 2014-12-30 下午1:42:06
	 */
	public static DBUSSnmpConnectionTool getInstance() {
		return instance;
	}

	/***
	 * 采集指定资源某些指标的监控数据
	 * 
	 * @param wrapper
	 * @param device
	 * @param metrics
	 * @return AplusDeviceMonitorData
	 * @author wuhao
	 * @date 2015-1-6 上午10:19:51
	 */
	@Override
	public List<AplusDeviceMonitorData> collectSomeMetricsOfDevice(
			DBUSConnectionWrapper wrapper,
			AplusDevice device, List<String> metrics) {

		List<AplusDeviceMonitorData> monitoerDataList = null;
		String deviceId = DBUSDatabusUtil.getDeviceTypeId(
				device.getDeviceType(), device.getDeviceVersion());
		// 根据设备类型和设备版本，获取设备的指标信息
		Optional<DBUSMetric> metricMapOption = 
				DBUSMetricManager.getInstance().getMetricMap(deviceId);
		if (!metricMapOption.isPresent()) {
			Object[] params = {deviceId};
			DBUSPluginException.throwException(
					DBUSPluginException.EXCEPTCODE_NO_METRIC, null, params, null);
		}
		// 将指标信息放入pdu
		DBUSMetric metricMap = metricMapOption.get();
		PDU pdu = getPdu(metrics, metricMap);

		ResponseEvent revent = getResponseEvent(wrapper, pdu);

		if (revent != null && revent.getResponse() != null) {
			monitoerDataList = readResponse(revent, metricMap);
		}
		return monitoerDataList;
	}

	/***
	 * 返回ResponseEvent
	 * 
	 * @param wrapper
	 * @param pdu
	 * @return
	 * @author wuhao
	 * @date 2015-1-4 下午4:18:40
	 */
	private ResponseEvent getResponseEvent(DBUSConnectionWrapper wrapper, PDU pdu) {

		// 获取连接次数
		// TODO 改！
//		PropertiesConfig config = ApplicationContextFactory.getBean(
//				"propertiesConfig", PropertiesConfig.class);
//		int retryTime = Integer.parseInt(config.getPropertiesConnectTime());
		int retryTime = 5;
		ResponseEvent revent = null;
		for (int count = 1; count <= retryTime; count++) {

			try {
				@SuppressWarnings("unchecked")
				Map<String, Object> connectionTable = 
						(ConcurrentHashMap<String, Object>) wrapper.getConnection();
				Object target = connectionTable.get(TARGET);
				Snmp snmp = (Snmp) connectionTable.get(SNMP);

				// 如果是v1/v2
				if (target instanceof CommunityTarget) {
					revent = snmp.send(pdu, (CommunityTarget) target);
				} else {
					revent = snmp.send(pdu, (UserTarget) target);
				}
			} catch (IOException e) {
				// 如果是最后一次，则抛出
				if (count == retryTime) {
					// 目标连接失败
					DBUSPluginException exception = new DBUSPluginException(
							DBUSPluginException.DEVICE_CONNECTION_FAILURE, null,
							null, null);
					exception.throwEx();
				}
			} finally {
				// 如果有查询结果，则直接返回
				if (revent != null && revent.getResponse() != null) {
					return revent;
				} else {
					// 清空连接池
					this.clearConnectionPool(wrapper.getConnectionInfo());
					// 重新获取
					wrapper = getConnection(wrapper.getConnectionInfo());
				}
			}
		}
		return null;

	}

	/***
	 * 返回指定指标的pdu，若指定指标为空，则返回所有的pdu
	 * 
	 * @param metrics
	 * @param metricsMap
	 * @return
	 * @author wuhao
	 * @date 2014-12-31 上午10:44:20
	 */
	private PDU getPdu(List<String> metrics, DBUSMetric metricsMap) {

		PDU pdu = new PDU();
		pdu.setType(PDU.GET);

		// 如果没有指标信息，获取全部的指标信息
		if (metrics == null || metrics.size() == 0) {
			List<String> allmetrics = metricsMap.getAllCodeList();
			for (String oid : allmetrics) {
				pdu.add(new VariableBinding(new OID(oid)));
			}
		} else {
			for (String oid : metrics) {
				pdu.add(new VariableBinding(new OID(metricsMap.getCode(oid))));
			}
		}
		return pdu;
	}

	/**
	 * 遍历查询结果，将key/value封装成后返回
	 * 
	 * @param respEvnt
	 * @return
	 * @author wuhao
	 * @param metricsMap
	 * @date 2014-12-25 下午4:08:46
	 */
	@SuppressWarnings("unchecked")
	private List<AplusDeviceMonitorData> readResponse(ResponseEvent respEvnt,
			DBUSMetric metricsMap) {

		AplusDeviceMonitorData monitorData = new AplusDeviceMonitorData();
		// 解析Response

		Vector<VariableBinding> recVBs = (Vector<VariableBinding>) respEvnt
				.getResponse().getVariableBindings();
		for (int i = 0; i < recVBs.size(); i++) {
			VariableBinding recVB = recVBs.elementAt(i);

			AplusMetricData metricData = new AplusMetricData();

			String oid = recVB.getOid().toString();
			Map<String, Object> metricEntity = metricsMap.getMetricMap(oid);
			String metricName = metricEntity.get(DBUSMetricConstants.NAME).toString();
			metricData.setName(metricName);
			Variable value = recVB.getVariable();
			Integer valueType = Integer.valueOf(metricEntity.get(
					DBUSMetricConstants.TYPE).toString());

			if (valueType.equals(AplusMetricValueType.TYPE_LONG)) {
				metricData.setValue(value.toLong());
			} else if (valueType.equals(AplusMetricValueType.TYPE_DOUBLE)) {
				Double result = Double.valueOf(value.toString());
				metricData.setValue(result);
			} else if (valueType.equals(AplusMetricValueType.TYPE_STRING)
					|| valueType.equals(AplusMetricValueType.TYPE_UNKNOWN)) {
				metricData.setValue(value.toString());
			} else {
				// deviceId
				// metricData.setValue(DBUSProtocolConnectionTool.getEnumInfo(
				// deviceId, metricData.getName(), value.toInt()));
				metricData.setValue(value);
			}
			metricData.setRecordTime(System.currentTimeMillis());
			monitorData.getMetricDatas().put(metricName, metricData);
		}
		List<AplusDeviceMonitorData> monitorDatas = new ArrayList<AplusDeviceMonitorData>(
				0);
		monitorDatas.add(monitorData);
		return monitorDatas;
	}

	/**
	 * 根据Connection创建链接
	 * 
	 * @param connection
	 * @return
	 * @author wuhao
	 * @date 2014-12-26 下午5:28:22
	 */
	public DBUSConnectionWrapper createConnection(AplusConnection connection) {
		DBUSSnmpConnection snmpConnection = new DBUSSnmpConnection(connection);
		Map<String, Object> returnTable = new ConcurrentHashMap<String, Object>();
		Snmp snmp = null;
		if (!snmpConnection.getVersion().equals(DBUSSnmp.VERSION3)) {

			CommunityTarget target = null;

			String ipAddress = DBUSSnmp.UDP + DBUSProtocolConstants.COLON
					+ snmpConnection.getIpAddress()
					+ DBUSProtocolConstants.LEFTBIAS + snmpConnection.getPort();
			Address targetAddress = GenericAddress.parse(ipAddress);

			target = new CommunityTarget();
			target.setCommunity(new OctetString(snmpConnection.getCommunity()));
			target.setAddress(targetAddress);
			target.setRetries(Integer.valueOf(snmpConnection.getRetry()));// 通信不成功时的重试次数 N+1次
			target.setTimeout(Integer.valueOf(snmpConnection.getTimeOut()));// 超时时间
//			target.setVersion(getVersion(snmpConnection.getVersion()));// SNMP
			target.setVersion(Integer.valueOf(snmpConnection.getVersion()));
			TransportMapping<?> transport;
			try {
				transport = new DefaultUdpTransportMapping();
				snmp = new Snmp(transport);
				transport.listen();
				returnTable.put(SNMP, snmp);
			} catch (IOException e) {
				DBUSPluginException
						.throwException(DBUSPluginException.DEVICE_CONNECTION_FAILURE);
			}
			returnTable.put(TARGET, target);
		} else {

			// 生成连接snmp v3 设备的用户/密码
			UsmUser user = new UsmUser(
					new OctetString(snmpConnection.getUser()), AuthMD5.ID,
					new OctetString(snmpConnection.getAuthPass()), PrivDES.ID,
					new OctetString(snmpConnection.getPrivPass()));

			UserTarget target = new UserTarget();

			String ipAddress = DBUSSnmp.UDP + DBUSProtocolConstants.COLON
					+ snmpConnection.getIpAddress()
					+ DBUSProtocolConstants.LEFTBIAS + snmpConnection.getPort();
			Address targetAddress = GenericAddress.parse(ipAddress);

			// 生成连接snmp v3 的UserTarget
			target.setAddress(targetAddress);
			target.setSecurityLevel(Integer.valueOf(snmpConnection.getLevel()));
			target.setSecurityName(new OctetString(snmpConnection.getUser()));
			target.setRetries(Integer.valueOf(snmpConnection.getRetry()));// 通信不成功时的重试次数 N+1次
			target.setTimeout(Integer.valueOf(snmpConnection.getTimeOut()));// 超时时间
			target.setVersion(Integer.valueOf(snmpConnection.getVersion()));// SNMP
																		// 版本

			try {
				snmp = new Snmp(new DefaultUdpTransportMapping());
				USM usm = new USM(SecurityProtocols.getInstance(),
						new OctetString(MPv3.createLocalEngineID()), 0);
				SecurityModels.getInstance().addSecurityModel(usm);
				snmp.getUSM().addUser(user.getSecurityName(), user);
				snmp.listen();
				returnTable.put(SNMP, snmp);

			} catch (IOException e) {
				DBUSPluginException
						.throwException(DBUSPluginException.DEVICE_CONNECTION_FAILURE);
			}
			returnTable.put(TARGET, target);
		}
		return new DBUSSnmpConnectionWrapper(connection, returnTable);
	}

	

	/**
	 * 不通过databus缓存调用的写法，直接create Connection。
	 * 
	 * @param connection
	 * @param device
	 * @param metricsMap
	 * @return
	 * @author wuhao
	 * @date 2015-2-1 上午10:00:25
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<AplusDeviceMonitorData> collectDeviceByMetricEntity(
			AplusConnection connection, AplusDevice device,
			DBUSMetric metricsMap) {

//		PropertiesConfig config = ApplicationContextFactory.getBean(
//				"propertiesConfig", PropertiesConfig.class);
		// 获取连接次数
//		int retryTime = Integer.parseInt(config.getPropertiesConnectTime());
		int retryTime  = 5;
		Map<String, Object> connectionTable = (Map<String, Object>) createConnection(connection);
		ResponseEvent revent = null;
		DBUSPluginException exception = null;
		PDU pdu = getPdu(null, metricsMap);

		for (int count = 1; count <= retryTime; count++) {
			try {
				Object target = connectionTable.get(TARGET);
				Snmp snmp = (Snmp) connectionTable.get(SNMP);

				// 如果是v1/v2
				if (target instanceof CommunityTarget) {
					revent = snmp.send(pdu, (CommunityTarget) target);
				} else {
					revent = snmp.send(pdu, (UserTarget) target);
				}
			} catch (IOException e) {
				// 目标连接失败
				exception = new DBUSPluginException(
						DBUSPluginException.DEVICE_CONNECTION_FAILURE, null,
						null, null);
				// 如果是最后一次，则抛出
				if (count == retryTime) {
					exception.throwEx();
				}
			}finally {
				// 如果有查询结果，则直接返回
				if (revent != null && revent.getResponse() != null) {
					return readResponse(revent, metricsMap);
				} else {
					connectionTable = (Map<String, Object>) createConnection(connection);
				}
			}

		}
		return null;
	}

	/**
	 * 修改指标的值(SNMP)
	 * 
	 * @param connection
	 *            链接信息
	 * @param device
	 *            资源信息
	 * @param value
	 *            指标的值
	 * @param actionName
	 *            脚本中对应的actionName
	 * @return
	 * @author zhangjian
	 * @data 2015年4月21日 上午10:50:46
	 * */
	@Override
	public boolean control(AplusConnection connection,
			DBUSConnectionTool connectiontool, AplusDevice device,
			String actionName, Object... value) {

		@SuppressWarnings("unchecked")
		Map<String, Object> connectionTable = (Map<String, Object>) connectiontool
				.createConnection(connection);

		String deviceId = DBUSDatabusUtil.getDeviceTypeId(
				device.getDeviceType(), device.getDeviceVersion());
		// 根据设备类型和设备版本，获取action信息
		Optional<DBUSMetric> actionMapOption = DBUSActionManager.getInstance()
				.getMetricMap(deviceId);
		if (!actionMapOption.isPresent()) {
			Object[] params = { deviceId };
			DBUSPluginException.throwException(
					DBUSPluginException.EXCEPTCODE_NO_ACTION, null, params,
					null);
		}
		DBUSMetric actionMap = actionMapOption.get();
		CommunityTarget target = (CommunityTarget) connectionTable.get(TARGET);
		Snmp snmp = (Snmp) connectionTable.get(SNMP);
		try {
			PDU pdu = setPDU(actionMap, actionName, value);
			snmp.send(pdu, target);
			return true;
		} catch (IOException e) {
			DBUSPluginException
					.throwException(DBUSPluginException.DEVICE_CONNECTION_FAILURE);
		}
		return false;
	}

	/**
	 * 设置PDU
	 * 
	 * @param actionMap
	 *            设备的指标信息
	 * @param actionName
	 *            设备的指标信息
	 * @param value
	 *            要修改的值
	 * */
	private PDU setPDU(DBUSMetric actionMap, String actionName, Object... value)
			throws IOException {
		PDU pdu = new PDU();
		pdu.setType(PDU.SET);
		String oid = actionMap.get(actionName).get("code").toString();
		pdu.add(new VariableBinding(new OID(oid), new OctetString(String
				.valueOf(value[0]))));
		return pdu;
	}

	@Override
	public boolean controlByActionEntity(AplusConnection connection, AplusDevice device,
			AplusControlData controlData) {
		throw new UnsupportedOperationException();
	}

}

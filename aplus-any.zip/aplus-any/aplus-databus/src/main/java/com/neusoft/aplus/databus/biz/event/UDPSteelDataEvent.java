package com.neusoft.aplus.databus.biz.event;

import com.neusoft.aplus.model.bizentity.hbgt.DBUSUDPSteelDataWrapper;

import java.util.List;

/**
 * @author mxm
 * @date 15-5-28
 */
public class UDPSteelDataEvent extends AbstractPluginEvent {
    private final List<DBUSUDPSteelDataWrapper> udpData;

    public UDPSteelDataEvent(List<DBUSUDPSteelDataWrapper> data) {
        udpData = data;
    }

    public List<DBUSUDPSteelDataWrapper> getMonitorDataList() {
        return udpData;
    }
}

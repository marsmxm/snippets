package com.neusoft.aplus.databus.biz.plugin.monitor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.monitor.FileAlterationListenerAdaptor;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupDir;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.neusoft.aplus.common.util.ZMQUtil;
import com.neusoft.aplus.common.zmq.ZMQConst;
import com.neusoft.aplus.common.zmq.model.ZMQMessage;
import com.neusoft.aplus.common.zmq.topic.Publisher;
import com.neusoft.aplus.common.zmq.topic.factory.PubSubFactory;
import com.neusoft.aplus.databus.biz.constants.DBUSPluginConstants;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.AplusMsgAction;

/**
 * @author Mu Xian Ming
 * @date 2015年2月11日 上午10:57:23
 */
public class DBUSExcelListener extends FileAlterationListenerAdaptor {
	private static Logger logger = Logger.getLogger(DBUSExcelListener.class);
	private String fileTopic;
	private String validExt;
	private String zmqTopic = ZMQConst.TOPIC_NOTIFY_INQUIRER;
	private Publisher pub = PubSubFactory.newPublisher(zmqTopic);
	
	public DBUSExcelListener(String topic) {
		this.fileTopic = topic;
		this.validExt = "xls";
	}
	
	@Override
	public void onFileCreate(File file) {
		String filename = file.getAbsolutePath();
		if (FilenameUtils.getExtension(filename).equals(validExt)) {
			logger.debug("Excel(" + fileTopic + ") created: " + filename);
			parseExcelForDeviceType(filename);
			parseExcelForDevice(filename);
			FileUtils.deleteQuietly(new File(filename));
		}
	}

	@Override
	public void onFileChange(File file) {

	}

	@Override
	public void onFileDelete(File file) {

	}
	
	private void parseExcelForDevice(String filename) {
		File excel = new File(filename);
		Workbook wb = null;
		try {
			POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream(excel));
			wb = new HSSFWorkbook(fs);
			String deviceSheet = "Device";
			Sheet sheet = wb.getSheet(deviceSheet);
			if (sheet.getPhysicalNumberOfRows() <= 1) {
				logger.error("Empty sheet: " + wb + "->" + sheet);
				return;
			}
			final int deviceTypeCol = 0;
			final int versionCol = 1;
			final int FQNCol = 2;
			JSONArray jarr = new JSONArray();
			for (Row row : sheet) {
				if (row.getRowNum() > 0) { // 从第二行开始
					String deviceType = "";
					String deviceTypeVersion = "";
					String FQN = "";
					StringBuilder connInfo = new StringBuilder();
					connInfo.append("{");
					for (Cell cell : row) {
						int colIndex = cell.getColumnIndex();
						switch (colIndex) {
							case deviceTypeCol:
								deviceType = getCellStringValue(cell);
								break;
							case versionCol:
								deviceTypeVersion = getCellStringValue(cell);
								break;
							case FQNCol:
								FQN = getCellStringValue(cell);
								break;
							default: // 连接信息
								String colName = cell.getSheet().getRow(0)
									.getCell(colIndex).getStringCellValue();
								connInfo.append(colName + ":\"" + getCellStringValue(cell) + "\",");
						}
					}
					if (connInfo.length() > 1) {
						connInfo.replace(connInfo.length() - 1, connInfo.length(), ""); // 去掉最后一个逗号
					}
					connInfo.append("}");
					JSONObject jobj = new JSONObject();
					jobj.put(DBUSPluginConstants.JSONOBJ_KEY_DEVICE_TYPE, deviceType);
					jobj.put(DBUSPluginConstants.JSONOBJ_KEY_DEVICE_VERSION, deviceTypeVersion);
					jobj.put(DBUSPluginConstants.JSONOBJ_KEY_FQN, FQN);
					jobj.put(DBUSPluginConstants.JSONOBJ_KEY_CONN_INFO, connInfo.toString());
					jarr.add(jobj);
				}
			}
			
			// 发送ZMQ消息
			ZMQMessage msg = new ZMQMessage();
			msg.setTopic(zmqTopic);
			msg.setAction(AplusMsgAction.ADD);
			msg.setBodyString(JSON.toJSONString(jarr));
			msg.setFlag(ZMQConst.DEVICE_DB_STORE);
			ZMQUtil.publish(pub, msg);

		} catch (IOException e) {
			logger.error(e);
		} finally {
			if (wb != null) {
				try {
					wb.close();
				} catch (IOException e) {
					// ignore
				}
			}
		}
			
	}
	
	private void parseExcelForDeviceType(String filename) {
		File excel = new File(filename);
		Workbook wb = null;
		Map<String, Map<String, Object>> deviceTypes = new HashMap<String, Map<String, Object>>();
		try {
			POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream(excel));
			wb = new HSSFWorkbook(fs);
			String deviceTypeSheet = "DeviceType";
			Sheet sheet = wb.getSheet(deviceTypeSheet);
			if (sheet.getPhysicalNumberOfRows() <= 1) {
				logger.error("Empty sheet: " + wb + "->" + sheet);
				return;
			}
			final int deviceTypeCol = 0;
			final int versionCol = 1;
			final int protocolCol = 2;
			final int protoModeCol = 3;
			final int metricStartCol = 4;
			
			String deviceType = "";
			String deviceTypeVersion = "";
			String protocol = "";
			String protocolMode = "";
			List<Map<String, String>> metrics = new ArrayList<Map<String, String>>();
			for (Row row : sheet) {
				if (row.getRowNum() > 0) { // 从第二行开始
					if (StringUtils.isNotBlank(getCellStringValue(row.getCell(deviceTypeCol)))) { // 新设备类型
						if (metrics.size() > 0) {
							// 将上个设备类型添加到map
							Map<String, Object> temp = new HashMap<String, Object>();
							temp.put("deviceType", deviceType);
							temp.put("deviceTypeVersion", deviceTypeVersion);
							temp.put("protocol", protocol);
							temp.put("protocolMode", protocolMode);
							temp.put("metrics", metrics);
							deviceTypes.put(deviceType + "_" + deviceTypeVersion, temp);
						}
						deviceType = getCellStringValue(row.getCell(deviceTypeCol));
						deviceTypeVersion = getCellStringValue(row.getCell(versionCol));
						protocol = getCellStringValue(row.getCell(protocolCol));
						protocolMode = getCellStringValue(row.getCell(protoModeCol));
						metrics = new ArrayList<Map<String, String>>();
					}
					Map<String, String> metric = new HashMap<String, String>();
					for (Cell cell : row) {
						int colIndex = cell.getColumnIndex();
						if (colIndex >= metricStartCol) {
							String colName = cell.getSheet().getRow(0)
									.getCell(colIndex).getStringCellValue();
							metric.put(colName, getCellStringValue(cell));
						}
					}
					metrics.add(metric);
				}
			}
			// 将最后一个设备类型添加到map
			Map<String, Object> temp = new HashMap<String, Object>();
			temp.put("deviceType", deviceType);
			temp.put("deviceTypeVersion", deviceTypeVersion);
			temp.put("protocol", protocol);
			temp.put("protocolMode", protocolMode);
			temp.put("metrics", metrics);
			deviceTypes.put(deviceType + "_" + deviceTypeVersion, temp);
		} catch (IOException e) {
			logger.error(e);
		} finally {
			if (wb != null) {
				try {
					wb.close();
				} catch (IOException e) {
					// ignore
				}
			}
		}
		genScript(deviceTypes);
			
	}
	
	private String getCellStringValue(Cell cell) {
		String result = "";
		switch (cell.getCellType()) {
	        case Cell.CELL_TYPE_STRING:
	            result = cell.getRichStringCellValue().getString();
	            break;
	        case Cell.CELL_TYPE_NUMERIC:
	            if (DateUtil.isCellDateFormatted(cell)) {
	                result = cell.getDateCellValue().toString();
	            } else {
	                result = Integer.toString((int) cell.getNumericCellValue());
	            }
	            break;
	        case Cell.CELL_TYPE_BOOLEAN:
	            result = Boolean.toString(cell.getBooleanCellValue());
	            // Python中的布尔型首字母大写
	            result = StringUtils.capitalize(result);
	            break;
	        case Cell.CELL_TYPE_FORMULA:
	            System.out.println(cell.getCellFormula());
	            break;
		}
		return result;
	}
	
	private void genScript(Map<String, Map<String, Object>> deviceTypes) {
		String templateDir = DBUSDatabusUtil.getTemplateDir();
//		String templateDir = "C:/Users/neusoft/workspace/aplus-any/aplus-databus/src/main/resources/plugins/template";
		STGroup group = new STGroupDir(templateDir);
		for (String key : deviceTypes.keySet()) {
			Map<String, Object> params = deviceTypes.get(key);
			ST st = group.getInstanceOf("snmp");
			st.add("protocolMode", params.get("protocolMode"));
			st.add("deviceType", params.get("deviceType"));
			st.add("deviceTypeVersion", params.get("deviceTypeVersion"));
			st.add("category", params.get("category"));
			st.add("metrics", params.get("metrics"));
			String outputDir = DBUSDatabusUtil.getPluginDir();
			String filename = key + ".py";
			File output = new File(outputDir + filename);
			BufferedWriter writer = null;
			try {
				writer = new BufferedWriter(new FileWriter(output));
				writer.write(st.render());
			} catch (IOException e) {
				logger.error(e);
			} finally {
				if (writer != null) {
					try {
						writer.close();
					} catch (IOException e) {
						logger.error(e);
					}
				}
			}
		}
	}
	
}

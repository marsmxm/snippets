package com.neusoft.aplus.databus.biz.protocol.opc;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;

import org.jinterop.dcom.common.JIException;
import org.jinterop.dcom.core.JIVariant;
import org.openscada.opc.lib.common.ConnectionInformation;
import org.openscada.opc.lib.da.AccessBase;
import org.openscada.opc.lib.da.DataCallback;
import org.openscada.opc.lib.da.Item;
import org.openscada.opc.lib.da.ItemState;
import org.openscada.opc.lib.da.Server;
import org.openscada.opc.lib.da.SyncAccess;
import org.python.google.common.base.Objects;
import org.python.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.TypeReference;
import com.google.common.base.Optional;
import com.google.common.collect.Maps;
import com.neusoft.aplus.common.util.AplusCollectionUtils;
import com.neusoft.aplus.common.util.JSONUtil;
import com.neusoft.aplus.databus.biz.constants.DBUSMetricConstants;
import com.neusoft.aplus.databus.biz.model.DBUSMetric;
import com.neusoft.aplus.databus.biz.protocol.DBUSAbstractConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.DBUSActionManager;
import com.neusoft.aplus.databus.biz.protocol.DBUSConnectionTool;
import com.neusoft.aplus.databus.biz.protocol.DBUSConnectionWrapper;
import com.neusoft.aplus.databus.biz.protocol.DBUSMetricManager;
import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import com.neusoft.aplus.model.bizentity.AplusConnection;
import com.neusoft.aplus.model.bizentity.AplusControlData;
import com.neusoft.aplus.model.bizentity.AplusDevice;
import com.neusoft.aplus.model.bizentity.AplusDeviceMonitorData;
import com.neusoft.aplus.model.bizentity.AplusMetricData;
import com.neusoft.aplus.model.bizentity.AplusMetricValueType;

/**
 * opc协议采集工具
 * 
 * @author zh_ch
 * @date 2015-1-8 下午7:17:11
 */
public final class DBUSOpcConnectionTool extends DBUSAbstractConnectionTool {
	private static final Logger logger = LoggerFactory
			.getLogger(DBUSOpcConnectionTool.class);
	private static DBUSOpcConnectionTool instance = new DBUSOpcConnectionTool();

	private DBUSOpcConnectionTool() {
	}

	public static DBUSOpcConnectionTool getInstance() {
		return instance;
	}

	@Override
	public DBUSConnectionWrapper createConnection(AplusConnection connection) {
		DBUSOpcConnection con = DBUSOpcConnection.of(connection);
		ConnectionInformation conInfo = new ConnectionInformation();

		conInfo.setHost(con.getHost());
		conInfo.setDomain(con.getDomain());
		conInfo.setUser(con.getUser());
		conInfo.setPassword(con.getPassword());
		conInfo.setProgId(con.getProgId());
		conInfo.setClsid(con.getClsId());

		return new DBUSOpcConnectionWrapper(connection, conInfo);
	}

	/**
	 * 标准指标的采集方法，标准指标在采集端缓存，调用接口时只需要传递指标名称列表即可
	 */
	@Override
	public List<AplusDeviceMonitorData> collectSomeMetricsOfDevice(
			DBUSConnectionWrapper wrapper, AplusDevice device,
			List<String> metrics) {
		String deviceId = DBUSDatabusUtil.getDeviceTypeId(
				device.getDeviceType(), device.getDeviceVersion());
		Optional<DBUSMetric> metricsMapOption = DBUSMetricManager.getInstance()
				.getMetricMap(deviceId);
		if (!metricsMapOption.isPresent()) {
			Object[] params = { deviceId };
			DBUSPluginException.throwException(
					DBUSPluginException.EXCEPTCODE_NO_METRIC, null, params,
					null);
		}
		DBUSMetric metricsMap = metricsMapOption.get();

		List<String> codes = null;
		if (AplusCollectionUtils.isBlank(metrics)) {
			codes = metricsMap.getActiveCodeList();
		} else {
			codes = getMetricCodes(metricsMap, metrics);
		}
		Server server = new Server(
				((DBUSOpcConnectionWrapper) wrapper).getConnection(),
				Executors.newSingleThreadScheduledExecutor());
		CountDownLatch countDownLatch = new CountDownLatch(codes.size());
		List<AplusDeviceMonitorData> monitorDatas = null;
		AplusDeviceMonitorData monitorData = null;
		Map<Object, String> dumpToCode = null;
		AccessBase accessBase = null;
		try {
			server.connect();
			accessBase = new SyncAccess(server, 100);
			dumpToCode = Maps.newConcurrentMap();
			monitorDatas = Lists.newArrayList();
			monitorData = new AplusDeviceMonitorData();
			for (String code : codes) {
				DataCallbackDump dataDump = new DataCallbackDump(
						countDownLatch, metricsMap, server, dumpToCode, device,
						monitorData);
				accessBase.addItem(code, dataDump);
				dumpToCode.put(dataDump, code);
			}
			accessBase.bind();
			countDownLatch.await();
			monitorDatas.add(monitorData);

		} catch (Exception e) {
			logger.error("OPC数据采集发生异常，异常信息:{}，指标信息:{}", e, dumpToCode);
		} finally {
			closeConnection(accessBase, server);
		}

		return monitorDatas;
	}

	/**
	 * 处理响应数据的私有类
	 * 
	 * @author zh_ch
	 * 
	 */
	private final class DataCallbackDump implements DataCallback {
		public CountDownLatch countDownLatch;
		public DBUSMetric metricsMap;
		public Server server;
		public Map<Object, String> dumpToCode;
		public AplusDevice aplusDevice;
		public AplusDeviceMonitorData monitorData;

		public DataCallbackDump(CountDownLatch countDownLatch,
				DBUSMetric metricsMap, Server server,
				Map<Object, String> dumpToCode, AplusDevice aplusDevice,
				AplusDeviceMonitorData monitorData) {
			super();
			this.countDownLatch = countDownLatch;
			this.metricsMap = metricsMap;
			this.server = server;
			this.dumpToCode = dumpToCode;
			this.aplusDevice = aplusDevice;
			this.monitorData = monitorData;
		}

		@Override
		public void changed(Item item, ItemState itemState) {
			JIVariant itemValue = itemState.getValue();
			if (countDownLatch.getCount() == 0
					|| Objects.equal(null, itemValue)) {
				return;
			}

			AplusMetricData metricData = new AplusMetricData();
			String code = dumpToCode.get(this);
			Map<String, Object> metricsInfo = metricsMap.getMetricMap(code);
			Object nameObject = metricsInfo.get(DBUSMetricConstants.NAME);
			Object typeObject = metricsInfo.get(DBUSMetricConstants.TYPE);
			String name = String.valueOf(nameObject);
			Integer type = Integer.valueOf(typeObject.toString());

			Object value = null;
			try {
				if (Objects.equal(type, AplusMetricValueType.TYPE_STRING)) {
					value = itemValue.getObject().toString();
				} else if (Objects.equal(type,
						AplusMetricValueType.TYPE_UNKNOWN)) {
					value = itemValue.getObject();
				} else if (Objects.equal(type,
						AplusMetricValueType.TYPE_BOOLEAN)) {
					value = itemValue.getObjectAsBoolean();
				} else if (Objects
						.equal(type, AplusMetricValueType.TYPE_DOUBLE)) {
					value = Double.valueOf(itemValue.getObject().toString());
				} else {
					value = Long.valueOf(itemValue.getObject().toString());
				}
				metricData.setName(name);
				metricData.setValue(value);
				metricData.setRecordTime(System.currentTimeMillis());
			} catch (JIException e) {
				logger.error(String.format("%08X: %s", e.getErrorCode(),
						server.getErrorMessage(e.getErrorCode())));
			}

			monitorData.setAplusDevice(aplusDevice);
			monitorData.getMetricDatas().put(name, metricData);
			countDownLatch.countDown();
		}
	}

	/**
	 * 获取所有code的私有方法
	 * 
	 * @param metricsMap
	 * @return
	 * @author zh_ch
	 * @date 2015-1-16 下午5:35:36
	 */
	private List<String> getMetricCodes(DBUSMetric metricsMap,
			List<String> metrics) {
		List<String> codes = Lists.newArrayList();
		for (String name : metrics) {
			Map<String, Object> map = metricsMap.get(name);
			String active = String.valueOf(map.get(DBUSMetricConstants.ACTIVE));
			if (Objects.equal(Boolean.valueOf(active), Boolean.FALSE)) {
				continue;
			}
			String code = String.valueOf(map.get(DBUSMetricConstants.CODE));
			codes.add(code);
		}
		return codes;
	}

	/**
	 * 
	 * @param connection
	 * @param device
	 * @param metricsMap
	 * @return
	 * @author wuhao
	 * @date 2015-2-1 上午10:00:25
	 */
	@Override
	public List<AplusDeviceMonitorData> collectDeviceByMetricEntity(
			AplusConnection connection, AplusDevice device,
			DBUSMetric metricsMap) {
		DBUSConnectionWrapper conWrapper = createConnection(connection);
		List<AplusDeviceMonitorData> monitorDatas = collectSomeMetricsOfDevice(
				connection, conWrapper, device, metricsMap);
		return monitorDatas;
	}

	private List<AplusDeviceMonitorData> collectSomeMetricsOfDevice(
			AplusConnection connection, DBUSConnectionWrapper conWrapper,
			AplusDevice device, DBUSMetric metricsMap) {
		List<String> codes = metricsMap.getActiveCodeList();
		Server server = new Server(((DBUSOpcConnectionWrapper) conWrapper).getConnection(),
				Executors.newSingleThreadScheduledExecutor());
		CountDownLatch countDownLatch = new CountDownLatch(codes.size());
		List<AplusDeviceMonitorData> monitorDatas = null;
		AplusDeviceMonitorData monitorData = null;
		Map<Object, String> dumpToCode = null;
		AccessBase accessBase = null;
		try {
			server.connect();
			accessBase = new SyncAccess(server, 100);
			dumpToCode = Maps.newConcurrentMap();
			monitorDatas = Lists.newArrayList();
			
			monitorData = new AplusDeviceMonitorData();
			Map<String,String> map = JSONUtil.getComplexObject(device.getAttr(),
					new TypeReference<Map<String, String>>() {
					});
			
			
			for (String code : codes) {
				DataCallbackDump dataDump = new DataCallbackDump(
						countDownLatch, metricsMap, server, dumpToCode, device,
						monitorData);
				accessBase.addItem(code, dataDump);
				dumpToCode.put(dataDump, code);
			}
			accessBase.bind();
			countDownLatch.await();
			monitorData.setAttributes(map);
			monitorDatas.add(monitorData);
		} catch (Exception e) {
			logger.error("OPC数据采集发生异常，异常信息:{}，指标信息:{}", e, dumpToCode);
		} finally {
			closeConnection(accessBase, server);
		}

		return monitorDatas;
	}

	/**
	 * 修改指定资源某些指标的值
	 */
	@Override
	public boolean controlByActionEntity(AplusConnection connection,
			AplusDevice device,
			AplusControlData controlData) {

		ConnectionInformation connInfo =
				((DBUSOpcConnectionWrapper) createConnection(connection)).getConnection();

		CountDownLatch countDownLatch = new CountDownLatch(1);

		Server server = new Server(connInfo,
				Executors.newSingleThreadScheduledExecutor());
		AccessBase accessBase = null;

		// 执行写入操作
		try {
			server.connect();
			accessBase = new SyncAccess(server, 1000);

			Object value = controlData.getActionValues().get(0);
			Integer type = controlData.getAplusMetricEntity().getMetricType();
			String code = controlData.getAplusMetricEntity().getMetricCode();

			DataCallbackDumpForControl dcd = new DataCallbackDumpForControl(
					countDownLatch, value, type);
			accessBase.addItem(code, dcd);
			accessBase.bind();
			countDownLatch.await();
			return true;
		} catch (Exception e) {
			logger.error("OPC控制发生异常，异常信息:{}，指标信息:{}", e);
		} finally {
			closeConnection(accessBase, server);
		}
		return false;
	}

	@Override
	public boolean control(AplusConnection connection,
			DBUSConnectionTool connectiontool, AplusDevice device,
			String actionName, Object... value) {

		ConnectionInformation connInfo = (ConnectionInformation) connectiontool
				.createConnection(connection);

		String deviceId = DBUSDatabusUtil.getDeviceTypeId(
				device.getDeviceType(), device.getDeviceVersion());
		// 根据设备类型和设备版本，获取action信息
		Optional<DBUSMetric> actionMapOption = DBUSActionManager.getInstance()
				.getMetricMap(deviceId);
		if (!actionMapOption.isPresent()) {
			Object[] params = { deviceId };
			DBUSPluginException.throwException(
					DBUSPluginException.EXCEPTCODE_NO_ACTION, null, params,
					null);
		}
		DBUSMetric actionMap = actionMapOption.get();
		// itemId
		String code = actionMap.get(actionName).get("code").toString();

		int type = (Integer) actionMap.get(actionName).get("type");

		CountDownLatch countDownLatch = new CountDownLatch(1);

		Server server = new Server(connInfo,
				Executors.newSingleThreadScheduledExecutor());
		AccessBase accessBase = null;
		// 执行写入操作
		try {
			server.connect();
			accessBase = new SyncAccess(server, 100);
			DataCallbackDumpForControl dcd = new DataCallbackDumpForControl(
					countDownLatch, value[0], type);
			accessBase.addItem(code, dcd);
			accessBase.bind();
			countDownLatch.await();
			return true;
		} catch (Exception e) {
			logger.error("OPC控制发生异常，异常信息:{}，指标信息:{}", e);
		} finally {
			closeConnection(accessBase, server);
		}

		return false;
	}

	private class DataCallbackDumpForControl implements DataCallback {

		public Object value;
		public CountDownLatch countDownLatch;
		public int type;

		public DataCallbackDumpForControl(CountDownLatch countDownLatch,
				Object value, int type) {
			this.value = value;
			this.countDownLatch = countDownLatch;
			this.type = type;
		}

		@Override
		public void changed(Item item, ItemState state) {
			JIVariant write;
			if (type == AplusMetricValueType.TYPE_STRING) {
				write = new JIVariant(String.valueOf(value));
			} else if (type == AplusMetricValueType.TYPE_LONG) {
				// 如果传入参数不是脚本中action所指定的参数类型则抛出异常
				if (!(value instanceof Integer)) {
					DBUSPluginException.throwException(
							DBUSPluginException.EXCEPTCODE_ILLEGAL_VALUE, null,
							null, null);
				}
				write = new JIVariant((Integer) value);
			} else if (type == AplusMetricValueType.TYPE_DOUBLE) {
				// 如果传入参数不是脚本中action所指定的参数类型则抛出异常
				if (!(value instanceof Double)) {
					DBUSPluginException.throwException(
							DBUSPluginException.EXCEPTCODE_ILLEGAL_VALUE, null,
							null, null);
				}
				write = new JIVariant((Double) value);
			} else {
				write = new JIVariant(String.valueOf(value));
			}
			try {
				item.write(write);
			} catch (JIException e) {
				logger.error("OPC写入数据发生异常，异常信息:{}，指标信息:{}", e);
			}
			countDownLatch.countDown();
		}
	}

	/**
	 * OPC采集工具的connection关闭工具类
	 * @param accessBase
	 * @param server
	 * @author zh_ch
	 * @date 2015年8月18日 下午2:00:22
	 */
	private static void closeConnection(AccessBase accessBase, Server server) {
		try {
			if (!Objects.equal(null, accessBase)) {
				accessBase.unbind();
			}

			if (!Objects.equal(null, server)) {
				server.disconnect();
			}
		} catch (Exception e) {
			logger.error("OPC协议关闭连接异常，异常信息：{}", e);
		}
	}
}

package com.neusoft.aplus.databus.biz.protocol.opc;

import org.apache.commons.lang.StringUtils;

import com.neusoft.aplus.databus.exception.DBUSProtocolException;
import com.neusoft.aplus.model.bizentity.AplusConnection;

/**
 * OPC采集工具的connection类
 * @author zh_ch
 * @date 2015-1-6 下午7:43:05
 */
public final class DBUSOpcConnection extends AplusConnection {

	private static final long serialVersionUID = 1L;

	// 主机名
	public static final String HOST = "host";
	// 域名
	public static final String DOMAIN = "domain";
	// 用户名
	public static final String USER = "user";
	// 密码
	public static final String PASSWORD = "pwd";
	// 进程标识
	public static final String PROGID = "progid";
	// 类的唯一标识
	public static final String CLSID = "clsid";

	public static DBUSOpcConnection of(AplusConnection conn) {
		String host = String.valueOf(conn.get(HOST));
		String domain = String.valueOf(conn.get(DOMAIN));
		String user = String.valueOf(conn.get(USER));
		String pwd = String.valueOf(conn.get(PASSWORD));
		String progid = String.valueOf(conn.get(PROGID));
		String clsid = String.valueOf(conn.get(CLSID));

		if (StringUtils.isBlank(host) || StringUtils.isBlank(user)
				|| StringUtils.isBlank(user) || StringUtils.isBlank(pwd)
				|| StringUtils.isBlank(clsid)) {
			DBUSProtocolException
					.throwException(DBUSProtocolException.OPC_PARA_ERROR);
		}

		DBUSOpcConnection newConn = new DBUSOpcConnection();

		newConn.setHost(host);
		newConn.setDomain(domain);
		newConn.setUser(user);
		newConn.setPassword(pwd);
		newConn.setProgId(progid);
		newConn.setClsId(clsid);
		return newConn;
	}

	public String getHost() {
		return String.valueOf(get(HOST));
	}

	public void setHost(String host) {
		put(HOST, host);
	}

	public String getDomain() {
		return String.valueOf(get(DOMAIN));
	}

	public void setDomain(String domain) {
		put(DOMAIN, domain);
	}

	public String getUser() {
		return String.valueOf(get(USER));
	}

	public void setUser(String user) {
		put(USER, user);
	}

	public String getPassword() {
		return String.valueOf(get(PASSWORD));
	}

	public void setPassword(String password) {
		put(PASSWORD, password);
	}

	public String getProgId() {
		return String.valueOf(get(PROGID));
	}

	public void setProgId(String progId) {
		put(PROGID, progId);
	}

	public String getClsId() {
		return String.valueOf(get(CLSID));
	}

	public void setClsId(String clsId) {
		put(CLSID, clsId);
	}
}

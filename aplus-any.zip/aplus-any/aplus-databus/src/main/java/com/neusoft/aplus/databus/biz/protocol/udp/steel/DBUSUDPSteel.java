package com.neusoft.aplus.databus.biz.protocol.udp.steel;

import com.neusoft.aplus.common.config.NettyClientConf;
import com.neusoft.aplus.common.util.SpringUtil;

/**
 * 河北钢铁udp常量类
 *
 * @author wuhao
 * @date 2015-6-29 下午4:47:05
 */
public final class DBUSUDPSteel {

    public static final String TYPE_DEVICE;
    public static final String VERSION_DEVICE;
    public static final String TYPE_ZONE;
    public static final String VERSION_ZONE;

    static {
        NettyClientConf conf = SpringUtil.getBean(NettyClientConf.class);
        TYPE_DEVICE = conf.getTypeUDPSteelDevice();
        VERSION_DEVICE = conf.getVersionUDPSteelDevice();
        TYPE_ZONE = conf.getTypeUDPSteelZone();
        VERSION_ZONE = conf.getVersionUDPSteelZone();
    }

    private DBUSUDPSteel() {}

    public static String getProtocol() {
        return "UDPSteel";
    }

}

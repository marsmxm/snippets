package com.neusoft.aplus.databus;

import com.alibaba.fastjson.JSON;
import com.neusoft.aplus.common.spring.SpringContextLoader;
import com.neusoft.aplus.databus.biz.cache.DBUSLocalCache;
import com.neusoft.aplus.databus.biz.model.DBUSSyncDelta;
import com.neusoft.aplus.databus.biz.plugin.manager.DBUSPluginManager;
import com.neusoft.aplus.databus.biz.plugin.monitor.DBUSFileMonitor;
import com.neusoft.aplus.databus.biz.protocol.DBUSMetricManager;
import com.neusoft.aplus.databus.exception.DBUSPluginException;
import com.neusoft.aplus.databus.util.DBUSDatabusUtil;
import org.apache.commons.io.FileUtils;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;
import org.python.google.common.base.Preconditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * 初始化DataBus
 * 
 * @author Mu Xian Ming
 * @date 2014年12月25日 下午5:17:57
 */
public class DataBusInit {
	private static Logger log = LoggerFactory.getLogger(DataBusInit.class);
	
	public static void loadSpring() {
		SpringContextLoader.load();
	}
	
	public static void init(String[] args) throws IOException {
		ArgsParser parser = new ArgsParser(args);
		if (parser.getPluginDir() != null) {
			DBUSDatabusUtil.setPluginDir(parser.getPluginDir());
		}
		if (parser.getPluginTemplateDir() != null) {
			DBUSDatabusUtil.setTemplateDir(parser.getPluginTemplateDir());
		}
		// suppress ehcache update checker
		System.setProperty("net.sf.ehcache.skipUpdateCheck", "true");
		DBUSLocalCache.getPluginCache().removeAll();
		String pluginDir = DBUSDatabusUtil.getPluginDir();
		// 加载脚本
		File dir = new File(pluginDir);
		File[] fileList = dir.listFiles(new FilenameFilter() {
			private Pattern pattern = Pattern.compile(".+\\.py$");

			public boolean accept(File file, String name) {
				return pattern.matcher(name).matches();
			}
		});
		Preconditions.checkNotNull(fileList, "plugin路径设置错误: " + pluginDir);
		DBUSPluginManager pluginManager = DBUSPluginManager.getInstance();
		try {
			for (File scriptFile : fileList) {
				pluginManager.add(scriptFile.getAbsolutePath());
			}
		} catch (DBUSPluginException e) {
			log.error("初始化DataBus出现异常: {}", e.getErrorMsg());
			e.throwEx();
		}
		// 加载指标/动作增量文件
		File[] deltaList = dir.listFiles(new FilenameFilter() {
			private Pattern pattern = Pattern.compile(".+\\.json$");

			public boolean accept(File file, String name) {
				return pattern.matcher(name).matches();
			}
		});
		DBUSMetricManager metricManager = DBUSMetricManager.getInstance();
		for (File jsonFile : deltaList) {
			String text = FileUtils.readFileToString(jsonFile);
			DBUSSyncDelta delta = JSON.parseObject(text, DBUSSyncDelta.class);
			String deviceTypeID = delta.getDeviceTypeID();
			if (delta.getBody().containsKey(DBUSSyncDelta.Type.METRIC)) {
				List<Map<String, Object>> metricDelta = 
						delta.getBody().get(DBUSSyncDelta.Type.METRIC);
				metricManager.update(deviceTypeID, metricDelta);
			}
			// TODO update action
		}

		// 监听目标目录下的所有文件的更改
		// 若更改的文件是python脚本会发送脚本更改相关的EventBus事件
		DBUSFileMonitor.startMonitor();
	}
	
	private static class ArgsParser {
		@Option(name="-pluginDir",usage="directory for plugin scripts")
		private static String pluginDir;
		
		@Option(name="-pluginTemplateDir",usage="directory for plugin scripts templates")
		private static String pluginTemplateDir;
		
		ArgsParser(String[] args) {
			CmdLineParser parser = new CmdLineParser(this);
			parser.setUsageWidth(80);
			try {
	            parser.parseArgument(args);
	        } catch(CmdLineException e) {
	            System.err.println(e.getMessage());
	            System.err.println("java ClientLaunch [options...]");
	            // print the list of available options
	            parser.printUsage(System.err);
	            System.err.println();
	            System.exit(1);
	        }
		}
		
		public String getPluginDir() {
			return pluginDir;
		}
		
		public String getPluginTemplateDir() {
			return pluginTemplateDir;
		}
	}

}

package com.neusoft.aplus.energywise.mock;

import java.io.Serializable;

import org.restlet.representation.ObjectRepresentation;
import org.restlet.representation.Representation;
import org.restlet.resource.ResourceException;

import com.neusoft.aplus.common.base.BaseAction;


/**
 * 模拟CSS的处理类
 * @author WanWei
 * @date 2014-6-6 下午4:41:20
 */
public class CSSResourceMock extends BaseAction{

	@Override
	public void doInit() {
		super.doInit();
	}

	@Override
	public void acceptRepresentation(Representation entity)
			throws ResourceException {
		System.out.println("do post");
		getResponse().setEntity(entity);
	}

	@Override
	public Representation represent() throws ResourceException {
		System.out.println("do get");
		return new ObjectRepresentation<Serializable>("get"); 
	}

	@Override
	public void removeRepresentations() throws ResourceException {
		System.out.println("do delete");
		getResponse().setEntity(new ObjectRepresentation<Serializable>("delete"));
	}

	@Override
	public void storeRepresentation(Representation entity)
			throws ResourceException {
		System.out.println("do put");
		getResponse().setEntity(entity);
	}

}

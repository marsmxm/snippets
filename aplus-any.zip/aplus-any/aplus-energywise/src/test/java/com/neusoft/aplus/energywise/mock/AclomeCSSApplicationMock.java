package com.neusoft.aplus.energywise.mock;

import org.restlet.Restlet;
import org.restlet.routing.Router;

import com.neusoft.aplus.common.base.BaseApplication;


/**
 * 模拟CSS系统的Rest服务
 * 
 * @author WanWei
 * @date 2014-6-6 下午4:39:30
 */
public class AclomeCSSApplicationMock extends BaseApplication{
	
	@Override
	public Restlet createInboundRoot() {
		Router router = new Router(getContext());
		router.attachDefault(CSSResourceMock.class);
		return router;
	}

}

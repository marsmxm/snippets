package com.neusoft.aplus.energywise.test;
/**
 * @author neusoft
 * @date 2014-6-17 下午12:31:27
 */
public class Sub2Exception extends BaseException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4937406297740509250L;

	public Sub2Exception(int code, Exception original, Object[] params){
		super(code,original,params);
	}

	//建议用法
	public static void throwException(int ecode, Exception original, Object[] params){
		SubException exception = new SubException(ecode,original,params);
		exception.throwEx();
	}
	
	public static void main(String[] args){
		try{
			Sub2Exception.throwException(0,null,null);
		}catch(Throwable e){
			e.printStackTrace();
		}
	}
}

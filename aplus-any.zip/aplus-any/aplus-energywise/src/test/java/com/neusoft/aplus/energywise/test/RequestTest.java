package com.neusoft.aplus.energywise.test;

import java.io.Serializable;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.ObjectRepresentation;

import com.neusoft.aclome.commons.constants.HypervisorConnectionType;
import com.neusoft.aclome.commons.constants.VisableScope;
import com.neusoft.aclome.shared.model.HypervisorConnection;
import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.common.config.RestServiceConfig;
import com.neusoft.aplus.energywise.launch.AplusEnergyWiseLaunch;
import com.neusoft.aplus.energywise.mock.AclomeCSSLaunch;

/**
 * 通过向A+E系统发送请求，测试A+E系统的url转发机制是否能正常工作
 * 
 * @author WanWei
 * @date 2014-6-6 下午4:50:39
 */
public class RequestTest extends TestCase {
	
	private RestClient client;

	@Override
	protected void setUp() throws Exception {
		client = new RestClient(Protocol.HTTPS);
		//A+E服务在8182端口启动
		int port = RestServiceConfig.port;
		int maxConn = Integer.valueOf(RestServiceConfig.maxThreads).intValue();

		AplusEnergyWiseLaunch.startServer(port, maxConn);
		//Aclome CSS在8888端口启动
		AclomeCSSLaunch.startServer(8888, 200);
	}
	
	/**
	 * 测试从A+E系统响应的GET请求
	 * 
	 * @author WanWei
	 * @date 2014-6-6 下午5:16:53
	 */
	@Test
	public void testGetFromAplus(){
		Reference uri = new Reference("http://localhost:8182/some/test/");
		Response res = client.get(uri);
		Assert.assertEquals(200, res.getStatus().getCode());
		Assert.assertTrue(res.getEntity() instanceof ObjectRepresentation);
	}
	
	/**
	 * 测试从Aclome系统中GET数据
	 * 
	 * @author WanWei
	 * @date 2014-6-6 下午5:17:32
	 */
	@Test
	public void testGetFromAclome(){
		try{
			Reference uri = new Reference("http://localhost:8182/api");
			Response res = client.get(uri);
			Assert.assertEquals(200, res.getStatus().getCode());
			Assert.assertTrue(res.getEntity() instanceof ObjectRepresentation);
			Object result = new ObjectRepresentation<Serializable>(res.getEntity()).getObject();
			Assert.assertEquals(String.valueOf(result), "get");
		}catch(Exception e){
			e.printStackTrace();
			Assert.fail();
		}
	}
	
	/**
	 * 测试向Aclome系统POST数据
	 * 
	 * @author WanWei
	 * @date 2014-6-6 下午5:18:00
	 */
	@Test
	public void testPostToAclome(){
		try{
			Reference uri = new Reference("http://localhost:8182/api");
			ObjectRepresentation<Serializable> param = new ObjectRepresentation<Serializable>("POST ONE");
			Response res = client.post(uri, param);
			Assert.assertEquals(200, res.getStatus().getCode());
			Assert.assertTrue(res.getEntity() instanceof ObjectRepresentation);
			Object result = new ObjectRepresentation<Serializable>(res.getEntity()).getObject();
			Assert.assertEquals(String.valueOf(result), "POST ONE");
		}catch(Exception e){
			e.printStackTrace();
			Assert.fail();
		}
	}
	
	/**
	 * 测试添加设备
	 * 
	 * @author guo.tc
	 * @date 2014-6-13 上午11:37:25
	 */
	@Test
	public void testAddDevice(){
		Reference uri = new Reference("http://localhost:8182//api/aclome/virtualcenter/connection/env/VMWARE");
		
		HypervisorConnection hconn = new HypervisorConnection();
		hconn.setUser("username");
		hconn.setType(HypervisorConnectionType.VCENTER);
		hconn.setPass("password");
		hconn.setIp("10.4.55.182");
		hconn.setScope(VisableScope.MC);
		ObjectRepresentation<Serializable> objectRepresentationRequest;
		objectRepresentationRequest = new ObjectRepresentation<Serializable>((Serializable) hconn);
		client.setUser("businessAdmin", null);
		Response res = client.post(uri, objectRepresentationRequest);
		Assert.assertEquals(200, res.getStatus().getCode());
	}
	/**
	 * 测试取得能源消耗
	 * 
	 * @author guo.tc
	 * @date 2014-6-13 上午11:37:41
	 */
	@Test
	public void testGetConsumption(){
		Reference uri = new Reference("http://localhost:8182/energywise/GetConsumption/Last7days/10.4.55.194");
		Response res = client.get(uri);
		JsonRepresentation jsonRep = (JsonRepresentation)res.getEntity();
		JSONObject dataJson = null;
		try {
			dataJson =jsonRep.getJsonObject();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		Assert.assertEquals(200, res.getStatus().getCode());
	}
	/**
	 * 测试取得模式分析报告
	 * 
	 * @author guo.tc
	 * @date 2014-6-13 上午11:37:53
	 */
	@Test
	public void testGetModelAnalysis(){
		Reference uri = new Reference("http://localhost:8182/energywise/GetModelAnalysis/");
		Response res = client.get(uri);
		JsonRepresentation jsonRep = (JsonRepresentation)res.getEntity();
		JSONObject dataJson = null;
		try {
			dataJson =jsonRep.getJsonObject();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		Assert.assertEquals(200, res.getStatus().getCode());
	}
	@Override
	protected void tearDown() throws Exception {
		
	}

}

package com.neusoft.aplus.energywise.test;

import java.io.IOException;
import java.lang.reflect.Field;

/**
 * @author neusoft
 * @date 2014-6-17 上午11:32:24
 */
public class SubException extends BaseException {
	
	public static String CODE_ITSM_EXCEPTION_OPEN = "itsm00001";
	
	public static String CODE_ITSM_EXCEPTION_OPEN_2 = "itsm00002";
	
	public static String CODE_ITSM_EXCEPTION_OPEN_3 = "itsm00003";
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4937406297740509250L;

	public SubException(int code, Exception original, Object[] params){
		super(code,original,params);
		 Field [] fields = this.getClass().getDeclaredFields();
	        for(int i=0; i< fields.length; i++)
	        {
	            Field f = fields[i];
	            System.out.println(f.getName());
	        }
	}

	//建议用法
	public static void throwException(int ecode, Exception original, Object[] params){
		SubException exception = new SubException(ecode,original,params);
		exception.throwEx();
		
		
	}
	
	public static void main(String[] args){
		try{
			SubException.throwException(0,null,null);
		}catch(Throwable e){
			e.printStackTrace();
		}
	
	}

	

}

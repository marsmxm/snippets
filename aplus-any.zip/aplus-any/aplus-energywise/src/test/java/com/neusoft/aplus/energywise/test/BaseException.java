package com.neusoft.aplus.energywise.test;

import java.util.Map;

public abstract class BaseException extends RuntimeException {
	private String tag;
	private String eCode;
	private String stackMsg;
	private Exception original;
	private Object[] params;
	private Map<String, Object> keyPoints;
	
	public BaseException(int code, Exception original, Object[] params){
		
		tag = (this.getClass().getSimpleName().toLowerCase());
		this.eCode = tag.concat("_") + code;
		this.original = original;
		this.params = params;
	}
	
	public final <T extends BaseException> void throwEx(){
//		T exception = (T) this.getClass().getName();
		System.out.println("tag:" + tag);
		System.out.println(this.getClass().getSimpleName());
		//publist this
//		  //publish异常处理模块
		throw this;
	}
	

}

package com.neusoft.aplus.energywise.util;

import com.neusoft.aplus.common.config.ForwardPoint;

/**
 * 共通方法
 * @author guo.tc
 * @date 2014-6-11 下午3:09:53
 */
public class AplusUtil {

	/**
	 * 取得Aclome系统的URL
	 * @return
	 * @author guo.tc
	 * @date 2014-6-11 下午1:48:40
	 */
	public static String getCSSURL(){
		String cssURL = "";
		cssURL = ForwardPoint.getForwardURL().toString();
		return cssURL;
	}
}

package com.neusoft.aplus.energywise.application;

import org.restlet.Restlet;
import org.restlet.routing.Router;

import com.neusoft.aplus.common.base.BaseApplication;
import com.neusoft.aplus.common.base.ForwardAction;
import com.neusoft.aplus.energywise.action.AddDeviceAction;
import com.neusoft.aplus.energywise.action.GetConsumptionAction;
import com.neusoft.aplus.energywise.action.GetModelAnalysisAction;
import com.neusoft.aplus.energywise.action.TestAction;

/**
 * 初始化A+E系统的请求处理路由，完成请求URL同处理action的匹配
 * 
 * @author WanWei
 * @date 2014-6-6 下午3:30:43
 *
 */
public class PlusEnergyWiseApplication extends BaseApplication {

	@Override
	public Restlet createInboundRoot() {
		Router router = new Router(getContext());
		router.attachDefault(ForwardAction.class);
		//create/resourcetype/{resource-type}/env/{virtual-env}/residenton/{fqn}{sss}
		router.attach("/some/test/", TestAction.class);
		router.attach("/api/aclome/virtualcenter/connection/env/VMWARE", AddDeviceAction.class);
	    router.attach("/api/aclome/virtualcenter/connection/env/VMWARE/check/available", ForwardAction.class);
		router.attach("/energywise/GetConsumption/{dtype}/{durl}", GetConsumptionAction.class);
		router.attach("/energywise/GetModelAnalysis/", GetModelAnalysisAction.class);
		return router;
	}



}

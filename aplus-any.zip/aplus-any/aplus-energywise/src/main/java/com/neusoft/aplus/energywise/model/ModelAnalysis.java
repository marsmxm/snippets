package com.neusoft.aplus.energywise.model;
/**
 * 模式分析报告
 * @author guo.tc
 * @date 2014-6-9 下午1:46:32
 */
public class ModelAnalysis {
	ReferenceModel referenceModel;
	ReferenceTime threeyears;
	ReferenceTime yearly;
	ReferenceTime monthly;
	public ReferenceModel getReferenceModel() {
		return referenceModel;
	}
	public void setReferenceModel(ReferenceModel referenceModel) {
		this.referenceModel = referenceModel;
	}
	public ReferenceTime getThreeyears() {
		return threeyears;
	}
	public void setThreeyears(ReferenceTime threeyears) {
		this.threeyears = threeyears;
	}
	public ReferenceTime getYearly() {
		return yearly;
	}
	public void setYearly(ReferenceTime yearly) {
		this.yearly = yearly;
	}
	public ReferenceTime getMonthly() {
		return monthly;
	}
	public void setMonthly(ReferenceTime monthly) {
		this.monthly = monthly;
	}
	
	
}

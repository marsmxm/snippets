package com.neusoft.aplus.energywise.biz.energywisemanage;

import org.restlet.Response;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.energywise.util.AplusUtil;

/**
 * 处理添加设备请求，发送请求到Aclome
 * @author guo.tc
 * @date 2014-6-11 下午1:18:20
 */
public class CSSConnection {

	public static final String  CSS_ADDDEVICE_URI = "/api/aclome/virtualcenter/connection/env/VMWARE";
	public static final String  CSS_SEARCHDEVICE_URI = "/api/aclome/virtualcenter/connections/containSubResCount/env/VMWARE/scope/MC";
	
	RestClient client;
	public CSSConnection(){
		client = new RestClient( Protocol.HTTP);
	}
	
	/**
	 * 发送Post请求到Aclome系统
	 * @param entity
	 * @author guo.tc
	 * @date 2014-6-11 下午1:49:04
	 */
	public Response postToAclome(Representation entity,String url,String userId){
		Reference uri = new Reference(url);
		client.setUser(userId, null);
		Response res = client.post(uri, entity);
		return res;
	}
	/**
	 * 取得添加设备Url
	 * @return
	 * @author guo.tc
	 * @date 2014-6-12 下午1:21:13
	 */
	public String getAddDeviceUrl(){
		String url = "";
		url = AplusUtil.getCSSURL() + CSS_ADDDEVICE_URI ;
		return url;
	}
	
	public String getDeviceUrl(){
		String url = "";
		url = AplusUtil.getCSSURL() + CSS_SEARCHDEVICE_URI ;
		return url;
	}
}

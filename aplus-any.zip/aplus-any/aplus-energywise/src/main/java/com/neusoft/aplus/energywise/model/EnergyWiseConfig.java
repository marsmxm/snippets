package com.neusoft.aplus.energywise.model;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author guo.tc
 * @date 2014-6-30 上午11:52:33
 */
public class EnergyWiseConfig {

	private static String ip ;
	private static int port;
	private static String protocol;
	private static String username;
	private static String password;
	
	public static String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		EnergyWiseConfig.protocol = protocol;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		EnergyWiseConfig.ip = ip;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		EnergyWiseConfig.port = port;
	}
	public static String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		EnergyWiseConfig.username = username;
	}
	public static String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		EnergyWiseConfig.password = password;
	}
	public static String getEnergywiseUrl(){
		String URL = "";
		String file = "";
		try {
			URL = new URL(protocol, ip, port, file).toString();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return URL;
	}
	
}

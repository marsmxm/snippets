package com.neusoft.aplus.energywise.model;
/**
 * ReferenceTime的值
 * @author guo.tc
 * @date 2014-6-9 下午1:47:27
 */
public class ReferenceTime {
	String power = "";
	String cost = "";
	String co2 = "";
	public String getPower() {
		return power;
	}
	public void setPower(String power) {
		this.power = power;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	public String getCo2() {
		return co2;
	}
	public void setCo2(String co2) {
		this.co2 = co2;
	}
	
	
}

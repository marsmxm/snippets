package com.neusoft.aplus.energywise.biz;

import org.json.JSONObject;

import com.neusoft.aplus.energywise.model.Device;

/**
 * @author wanw
 * @date 2014-7-1 上午10:41:30
 */
public interface EnergyWiseBizInterface {
	
	public String[] getDevices();
	
	public JSONObject getDeviceEnergyConsumption(String dtype,String uri);
	
	public  JSONObject getDeviceModelAnalysis();
	
	public boolean addDevice(Device device);
}

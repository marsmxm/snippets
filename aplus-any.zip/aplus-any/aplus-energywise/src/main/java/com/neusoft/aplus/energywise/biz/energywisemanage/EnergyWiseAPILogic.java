package com.neusoft.aplus.energywise.biz.energywisemanage;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.Response;
import org.restlet.data.Reference;
import org.restlet.ext.json.JsonRepresentation;

import com.neusoft.aplus.common.base.RestClient;
import com.neusoft.aplus.energywise.exception.EnergyException;
import com.neusoft.aplus.energywise.model.Device;

/**
 * Energywise数据收集处理
 * @author guo.tc
 * @date 2014-6-9 下午3:16:33
 */
public class EnergyWiseAPILogic {

	private static Logger log = Logger.getLogger(EnergyWiseAPILogic.class);
	RestClient client;
	String url = "";
	String auth = "";
	
	public EnergyWiseAPILogic(String url,String username,String pwd){
		client = new RestClient();
		this.url = url;
		this.auth = "auth=" + username +"||"+pwd;
	}

	/**
	 * 取得所有设备信息
	 * @return
	 * @author guo.tc
	 * @date 2014-6-13 上午9:38:00
	 */
	public JSONObject getDevices() {
		Reference reference = new Reference(url.concat("/central/api/1.0/scripts/js/execute?"+auth));
		StringBuffer script = new StringBuffer("var list = queryDevices();");
		script.append("var result = \"\", uri, power, totalpower = 0;")
				.append("for( var i=0; i<list.length-1;i++ ) {")
				.append("d = list[i];")
				.append("uri = dget(\"uri\", d) || \"(unknown)\";")
				.append("power = dget(\"power\", d) || 0;")
				.append("totalpower += power;")
				.append("result += \"URI:\"+uri+\", \" ;")
				.append("}")
				.append("d = list[list.length-1];")
				.append("uri = dget(\"uri\", d) || \"(unknown)\";")
				.append("result += \" URI:\"+uri;")
				.append("result;");
		JSONObject json = new JSONObject();
		try {
			json.put("script", script.toString());
		} catch (JSONException e) {
			log.error(e.getMessage(), e);
			String [] params ={script.toString()}; 
			EnergyException.throwException(EnergyException.CODE_AES_EXCEPTION_JSONFORMAT, e, params, null);
		}
		Response response = client
				.post(reference, new JsonRepresentation(json));
		if(!checkResult(response)){
			return null;
		}
		JsonRepresentation jsonRep = (JsonRepresentation)response.getEntity();
		JSONObject dataJson = null;
		try {
			dataJson =jsonRep.getJsonObject();
		} catch (JSONException e) {
			log.error(e.getMessage(), e);
			EnergyException.throwException(EnergyException.CODE_AES_EXCEPTION_GETDEVICE, e, null, null);
		}

		return dataJson;
	}
	/**
	 * 根据周期，取得所有设备的能源消耗
	 * @param dtype
	 * @return
	 * @author guo.tc
	 * @date 2014-6-13 上午9:38:20
	 */
	public JSONObject getDeviceEnergyConsumption(String dtype,String uri) {
		Reference reference = new Reference(url.concat("/reports/json/votws?" + auth + 
				"&report=votws" +
				"&comparable=false" +
				"&metric0=power" +
				"&segment0=uri%3D" + uri +
				"&dtype=" +dtype +
				"&ds=&de=" +
				"&locale=en" +
				"&tz=480"
				));
		Response response = client.get(reference);
		if(!checkResult(response)){
			return null;
		}
		JsonRepresentation jsonRep = (JsonRepresentation)response.getEntity();
		JSONObject dataJson = null;
		try {
			dataJson =jsonRep.getJsonObject();
		} catch (JSONException e) {
			log.error(e.getMessage(), e);
			EnergyException.throwException(EnergyException.CODE_AES_EXCEPTION_GETCONSUMPTION, e, null, null);
		}
		return dataJson;
		
	}
	/**
	 * 取得模式分析报告
	 * @return
	 * @author guo.tc
	 * @date 2014-6-13 上午9:38:59
	 */
	public JSONObject getDeviceModelAnalysis() {
		Reference reference = new Reference(url.concat("/reports/json/modelanalysis?" + auth +
				"&report=modelanalysis" +
				"&metric0=power" +
				//TODO mr_model应该是传入的，不能写死
				"&mr_model=IBM%2F%2Fx3690%20X5%2F%2F%5B7147I8H%5D" +
				"&locale=en&tz=480" 
				));
		Response response = client.get(reference);
		if(!checkResult(response)){
			return null;
		}
		JsonRepresentation jsonRep = (JsonRepresentation)response.getEntity();
		JSONObject dataJson = null;
		try {
			dataJson =jsonRep.getJsonObject();
		} catch (JSONException e) {
			log.error(e.getMessage(), e);
			EnergyException.throwException(EnergyException.CODE_AES_EXCEPTION_GETANALYSIS, e, null, null);
		}
		return dataJson;

	}
	/**
	 * 添加设备到Energywise
	 * @param device
	 * @return
	 * @author guo.tc
	 * @date 2014-6-13 上午9:39:16
	 */
	public boolean addDevice(Device device){
		if(null==device) return false;
		Reference reference = new Reference(url.concat("/central/api/1.0/scripts/js/execute?auth=admin||admin"));
		String deviceId = device.getFqn();
		String deviceLocation = device.getLocation();
		String deviceType = device.getEnergytype();
		String deviceUrl = device.getUrl();
		String deviceUsername = device.getUsername();
		String devicePassword = device.getPassword();
		
		StringBuffer script = new StringBuffer("addDevice(");
		script.append("{uri : \""+deviceUrl+"\",")
			  .append("type : \""+deviceType+"\",")
			  .append("location : \""+deviceLocation+"\",")
			  .append("username : \""+deviceUsername+"\",")
			  .append("password : \""+devicePassword+"\",")
			  // 追加属性对应alcome系统设备ID
			  .append("fqn : \""+deviceId+"\"")
			  .append("});");
		
		JSONObject json = new JSONObject();
		try {
			json.put("scriptLabel", "addDevice");
			json.put("script", script.toString());
		} catch (JSONException e) {
			log.error(e.getMessage(), e);
			String [] params ={script.toString()}; 
			EnergyException.throwException(EnergyException.CODE_AES_EXCEPTION_JSONFORMAT, e, params, null);
		}
		Response response = client
				.post(reference, new JsonRepresentation(json));
		return checkResult(response);
		
	}
	private boolean checkResult(Response response){
		int status = response.getStatus().getCode();
		if(status==200) return true;
		return false;
	}
}

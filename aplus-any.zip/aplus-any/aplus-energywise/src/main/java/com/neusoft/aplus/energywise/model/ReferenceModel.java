package com.neusoft.aplus.energywise.model;
/**
 * ReferenceModel的值
 * @author guo.tc
 * @date 2014-6-9 下午2:01:48
 */
public class ReferenceModel {

	String onMin = "";
	String onAvg = "";
	String onMax = "";
	String offStbHib = "";
	String name = "";
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOnMin() {
		return onMin;
	}
	public void setOnMin(String onMin) {
		this.onMin = onMin;
	}
	public String getOnAvg() {
		return onAvg;
	}
	public void setOnAvg(String onAvg) {
		this.onAvg = onAvg;
	}
	public String getOnMax() {
		return onMax;
	}
	public void setOnMax(String onMax) {
		this.onMax = onMax;
	}
	public String getOffStbHib() {
		return offStbHib;
	}
	public void setOffStbHib(String offStbHib) {
		this.offStbHib = offStbHib;
	}
	
	
}

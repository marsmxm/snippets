package com.neusoft.aplus.energywise.action;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.restlet.Response;
import org.restlet.data.Reference;
import org.restlet.representation.ObjectRepresentation;
import org.restlet.representation.Representation;
import org.restlet.resource.ResourceException;

import com.neusoft.aclome.commons.TCloudConstants;
import com.neusoft.aclome.commons.constants.VirtualResourceType;
import com.neusoft.aclome.commons.constants.VisableScope;
import com.neusoft.aclome.shared.model.HypervisorConnection;
import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.energywise.biz.EnergyWiseBizInterface;
import com.neusoft.aplus.energywise.biz.EnergyWiseImpl;
import com.neusoft.aplus.energywise.biz.energywisemanage.CSSConnection;
import com.neusoft.aplus.energywise.biz.energywisemanage.DeviceType;
import com.neusoft.aplus.energywise.exception.EnergyException;
import com.neusoft.aplus.energywise.model.Device;
import com.neusoft.aplus.energywise.model.VMwareVCenterPojo;

/**
 * 处理添加设备请求
 * @author guo.tc
 * @date 2014-6-10 上午9:15:37
 */
public class AddDeviceAction extends BaseAction{
	private static Logger log = Logger.getLogger(AddDeviceAction.class);
	
	EnergyWiseBizInterface energywiseHelper ;
	Device device;
	String userId="";
	@Override
	public void doInit() {
		energywiseHelper = new EnergyWiseImpl();
	}
	@Override
	public void acceptRepresentation(Representation entity)
			throws ResourceException {
		// 从请求中取得Url,userId,Ip
		Reference url = this.getReference();
		userId =this.getUserId();
		log.info("alcome请求 url:"+url.toString());
		// 从Aclome请求中取得添加的设备信息
		device = getDevice(entity);
		// post添加设备请求到Aclome系统
		boolean addDeviceFlg = postAddDeviceToAclome(device,userId);
	
		// 添加设备成功时
		if(addDeviceFlg){
			Thread t=new Thread(){
			    public void run(){
			    	String fqn = "";
			    	while(true){
			    		// 取得所有设备信息
						Response res = postGetDeviceToAclome(userId);
						// 取得添加的设备的fqn
						String ip = device.getUrl();
						fqn = getFqn(res,ip);
						if(!"".equals(fqn)) break;
						log.info("fqn取得失败!");
			    		try {
							Thread.sleep(10000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
			    	}
			    	log.info("添加设备的fqn : "+fqn);
					device.setFqn(fqn);
					device.setEnergytype(DeviceType.Windows.getType());
					// TODO for test
					device.setUrl("3.3.3.3");
					// 添加设备到Energywise系统
					postAddDeviceToEnergywise(device);
			   }
			};
			t.start();
		}
	}
	
	/**
	 *  从Aclome请求中取得添加的设备信息
	 * @param entity
	 * @return
	 * @author guo.tc
	 * @date 2014-6-12 下午2:23:06
	 */
	private Device getDevice(Representation entity){
		Device device = new Device();
		try{
			ObjectRepresentation<?> obj = new ObjectRepresentation<Serializable>(entity);
			HypervisorConnection hconn = (HypervisorConnection)obj.getObject();
			device.setUsername(hconn.getUser());
			device.setPassword(hconn.getPass());
			device.setUrl(hconn.getIp());
			device.setType(hconn.getType());
			
		} catch(Exception e) {	
			log.error(e.getMessage(), e);
			EnergyException.throwException(EnergyException.CODE_AES_EXCEPTION_GETDEVICE, e, null, null);
		}
		return device;
	}
	
	private void postAddDeviceToEnergywise(Device device){
		try{
			energywiseHelper.addDevice(device);
		}catch(Exception e){
			String errormsg = "Energywise系统添加设备失败.";
			log.error(errormsg);
			EnergyException.throwException(EnergyException.CODE_AES_EXCEPTION_ADDDEVICE, e, null, null);
		}
	}
	/**
	 * 发送取得设备请求到Aclome
	 * @param entity
	 * @author guo.tc
	 * @date 2014-6-11 下午1:53:53
	 */
	private Response postGetDeviceToAclome(String userId){
		Response res =null;
		try{
			CSSConnection conn = new CSSConnection();
			String url = conn.getDeviceUrl();
			List<VirtualResourceType> virtualResourceTypeList = new ArrayList<VirtualResourceType>();
			virtualResourceTypeList.add(VirtualResourceType.HOST);
			virtualResourceTypeList.add(VirtualResourceType.DATACENTER);
			virtualResourceTypeList.add(VirtualResourceType.VM);
			virtualResourceTypeList.add(VirtualResourceType.VM_TEMPLATE);
			ObjectRepresentation<Serializable> request = new ObjectRepresentation<Serializable>((Serializable) virtualResourceTypeList);
			res = conn.postToAclome(request,url,userId);
		}catch(Exception e){
			String errormsg = "Aclome系统取得设备信息失败.";
			log.error(errormsg);
			EnergyException.throwException(EnergyException.CODE_AES_EXCEPTION_GETDEVICEINFO, e, null, null);
		}
		return res;
	}
	/**
	 * 取得添加设备的fqn
	 * @param response
	 * @param addIp
	 * @return
	 * @author guo.tc
	 * @date 2014-6-12 下午2:26:09
	 */
	@SuppressWarnings("unchecked")
	private String  getFqn(Response response ,String addIp){
		if (response == null) 	return "";
		if (addIp == null) 	return "";
		String fqn = "";
		ObjectRepresentation<?> obj = (ObjectRepresentation<Serializable>) response.getEntity();
		if (obj == null) 	return "";
		try {
			List<HashMap<String, String>> list = (ArrayList<HashMap<String, String>>) obj.getObject();
			for (HashMap<String, String> map : list) {
				VMwareVCenterPojo tempVcenterPojo = new VMwareVCenterPojo();
				tempVcenterPojo.setId(map.get(TCloudConstants.HYPERVISOR_CONNECTION_ID));
				tempVcenterPojo.setName(map.get(TCloudConstants.HYPERVISOR_CONNECTION_NAME));
				tempVcenterPojo.setIp(map.get(TCloudConstants.HYPERVISOR_CONNECTION_IP));
				tempVcenterPojo.setFqn(map.get(TCloudConstants.HYPERVISOR_CONNECTION_FQN));
				String dataCenters = map.get(TCloudConstants.HYPERVISOR_CONNECTION_NUM_OF_DATACENTER);
				if (dataCenters != null) {
					tempVcenterPojo.setDataCenters((Integer.valueOf(dataCenters)).intValue());
				}
				String hosts = map.get(TCloudConstants.HYPERVISOR_CONNECTION_NUM_OF_HOST);
				if (hosts != null) {
					tempVcenterPojo.setHosts((Integer.valueOf(hosts)).intValue());
				}
				String vmTemplates = map.get(TCloudConstants.HYPERVISOR_CONNECTION_NUM_OF_TEMPLATE);
				if (vmTemplates != null) {
					tempVcenterPojo.setVmTemplates((Integer.valueOf(vmTemplates)).intValue());
				}
				String vms = map.get(TCloudConstants.HYPERVISOR_CONNECTION_NUM_OF_VM);
				if (vms != null) {
					tempVcenterPojo.setVms((Integer.valueOf(vms)).intValue());
				}
				if(addIp.equals(tempVcenterPojo.getIp())) return tempVcenterPojo.getFqn();
			}
		} catch (IOException e) {
			log.error(e.getMessage(), e);
			EnergyException.throwException(EnergyException.CODE_AES_EXCEPTION_GETFQN, e, null, null);
		}
		return fqn;
	}
	/**
	 * 发送添加设备请求到Aclome
	 * @param entity
	 * @author guo.tc
	 * @date 2014-6-11 下午1:53:53
	 */
	private boolean postAddDeviceToAclome(Device device,String userId){
		try{
			CSSConnection conn = new CSSConnection();
			String url = conn.getAddDeviceUrl();
			HypervisorConnection hconn = new HypervisorConnection();
			hconn.setUser(device.getUsername());
			hconn.setType(device.getType());
			hconn.setPass(device.getPassword());
			hconn.setIp(device.getUrl());
			hconn.setScope(VisableScope.MC);
			ObjectRepresentation<Serializable> objectRepresentationRequest;
			objectRepresentationRequest = new ObjectRepresentation<Serializable>((Serializable) hconn);
	
			Response res = conn.postToAclome(objectRepresentationRequest,url,userId);
			int code = res.getStatus().getCode();
			if(code==200) return true;
			return false;
		}catch(Exception e){
			String errormsg = "Aclome系统添加设备失败.";
			log.error(errormsg);
			EnergyException.throwException(EnergyException.CODE_AES_EXCEPTION_ADDDEVICE, new RuntimeException(errormsg), null, null);
			return false;
		}
	}
	@Override
	public Representation represent() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		
	}
}

package com.neusoft.aplus.energywise.action;

import java.io.Serializable;

import org.restlet.representation.ObjectRepresentation;
import org.restlet.representation.Representation;

import com.neusoft.aplus.common.base.BaseAction;


/**
 * 处理xxxx请求
 * 
 * @author WanWei
 * @date 2014-6-6 下午3:55:53
 */
public class TestAction extends BaseAction {
	
	@Override
	public void doInit() {
		this.getRequestAttributes().get("key");
	}
	
	@Override
	public Representation represent(){
		System.out.println("OK! match me!");
		return new ObjectRepresentation<Serializable>("OK"); 
	}

	@Override
	public void acceptRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		
	}
	
}

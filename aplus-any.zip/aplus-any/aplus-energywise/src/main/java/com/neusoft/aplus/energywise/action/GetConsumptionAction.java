package com.neusoft.aplus.energywise.action;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.ObjectRepresentation;
import org.restlet.representation.Representation;
import org.restlet.resource.ResourceException;

import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.energywise.biz.EnergyWiseBizInterface;
import com.neusoft.aplus.energywise.biz.EnergyWiseImpl;
import com.neusoft.aplus.energywise.exception.EnergyException;

/**
 * 处理能源消耗请求
 * @author guo.tc
 * @date 2014-6-10 上午11:07:41
 */
public class GetConsumptionAction extends BaseAction{
	private static Logger log = Logger.getLogger(GetConsumptionAction.class);

	EnergyWiseBizInterface energywiseHelper ;
	String dtype = "";
	String durl = "";
	@Override
	public void doInit() {
		dtype = (String)this.getRequestAttributes().get("dtype");
		durl = (String)this.getRequestAttributes().get("durl");
		energywiseHelper = new EnergyWiseImpl();
	}
	@Override
	public Representation represent() throws ResourceException {
		JSONObject Jsonresult = null;
		try{
		Jsonresult = energywiseHelper.getDeviceEnergyConsumption(dtype,durl);
		}catch(Exception e){
			String errormsg = "能源消耗信息取得失败.";
			log.error(errormsg);
			EnergyException.throwException(EnergyException.CODE_AES_EXCEPTION_GETCONSUMPTION, e, null, null);
			return new ObjectRepresentation<Serializable>(e);
		}
		return new JsonRepresentation(Jsonresult);
	}
	@Override
	public void acceptRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		
	}
}

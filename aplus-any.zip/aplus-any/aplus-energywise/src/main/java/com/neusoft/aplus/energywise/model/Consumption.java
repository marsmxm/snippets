package com.neusoft.aplus.energywise.model;
/**
 * 能源消耗报告
 * @author guo.tc
 * @date 2014-6-9 下午1:38:43
 */
public class Consumption {

	String date  = "";
	String powerValue = "";
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getPowerValue() {
		return powerValue;
	}
	public void setPowerValue(String powerValue) {
		this.powerValue = powerValue;
	}
	
	
}

package com.neusoft.aplus.energywise.launch;

import org.apache.log4j.Logger;
import org.restlet.Component;
import org.restlet.Server;
import org.restlet.data.Protocol;

import com.neusoft.aplus.common.config.RestServiceConfig;
import com.neusoft.aplus.energywise.application.PlusEnergyWiseApplication;

/**
 * A+E系统启动类
 * 
 * @author WanWei
 * @date 2014-6-6 下午4:05:10
 */
public class AplusEnergyWiseLaunch {
	
	private static Logger log = Logger.getLogger(AplusEnergyWiseLaunch.class);

	//Rest组件
	private static Component component = null;

	/**
	 * 启动系统
	 * @param args
	 */
	public static void startServer(int port, int maxConnect) throws Exception {
		try{
			component = new Component();
			Server server = component.getServers().add(Protocol.HTTP, port);
			component.getClients().add(Protocol.HTTP);
			//设置系统最大连接数，即可并发处理的请求数上限
			//TODO 通过配置文件配置
			server.getContext().getParameters().add("maxThreads", String.valueOf(maxConnect));
			//TODO 这里引入spring处理
			component.getDefaultHost().attach(new PlusEnergyWiseApplication());
			component.start();
		}catch(Exception e){
			log.error(e.getMessage(), e);
			throw new Exception("Http代理服务启动失败，请确认端口号[" + port + "]是否已经被占用");
		}
	}
	
	public static void stopServer()throws Exception {
		try{
			if(component != null){
				component.stop();
				component = null;
			}
		}catch(Exception e){
			log.error(e.getMessage(), e);
			throw new Exception("停止服务失败,请直接关闭界面!");
		}
	}
	
	/**
	 * 启动入口
	 * 
	 * @param args
	 * @author WanWei
	 * @date 2014-6-6 下午4:11:25
	 */
	public static void main(String[] args){
		try{
			//TODO 以下两个值通过配置文件获取
			int port = RestServiceConfig.port;
			int maxConn = Integer.valueOf(RestServiceConfig.maxThreads).intValue();
			AplusEnergyWiseLaunch.startServer(port, maxConn);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
}

package com.neusoft.aplus.energywise.exception;

import java.util.Map;

import com.neusoft.aplus.common.exception.AplusException;
import com.neusoft.aplus.common.exception.annotation.MessageCN;
import com.neusoft.aplus.common.exception.annotation.MessageUS;


/**
 * energywise处理异常类
 * @author guo.tc
 * @date 2014-6-24 下午2:10:48
 */
public class EnergyException extends AplusException{

	private static final long serialVersionUID = 1L;
	
	@MessageCN("JSON数据格式不正确.JSONDATA：{0}")
	@MessageUS("Invalid json data format.JSONDATA:{0}")
	public static String CODE_AES_EXCEPTION_JSONFORMAT = createExceptionCode(1);
	@MessageCN("Device信息取得失败.")
	@MessageUS("Failed to get device info.")
	public static String CODE_AES_EXCEPTION_GETDEVICE = createExceptionCode(2);
	@MessageCN("能源消耗信息取得失败.")
	@MessageUS("Failed to get EnergyConsumption info.")
	public static String CODE_AES_EXCEPTION_GETCONSUMPTION = createExceptionCode(3);
	@MessageCN("分析报告信息取得失败.")
	@MessageUS("Failed to get analysis info.")
	public static String CODE_AES_EXCEPTION_GETANALYSIS = createExceptionCode(4);
	@MessageCN("添加设备失败.")
	@MessageUS("Failed to add device.")
	public static String CODE_AES_EXCEPTION_ADDDEVICE = createExceptionCode(5);
	@MessageCN("FQN取得失败.")
	@MessageUS("Failed to get fqn.")
	public static String CODE_AES_EXCEPTION_GETFQN = createExceptionCode(6);
	@MessageCN("取得设备信息失败.")
	@MessageUS("Failed to get device info.")
	public static String CODE_AES_EXCEPTION_GETDEVICEINFO = createExceptionCode(7);

	public EnergyException(String code, Exception original, Object[] params,
			Map<String, Object> keyPoints) {
		super(code, original, params, keyPoints);
		
	}
	/**
	 * 封装异常创建及抛出
	 * @param ecode
	 * @param original
	 * @param params
	 * @param keyPoints
	 * @author guo.tc
	 * @date 2014-6-30 下午5:45:48
	 */
	public static void throwException(String ecode, Exception original, Object[] params,Map<String, Object> keyPoints){
		EnergyException exception = new EnergyException(ecode,original,params,keyPoints);
		exception.throwEx();
	}
	/**
	 * 工具方法，负责生成异常码
	 * 
	 * @param code
	 * @return String
	 * @author WanWei
	 * @date 2014-6-26 下午8:10:07
	 */
	private static String createExceptionCode(int code){
		return getFormatedNumber(ID_AE_SERVER, code);
	}
}

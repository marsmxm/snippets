package com.neusoft.aplus.energywise.action;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.restlet.ext.json.JsonRepresentation;
import org.restlet.representation.ObjectRepresentation;
import org.restlet.representation.Representation;
import org.restlet.resource.ResourceException;

import com.neusoft.aplus.common.base.BaseAction;
import com.neusoft.aplus.energywise.biz.EnergyWiseBizInterface;
import com.neusoft.aplus.energywise.biz.EnergyWiseImpl;
import com.neusoft.aplus.energywise.exception.EnergyException;

/**
 * 处理模式分析报告请求
 * @author guo.tc
 * @date 2014-6-10 上午11:14:39
 */
public class GetModelAnalysisAction extends BaseAction{
	private static Logger log = Logger.getLogger(GetModelAnalysisAction.class);

	EnergyWiseBizInterface energywiseHelper ;
	@Override
	public void doInit() {
		energywiseHelper = new EnergyWiseImpl();
	}
	@Override
	public Representation represent() throws ResourceException {
		JSONObject Jsonresult = null;
		try{
			Jsonresult = energywiseHelper.getDeviceModelAnalysis();
		}catch(Exception e){
			String errormsg = "分析报告信息取得失败.";
			log.error(errormsg);
			EnergyException.throwException(EnergyException.CODE_AES_EXCEPTION_GETANALYSIS, e, null, null);
			return new ObjectRepresentation<Serializable>(e);
		}
		return new JsonRepresentation(Jsonresult);
	}
	@Override
	public void acceptRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void removeRepresentations() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void storeRepresentation(Representation entity) {
		// TODO Auto-generated method stub
		
	}
}

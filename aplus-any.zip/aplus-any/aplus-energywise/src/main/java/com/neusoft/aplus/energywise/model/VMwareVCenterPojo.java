package com.neusoft.aplus.energywise.model;

import java.io.Serializable;

import com.neusoft.aclome.commons.constants.VPlatformType;
import com.neusoft.aclome.commons.constants.VirtualResourceType;

/**
 * VMware中的VCenter，前台模型
 * 
 * @author guo.tc
 * @date 2014-6-9 下午1:38:43
 */
public class VMwareVCenterPojo implements Serializable {

	private static final long serialVersionUID = -3985482296787780580L;

	private VPlatformType virtualPlatformType;

	private VirtualResourceType virtualResourceType;

	private String id;

	private String name;

	private String fqn;

	private String ip;

	private int dataCenters;

	private int hosts;

	private int vms;

	private int vmTemplates;

	private int vmAndTemplates;

	public VPlatformType getVirtualPlatformType() {
		if (virtualPlatformType == null) {
			virtualPlatformType = VPlatformType.VMWARE;
		}
		return virtualPlatformType;
	}

	public void setVirtualPlatformType(VPlatformType virtualPlatformType) {
		this.virtualPlatformType = virtualPlatformType;
	}

	public VirtualResourceType getVirtualResourceType() {
		if (virtualResourceType == null) {
			virtualResourceType = VirtualResourceType.VCENTER;
		}
		return virtualResourceType;
	}

	public void setVirtualResourceType(VirtualResourceType virtualResourceType) {
		this.virtualResourceType = virtualResourceType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFqn() {
		return fqn;
	}

	public void setFqn(String fqn) {
		this.fqn = fqn;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public int getDataCenters() {
		return dataCenters;
	}

	public void setDataCenters(int dataCenters) {
		this.dataCenters = dataCenters;
	}

	public int getHosts() {
		return hosts;
	}

	public void setHosts(int hosts) {
		this.hosts = hosts;
	}

	public int getVms() {
		return vms;
	}

	public void setVms(int vms) {
		this.vms = vms;
	}

	public int getVmTemplates() {
		return vmTemplates;
	}

	public void setVmTemplates(int vmTemplates) {
		this.vmTemplates = vmTemplates;
	}

	public int getVmAndTemplates() {
		vmAndTemplates = vms + vmTemplates;
		return vmAndTemplates;
	}

	public void setVmAndTemplates(int vmAndTemplates) {
		this.vmAndTemplates = vmAndTemplates;
	}

}

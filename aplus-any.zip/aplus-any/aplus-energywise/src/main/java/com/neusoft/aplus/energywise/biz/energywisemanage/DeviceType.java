package com.neusoft.aplus.energywise.biz.energywisemanage;
/**
 * @author guo.tc
 * @date 2014-6-10 上午9:32:09
 */
public enum DeviceType {
	Windows("pc.windows"), 
	Vmware("vmware.host");
	private final String type;
	private DeviceType(String type) {
		this.type = type;
	}
	public String getType() {
		return type;
	}
}

package com.neusoft.aplus.energywise.biz;

import org.json.JSONException;
import org.json.JSONObject;

import com.neusoft.aplus.energywise.biz.energywisemanage.EnergyWiseAPILogic;
import com.neusoft.aplus.energywise.model.Device;
import com.neusoft.aplus.energywise.model.EnergyWiseConfig;

/**
 * @author wanw
 * @date 2014-7-1 上午10:41:52
 */
public class EnergyWiseImpl implements EnergyWiseBizInterface{
	EnergyWiseAPILogic logic;
	
	public EnergyWiseImpl(){
		String url = EnergyWiseConfig.getEnergywiseUrl();
		String username = EnergyWiseConfig.getUsername();
		String pwd = EnergyWiseConfig.getPassword();
		logic = new EnergyWiseAPILogic(url,username,pwd);
	}
	public String[] getDevices() {
		JSONObject dataJson = logic.getDevices(); 
		String[] urls;
		urls = getDevices(dataJson);
		return urls;
	}
	public JSONObject getDeviceEnergyConsumption(String dtype,String uri) {
		JSONObject dataJson = logic.getDeviceEnergyConsumption(dtype,uri); 
		return dataJson;
	}
	public JSONObject getDeviceModelAnalysis() {
		JSONObject dataJson = logic.getDeviceModelAnalysis(); 
		return dataJson;
	}
	public boolean addDevice(Device device) {
		return logic.addDevice(device);
	}
	/**
	 *  取得设备列表
	 * @param dataJson
	 * @return
	 * @throws JSONException
	 * @author guo.tc
	 * @date 2014-6-9 下午3:50:54
	 */
	public String[] getDevices(JSONObject  dataJson) {
		if(null==dataJson) return null;
		JSONObject result;
		String value = "";
		result = getJsonObj(dataJson,"result");
		value = getJsonString(result,"value");
		String[] urls = value.split(",");
		return urls;
	}
	public JSONObject getJsonObj(JSONObject  dataJson,String key) {
		JSONObject data = null;
		try {
			data = dataJson.getJSONObject(key);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return data;
	}
	public String getJsonString(JSONObject  dataJson,String key){
		String data = "";;
		try {
			data = dataJson.getString(key);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return data;
	}
}

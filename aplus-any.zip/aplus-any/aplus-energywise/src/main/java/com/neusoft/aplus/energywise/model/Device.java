package com.neusoft.aplus.energywise.model;

import com.neusoft.aclome.commons.constants.HypervisorConnectionType;

/**
 * Energywise的设备
 * @author guo.tc
 * @date 2014-6-12 下午1:58:15
 */
public class Device {

	String url = "";
	String username = "";
	String password = "";
	String location = "dalian";
	String fqn = "";
	HypervisorConnectionType type ;
	String energytype = "";
	
	
	public String getEnergytype() {
		return energytype;
	}
	public void setEnergytype(String energytype) {
		this.energytype = energytype;
	}

	public HypervisorConnectionType getType() {
		return type;
	}
	public void setType(HypervisorConnectionType type) {
		this.type = type;
	}
	public String getFqn() {
		return fqn;
	}
	public void setFqn(String fqn) {
		this.fqn = fqn;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
